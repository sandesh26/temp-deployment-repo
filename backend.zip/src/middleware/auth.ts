import type { NextApiRequest, NextApiResponse } from 'next';

export function withAuth(handler: any, allowedRoles: string[] = []) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    // Example: get user from session or token
    const user = (req as any).user;
    const session = (req as any).session;

    if (!user || (allowedRoles.length && !allowedRoles.includes(user.role))) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    return handler(req, res);
  };
}