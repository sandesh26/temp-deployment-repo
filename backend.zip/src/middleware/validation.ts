import type { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod';

// Example employee schema using zod
export const employeeSchema = z.object({
  full_name: z.string(),
  email: z.string().email(),
  phone: z.string(),
  role: z.string(),
  govt_id_number: z.string(),
  govt_id_type: z.string(),
  password: z.string(),
  username: z.string(),
  access_level: z.number(),
});

export function validateRequest(schema: any) {
  return (req: NextApiRequest, res: NextApiResponse, next: () => void) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
        if (error instanceof Error) {
            // Now you can safely access error.message, error.stack, etc.
            res.status(500).json({ error: error.message });
        } else {
            // Fallback for non-Error objects
            res.status(500).json({ error: 'An unknown error occurred' });
        }
    }
  };
}

// Simple in-memory rate limiter (for demonstration)
export function createRateLimiter() {
  let lastRequest = 0;
  return (req: NextApiRequest, res: NextApiResponse, next: () => void) => {
    const now = Date.now();
    if (now - lastRequest < 1000) {
      // Call next with an Error so callers using a callback/promise can react
      // instead of the middleware directly sending a response and leaving
      // callers waiting for the callback to run.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return (next as any)(new Error('Too many requests'));
    }
    lastRequest = now;
    next();
  };
}