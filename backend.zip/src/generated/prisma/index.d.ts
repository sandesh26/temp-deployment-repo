
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Employee
 * 
 */
export type Employee = $Result.DefaultSelection<Prisma.$EmployeePayload>
/**
 * Model PlayerCard
 * 
 */
export type PlayerCard = $Result.DefaultSelection<Prisma.$PlayerCardPayload>
/**
 * Model SlotMachine
 * 
 */
export type SlotMachine = $Result.DefaultSelection<Prisma.$SlotMachinePayload>
/**
 * Model TITO
 * 
 */
export type TITO = $Result.DefaultSelection<Prisma.$TITOPayload>
/**
 * Model Transaction
 * 
 */
export type Transaction = $Result.DefaultSelection<Prisma.$TransactionPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  Player: 'Player',
  Counter_Operator: 'Counter_Operator',
  Cage_Manager: 'Cage_Manager',
  Cage_Supervisor: 'Cage_Supervisor',
  Receptionist: 'Receptionist',
  Admin: 'Admin',
  SuperAdmin: 'SuperAdmin',
  Technical: 'Technical'
};

export type Role = (typeof Role)[keyof typeof Role]


export const GovtID: {
  Aadhar: 'Aadhar',
  PAN: 'PAN',
  Passport: 'Passport',
  Driving_License: 'Driving_License'
};

export type GovtID = (typeof GovtID)[keyof typeof GovtID]


export const Status: {
  Active: 'Active',
  Inactive: 'Inactive',
  Banned: 'Banned'
};

export type Status = (typeof Status)[keyof typeof Status]


export const Tier: {
  VIP: 'VIP',
  VVIP: 'VVIP',
  Premium: 'Premium',
  Gold: 'Gold',
  Silver: 'Silver'
};

export type Tier = (typeof Tier)[keyof typeof Tier]


export const MachineStatus: {
  Active: 'Active',
  Inactive: 'Inactive',
  Under_Maintenance: 'Under_Maintenance'
};

export type MachineStatus = (typeof MachineStatus)[keyof typeof MachineStatus]


export const TITOStatus: {
  Generated: 'Generated',
  Redeemed: 'Redeemed',
  Expired: 'Expired'
};

export type TITOStatus = (typeof TITOStatus)[keyof typeof TITOStatus]


export const TransactionType: {
  Credit: 'Credit',
  Debit: 'Debit',
  Encash: 'Encash',
  Balance_Inquiry: 'Balance_Inquiry'
};

export type TransactionType = (typeof TransactionType)[keyof typeof TransactionType]


export const PaymentMethod: {
  Cash: 'Cash',
  Chips: 'Chips',
  UPI: 'UPI',
  Credit_Debit_Card: 'Credit_Debit_Card',
  TITO: 'TITO'
};

export type PaymentMethod = (typeof PaymentMethod)[keyof typeof PaymentMethod]


export const TransactionStatus: {
  Pending: 'Pending',
  Completed: 'Completed',
  Failed: 'Failed'
};

export type TransactionStatus = (typeof TransactionStatus)[keyof typeof TransactionStatus]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

export type GovtID = $Enums.GovtID

export const GovtID: typeof $Enums.GovtID

export type Status = $Enums.Status

export const Status: typeof $Enums.Status

export type Tier = $Enums.Tier

export const Tier: typeof $Enums.Tier

export type MachineStatus = $Enums.MachineStatus

export const MachineStatus: typeof $Enums.MachineStatus

export type TITOStatus = $Enums.TITOStatus

export const TITOStatus: typeof $Enums.TITOStatus

export type TransactionType = $Enums.TransactionType

export const TransactionType: typeof $Enums.TransactionType

export type PaymentMethod = $Enums.PaymentMethod

export const PaymentMethod: typeof $Enums.PaymentMethod

export type TransactionStatus = $Enums.TransactionStatus

export const TransactionStatus: typeof $Enums.TransactionStatus

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.employee`: Exposes CRUD operations for the **Employee** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Employees
    * const employees = await prisma.employee.findMany()
    * ```
    */
  get employee(): Prisma.EmployeeDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.playerCard`: Exposes CRUD operations for the **PlayerCard** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PlayerCards
    * const playerCards = await prisma.playerCard.findMany()
    * ```
    */
  get playerCard(): Prisma.PlayerCardDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.slotMachine`: Exposes CRUD operations for the **SlotMachine** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SlotMachines
    * const slotMachines = await prisma.slotMachine.findMany()
    * ```
    */
  get slotMachine(): Prisma.SlotMachineDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.tITO`: Exposes CRUD operations for the **TITO** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TITOS
    * const tITOS = await prisma.tITO.findMany()
    * ```
    */
  get tITO(): Prisma.TITODelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.transaction`: Exposes CRUD operations for the **Transaction** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Transactions
    * const transactions = await prisma.transaction.findMany()
    * ```
    */
  get transaction(): Prisma.TransactionDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.6.0
   * Query Engine version: f676762280b54cd07c770017ed3711ddde35f37a
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Employee: 'Employee',
    PlayerCard: 'PlayerCard',
    SlotMachine: 'SlotMachine',
    TITO: 'TITO',
    Transaction: 'Transaction'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "employee" | "playerCard" | "slotMachine" | "tITO" | "transaction"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Employee: {
        payload: Prisma.$EmployeePayload<ExtArgs>
        fields: Prisma.EmployeeFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EmployeeFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EmployeeFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          findFirst: {
            args: Prisma.EmployeeFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EmployeeFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          findMany: {
            args: Prisma.EmployeeFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>[]
          }
          create: {
            args: Prisma.EmployeeCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          createMany: {
            args: Prisma.EmployeeCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.EmployeeDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          update: {
            args: Prisma.EmployeeUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          deleteMany: {
            args: Prisma.EmployeeDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EmployeeUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.EmployeeUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmployeePayload>
          }
          aggregate: {
            args: Prisma.EmployeeAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEmployee>
          }
          groupBy: {
            args: Prisma.EmployeeGroupByArgs<ExtArgs>
            result: $Utils.Optional<EmployeeGroupByOutputType>[]
          }
          count: {
            args: Prisma.EmployeeCountArgs<ExtArgs>
            result: $Utils.Optional<EmployeeCountAggregateOutputType> | number
          }
        }
      }
      PlayerCard: {
        payload: Prisma.$PlayerCardPayload<ExtArgs>
        fields: Prisma.PlayerCardFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PlayerCardFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PlayerCardFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          findFirst: {
            args: Prisma.PlayerCardFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PlayerCardFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          findMany: {
            args: Prisma.PlayerCardFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>[]
          }
          create: {
            args: Prisma.PlayerCardCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          createMany: {
            args: Prisma.PlayerCardCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PlayerCardDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          update: {
            args: Prisma.PlayerCardUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          deleteMany: {
            args: Prisma.PlayerCardDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PlayerCardUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PlayerCardUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PlayerCardPayload>
          }
          aggregate: {
            args: Prisma.PlayerCardAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePlayerCard>
          }
          groupBy: {
            args: Prisma.PlayerCardGroupByArgs<ExtArgs>
            result: $Utils.Optional<PlayerCardGroupByOutputType>[]
          }
          count: {
            args: Prisma.PlayerCardCountArgs<ExtArgs>
            result: $Utils.Optional<PlayerCardCountAggregateOutputType> | number
          }
        }
      }
      SlotMachine: {
        payload: Prisma.$SlotMachinePayload<ExtArgs>
        fields: Prisma.SlotMachineFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SlotMachineFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SlotMachineFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          findFirst: {
            args: Prisma.SlotMachineFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SlotMachineFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          findMany: {
            args: Prisma.SlotMachineFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>[]
          }
          create: {
            args: Prisma.SlotMachineCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          createMany: {
            args: Prisma.SlotMachineCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SlotMachineDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          update: {
            args: Prisma.SlotMachineUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          deleteMany: {
            args: Prisma.SlotMachineDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SlotMachineUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SlotMachineUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SlotMachinePayload>
          }
          aggregate: {
            args: Prisma.SlotMachineAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSlotMachine>
          }
          groupBy: {
            args: Prisma.SlotMachineGroupByArgs<ExtArgs>
            result: $Utils.Optional<SlotMachineGroupByOutputType>[]
          }
          count: {
            args: Prisma.SlotMachineCountArgs<ExtArgs>
            result: $Utils.Optional<SlotMachineCountAggregateOutputType> | number
          }
        }
      }
      TITO: {
        payload: Prisma.$TITOPayload<ExtArgs>
        fields: Prisma.TITOFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TITOFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TITOFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          findFirst: {
            args: Prisma.TITOFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TITOFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          findMany: {
            args: Prisma.TITOFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>[]
          }
          create: {
            args: Prisma.TITOCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          createMany: {
            args: Prisma.TITOCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TITODeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          update: {
            args: Prisma.TITOUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          deleteMany: {
            args: Prisma.TITODeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TITOUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TITOUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TITOPayload>
          }
          aggregate: {
            args: Prisma.TITOAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTITO>
          }
          groupBy: {
            args: Prisma.TITOGroupByArgs<ExtArgs>
            result: $Utils.Optional<TITOGroupByOutputType>[]
          }
          count: {
            args: Prisma.TITOCountArgs<ExtArgs>
            result: $Utils.Optional<TITOCountAggregateOutputType> | number
          }
        }
      }
      Transaction: {
        payload: Prisma.$TransactionPayload<ExtArgs>
        fields: Prisma.TransactionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TransactionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TransactionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          findFirst: {
            args: Prisma.TransactionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TransactionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          findMany: {
            args: Prisma.TransactionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>[]
          }
          create: {
            args: Prisma.TransactionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          createMany: {
            args: Prisma.TransactionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TransactionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          update: {
            args: Prisma.TransactionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          deleteMany: {
            args: Prisma.TransactionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TransactionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TransactionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TransactionPayload>
          }
          aggregate: {
            args: Prisma.TransactionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTransaction>
          }
          groupBy: {
            args: Prisma.TransactionGroupByArgs<ExtArgs>
            result: $Utils.Optional<TransactionGroupByOutputType>[]
          }
          count: {
            args: Prisma.TransactionCountArgs<ExtArgs>
            result: $Utils.Optional<TransactionCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    employee?: EmployeeOmit
    playerCard?: PlayerCardOmit
    slotMachine?: SlotMachineOmit
    tITO?: TITOOmit
    transaction?: TransactionOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    current_machines: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    current_machines?: boolean | UserCountOutputTypeCountCurrent_machinesArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCurrent_machinesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SlotMachineWhereInput
  }


  /**
   * Count Type PlayerCardCountOutputType
   */

  export type PlayerCardCountOutputType = {
    transactions: number
  }

  export type PlayerCardCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    transactions?: boolean | PlayerCardCountOutputTypeCountTransactionsArgs
  }

  // Custom InputTypes
  /**
   * PlayerCardCountOutputType without action
   */
  export type PlayerCardCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCardCountOutputType
     */
    select?: PlayerCardCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PlayerCardCountOutputType without action
   */
  export type PlayerCardCountOutputTypeCountTransactionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserAvgAggregateOutputType = {
    user_id: number | null
  }

  export type UserSumAggregateOutputType = {
    user_id: number | null
  }

  export type UserMinAggregateOutputType = {
    user_id: number | null
    full_name: string | null
    address: string | null
    date_of_birth: Date | null
    govt_id_number: string | null
    govt_id_type: $Enums.GovtID | null
    photo_url: string | null
    email: string | null
    phone: string | null
    role: $Enums.Role | null
    status: $Enums.Status | null
    created_at: Date | null
  }

  export type UserMaxAggregateOutputType = {
    user_id: number | null
    full_name: string | null
    address: string | null
    date_of_birth: Date | null
    govt_id_number: string | null
    govt_id_type: $Enums.GovtID | null
    photo_url: string | null
    email: string | null
    phone: string | null
    role: $Enums.Role | null
    status: $Enums.Status | null
    created_at: Date | null
  }

  export type UserCountAggregateOutputType = {
    user_id: number
    full_name: number
    address: number
    date_of_birth: number
    govt_id_number: number
    govt_id_type: number
    photo_url: number
    email: number
    phone: number
    role: number
    status: number
    created_at: number
    _all: number
  }


  export type UserAvgAggregateInputType = {
    user_id?: true
  }

  export type UserSumAggregateInputType = {
    user_id?: true
  }

  export type UserMinAggregateInputType = {
    user_id?: true
    full_name?: true
    address?: true
    date_of_birth?: true
    govt_id_number?: true
    govt_id_type?: true
    photo_url?: true
    email?: true
    phone?: true
    role?: true
    status?: true
    created_at?: true
  }

  export type UserMaxAggregateInputType = {
    user_id?: true
    full_name?: true
    address?: true
    date_of_birth?: true
    govt_id_number?: true
    govt_id_type?: true
    photo_url?: true
    email?: true
    phone?: true
    role?: true
    status?: true
    created_at?: true
  }

  export type UserCountAggregateInputType = {
    user_id?: true
    full_name?: true
    address?: true
    date_of_birth?: true
    govt_id_number?: true
    govt_id_type?: true
    photo_url?: true
    email?: true
    phone?: true
    role?: true
    status?: true
    created_at?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UserAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UserSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _avg?: UserAvgAggregateInputType
    _sum?: UserSumAggregateInputType
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    user_id: number
    full_name: string
    address: string | null
    date_of_birth: Date | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url: string | null
    email: string | null
    phone: string
    role: $Enums.Role
    status: $Enums.Status
    created_at: Date
    _count: UserCountAggregateOutputType | null
    _avg: UserAvgAggregateOutputType | null
    _sum: UserSumAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    user_id?: boolean
    full_name?: boolean
    address?: boolean
    date_of_birth?: boolean
    govt_id_number?: boolean
    govt_id_type?: boolean
    photo_url?: boolean
    email?: boolean
    phone?: boolean
    role?: boolean
    status?: boolean
    created_at?: boolean
    employee?: boolean | User$employeeArgs<ExtArgs>
    playerCard?: boolean | User$playerCardArgs<ExtArgs>
    current_machines?: boolean | User$current_machinesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>



  export type UserSelectScalar = {
    user_id?: boolean
    full_name?: boolean
    address?: boolean
    date_of_birth?: boolean
    govt_id_number?: boolean
    govt_id_type?: boolean
    photo_url?: boolean
    email?: boolean
    phone?: boolean
    role?: boolean
    status?: boolean
    created_at?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"user_id" | "full_name" | "address" | "date_of_birth" | "govt_id_number" | "govt_id_type" | "photo_url" | "email" | "phone" | "role" | "status" | "created_at", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    employee?: boolean | User$employeeArgs<ExtArgs>
    playerCard?: boolean | User$playerCardArgs<ExtArgs>
    current_machines?: boolean | User$current_machinesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      employee: Prisma.$EmployeePayload<ExtArgs> | null
      playerCard: Prisma.$PlayerCardPayload<ExtArgs> | null
      current_machines: Prisma.$SlotMachinePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      user_id: number
      full_name: string
      address: string | null
      date_of_birth: Date | null
      govt_id_number: string
      govt_id_type: $Enums.GovtID
      photo_url: string | null
      email: string | null
      phone: string
      role: $Enums.Role
      status: $Enums.Status
      created_at: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `user_id`
     * const userWithUser_idOnly = await prisma.user.findMany({ select: { user_id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    employee<T extends User$employeeArgs<ExtArgs> = {}>(args?: Subset<T, User$employeeArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    playerCard<T extends User$playerCardArgs<ExtArgs> = {}>(args?: Subset<T, User$playerCardArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    current_machines<T extends User$current_machinesArgs<ExtArgs> = {}>(args?: Subset<T, User$current_machinesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly user_id: FieldRef<"User", 'Int'>
    readonly full_name: FieldRef<"User", 'String'>
    readonly address: FieldRef<"User", 'String'>
    readonly date_of_birth: FieldRef<"User", 'DateTime'>
    readonly govt_id_number: FieldRef<"User", 'String'>
    readonly govt_id_type: FieldRef<"User", 'GovtID'>
    readonly photo_url: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly phone: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
    readonly status: FieldRef<"User", 'Status'>
    readonly created_at: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.employee
   */
  export type User$employeeArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    where?: EmployeeWhereInput
  }

  /**
   * User.playerCard
   */
  export type User$playerCardArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    where?: PlayerCardWhereInput
  }

  /**
   * User.current_machines
   */
  export type User$current_machinesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    where?: SlotMachineWhereInput
    orderBy?: SlotMachineOrderByWithRelationInput | SlotMachineOrderByWithRelationInput[]
    cursor?: SlotMachineWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SlotMachineScalarFieldEnum | SlotMachineScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Employee
   */

  export type AggregateEmployee = {
    _count: EmployeeCountAggregateOutputType | null
    _avg: EmployeeAvgAggregateOutputType | null
    _sum: EmployeeSumAggregateOutputType | null
    _min: EmployeeMinAggregateOutputType | null
    _max: EmployeeMaxAggregateOutputType | null
  }

  export type EmployeeAvgAggregateOutputType = {
    employee_id: number | null
    user_id: number | null
    access_level: number | null
  }

  export type EmployeeSumAggregateOutputType = {
    employee_id: number | null
    user_id: number | null
    access_level: number | null
  }

  export type EmployeeMinAggregateOutputType = {
    employee_id: number | null
    user_id: number | null
    username: string | null
    password_hash: string | null
    access_level: number | null
    role: $Enums.Role | null
  }

  export type EmployeeMaxAggregateOutputType = {
    employee_id: number | null
    user_id: number | null
    username: string | null
    password_hash: string | null
    access_level: number | null
    role: $Enums.Role | null
  }

  export type EmployeeCountAggregateOutputType = {
    employee_id: number
    user_id: number
    username: number
    password_hash: number
    access_level: number
    role: number
    _all: number
  }


  export type EmployeeAvgAggregateInputType = {
    employee_id?: true
    user_id?: true
    access_level?: true
  }

  export type EmployeeSumAggregateInputType = {
    employee_id?: true
    user_id?: true
    access_level?: true
  }

  export type EmployeeMinAggregateInputType = {
    employee_id?: true
    user_id?: true
    username?: true
    password_hash?: true
    access_level?: true
    role?: true
  }

  export type EmployeeMaxAggregateInputType = {
    employee_id?: true
    user_id?: true
    username?: true
    password_hash?: true
    access_level?: true
    role?: true
  }

  export type EmployeeCountAggregateInputType = {
    employee_id?: true
    user_id?: true
    username?: true
    password_hash?: true
    access_level?: true
    role?: true
    _all?: true
  }

  export type EmployeeAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Employee to aggregate.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Employees
    **/
    _count?: true | EmployeeCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EmployeeAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EmployeeSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EmployeeMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EmployeeMaxAggregateInputType
  }

  export type GetEmployeeAggregateType<T extends EmployeeAggregateArgs> = {
        [P in keyof T & keyof AggregateEmployee]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEmployee[P]>
      : GetScalarType<T[P], AggregateEmployee[P]>
  }




  export type EmployeeGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EmployeeWhereInput
    orderBy?: EmployeeOrderByWithAggregationInput | EmployeeOrderByWithAggregationInput[]
    by: EmployeeScalarFieldEnum[] | EmployeeScalarFieldEnum
    having?: EmployeeScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EmployeeCountAggregateInputType | true
    _avg?: EmployeeAvgAggregateInputType
    _sum?: EmployeeSumAggregateInputType
    _min?: EmployeeMinAggregateInputType
    _max?: EmployeeMaxAggregateInputType
  }

  export type EmployeeGroupByOutputType = {
    employee_id: number
    user_id: number
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
    _count: EmployeeCountAggregateOutputType | null
    _avg: EmployeeAvgAggregateOutputType | null
    _sum: EmployeeSumAggregateOutputType | null
    _min: EmployeeMinAggregateOutputType | null
    _max: EmployeeMaxAggregateOutputType | null
  }

  type GetEmployeeGroupByPayload<T extends EmployeeGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EmployeeGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EmployeeGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EmployeeGroupByOutputType[P]>
            : GetScalarType<T[P], EmployeeGroupByOutputType[P]>
        }
      >
    >


  export type EmployeeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    employee_id?: boolean
    user_id?: boolean
    username?: boolean
    password_hash?: boolean
    access_level?: boolean
    role?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["employee"]>



  export type EmployeeSelectScalar = {
    employee_id?: boolean
    user_id?: boolean
    username?: boolean
    password_hash?: boolean
    access_level?: boolean
    role?: boolean
  }

  export type EmployeeOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"employee_id" | "user_id" | "username" | "password_hash" | "access_level" | "role", ExtArgs["result"]["employee"]>
  export type EmployeeInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $EmployeePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Employee"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      employee_id: number
      user_id: number
      username: string
      password_hash: string
      access_level: number
      role: $Enums.Role
    }, ExtArgs["result"]["employee"]>
    composites: {}
  }

  type EmployeeGetPayload<S extends boolean | null | undefined | EmployeeDefaultArgs> = $Result.GetResult<Prisma.$EmployeePayload, S>

  type EmployeeCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EmployeeFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EmployeeCountAggregateInputType | true
    }

  export interface EmployeeDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Employee'], meta: { name: 'Employee' } }
    /**
     * Find zero or one Employee that matches the filter.
     * @param {EmployeeFindUniqueArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EmployeeFindUniqueArgs>(args: SelectSubset<T, EmployeeFindUniqueArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Employee that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EmployeeFindUniqueOrThrowArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EmployeeFindUniqueOrThrowArgs>(args: SelectSubset<T, EmployeeFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Employee that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindFirstArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EmployeeFindFirstArgs>(args?: SelectSubset<T, EmployeeFindFirstArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Employee that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindFirstOrThrowArgs} args - Arguments to find a Employee
     * @example
     * // Get one Employee
     * const employee = await prisma.employee.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EmployeeFindFirstOrThrowArgs>(args?: SelectSubset<T, EmployeeFindFirstOrThrowArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Employees that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Employees
     * const employees = await prisma.employee.findMany()
     * 
     * // Get first 10 Employees
     * const employees = await prisma.employee.findMany({ take: 10 })
     * 
     * // Only select the `employee_id`
     * const employeeWithEmployee_idOnly = await prisma.employee.findMany({ select: { employee_id: true } })
     * 
     */
    findMany<T extends EmployeeFindManyArgs>(args?: SelectSubset<T, EmployeeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Employee.
     * @param {EmployeeCreateArgs} args - Arguments to create a Employee.
     * @example
     * // Create one Employee
     * const Employee = await prisma.employee.create({
     *   data: {
     *     // ... data to create a Employee
     *   }
     * })
     * 
     */
    create<T extends EmployeeCreateArgs>(args: SelectSubset<T, EmployeeCreateArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Employees.
     * @param {EmployeeCreateManyArgs} args - Arguments to create many Employees.
     * @example
     * // Create many Employees
     * const employee = await prisma.employee.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EmployeeCreateManyArgs>(args?: SelectSubset<T, EmployeeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Employee.
     * @param {EmployeeDeleteArgs} args - Arguments to delete one Employee.
     * @example
     * // Delete one Employee
     * const Employee = await prisma.employee.delete({
     *   where: {
     *     // ... filter to delete one Employee
     *   }
     * })
     * 
     */
    delete<T extends EmployeeDeleteArgs>(args: SelectSubset<T, EmployeeDeleteArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Employee.
     * @param {EmployeeUpdateArgs} args - Arguments to update one Employee.
     * @example
     * // Update one Employee
     * const employee = await prisma.employee.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EmployeeUpdateArgs>(args: SelectSubset<T, EmployeeUpdateArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Employees.
     * @param {EmployeeDeleteManyArgs} args - Arguments to filter Employees to delete.
     * @example
     * // Delete a few Employees
     * const { count } = await prisma.employee.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EmployeeDeleteManyArgs>(args?: SelectSubset<T, EmployeeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Employees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Employees
     * const employee = await prisma.employee.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EmployeeUpdateManyArgs>(args: SelectSubset<T, EmployeeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Employee.
     * @param {EmployeeUpsertArgs} args - Arguments to update or create a Employee.
     * @example
     * // Update or create a Employee
     * const employee = await prisma.employee.upsert({
     *   create: {
     *     // ... data to create a Employee
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Employee we want to update
     *   }
     * })
     */
    upsert<T extends EmployeeUpsertArgs>(args: SelectSubset<T, EmployeeUpsertArgs<ExtArgs>>): Prisma__EmployeeClient<$Result.GetResult<Prisma.$EmployeePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Employees.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeCountArgs} args - Arguments to filter Employees to count.
     * @example
     * // Count the number of Employees
     * const count = await prisma.employee.count({
     *   where: {
     *     // ... the filter for the Employees we want to count
     *   }
     * })
    **/
    count<T extends EmployeeCountArgs>(
      args?: Subset<T, EmployeeCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EmployeeCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Employee.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EmployeeAggregateArgs>(args: Subset<T, EmployeeAggregateArgs>): Prisma.PrismaPromise<GetEmployeeAggregateType<T>>

    /**
     * Group by Employee.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmployeeGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EmployeeGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EmployeeGroupByArgs['orderBy'] }
        : { orderBy?: EmployeeGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EmployeeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEmployeeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Employee model
   */
  readonly fields: EmployeeFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Employee.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EmployeeClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Employee model
   */
  interface EmployeeFieldRefs {
    readonly employee_id: FieldRef<"Employee", 'Int'>
    readonly user_id: FieldRef<"Employee", 'Int'>
    readonly username: FieldRef<"Employee", 'String'>
    readonly password_hash: FieldRef<"Employee", 'String'>
    readonly access_level: FieldRef<"Employee", 'Int'>
    readonly role: FieldRef<"Employee", 'Role'>
  }
    

  // Custom InputTypes
  /**
   * Employee findUnique
   */
  export type EmployeeFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee findUniqueOrThrow
   */
  export type EmployeeFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee findFirst
   */
  export type EmployeeFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Employees.
     */
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee findFirstOrThrow
   */
  export type EmployeeFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employee to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Employees.
     */
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee findMany
   */
  export type EmployeeFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter, which Employees to fetch.
     */
    where?: EmployeeWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Employees to fetch.
     */
    orderBy?: EmployeeOrderByWithRelationInput | EmployeeOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Employees.
     */
    cursor?: EmployeeWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Employees from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Employees.
     */
    skip?: number
    distinct?: EmployeeScalarFieldEnum | EmployeeScalarFieldEnum[]
  }

  /**
   * Employee create
   */
  export type EmployeeCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The data needed to create a Employee.
     */
    data: XOR<EmployeeCreateInput, EmployeeUncheckedCreateInput>
  }

  /**
   * Employee createMany
   */
  export type EmployeeCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Employees.
     */
    data: EmployeeCreateManyInput | EmployeeCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Employee update
   */
  export type EmployeeUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The data needed to update a Employee.
     */
    data: XOR<EmployeeUpdateInput, EmployeeUncheckedUpdateInput>
    /**
     * Choose, which Employee to update.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee updateMany
   */
  export type EmployeeUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Employees.
     */
    data: XOR<EmployeeUpdateManyMutationInput, EmployeeUncheckedUpdateManyInput>
    /**
     * Filter which Employees to update
     */
    where?: EmployeeWhereInput
    /**
     * Limit how many Employees to update.
     */
    limit?: number
  }

  /**
   * Employee upsert
   */
  export type EmployeeUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * The filter to search for the Employee to update in case it exists.
     */
    where: EmployeeWhereUniqueInput
    /**
     * In case the Employee found by the `where` argument doesn't exist, create a new Employee with this data.
     */
    create: XOR<EmployeeCreateInput, EmployeeUncheckedCreateInput>
    /**
     * In case the Employee was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EmployeeUpdateInput, EmployeeUncheckedUpdateInput>
  }

  /**
   * Employee delete
   */
  export type EmployeeDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
    /**
     * Filter which Employee to delete.
     */
    where: EmployeeWhereUniqueInput
  }

  /**
   * Employee deleteMany
   */
  export type EmployeeDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Employees to delete
     */
    where?: EmployeeWhereInput
    /**
     * Limit how many Employees to delete.
     */
    limit?: number
  }

  /**
   * Employee without action
   */
  export type EmployeeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Employee
     */
    select?: EmployeeSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Employee
     */
    omit?: EmployeeOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmployeeInclude<ExtArgs> | null
  }


  /**
   * Model PlayerCard
   */

  export type AggregatePlayerCard = {
    _count: PlayerCardCountAggregateOutputType | null
    _avg: PlayerCardAvgAggregateOutputType | null
    _sum: PlayerCardSumAggregateOutputType | null
    _min: PlayerCardMinAggregateOutputType | null
    _max: PlayerCardMaxAggregateOutputType | null
  }

  export type PlayerCardAvgAggregateOutputType = {
    card_id: number | null
    user_id: number | null
    balance: Decimal | null
    loyalty_points: number | null
  }

  export type PlayerCardSumAggregateOutputType = {
    card_id: number | null
    user_id: number | null
    balance: Decimal | null
    loyalty_points: number | null
  }

  export type PlayerCardMinAggregateOutputType = {
    card_id: number | null
    user_id: number | null
    rfid_number: string | null
    pin: string | null
    balance: Decimal | null
    loyalty_points: number | null
    tier: $Enums.Tier | null
  }

  export type PlayerCardMaxAggregateOutputType = {
    card_id: number | null
    user_id: number | null
    rfid_number: string | null
    pin: string | null
    balance: Decimal | null
    loyalty_points: number | null
    tier: $Enums.Tier | null
  }

  export type PlayerCardCountAggregateOutputType = {
    card_id: number
    user_id: number
    rfid_number: number
    pin: number
    balance: number
    loyalty_points: number
    tier: number
    _all: number
  }


  export type PlayerCardAvgAggregateInputType = {
    card_id?: true
    user_id?: true
    balance?: true
    loyalty_points?: true
  }

  export type PlayerCardSumAggregateInputType = {
    card_id?: true
    user_id?: true
    balance?: true
    loyalty_points?: true
  }

  export type PlayerCardMinAggregateInputType = {
    card_id?: true
    user_id?: true
    rfid_number?: true
    pin?: true
    balance?: true
    loyalty_points?: true
    tier?: true
  }

  export type PlayerCardMaxAggregateInputType = {
    card_id?: true
    user_id?: true
    rfid_number?: true
    pin?: true
    balance?: true
    loyalty_points?: true
    tier?: true
  }

  export type PlayerCardCountAggregateInputType = {
    card_id?: true
    user_id?: true
    rfid_number?: true
    pin?: true
    balance?: true
    loyalty_points?: true
    tier?: true
    _all?: true
  }

  export type PlayerCardAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlayerCard to aggregate.
     */
    where?: PlayerCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlayerCards to fetch.
     */
    orderBy?: PlayerCardOrderByWithRelationInput | PlayerCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PlayerCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlayerCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlayerCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PlayerCards
    **/
    _count?: true | PlayerCardCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PlayerCardAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PlayerCardSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PlayerCardMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PlayerCardMaxAggregateInputType
  }

  export type GetPlayerCardAggregateType<T extends PlayerCardAggregateArgs> = {
        [P in keyof T & keyof AggregatePlayerCard]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePlayerCard[P]>
      : GetScalarType<T[P], AggregatePlayerCard[P]>
  }




  export type PlayerCardGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PlayerCardWhereInput
    orderBy?: PlayerCardOrderByWithAggregationInput | PlayerCardOrderByWithAggregationInput[]
    by: PlayerCardScalarFieldEnum[] | PlayerCardScalarFieldEnum
    having?: PlayerCardScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PlayerCardCountAggregateInputType | true
    _avg?: PlayerCardAvgAggregateInputType
    _sum?: PlayerCardSumAggregateInputType
    _min?: PlayerCardMinAggregateInputType
    _max?: PlayerCardMaxAggregateInputType
  }

  export type PlayerCardGroupByOutputType = {
    card_id: number
    user_id: number
    rfid_number: string
    pin: string
    balance: Decimal
    loyalty_points: number
    tier: $Enums.Tier
    _count: PlayerCardCountAggregateOutputType | null
    _avg: PlayerCardAvgAggregateOutputType | null
    _sum: PlayerCardSumAggregateOutputType | null
    _min: PlayerCardMinAggregateOutputType | null
    _max: PlayerCardMaxAggregateOutputType | null
  }

  type GetPlayerCardGroupByPayload<T extends PlayerCardGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PlayerCardGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PlayerCardGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PlayerCardGroupByOutputType[P]>
            : GetScalarType<T[P], PlayerCardGroupByOutputType[P]>
        }
      >
    >


  export type PlayerCardSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    card_id?: boolean
    user_id?: boolean
    rfid_number?: boolean
    pin?: boolean
    balance?: boolean
    loyalty_points?: boolean
    tier?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    transactions?: boolean | PlayerCard$transactionsArgs<ExtArgs>
    _count?: boolean | PlayerCardCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["playerCard"]>



  export type PlayerCardSelectScalar = {
    card_id?: boolean
    user_id?: boolean
    rfid_number?: boolean
    pin?: boolean
    balance?: boolean
    loyalty_points?: boolean
    tier?: boolean
  }

  export type PlayerCardOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"card_id" | "user_id" | "rfid_number" | "pin" | "balance" | "loyalty_points" | "tier", ExtArgs["result"]["playerCard"]>
  export type PlayerCardInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    transactions?: boolean | PlayerCard$transactionsArgs<ExtArgs>
    _count?: boolean | PlayerCardCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $PlayerCardPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PlayerCard"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      transactions: Prisma.$TransactionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      card_id: number
      user_id: number
      rfid_number: string
      pin: string
      balance: Prisma.Decimal
      loyalty_points: number
      tier: $Enums.Tier
    }, ExtArgs["result"]["playerCard"]>
    composites: {}
  }

  type PlayerCardGetPayload<S extends boolean | null | undefined | PlayerCardDefaultArgs> = $Result.GetResult<Prisma.$PlayerCardPayload, S>

  type PlayerCardCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PlayerCardFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PlayerCardCountAggregateInputType | true
    }

  export interface PlayerCardDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PlayerCard'], meta: { name: 'PlayerCard' } }
    /**
     * Find zero or one PlayerCard that matches the filter.
     * @param {PlayerCardFindUniqueArgs} args - Arguments to find a PlayerCard
     * @example
     * // Get one PlayerCard
     * const playerCard = await prisma.playerCard.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PlayerCardFindUniqueArgs>(args: SelectSubset<T, PlayerCardFindUniqueArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PlayerCard that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PlayerCardFindUniqueOrThrowArgs} args - Arguments to find a PlayerCard
     * @example
     * // Get one PlayerCard
     * const playerCard = await prisma.playerCard.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PlayerCardFindUniqueOrThrowArgs>(args: SelectSubset<T, PlayerCardFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlayerCard that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardFindFirstArgs} args - Arguments to find a PlayerCard
     * @example
     * // Get one PlayerCard
     * const playerCard = await prisma.playerCard.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PlayerCardFindFirstArgs>(args?: SelectSubset<T, PlayerCardFindFirstArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PlayerCard that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardFindFirstOrThrowArgs} args - Arguments to find a PlayerCard
     * @example
     * // Get one PlayerCard
     * const playerCard = await prisma.playerCard.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PlayerCardFindFirstOrThrowArgs>(args?: SelectSubset<T, PlayerCardFindFirstOrThrowArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PlayerCards that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PlayerCards
     * const playerCards = await prisma.playerCard.findMany()
     * 
     * // Get first 10 PlayerCards
     * const playerCards = await prisma.playerCard.findMany({ take: 10 })
     * 
     * // Only select the `card_id`
     * const playerCardWithCard_idOnly = await prisma.playerCard.findMany({ select: { card_id: true } })
     * 
     */
    findMany<T extends PlayerCardFindManyArgs>(args?: SelectSubset<T, PlayerCardFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PlayerCard.
     * @param {PlayerCardCreateArgs} args - Arguments to create a PlayerCard.
     * @example
     * // Create one PlayerCard
     * const PlayerCard = await prisma.playerCard.create({
     *   data: {
     *     // ... data to create a PlayerCard
     *   }
     * })
     * 
     */
    create<T extends PlayerCardCreateArgs>(args: SelectSubset<T, PlayerCardCreateArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PlayerCards.
     * @param {PlayerCardCreateManyArgs} args - Arguments to create many PlayerCards.
     * @example
     * // Create many PlayerCards
     * const playerCard = await prisma.playerCard.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PlayerCardCreateManyArgs>(args?: SelectSubset<T, PlayerCardCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a PlayerCard.
     * @param {PlayerCardDeleteArgs} args - Arguments to delete one PlayerCard.
     * @example
     * // Delete one PlayerCard
     * const PlayerCard = await prisma.playerCard.delete({
     *   where: {
     *     // ... filter to delete one PlayerCard
     *   }
     * })
     * 
     */
    delete<T extends PlayerCardDeleteArgs>(args: SelectSubset<T, PlayerCardDeleteArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PlayerCard.
     * @param {PlayerCardUpdateArgs} args - Arguments to update one PlayerCard.
     * @example
     * // Update one PlayerCard
     * const playerCard = await prisma.playerCard.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PlayerCardUpdateArgs>(args: SelectSubset<T, PlayerCardUpdateArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PlayerCards.
     * @param {PlayerCardDeleteManyArgs} args - Arguments to filter PlayerCards to delete.
     * @example
     * // Delete a few PlayerCards
     * const { count } = await prisma.playerCard.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PlayerCardDeleteManyArgs>(args?: SelectSubset<T, PlayerCardDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PlayerCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PlayerCards
     * const playerCard = await prisma.playerCard.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PlayerCardUpdateManyArgs>(args: SelectSubset<T, PlayerCardUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one PlayerCard.
     * @param {PlayerCardUpsertArgs} args - Arguments to update or create a PlayerCard.
     * @example
     * // Update or create a PlayerCard
     * const playerCard = await prisma.playerCard.upsert({
     *   create: {
     *     // ... data to create a PlayerCard
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PlayerCard we want to update
     *   }
     * })
     */
    upsert<T extends PlayerCardUpsertArgs>(args: SelectSubset<T, PlayerCardUpsertArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PlayerCards.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardCountArgs} args - Arguments to filter PlayerCards to count.
     * @example
     * // Count the number of PlayerCards
     * const count = await prisma.playerCard.count({
     *   where: {
     *     // ... the filter for the PlayerCards we want to count
     *   }
     * })
    **/
    count<T extends PlayerCardCountArgs>(
      args?: Subset<T, PlayerCardCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PlayerCardCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PlayerCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PlayerCardAggregateArgs>(args: Subset<T, PlayerCardAggregateArgs>): Prisma.PrismaPromise<GetPlayerCardAggregateType<T>>

    /**
     * Group by PlayerCard.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PlayerCardGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PlayerCardGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PlayerCardGroupByArgs['orderBy'] }
        : { orderBy?: PlayerCardGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PlayerCardGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPlayerCardGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PlayerCard model
   */
  readonly fields: PlayerCardFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PlayerCard.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PlayerCardClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    transactions<T extends PlayerCard$transactionsArgs<ExtArgs> = {}>(args?: Subset<T, PlayerCard$transactionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PlayerCard model
   */
  interface PlayerCardFieldRefs {
    readonly card_id: FieldRef<"PlayerCard", 'Int'>
    readonly user_id: FieldRef<"PlayerCard", 'Int'>
    readonly rfid_number: FieldRef<"PlayerCard", 'String'>
    readonly pin: FieldRef<"PlayerCard", 'String'>
    readonly balance: FieldRef<"PlayerCard", 'Decimal'>
    readonly loyalty_points: FieldRef<"PlayerCard", 'Int'>
    readonly tier: FieldRef<"PlayerCard", 'Tier'>
  }
    

  // Custom InputTypes
  /**
   * PlayerCard findUnique
   */
  export type PlayerCardFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter, which PlayerCard to fetch.
     */
    where: PlayerCardWhereUniqueInput
  }

  /**
   * PlayerCard findUniqueOrThrow
   */
  export type PlayerCardFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter, which PlayerCard to fetch.
     */
    where: PlayerCardWhereUniqueInput
  }

  /**
   * PlayerCard findFirst
   */
  export type PlayerCardFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter, which PlayerCard to fetch.
     */
    where?: PlayerCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlayerCards to fetch.
     */
    orderBy?: PlayerCardOrderByWithRelationInput | PlayerCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlayerCards.
     */
    cursor?: PlayerCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlayerCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlayerCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlayerCards.
     */
    distinct?: PlayerCardScalarFieldEnum | PlayerCardScalarFieldEnum[]
  }

  /**
   * PlayerCard findFirstOrThrow
   */
  export type PlayerCardFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter, which PlayerCard to fetch.
     */
    where?: PlayerCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlayerCards to fetch.
     */
    orderBy?: PlayerCardOrderByWithRelationInput | PlayerCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PlayerCards.
     */
    cursor?: PlayerCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlayerCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlayerCards.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PlayerCards.
     */
    distinct?: PlayerCardScalarFieldEnum | PlayerCardScalarFieldEnum[]
  }

  /**
   * PlayerCard findMany
   */
  export type PlayerCardFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter, which PlayerCards to fetch.
     */
    where?: PlayerCardWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PlayerCards to fetch.
     */
    orderBy?: PlayerCardOrderByWithRelationInput | PlayerCardOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PlayerCards.
     */
    cursor?: PlayerCardWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PlayerCards from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PlayerCards.
     */
    skip?: number
    distinct?: PlayerCardScalarFieldEnum | PlayerCardScalarFieldEnum[]
  }

  /**
   * PlayerCard create
   */
  export type PlayerCardCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * The data needed to create a PlayerCard.
     */
    data: XOR<PlayerCardCreateInput, PlayerCardUncheckedCreateInput>
  }

  /**
   * PlayerCard createMany
   */
  export type PlayerCardCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PlayerCards.
     */
    data: PlayerCardCreateManyInput | PlayerCardCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PlayerCard update
   */
  export type PlayerCardUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * The data needed to update a PlayerCard.
     */
    data: XOR<PlayerCardUpdateInput, PlayerCardUncheckedUpdateInput>
    /**
     * Choose, which PlayerCard to update.
     */
    where: PlayerCardWhereUniqueInput
  }

  /**
   * PlayerCard updateMany
   */
  export type PlayerCardUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PlayerCards.
     */
    data: XOR<PlayerCardUpdateManyMutationInput, PlayerCardUncheckedUpdateManyInput>
    /**
     * Filter which PlayerCards to update
     */
    where?: PlayerCardWhereInput
    /**
     * Limit how many PlayerCards to update.
     */
    limit?: number
  }

  /**
   * PlayerCard upsert
   */
  export type PlayerCardUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * The filter to search for the PlayerCard to update in case it exists.
     */
    where: PlayerCardWhereUniqueInput
    /**
     * In case the PlayerCard found by the `where` argument doesn't exist, create a new PlayerCard with this data.
     */
    create: XOR<PlayerCardCreateInput, PlayerCardUncheckedCreateInput>
    /**
     * In case the PlayerCard was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PlayerCardUpdateInput, PlayerCardUncheckedUpdateInput>
  }

  /**
   * PlayerCard delete
   */
  export type PlayerCardDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    /**
     * Filter which PlayerCard to delete.
     */
    where: PlayerCardWhereUniqueInput
  }

  /**
   * PlayerCard deleteMany
   */
  export type PlayerCardDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PlayerCards to delete
     */
    where?: PlayerCardWhereInput
    /**
     * Limit how many PlayerCards to delete.
     */
    limit?: number
  }

  /**
   * PlayerCard.transactions
   */
  export type PlayerCard$transactionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    where?: TransactionWhereInput
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    cursor?: TransactionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * PlayerCard without action
   */
  export type PlayerCardDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
  }


  /**
   * Model SlotMachine
   */

  export type AggregateSlotMachine = {
    _count: SlotMachineCountAggregateOutputType | null
    _avg: SlotMachineAvgAggregateOutputType | null
    _sum: SlotMachineSumAggregateOutputType | null
    _min: SlotMachineMinAggregateOutputType | null
    _max: SlotMachineMaxAggregateOutputType | null
  }

  export type SlotMachineAvgAggregateOutputType = {
    machine_id: number | null
    current_player_id: number | null
    current_balance: Decimal | null
  }

  export type SlotMachineSumAggregateOutputType = {
    machine_id: number | null
    current_player_id: number | null
    current_balance: Decimal | null
  }

  export type SlotMachineMinAggregateOutputType = {
    machine_id: number | null
    machine_number: string | null
    location: string | null
    current_player_id: number | null
    current_balance: Decimal | null
    machine_status: $Enums.MachineStatus | null
    last_updated: Date | null
  }

  export type SlotMachineMaxAggregateOutputType = {
    machine_id: number | null
    machine_number: string | null
    location: string | null
    current_player_id: number | null
    current_balance: Decimal | null
    machine_status: $Enums.MachineStatus | null
    last_updated: Date | null
  }

  export type SlotMachineCountAggregateOutputType = {
    machine_id: number
    machine_number: number
    location: number
    current_player_id: number
    current_balance: number
    machine_status: number
    last_updated: number
    _all: number
  }


  export type SlotMachineAvgAggregateInputType = {
    machine_id?: true
    current_player_id?: true
    current_balance?: true
  }

  export type SlotMachineSumAggregateInputType = {
    machine_id?: true
    current_player_id?: true
    current_balance?: true
  }

  export type SlotMachineMinAggregateInputType = {
    machine_id?: true
    machine_number?: true
    location?: true
    current_player_id?: true
    current_balance?: true
    machine_status?: true
    last_updated?: true
  }

  export type SlotMachineMaxAggregateInputType = {
    machine_id?: true
    machine_number?: true
    location?: true
    current_player_id?: true
    current_balance?: true
    machine_status?: true
    last_updated?: true
  }

  export type SlotMachineCountAggregateInputType = {
    machine_id?: true
    machine_number?: true
    location?: true
    current_player_id?: true
    current_balance?: true
    machine_status?: true
    last_updated?: true
    _all?: true
  }

  export type SlotMachineAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SlotMachine to aggregate.
     */
    where?: SlotMachineWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlotMachines to fetch.
     */
    orderBy?: SlotMachineOrderByWithRelationInput | SlotMachineOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SlotMachineWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlotMachines from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlotMachines.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SlotMachines
    **/
    _count?: true | SlotMachineCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SlotMachineAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SlotMachineSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SlotMachineMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SlotMachineMaxAggregateInputType
  }

  export type GetSlotMachineAggregateType<T extends SlotMachineAggregateArgs> = {
        [P in keyof T & keyof AggregateSlotMachine]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSlotMachine[P]>
      : GetScalarType<T[P], AggregateSlotMachine[P]>
  }




  export type SlotMachineGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SlotMachineWhereInput
    orderBy?: SlotMachineOrderByWithAggregationInput | SlotMachineOrderByWithAggregationInput[]
    by: SlotMachineScalarFieldEnum[] | SlotMachineScalarFieldEnum
    having?: SlotMachineScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SlotMachineCountAggregateInputType | true
    _avg?: SlotMachineAvgAggregateInputType
    _sum?: SlotMachineSumAggregateInputType
    _min?: SlotMachineMinAggregateInputType
    _max?: SlotMachineMaxAggregateInputType
  }

  export type SlotMachineGroupByOutputType = {
    machine_id: number
    machine_number: string
    location: string | null
    current_player_id: number | null
    current_balance: Decimal
    machine_status: $Enums.MachineStatus
    last_updated: Date | null
    _count: SlotMachineCountAggregateOutputType | null
    _avg: SlotMachineAvgAggregateOutputType | null
    _sum: SlotMachineSumAggregateOutputType | null
    _min: SlotMachineMinAggregateOutputType | null
    _max: SlotMachineMaxAggregateOutputType | null
  }

  type GetSlotMachineGroupByPayload<T extends SlotMachineGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SlotMachineGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SlotMachineGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SlotMachineGroupByOutputType[P]>
            : GetScalarType<T[P], SlotMachineGroupByOutputType[P]>
        }
      >
    >


  export type SlotMachineSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    machine_id?: boolean
    machine_number?: boolean
    location?: boolean
    current_player_id?: boolean
    current_balance?: boolean
    machine_status?: boolean
    last_updated?: boolean
    current_player?: boolean | SlotMachine$current_playerArgs<ExtArgs>
  }, ExtArgs["result"]["slotMachine"]>



  export type SlotMachineSelectScalar = {
    machine_id?: boolean
    machine_number?: boolean
    location?: boolean
    current_player_id?: boolean
    current_balance?: boolean
    machine_status?: boolean
    last_updated?: boolean
  }

  export type SlotMachineOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"machine_id" | "machine_number" | "location" | "current_player_id" | "current_balance" | "machine_status" | "last_updated", ExtArgs["result"]["slotMachine"]>
  export type SlotMachineInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    current_player?: boolean | SlotMachine$current_playerArgs<ExtArgs>
  }

  export type $SlotMachinePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SlotMachine"
    objects: {
      current_player: Prisma.$UserPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      machine_id: number
      machine_number: string
      location: string | null
      current_player_id: number | null
      current_balance: Prisma.Decimal
      machine_status: $Enums.MachineStatus
      last_updated: Date | null
    }, ExtArgs["result"]["slotMachine"]>
    composites: {}
  }

  type SlotMachineGetPayload<S extends boolean | null | undefined | SlotMachineDefaultArgs> = $Result.GetResult<Prisma.$SlotMachinePayload, S>

  type SlotMachineCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SlotMachineFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SlotMachineCountAggregateInputType | true
    }

  export interface SlotMachineDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SlotMachine'], meta: { name: 'SlotMachine' } }
    /**
     * Find zero or one SlotMachine that matches the filter.
     * @param {SlotMachineFindUniqueArgs} args - Arguments to find a SlotMachine
     * @example
     * // Get one SlotMachine
     * const slotMachine = await prisma.slotMachine.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SlotMachineFindUniqueArgs>(args: SelectSubset<T, SlotMachineFindUniqueArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SlotMachine that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SlotMachineFindUniqueOrThrowArgs} args - Arguments to find a SlotMachine
     * @example
     * // Get one SlotMachine
     * const slotMachine = await prisma.slotMachine.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SlotMachineFindUniqueOrThrowArgs>(args: SelectSubset<T, SlotMachineFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SlotMachine that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineFindFirstArgs} args - Arguments to find a SlotMachine
     * @example
     * // Get one SlotMachine
     * const slotMachine = await prisma.slotMachine.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SlotMachineFindFirstArgs>(args?: SelectSubset<T, SlotMachineFindFirstArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SlotMachine that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineFindFirstOrThrowArgs} args - Arguments to find a SlotMachine
     * @example
     * // Get one SlotMachine
     * const slotMachine = await prisma.slotMachine.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SlotMachineFindFirstOrThrowArgs>(args?: SelectSubset<T, SlotMachineFindFirstOrThrowArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SlotMachines that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SlotMachines
     * const slotMachines = await prisma.slotMachine.findMany()
     * 
     * // Get first 10 SlotMachines
     * const slotMachines = await prisma.slotMachine.findMany({ take: 10 })
     * 
     * // Only select the `machine_id`
     * const slotMachineWithMachine_idOnly = await prisma.slotMachine.findMany({ select: { machine_id: true } })
     * 
     */
    findMany<T extends SlotMachineFindManyArgs>(args?: SelectSubset<T, SlotMachineFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SlotMachine.
     * @param {SlotMachineCreateArgs} args - Arguments to create a SlotMachine.
     * @example
     * // Create one SlotMachine
     * const SlotMachine = await prisma.slotMachine.create({
     *   data: {
     *     // ... data to create a SlotMachine
     *   }
     * })
     * 
     */
    create<T extends SlotMachineCreateArgs>(args: SelectSubset<T, SlotMachineCreateArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SlotMachines.
     * @param {SlotMachineCreateManyArgs} args - Arguments to create many SlotMachines.
     * @example
     * // Create many SlotMachines
     * const slotMachine = await prisma.slotMachine.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SlotMachineCreateManyArgs>(args?: SelectSubset<T, SlotMachineCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SlotMachine.
     * @param {SlotMachineDeleteArgs} args - Arguments to delete one SlotMachine.
     * @example
     * // Delete one SlotMachine
     * const SlotMachine = await prisma.slotMachine.delete({
     *   where: {
     *     // ... filter to delete one SlotMachine
     *   }
     * })
     * 
     */
    delete<T extends SlotMachineDeleteArgs>(args: SelectSubset<T, SlotMachineDeleteArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SlotMachine.
     * @param {SlotMachineUpdateArgs} args - Arguments to update one SlotMachine.
     * @example
     * // Update one SlotMachine
     * const slotMachine = await prisma.slotMachine.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SlotMachineUpdateArgs>(args: SelectSubset<T, SlotMachineUpdateArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SlotMachines.
     * @param {SlotMachineDeleteManyArgs} args - Arguments to filter SlotMachines to delete.
     * @example
     * // Delete a few SlotMachines
     * const { count } = await prisma.slotMachine.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SlotMachineDeleteManyArgs>(args?: SelectSubset<T, SlotMachineDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SlotMachines.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SlotMachines
     * const slotMachine = await prisma.slotMachine.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SlotMachineUpdateManyArgs>(args: SelectSubset<T, SlotMachineUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SlotMachine.
     * @param {SlotMachineUpsertArgs} args - Arguments to update or create a SlotMachine.
     * @example
     * // Update or create a SlotMachine
     * const slotMachine = await prisma.slotMachine.upsert({
     *   create: {
     *     // ... data to create a SlotMachine
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SlotMachine we want to update
     *   }
     * })
     */
    upsert<T extends SlotMachineUpsertArgs>(args: SelectSubset<T, SlotMachineUpsertArgs<ExtArgs>>): Prisma__SlotMachineClient<$Result.GetResult<Prisma.$SlotMachinePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SlotMachines.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineCountArgs} args - Arguments to filter SlotMachines to count.
     * @example
     * // Count the number of SlotMachines
     * const count = await prisma.slotMachine.count({
     *   where: {
     *     // ... the filter for the SlotMachines we want to count
     *   }
     * })
    **/
    count<T extends SlotMachineCountArgs>(
      args?: Subset<T, SlotMachineCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SlotMachineCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SlotMachine.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SlotMachineAggregateArgs>(args: Subset<T, SlotMachineAggregateArgs>): Prisma.PrismaPromise<GetSlotMachineAggregateType<T>>

    /**
     * Group by SlotMachine.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SlotMachineGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SlotMachineGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SlotMachineGroupByArgs['orderBy'] }
        : { orderBy?: SlotMachineGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SlotMachineGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSlotMachineGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SlotMachine model
   */
  readonly fields: SlotMachineFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SlotMachine.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SlotMachineClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    current_player<T extends SlotMachine$current_playerArgs<ExtArgs> = {}>(args?: Subset<T, SlotMachine$current_playerArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SlotMachine model
   */
  interface SlotMachineFieldRefs {
    readonly machine_id: FieldRef<"SlotMachine", 'Int'>
    readonly machine_number: FieldRef<"SlotMachine", 'String'>
    readonly location: FieldRef<"SlotMachine", 'String'>
    readonly current_player_id: FieldRef<"SlotMachine", 'Int'>
    readonly current_balance: FieldRef<"SlotMachine", 'Decimal'>
    readonly machine_status: FieldRef<"SlotMachine", 'MachineStatus'>
    readonly last_updated: FieldRef<"SlotMachine", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SlotMachine findUnique
   */
  export type SlotMachineFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter, which SlotMachine to fetch.
     */
    where: SlotMachineWhereUniqueInput
  }

  /**
   * SlotMachine findUniqueOrThrow
   */
  export type SlotMachineFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter, which SlotMachine to fetch.
     */
    where: SlotMachineWhereUniqueInput
  }

  /**
   * SlotMachine findFirst
   */
  export type SlotMachineFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter, which SlotMachine to fetch.
     */
    where?: SlotMachineWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlotMachines to fetch.
     */
    orderBy?: SlotMachineOrderByWithRelationInput | SlotMachineOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SlotMachines.
     */
    cursor?: SlotMachineWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlotMachines from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlotMachines.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SlotMachines.
     */
    distinct?: SlotMachineScalarFieldEnum | SlotMachineScalarFieldEnum[]
  }

  /**
   * SlotMachine findFirstOrThrow
   */
  export type SlotMachineFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter, which SlotMachine to fetch.
     */
    where?: SlotMachineWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlotMachines to fetch.
     */
    orderBy?: SlotMachineOrderByWithRelationInput | SlotMachineOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SlotMachines.
     */
    cursor?: SlotMachineWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlotMachines from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlotMachines.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SlotMachines.
     */
    distinct?: SlotMachineScalarFieldEnum | SlotMachineScalarFieldEnum[]
  }

  /**
   * SlotMachine findMany
   */
  export type SlotMachineFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter, which SlotMachines to fetch.
     */
    where?: SlotMachineWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SlotMachines to fetch.
     */
    orderBy?: SlotMachineOrderByWithRelationInput | SlotMachineOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SlotMachines.
     */
    cursor?: SlotMachineWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SlotMachines from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SlotMachines.
     */
    skip?: number
    distinct?: SlotMachineScalarFieldEnum | SlotMachineScalarFieldEnum[]
  }

  /**
   * SlotMachine create
   */
  export type SlotMachineCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * The data needed to create a SlotMachine.
     */
    data: XOR<SlotMachineCreateInput, SlotMachineUncheckedCreateInput>
  }

  /**
   * SlotMachine createMany
   */
  export type SlotMachineCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SlotMachines.
     */
    data: SlotMachineCreateManyInput | SlotMachineCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * SlotMachine update
   */
  export type SlotMachineUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * The data needed to update a SlotMachine.
     */
    data: XOR<SlotMachineUpdateInput, SlotMachineUncheckedUpdateInput>
    /**
     * Choose, which SlotMachine to update.
     */
    where: SlotMachineWhereUniqueInput
  }

  /**
   * SlotMachine updateMany
   */
  export type SlotMachineUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SlotMachines.
     */
    data: XOR<SlotMachineUpdateManyMutationInput, SlotMachineUncheckedUpdateManyInput>
    /**
     * Filter which SlotMachines to update
     */
    where?: SlotMachineWhereInput
    /**
     * Limit how many SlotMachines to update.
     */
    limit?: number
  }

  /**
   * SlotMachine upsert
   */
  export type SlotMachineUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * The filter to search for the SlotMachine to update in case it exists.
     */
    where: SlotMachineWhereUniqueInput
    /**
     * In case the SlotMachine found by the `where` argument doesn't exist, create a new SlotMachine with this data.
     */
    create: XOR<SlotMachineCreateInput, SlotMachineUncheckedCreateInput>
    /**
     * In case the SlotMachine was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SlotMachineUpdateInput, SlotMachineUncheckedUpdateInput>
  }

  /**
   * SlotMachine delete
   */
  export type SlotMachineDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
    /**
     * Filter which SlotMachine to delete.
     */
    where: SlotMachineWhereUniqueInput
  }

  /**
   * SlotMachine deleteMany
   */
  export type SlotMachineDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SlotMachines to delete
     */
    where?: SlotMachineWhereInput
    /**
     * Limit how many SlotMachines to delete.
     */
    limit?: number
  }

  /**
   * SlotMachine.current_player
   */
  export type SlotMachine$current_playerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * SlotMachine without action
   */
  export type SlotMachineDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SlotMachine
     */
    select?: SlotMachineSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SlotMachine
     */
    omit?: SlotMachineOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SlotMachineInclude<ExtArgs> | null
  }


  /**
   * Model TITO
   */

  export type AggregateTITO = {
    _count: TITOCountAggregateOutputType | null
    _avg: TITOAvgAggregateOutputType | null
    _sum: TITOSumAggregateOutputType | null
    _min: TITOMinAggregateOutputType | null
    _max: TITOMaxAggregateOutputType | null
  }

  export type TITOAvgAggregateOutputType = {
    tito_id: number | null
    machine_id: number | null
    amount: Decimal | null
  }

  export type TITOSumAggregateOutputType = {
    tito_id: number | null
    machine_id: number | null
    amount: Decimal | null
  }

  export type TITOMinAggregateOutputType = {
    tito_id: number | null
    machine_id: number | null
    unique_identifier: string | null
    barcode: string | null
    amount: Decimal | null
    issued_at: Date | null
    redeemed_at: Date | null
    status: $Enums.TITOStatus | null
  }

  export type TITOMaxAggregateOutputType = {
    tito_id: number | null
    machine_id: number | null
    unique_identifier: string | null
    barcode: string | null
    amount: Decimal | null
    issued_at: Date | null
    redeemed_at: Date | null
    status: $Enums.TITOStatus | null
  }

  export type TITOCountAggregateOutputType = {
    tito_id: number
    machine_id: number
    unique_identifier: number
    barcode: number
    amount: number
    issued_at: number
    redeemed_at: number
    status: number
    _all: number
  }


  export type TITOAvgAggregateInputType = {
    tito_id?: true
    machine_id?: true
    amount?: true
  }

  export type TITOSumAggregateInputType = {
    tito_id?: true
    machine_id?: true
    amount?: true
  }

  export type TITOMinAggregateInputType = {
    tito_id?: true
    machine_id?: true
    unique_identifier?: true
    barcode?: true
    amount?: true
    issued_at?: true
    redeemed_at?: true
    status?: true
  }

  export type TITOMaxAggregateInputType = {
    tito_id?: true
    machine_id?: true
    unique_identifier?: true
    barcode?: true
    amount?: true
    issued_at?: true
    redeemed_at?: true
    status?: true
  }

  export type TITOCountAggregateInputType = {
    tito_id?: true
    machine_id?: true
    unique_identifier?: true
    barcode?: true
    amount?: true
    issued_at?: true
    redeemed_at?: true
    status?: true
    _all?: true
  }

  export type TITOAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TITO to aggregate.
     */
    where?: TITOWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TITOS to fetch.
     */
    orderBy?: TITOOrderByWithRelationInput | TITOOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TITOWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TITOS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TITOS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TITOS
    **/
    _count?: true | TITOCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TITOAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TITOSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TITOMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TITOMaxAggregateInputType
  }

  export type GetTITOAggregateType<T extends TITOAggregateArgs> = {
        [P in keyof T & keyof AggregateTITO]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTITO[P]>
      : GetScalarType<T[P], AggregateTITO[P]>
  }




  export type TITOGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TITOWhereInput
    orderBy?: TITOOrderByWithAggregationInput | TITOOrderByWithAggregationInput[]
    by: TITOScalarFieldEnum[] | TITOScalarFieldEnum
    having?: TITOScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TITOCountAggregateInputType | true
    _avg?: TITOAvgAggregateInputType
    _sum?: TITOSumAggregateInputType
    _min?: TITOMinAggregateInputType
    _max?: TITOMaxAggregateInputType
  }

  export type TITOGroupByOutputType = {
    tito_id: number
    machine_id: number
    unique_identifier: string
    barcode: string
    amount: Decimal
    issued_at: Date | null
    redeemed_at: Date | null
    status: $Enums.TITOStatus
    _count: TITOCountAggregateOutputType | null
    _avg: TITOAvgAggregateOutputType | null
    _sum: TITOSumAggregateOutputType | null
    _min: TITOMinAggregateOutputType | null
    _max: TITOMaxAggregateOutputType | null
  }

  type GetTITOGroupByPayload<T extends TITOGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TITOGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TITOGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TITOGroupByOutputType[P]>
            : GetScalarType<T[P], TITOGroupByOutputType[P]>
        }
      >
    >


  export type TITOSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    tito_id?: boolean
    machine_id?: boolean
    unique_identifier?: boolean
    barcode?: boolean
    amount?: boolean
    issued_at?: boolean
    redeemed_at?: boolean
    status?: boolean
  }, ExtArgs["result"]["tITO"]>



  export type TITOSelectScalar = {
    tito_id?: boolean
    machine_id?: boolean
    unique_identifier?: boolean
    barcode?: boolean
    amount?: boolean
    issued_at?: boolean
    redeemed_at?: boolean
    status?: boolean
  }

  export type TITOOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"tito_id" | "machine_id" | "unique_identifier" | "barcode" | "amount" | "issued_at" | "redeemed_at" | "status", ExtArgs["result"]["tITO"]>

  export type $TITOPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TITO"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      tito_id: number
      machine_id: number
      unique_identifier: string
      barcode: string
      amount: Prisma.Decimal
      issued_at: Date | null
      redeemed_at: Date | null
      status: $Enums.TITOStatus
    }, ExtArgs["result"]["tITO"]>
    composites: {}
  }

  type TITOGetPayload<S extends boolean | null | undefined | TITODefaultArgs> = $Result.GetResult<Prisma.$TITOPayload, S>

  type TITOCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TITOFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TITOCountAggregateInputType | true
    }

  export interface TITODelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TITO'], meta: { name: 'TITO' } }
    /**
     * Find zero or one TITO that matches the filter.
     * @param {TITOFindUniqueArgs} args - Arguments to find a TITO
     * @example
     * // Get one TITO
     * const tITO = await prisma.tITO.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TITOFindUniqueArgs>(args: SelectSubset<T, TITOFindUniqueArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TITO that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TITOFindUniqueOrThrowArgs} args - Arguments to find a TITO
     * @example
     * // Get one TITO
     * const tITO = await prisma.tITO.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TITOFindUniqueOrThrowArgs>(args: SelectSubset<T, TITOFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TITO that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOFindFirstArgs} args - Arguments to find a TITO
     * @example
     * // Get one TITO
     * const tITO = await prisma.tITO.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TITOFindFirstArgs>(args?: SelectSubset<T, TITOFindFirstArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TITO that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOFindFirstOrThrowArgs} args - Arguments to find a TITO
     * @example
     * // Get one TITO
     * const tITO = await prisma.tITO.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TITOFindFirstOrThrowArgs>(args?: SelectSubset<T, TITOFindFirstOrThrowArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TITOS that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TITOS
     * const tITOS = await prisma.tITO.findMany()
     * 
     * // Get first 10 TITOS
     * const tITOS = await prisma.tITO.findMany({ take: 10 })
     * 
     * // Only select the `tito_id`
     * const tITOWithTito_idOnly = await prisma.tITO.findMany({ select: { tito_id: true } })
     * 
     */
    findMany<T extends TITOFindManyArgs>(args?: SelectSubset<T, TITOFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TITO.
     * @param {TITOCreateArgs} args - Arguments to create a TITO.
     * @example
     * // Create one TITO
     * const TITO = await prisma.tITO.create({
     *   data: {
     *     // ... data to create a TITO
     *   }
     * })
     * 
     */
    create<T extends TITOCreateArgs>(args: SelectSubset<T, TITOCreateArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TITOS.
     * @param {TITOCreateManyArgs} args - Arguments to create many TITOS.
     * @example
     * // Create many TITOS
     * const tITO = await prisma.tITO.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TITOCreateManyArgs>(args?: SelectSubset<T, TITOCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a TITO.
     * @param {TITODeleteArgs} args - Arguments to delete one TITO.
     * @example
     * // Delete one TITO
     * const TITO = await prisma.tITO.delete({
     *   where: {
     *     // ... filter to delete one TITO
     *   }
     * })
     * 
     */
    delete<T extends TITODeleteArgs>(args: SelectSubset<T, TITODeleteArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TITO.
     * @param {TITOUpdateArgs} args - Arguments to update one TITO.
     * @example
     * // Update one TITO
     * const tITO = await prisma.tITO.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TITOUpdateArgs>(args: SelectSubset<T, TITOUpdateArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TITOS.
     * @param {TITODeleteManyArgs} args - Arguments to filter TITOS to delete.
     * @example
     * // Delete a few TITOS
     * const { count } = await prisma.tITO.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TITODeleteManyArgs>(args?: SelectSubset<T, TITODeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TITOS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TITOS
     * const tITO = await prisma.tITO.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TITOUpdateManyArgs>(args: SelectSubset<T, TITOUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one TITO.
     * @param {TITOUpsertArgs} args - Arguments to update or create a TITO.
     * @example
     * // Update or create a TITO
     * const tITO = await prisma.tITO.upsert({
     *   create: {
     *     // ... data to create a TITO
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TITO we want to update
     *   }
     * })
     */
    upsert<T extends TITOUpsertArgs>(args: SelectSubset<T, TITOUpsertArgs<ExtArgs>>): Prisma__TITOClient<$Result.GetResult<Prisma.$TITOPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TITOS.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOCountArgs} args - Arguments to filter TITOS to count.
     * @example
     * // Count the number of TITOS
     * const count = await prisma.tITO.count({
     *   where: {
     *     // ... the filter for the TITOS we want to count
     *   }
     * })
    **/
    count<T extends TITOCountArgs>(
      args?: Subset<T, TITOCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TITOCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TITO.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TITOAggregateArgs>(args: Subset<T, TITOAggregateArgs>): Prisma.PrismaPromise<GetTITOAggregateType<T>>

    /**
     * Group by TITO.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TITOGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TITOGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TITOGroupByArgs['orderBy'] }
        : { orderBy?: TITOGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TITOGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTITOGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TITO model
   */
  readonly fields: TITOFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TITO.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TITOClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TITO model
   */
  interface TITOFieldRefs {
    readonly tito_id: FieldRef<"TITO", 'Int'>
    readonly machine_id: FieldRef<"TITO", 'Int'>
    readonly unique_identifier: FieldRef<"TITO", 'String'>
    readonly barcode: FieldRef<"TITO", 'String'>
    readonly amount: FieldRef<"TITO", 'Decimal'>
    readonly issued_at: FieldRef<"TITO", 'DateTime'>
    readonly redeemed_at: FieldRef<"TITO", 'DateTime'>
    readonly status: FieldRef<"TITO", 'TITOStatus'>
  }
    

  // Custom InputTypes
  /**
   * TITO findUnique
   */
  export type TITOFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter, which TITO to fetch.
     */
    where: TITOWhereUniqueInput
  }

  /**
   * TITO findUniqueOrThrow
   */
  export type TITOFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter, which TITO to fetch.
     */
    where: TITOWhereUniqueInput
  }

  /**
   * TITO findFirst
   */
  export type TITOFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter, which TITO to fetch.
     */
    where?: TITOWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TITOS to fetch.
     */
    orderBy?: TITOOrderByWithRelationInput | TITOOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TITOS.
     */
    cursor?: TITOWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TITOS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TITOS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TITOS.
     */
    distinct?: TITOScalarFieldEnum | TITOScalarFieldEnum[]
  }

  /**
   * TITO findFirstOrThrow
   */
  export type TITOFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter, which TITO to fetch.
     */
    where?: TITOWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TITOS to fetch.
     */
    orderBy?: TITOOrderByWithRelationInput | TITOOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TITOS.
     */
    cursor?: TITOWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TITOS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TITOS.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TITOS.
     */
    distinct?: TITOScalarFieldEnum | TITOScalarFieldEnum[]
  }

  /**
   * TITO findMany
   */
  export type TITOFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter, which TITOS to fetch.
     */
    where?: TITOWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TITOS to fetch.
     */
    orderBy?: TITOOrderByWithRelationInput | TITOOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TITOS.
     */
    cursor?: TITOWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TITOS from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TITOS.
     */
    skip?: number
    distinct?: TITOScalarFieldEnum | TITOScalarFieldEnum[]
  }

  /**
   * TITO create
   */
  export type TITOCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * The data needed to create a TITO.
     */
    data: XOR<TITOCreateInput, TITOUncheckedCreateInput>
  }

  /**
   * TITO createMany
   */
  export type TITOCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TITOS.
     */
    data: TITOCreateManyInput | TITOCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TITO update
   */
  export type TITOUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * The data needed to update a TITO.
     */
    data: XOR<TITOUpdateInput, TITOUncheckedUpdateInput>
    /**
     * Choose, which TITO to update.
     */
    where: TITOWhereUniqueInput
  }

  /**
   * TITO updateMany
   */
  export type TITOUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TITOS.
     */
    data: XOR<TITOUpdateManyMutationInput, TITOUncheckedUpdateManyInput>
    /**
     * Filter which TITOS to update
     */
    where?: TITOWhereInput
    /**
     * Limit how many TITOS to update.
     */
    limit?: number
  }

  /**
   * TITO upsert
   */
  export type TITOUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * The filter to search for the TITO to update in case it exists.
     */
    where: TITOWhereUniqueInput
    /**
     * In case the TITO found by the `where` argument doesn't exist, create a new TITO with this data.
     */
    create: XOR<TITOCreateInput, TITOUncheckedCreateInput>
    /**
     * In case the TITO was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TITOUpdateInput, TITOUncheckedUpdateInput>
  }

  /**
   * TITO delete
   */
  export type TITODeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
    /**
     * Filter which TITO to delete.
     */
    where: TITOWhereUniqueInput
  }

  /**
   * TITO deleteMany
   */
  export type TITODeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TITOS to delete
     */
    where?: TITOWhereInput
    /**
     * Limit how many TITOS to delete.
     */
    limit?: number
  }

  /**
   * TITO without action
   */
  export type TITODefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TITO
     */
    select?: TITOSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TITO
     */
    omit?: TITOOmit<ExtArgs> | null
  }


  /**
   * Model Transaction
   */

  export type AggregateTransaction = {
    _count: TransactionCountAggregateOutputType | null
    _avg: TransactionAvgAggregateOutputType | null
    _sum: TransactionSumAggregateOutputType | null
    _min: TransactionMinAggregateOutputType | null
    _max: TransactionMaxAggregateOutputType | null
  }

  export type TransactionAvgAggregateOutputType = {
    transaction_id: number | null
    card_id: number | null
    amount: Decimal | null
  }

  export type TransactionSumAggregateOutputType = {
    transaction_id: number | null
    card_id: number | null
    amount: Decimal | null
  }

  export type TransactionMinAggregateOutputType = {
    transaction_id: number | null
    card_id: number | null
    transaction_type: $Enums.TransactionType | null
    amount: Decimal | null
    payment_method: $Enums.PaymentMethod | null
    transaction_status: $Enums.TransactionStatus | null
    timestamp: Date | null
  }

  export type TransactionMaxAggregateOutputType = {
    transaction_id: number | null
    card_id: number | null
    transaction_type: $Enums.TransactionType | null
    amount: Decimal | null
    payment_method: $Enums.PaymentMethod | null
    transaction_status: $Enums.TransactionStatus | null
    timestamp: Date | null
  }

  export type TransactionCountAggregateOutputType = {
    transaction_id: number
    card_id: number
    transaction_type: number
    amount: number
    payment_method: number
    transaction_status: number
    timestamp: number
    _all: number
  }


  export type TransactionAvgAggregateInputType = {
    transaction_id?: true
    card_id?: true
    amount?: true
  }

  export type TransactionSumAggregateInputType = {
    transaction_id?: true
    card_id?: true
    amount?: true
  }

  export type TransactionMinAggregateInputType = {
    transaction_id?: true
    card_id?: true
    transaction_type?: true
    amount?: true
    payment_method?: true
    transaction_status?: true
    timestamp?: true
  }

  export type TransactionMaxAggregateInputType = {
    transaction_id?: true
    card_id?: true
    transaction_type?: true
    amount?: true
    payment_method?: true
    transaction_status?: true
    timestamp?: true
  }

  export type TransactionCountAggregateInputType = {
    transaction_id?: true
    card_id?: true
    transaction_type?: true
    amount?: true
    payment_method?: true
    transaction_status?: true
    timestamp?: true
    _all?: true
  }

  export type TransactionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Transaction to aggregate.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Transactions
    **/
    _count?: true | TransactionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TransactionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TransactionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TransactionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TransactionMaxAggregateInputType
  }

  export type GetTransactionAggregateType<T extends TransactionAggregateArgs> = {
        [P in keyof T & keyof AggregateTransaction]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTransaction[P]>
      : GetScalarType<T[P], AggregateTransaction[P]>
  }




  export type TransactionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TransactionWhereInput
    orderBy?: TransactionOrderByWithAggregationInput | TransactionOrderByWithAggregationInput[]
    by: TransactionScalarFieldEnum[] | TransactionScalarFieldEnum
    having?: TransactionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TransactionCountAggregateInputType | true
    _avg?: TransactionAvgAggregateInputType
    _sum?: TransactionSumAggregateInputType
    _min?: TransactionMinAggregateInputType
    _max?: TransactionMaxAggregateInputType
  }

  export type TransactionGroupByOutputType = {
    transaction_id: number
    card_id: number | null
    transaction_type: $Enums.TransactionType
    amount: Decimal
    payment_method: $Enums.PaymentMethod
    transaction_status: $Enums.TransactionStatus
    timestamp: Date | null
    _count: TransactionCountAggregateOutputType | null
    _avg: TransactionAvgAggregateOutputType | null
    _sum: TransactionSumAggregateOutputType | null
    _min: TransactionMinAggregateOutputType | null
    _max: TransactionMaxAggregateOutputType | null
  }

  type GetTransactionGroupByPayload<T extends TransactionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TransactionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TransactionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TransactionGroupByOutputType[P]>
            : GetScalarType<T[P], TransactionGroupByOutputType[P]>
        }
      >
    >


  export type TransactionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    transaction_id?: boolean
    card_id?: boolean
    transaction_type?: boolean
    amount?: boolean
    payment_method?: boolean
    transaction_status?: boolean
    timestamp?: boolean
    card?: boolean | Transaction$cardArgs<ExtArgs>
  }, ExtArgs["result"]["transaction"]>



  export type TransactionSelectScalar = {
    transaction_id?: boolean
    card_id?: boolean
    transaction_type?: boolean
    amount?: boolean
    payment_method?: boolean
    transaction_status?: boolean
    timestamp?: boolean
  }

  export type TransactionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"transaction_id" | "card_id" | "transaction_type" | "amount" | "payment_method" | "transaction_status" | "timestamp", ExtArgs["result"]["transaction"]>
  export type TransactionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    card?: boolean | Transaction$cardArgs<ExtArgs>
  }

  export type $TransactionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Transaction"
    objects: {
      card: Prisma.$PlayerCardPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      transaction_id: number
      card_id: number | null
      transaction_type: $Enums.TransactionType
      amount: Prisma.Decimal
      payment_method: $Enums.PaymentMethod
      transaction_status: $Enums.TransactionStatus
      timestamp: Date | null
    }, ExtArgs["result"]["transaction"]>
    composites: {}
  }

  type TransactionGetPayload<S extends boolean | null | undefined | TransactionDefaultArgs> = $Result.GetResult<Prisma.$TransactionPayload, S>

  type TransactionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TransactionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TransactionCountAggregateInputType | true
    }

  export interface TransactionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Transaction'], meta: { name: 'Transaction' } }
    /**
     * Find zero or one Transaction that matches the filter.
     * @param {TransactionFindUniqueArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TransactionFindUniqueArgs>(args: SelectSubset<T, TransactionFindUniqueArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Transaction that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TransactionFindUniqueOrThrowArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TransactionFindUniqueOrThrowArgs>(args: SelectSubset<T, TransactionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Transaction that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindFirstArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TransactionFindFirstArgs>(args?: SelectSubset<T, TransactionFindFirstArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Transaction that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindFirstOrThrowArgs} args - Arguments to find a Transaction
     * @example
     * // Get one Transaction
     * const transaction = await prisma.transaction.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TransactionFindFirstOrThrowArgs>(args?: SelectSubset<T, TransactionFindFirstOrThrowArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Transactions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Transactions
     * const transactions = await prisma.transaction.findMany()
     * 
     * // Get first 10 Transactions
     * const transactions = await prisma.transaction.findMany({ take: 10 })
     * 
     * // Only select the `transaction_id`
     * const transactionWithTransaction_idOnly = await prisma.transaction.findMany({ select: { transaction_id: true } })
     * 
     */
    findMany<T extends TransactionFindManyArgs>(args?: SelectSubset<T, TransactionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Transaction.
     * @param {TransactionCreateArgs} args - Arguments to create a Transaction.
     * @example
     * // Create one Transaction
     * const Transaction = await prisma.transaction.create({
     *   data: {
     *     // ... data to create a Transaction
     *   }
     * })
     * 
     */
    create<T extends TransactionCreateArgs>(args: SelectSubset<T, TransactionCreateArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Transactions.
     * @param {TransactionCreateManyArgs} args - Arguments to create many Transactions.
     * @example
     * // Create many Transactions
     * const transaction = await prisma.transaction.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TransactionCreateManyArgs>(args?: SelectSubset<T, TransactionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Transaction.
     * @param {TransactionDeleteArgs} args - Arguments to delete one Transaction.
     * @example
     * // Delete one Transaction
     * const Transaction = await prisma.transaction.delete({
     *   where: {
     *     // ... filter to delete one Transaction
     *   }
     * })
     * 
     */
    delete<T extends TransactionDeleteArgs>(args: SelectSubset<T, TransactionDeleteArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Transaction.
     * @param {TransactionUpdateArgs} args - Arguments to update one Transaction.
     * @example
     * // Update one Transaction
     * const transaction = await prisma.transaction.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TransactionUpdateArgs>(args: SelectSubset<T, TransactionUpdateArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Transactions.
     * @param {TransactionDeleteManyArgs} args - Arguments to filter Transactions to delete.
     * @example
     * // Delete a few Transactions
     * const { count } = await prisma.transaction.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TransactionDeleteManyArgs>(args?: SelectSubset<T, TransactionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Transactions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Transactions
     * const transaction = await prisma.transaction.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TransactionUpdateManyArgs>(args: SelectSubset<T, TransactionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Transaction.
     * @param {TransactionUpsertArgs} args - Arguments to update or create a Transaction.
     * @example
     * // Update or create a Transaction
     * const transaction = await prisma.transaction.upsert({
     *   create: {
     *     // ... data to create a Transaction
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Transaction we want to update
     *   }
     * })
     */
    upsert<T extends TransactionUpsertArgs>(args: SelectSubset<T, TransactionUpsertArgs<ExtArgs>>): Prisma__TransactionClient<$Result.GetResult<Prisma.$TransactionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Transactions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionCountArgs} args - Arguments to filter Transactions to count.
     * @example
     * // Count the number of Transactions
     * const count = await prisma.transaction.count({
     *   where: {
     *     // ... the filter for the Transactions we want to count
     *   }
     * })
    **/
    count<T extends TransactionCountArgs>(
      args?: Subset<T, TransactionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TransactionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Transaction.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TransactionAggregateArgs>(args: Subset<T, TransactionAggregateArgs>): Prisma.PrismaPromise<GetTransactionAggregateType<T>>

    /**
     * Group by Transaction.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TransactionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TransactionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TransactionGroupByArgs['orderBy'] }
        : { orderBy?: TransactionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TransactionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTransactionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Transaction model
   */
  readonly fields: TransactionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Transaction.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TransactionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    card<T extends Transaction$cardArgs<ExtArgs> = {}>(args?: Subset<T, Transaction$cardArgs<ExtArgs>>): Prisma__PlayerCardClient<$Result.GetResult<Prisma.$PlayerCardPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Transaction model
   */
  interface TransactionFieldRefs {
    readonly transaction_id: FieldRef<"Transaction", 'Int'>
    readonly card_id: FieldRef<"Transaction", 'Int'>
    readonly transaction_type: FieldRef<"Transaction", 'TransactionType'>
    readonly amount: FieldRef<"Transaction", 'Decimal'>
    readonly payment_method: FieldRef<"Transaction", 'PaymentMethod'>
    readonly transaction_status: FieldRef<"Transaction", 'TransactionStatus'>
    readonly timestamp: FieldRef<"Transaction", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Transaction findUnique
   */
  export type TransactionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction findUniqueOrThrow
   */
  export type TransactionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction findFirst
   */
  export type TransactionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Transactions.
     */
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction findFirstOrThrow
   */
  export type TransactionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transaction to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Transactions.
     */
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction findMany
   */
  export type TransactionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter, which Transactions to fetch.
     */
    where?: TransactionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Transactions to fetch.
     */
    orderBy?: TransactionOrderByWithRelationInput | TransactionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Transactions.
     */
    cursor?: TransactionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Transactions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Transactions.
     */
    skip?: number
    distinct?: TransactionScalarFieldEnum | TransactionScalarFieldEnum[]
  }

  /**
   * Transaction create
   */
  export type TransactionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The data needed to create a Transaction.
     */
    data: XOR<TransactionCreateInput, TransactionUncheckedCreateInput>
  }

  /**
   * Transaction createMany
   */
  export type TransactionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Transactions.
     */
    data: TransactionCreateManyInput | TransactionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Transaction update
   */
  export type TransactionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The data needed to update a Transaction.
     */
    data: XOR<TransactionUpdateInput, TransactionUncheckedUpdateInput>
    /**
     * Choose, which Transaction to update.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction updateMany
   */
  export type TransactionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Transactions.
     */
    data: XOR<TransactionUpdateManyMutationInput, TransactionUncheckedUpdateManyInput>
    /**
     * Filter which Transactions to update
     */
    where?: TransactionWhereInput
    /**
     * Limit how many Transactions to update.
     */
    limit?: number
  }

  /**
   * Transaction upsert
   */
  export type TransactionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * The filter to search for the Transaction to update in case it exists.
     */
    where: TransactionWhereUniqueInput
    /**
     * In case the Transaction found by the `where` argument doesn't exist, create a new Transaction with this data.
     */
    create: XOR<TransactionCreateInput, TransactionUncheckedCreateInput>
    /**
     * In case the Transaction was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TransactionUpdateInput, TransactionUncheckedUpdateInput>
  }

  /**
   * Transaction delete
   */
  export type TransactionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
    /**
     * Filter which Transaction to delete.
     */
    where: TransactionWhereUniqueInput
  }

  /**
   * Transaction deleteMany
   */
  export type TransactionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Transactions to delete
     */
    where?: TransactionWhereInput
    /**
     * Limit how many Transactions to delete.
     */
    limit?: number
  }

  /**
   * Transaction.card
   */
  export type Transaction$cardArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PlayerCard
     */
    select?: PlayerCardSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PlayerCard
     */
    omit?: PlayerCardOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PlayerCardInclude<ExtArgs> | null
    where?: PlayerCardWhereInput
  }

  /**
   * Transaction without action
   */
  export type TransactionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Transaction
     */
    select?: TransactionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Transaction
     */
    omit?: TransactionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TransactionInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    user_id: 'user_id',
    full_name: 'full_name',
    address: 'address',
    date_of_birth: 'date_of_birth',
    govt_id_number: 'govt_id_number',
    govt_id_type: 'govt_id_type',
    photo_url: 'photo_url',
    email: 'email',
    phone: 'phone',
    role: 'role',
    status: 'status',
    created_at: 'created_at'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const EmployeeScalarFieldEnum: {
    employee_id: 'employee_id',
    user_id: 'user_id',
    username: 'username',
    password_hash: 'password_hash',
    access_level: 'access_level',
    role: 'role'
  };

  export type EmployeeScalarFieldEnum = (typeof EmployeeScalarFieldEnum)[keyof typeof EmployeeScalarFieldEnum]


  export const PlayerCardScalarFieldEnum: {
    card_id: 'card_id',
    user_id: 'user_id',
    rfid_number: 'rfid_number',
    pin: 'pin',
    balance: 'balance',
    loyalty_points: 'loyalty_points',
    tier: 'tier'
  };

  export type PlayerCardScalarFieldEnum = (typeof PlayerCardScalarFieldEnum)[keyof typeof PlayerCardScalarFieldEnum]


  export const SlotMachineScalarFieldEnum: {
    machine_id: 'machine_id',
    machine_number: 'machine_number',
    location: 'location',
    current_player_id: 'current_player_id',
    current_balance: 'current_balance',
    machine_status: 'machine_status',
    last_updated: 'last_updated'
  };

  export type SlotMachineScalarFieldEnum = (typeof SlotMachineScalarFieldEnum)[keyof typeof SlotMachineScalarFieldEnum]


  export const TITOScalarFieldEnum: {
    tito_id: 'tito_id',
    machine_id: 'machine_id',
    unique_identifier: 'unique_identifier',
    barcode: 'barcode',
    amount: 'amount',
    issued_at: 'issued_at',
    redeemed_at: 'redeemed_at',
    status: 'status'
  };

  export type TITOScalarFieldEnum = (typeof TITOScalarFieldEnum)[keyof typeof TITOScalarFieldEnum]


  export const TransactionScalarFieldEnum: {
    transaction_id: 'transaction_id',
    card_id: 'card_id',
    transaction_type: 'transaction_type',
    amount: 'amount',
    payment_method: 'payment_method',
    transaction_status: 'transaction_status',
    timestamp: 'timestamp'
  };

  export type TransactionScalarFieldEnum = (typeof TransactionScalarFieldEnum)[keyof typeof TransactionScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const UserOrderByRelevanceFieldEnum: {
    full_name: 'full_name',
    address: 'address',
    govt_id_number: 'govt_id_number',
    photo_url: 'photo_url',
    email: 'email',
    phone: 'phone'
  };

  export type UserOrderByRelevanceFieldEnum = (typeof UserOrderByRelevanceFieldEnum)[keyof typeof UserOrderByRelevanceFieldEnum]


  export const EmployeeOrderByRelevanceFieldEnum: {
    username: 'username',
    password_hash: 'password_hash'
  };

  export type EmployeeOrderByRelevanceFieldEnum = (typeof EmployeeOrderByRelevanceFieldEnum)[keyof typeof EmployeeOrderByRelevanceFieldEnum]


  export const PlayerCardOrderByRelevanceFieldEnum: {
    rfid_number: 'rfid_number',
    pin: 'pin'
  };

  export type PlayerCardOrderByRelevanceFieldEnum = (typeof PlayerCardOrderByRelevanceFieldEnum)[keyof typeof PlayerCardOrderByRelevanceFieldEnum]


  export const SlotMachineOrderByRelevanceFieldEnum: {
    machine_number: 'machine_number',
    location: 'location'
  };

  export type SlotMachineOrderByRelevanceFieldEnum = (typeof SlotMachineOrderByRelevanceFieldEnum)[keyof typeof SlotMachineOrderByRelevanceFieldEnum]


  export const TITOOrderByRelevanceFieldEnum: {
    unique_identifier: 'unique_identifier',
    barcode: 'barcode'
  };

  export type TITOOrderByRelevanceFieldEnum = (typeof TITOOrderByRelevanceFieldEnum)[keyof typeof TITOOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'GovtID'
   */
  export type EnumGovtIDFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'GovtID'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'Status'
   */
  export type EnumStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Status'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Tier'
   */
  export type EnumTierFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Tier'>
    


  /**
   * Reference to a field of type 'MachineStatus'
   */
  export type EnumMachineStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MachineStatus'>
    


  /**
   * Reference to a field of type 'TITOStatus'
   */
  export type EnumTITOStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TITOStatus'>
    


  /**
   * Reference to a field of type 'TransactionType'
   */
  export type EnumTransactionTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TransactionType'>
    


  /**
   * Reference to a field of type 'PaymentMethod'
   */
  export type EnumPaymentMethodFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PaymentMethod'>
    


  /**
   * Reference to a field of type 'TransactionStatus'
   */
  export type EnumTransactionStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TransactionStatus'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    user_id?: IntFilter<"User"> | number
    full_name?: StringFilter<"User"> | string
    address?: StringNullableFilter<"User"> | string | null
    date_of_birth?: DateTimeNullableFilter<"User"> | Date | string | null
    govt_id_number?: StringFilter<"User"> | string
    govt_id_type?: EnumGovtIDFilter<"User"> | $Enums.GovtID
    photo_url?: StringNullableFilter<"User"> | string | null
    email?: StringNullableFilter<"User"> | string | null
    phone?: StringFilter<"User"> | string
    role?: EnumRoleFilter<"User"> | $Enums.Role
    status?: EnumStatusFilter<"User"> | $Enums.Status
    created_at?: DateTimeFilter<"User"> | Date | string
    employee?: XOR<EmployeeNullableScalarRelationFilter, EmployeeWhereInput> | null
    playerCard?: XOR<PlayerCardNullableScalarRelationFilter, PlayerCardWhereInput> | null
    current_machines?: SlotMachineListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    user_id?: SortOrder
    full_name?: SortOrder
    address?: SortOrderInput | SortOrder
    date_of_birth?: SortOrderInput | SortOrder
    govt_id_number?: SortOrder
    govt_id_type?: SortOrder
    photo_url?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    phone?: SortOrder
    role?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    employee?: EmployeeOrderByWithRelationInput
    playerCard?: PlayerCardOrderByWithRelationInput
    current_machines?: SlotMachineOrderByRelationAggregateInput
    _relevance?: UserOrderByRelevanceInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    user_id?: number
    govt_id_number?: string
    email?: string
    phone?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    full_name?: StringFilter<"User"> | string
    address?: StringNullableFilter<"User"> | string | null
    date_of_birth?: DateTimeNullableFilter<"User"> | Date | string | null
    govt_id_type?: EnumGovtIDFilter<"User"> | $Enums.GovtID
    photo_url?: StringNullableFilter<"User"> | string | null
    role?: EnumRoleFilter<"User"> | $Enums.Role
    status?: EnumStatusFilter<"User"> | $Enums.Status
    created_at?: DateTimeFilter<"User"> | Date | string
    employee?: XOR<EmployeeNullableScalarRelationFilter, EmployeeWhereInput> | null
    playerCard?: XOR<PlayerCardNullableScalarRelationFilter, PlayerCardWhereInput> | null
    current_machines?: SlotMachineListRelationFilter
  }, "user_id" | "govt_id_number" | "email" | "phone">

  export type UserOrderByWithAggregationInput = {
    user_id?: SortOrder
    full_name?: SortOrder
    address?: SortOrderInput | SortOrder
    date_of_birth?: SortOrderInput | SortOrder
    govt_id_number?: SortOrder
    govt_id_type?: SortOrder
    photo_url?: SortOrderInput | SortOrder
    email?: SortOrderInput | SortOrder
    phone?: SortOrder
    role?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _avg?: UserAvgOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
    _sum?: UserSumOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    user_id?: IntWithAggregatesFilter<"User"> | number
    full_name?: StringWithAggregatesFilter<"User"> | string
    address?: StringNullableWithAggregatesFilter<"User"> | string | null
    date_of_birth?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    govt_id_number?: StringWithAggregatesFilter<"User"> | string
    govt_id_type?: EnumGovtIDWithAggregatesFilter<"User"> | $Enums.GovtID
    photo_url?: StringNullableWithAggregatesFilter<"User"> | string | null
    email?: StringNullableWithAggregatesFilter<"User"> | string | null
    phone?: StringWithAggregatesFilter<"User"> | string
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
    status?: EnumStatusWithAggregatesFilter<"User"> | $Enums.Status
    created_at?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type EmployeeWhereInput = {
    AND?: EmployeeWhereInput | EmployeeWhereInput[]
    OR?: EmployeeWhereInput[]
    NOT?: EmployeeWhereInput | EmployeeWhereInput[]
    employee_id?: IntFilter<"Employee"> | number
    user_id?: IntFilter<"Employee"> | number
    username?: StringFilter<"Employee"> | string
    password_hash?: StringFilter<"Employee"> | string
    access_level?: IntFilter<"Employee"> | number
    role?: EnumRoleFilter<"Employee"> | $Enums.Role
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type EmployeeOrderByWithRelationInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    username?: SortOrder
    password_hash?: SortOrder
    access_level?: SortOrder
    role?: SortOrder
    user?: UserOrderByWithRelationInput
    _relevance?: EmployeeOrderByRelevanceInput
  }

  export type EmployeeWhereUniqueInput = Prisma.AtLeast<{
    employee_id?: number
    user_id?: number
    username?: string
    AND?: EmployeeWhereInput | EmployeeWhereInput[]
    OR?: EmployeeWhereInput[]
    NOT?: EmployeeWhereInput | EmployeeWhereInput[]
    password_hash?: StringFilter<"Employee"> | string
    access_level?: IntFilter<"Employee"> | number
    role?: EnumRoleFilter<"Employee"> | $Enums.Role
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "employee_id" | "user_id" | "username">

  export type EmployeeOrderByWithAggregationInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    username?: SortOrder
    password_hash?: SortOrder
    access_level?: SortOrder
    role?: SortOrder
    _count?: EmployeeCountOrderByAggregateInput
    _avg?: EmployeeAvgOrderByAggregateInput
    _max?: EmployeeMaxOrderByAggregateInput
    _min?: EmployeeMinOrderByAggregateInput
    _sum?: EmployeeSumOrderByAggregateInput
  }

  export type EmployeeScalarWhereWithAggregatesInput = {
    AND?: EmployeeScalarWhereWithAggregatesInput | EmployeeScalarWhereWithAggregatesInput[]
    OR?: EmployeeScalarWhereWithAggregatesInput[]
    NOT?: EmployeeScalarWhereWithAggregatesInput | EmployeeScalarWhereWithAggregatesInput[]
    employee_id?: IntWithAggregatesFilter<"Employee"> | number
    user_id?: IntWithAggregatesFilter<"Employee"> | number
    username?: StringWithAggregatesFilter<"Employee"> | string
    password_hash?: StringWithAggregatesFilter<"Employee"> | string
    access_level?: IntWithAggregatesFilter<"Employee"> | number
    role?: EnumRoleWithAggregatesFilter<"Employee"> | $Enums.Role
  }

  export type PlayerCardWhereInput = {
    AND?: PlayerCardWhereInput | PlayerCardWhereInput[]
    OR?: PlayerCardWhereInput[]
    NOT?: PlayerCardWhereInput | PlayerCardWhereInput[]
    card_id?: IntFilter<"PlayerCard"> | number
    user_id?: IntFilter<"PlayerCard"> | number
    rfid_number?: StringFilter<"PlayerCard"> | string
    pin?: StringFilter<"PlayerCard"> | string
    balance?: DecimalFilter<"PlayerCard"> | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFilter<"PlayerCard"> | number
    tier?: EnumTierFilter<"PlayerCard"> | $Enums.Tier
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    transactions?: TransactionListRelationFilter
  }

  export type PlayerCardOrderByWithRelationInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    rfid_number?: SortOrder
    pin?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
    tier?: SortOrder
    user?: UserOrderByWithRelationInput
    transactions?: TransactionOrderByRelationAggregateInput
    _relevance?: PlayerCardOrderByRelevanceInput
  }

  export type PlayerCardWhereUniqueInput = Prisma.AtLeast<{
    card_id?: number
    user_id?: number
    rfid_number?: string
    AND?: PlayerCardWhereInput | PlayerCardWhereInput[]
    OR?: PlayerCardWhereInput[]
    NOT?: PlayerCardWhereInput | PlayerCardWhereInput[]
    pin?: StringFilter<"PlayerCard"> | string
    balance?: DecimalFilter<"PlayerCard"> | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFilter<"PlayerCard"> | number
    tier?: EnumTierFilter<"PlayerCard"> | $Enums.Tier
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    transactions?: TransactionListRelationFilter
  }, "card_id" | "user_id" | "rfid_number">

  export type PlayerCardOrderByWithAggregationInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    rfid_number?: SortOrder
    pin?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
    tier?: SortOrder
    _count?: PlayerCardCountOrderByAggregateInput
    _avg?: PlayerCardAvgOrderByAggregateInput
    _max?: PlayerCardMaxOrderByAggregateInput
    _min?: PlayerCardMinOrderByAggregateInput
    _sum?: PlayerCardSumOrderByAggregateInput
  }

  export type PlayerCardScalarWhereWithAggregatesInput = {
    AND?: PlayerCardScalarWhereWithAggregatesInput | PlayerCardScalarWhereWithAggregatesInput[]
    OR?: PlayerCardScalarWhereWithAggregatesInput[]
    NOT?: PlayerCardScalarWhereWithAggregatesInput | PlayerCardScalarWhereWithAggregatesInput[]
    card_id?: IntWithAggregatesFilter<"PlayerCard"> | number
    user_id?: IntWithAggregatesFilter<"PlayerCard"> | number
    rfid_number?: StringWithAggregatesFilter<"PlayerCard"> | string
    pin?: StringWithAggregatesFilter<"PlayerCard"> | string
    balance?: DecimalWithAggregatesFilter<"PlayerCard"> | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntWithAggregatesFilter<"PlayerCard"> | number
    tier?: EnumTierWithAggregatesFilter<"PlayerCard"> | $Enums.Tier
  }

  export type SlotMachineWhereInput = {
    AND?: SlotMachineWhereInput | SlotMachineWhereInput[]
    OR?: SlotMachineWhereInput[]
    NOT?: SlotMachineWhereInput | SlotMachineWhereInput[]
    machine_id?: IntFilter<"SlotMachine"> | number
    machine_number?: StringFilter<"SlotMachine"> | string
    location?: StringNullableFilter<"SlotMachine"> | string | null
    current_player_id?: IntNullableFilter<"SlotMachine"> | number | null
    current_balance?: DecimalFilter<"SlotMachine"> | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFilter<"SlotMachine"> | $Enums.MachineStatus
    last_updated?: DateTimeNullableFilter<"SlotMachine"> | Date | string | null
    current_player?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }

  export type SlotMachineOrderByWithRelationInput = {
    machine_id?: SortOrder
    machine_number?: SortOrder
    location?: SortOrderInput | SortOrder
    current_player_id?: SortOrderInput | SortOrder
    current_balance?: SortOrder
    machine_status?: SortOrder
    last_updated?: SortOrderInput | SortOrder
    current_player?: UserOrderByWithRelationInput
    _relevance?: SlotMachineOrderByRelevanceInput
  }

  export type SlotMachineWhereUniqueInput = Prisma.AtLeast<{
    machine_id?: number
    machine_number?: string
    AND?: SlotMachineWhereInput | SlotMachineWhereInput[]
    OR?: SlotMachineWhereInput[]
    NOT?: SlotMachineWhereInput | SlotMachineWhereInput[]
    location?: StringNullableFilter<"SlotMachine"> | string | null
    current_player_id?: IntNullableFilter<"SlotMachine"> | number | null
    current_balance?: DecimalFilter<"SlotMachine"> | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFilter<"SlotMachine"> | $Enums.MachineStatus
    last_updated?: DateTimeNullableFilter<"SlotMachine"> | Date | string | null
    current_player?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
  }, "machine_id" | "machine_number">

  export type SlotMachineOrderByWithAggregationInput = {
    machine_id?: SortOrder
    machine_number?: SortOrder
    location?: SortOrderInput | SortOrder
    current_player_id?: SortOrderInput | SortOrder
    current_balance?: SortOrder
    machine_status?: SortOrder
    last_updated?: SortOrderInput | SortOrder
    _count?: SlotMachineCountOrderByAggregateInput
    _avg?: SlotMachineAvgOrderByAggregateInput
    _max?: SlotMachineMaxOrderByAggregateInput
    _min?: SlotMachineMinOrderByAggregateInput
    _sum?: SlotMachineSumOrderByAggregateInput
  }

  export type SlotMachineScalarWhereWithAggregatesInput = {
    AND?: SlotMachineScalarWhereWithAggregatesInput | SlotMachineScalarWhereWithAggregatesInput[]
    OR?: SlotMachineScalarWhereWithAggregatesInput[]
    NOT?: SlotMachineScalarWhereWithAggregatesInput | SlotMachineScalarWhereWithAggregatesInput[]
    machine_id?: IntWithAggregatesFilter<"SlotMachine"> | number
    machine_number?: StringWithAggregatesFilter<"SlotMachine"> | string
    location?: StringNullableWithAggregatesFilter<"SlotMachine"> | string | null
    current_player_id?: IntNullableWithAggregatesFilter<"SlotMachine"> | number | null
    current_balance?: DecimalWithAggregatesFilter<"SlotMachine"> | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusWithAggregatesFilter<"SlotMachine"> | $Enums.MachineStatus
    last_updated?: DateTimeNullableWithAggregatesFilter<"SlotMachine"> | Date | string | null
  }

  export type TITOWhereInput = {
    AND?: TITOWhereInput | TITOWhereInput[]
    OR?: TITOWhereInput[]
    NOT?: TITOWhereInput | TITOWhereInput[]
    tito_id?: IntFilter<"TITO"> | number
    machine_id?: IntFilter<"TITO"> | number
    unique_identifier?: StringFilter<"TITO"> | string
    barcode?: StringFilter<"TITO"> | string
    amount?: DecimalFilter<"TITO"> | Decimal | DecimalJsLike | number | string
    issued_at?: DateTimeNullableFilter<"TITO"> | Date | string | null
    redeemed_at?: DateTimeNullableFilter<"TITO"> | Date | string | null
    status?: EnumTITOStatusFilter<"TITO"> | $Enums.TITOStatus
  }

  export type TITOOrderByWithRelationInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    unique_identifier?: SortOrder
    barcode?: SortOrder
    amount?: SortOrder
    issued_at?: SortOrderInput | SortOrder
    redeemed_at?: SortOrderInput | SortOrder
    status?: SortOrder
    _relevance?: TITOOrderByRelevanceInput
  }

  export type TITOWhereUniqueInput = Prisma.AtLeast<{
    tito_id?: number
    unique_identifier?: string
    barcode?: string
    AND?: TITOWhereInput | TITOWhereInput[]
    OR?: TITOWhereInput[]
    NOT?: TITOWhereInput | TITOWhereInput[]
    machine_id?: IntFilter<"TITO"> | number
    amount?: DecimalFilter<"TITO"> | Decimal | DecimalJsLike | number | string
    issued_at?: DateTimeNullableFilter<"TITO"> | Date | string | null
    redeemed_at?: DateTimeNullableFilter<"TITO"> | Date | string | null
    status?: EnumTITOStatusFilter<"TITO"> | $Enums.TITOStatus
  }, "tito_id" | "unique_identifier" | "barcode">

  export type TITOOrderByWithAggregationInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    unique_identifier?: SortOrder
    barcode?: SortOrder
    amount?: SortOrder
    issued_at?: SortOrderInput | SortOrder
    redeemed_at?: SortOrderInput | SortOrder
    status?: SortOrder
    _count?: TITOCountOrderByAggregateInput
    _avg?: TITOAvgOrderByAggregateInput
    _max?: TITOMaxOrderByAggregateInput
    _min?: TITOMinOrderByAggregateInput
    _sum?: TITOSumOrderByAggregateInput
  }

  export type TITOScalarWhereWithAggregatesInput = {
    AND?: TITOScalarWhereWithAggregatesInput | TITOScalarWhereWithAggregatesInput[]
    OR?: TITOScalarWhereWithAggregatesInput[]
    NOT?: TITOScalarWhereWithAggregatesInput | TITOScalarWhereWithAggregatesInput[]
    tito_id?: IntWithAggregatesFilter<"TITO"> | number
    machine_id?: IntWithAggregatesFilter<"TITO"> | number
    unique_identifier?: StringWithAggregatesFilter<"TITO"> | string
    barcode?: StringWithAggregatesFilter<"TITO"> | string
    amount?: DecimalWithAggregatesFilter<"TITO"> | Decimal | DecimalJsLike | number | string
    issued_at?: DateTimeNullableWithAggregatesFilter<"TITO"> | Date | string | null
    redeemed_at?: DateTimeNullableWithAggregatesFilter<"TITO"> | Date | string | null
    status?: EnumTITOStatusWithAggregatesFilter<"TITO"> | $Enums.TITOStatus
  }

  export type TransactionWhereInput = {
    AND?: TransactionWhereInput | TransactionWhereInput[]
    OR?: TransactionWhereInput[]
    NOT?: TransactionWhereInput | TransactionWhereInput[]
    transaction_id?: IntFilter<"Transaction"> | number
    card_id?: IntNullableFilter<"Transaction"> | number | null
    transaction_type?: EnumTransactionTypeFilter<"Transaction"> | $Enums.TransactionType
    amount?: DecimalFilter<"Transaction"> | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFilter<"Transaction"> | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFilter<"Transaction"> | $Enums.TransactionStatus
    timestamp?: DateTimeNullableFilter<"Transaction"> | Date | string | null
    card?: XOR<PlayerCardNullableScalarRelationFilter, PlayerCardWhereInput> | null
  }

  export type TransactionOrderByWithRelationInput = {
    transaction_id?: SortOrder
    card_id?: SortOrderInput | SortOrder
    transaction_type?: SortOrder
    amount?: SortOrder
    payment_method?: SortOrder
    transaction_status?: SortOrder
    timestamp?: SortOrderInput | SortOrder
    card?: PlayerCardOrderByWithRelationInput
  }

  export type TransactionWhereUniqueInput = Prisma.AtLeast<{
    transaction_id?: number
    AND?: TransactionWhereInput | TransactionWhereInput[]
    OR?: TransactionWhereInput[]
    NOT?: TransactionWhereInput | TransactionWhereInput[]
    card_id?: IntNullableFilter<"Transaction"> | number | null
    transaction_type?: EnumTransactionTypeFilter<"Transaction"> | $Enums.TransactionType
    amount?: DecimalFilter<"Transaction"> | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFilter<"Transaction"> | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFilter<"Transaction"> | $Enums.TransactionStatus
    timestamp?: DateTimeNullableFilter<"Transaction"> | Date | string | null
    card?: XOR<PlayerCardNullableScalarRelationFilter, PlayerCardWhereInput> | null
  }, "transaction_id">

  export type TransactionOrderByWithAggregationInput = {
    transaction_id?: SortOrder
    card_id?: SortOrderInput | SortOrder
    transaction_type?: SortOrder
    amount?: SortOrder
    payment_method?: SortOrder
    transaction_status?: SortOrder
    timestamp?: SortOrderInput | SortOrder
    _count?: TransactionCountOrderByAggregateInput
    _avg?: TransactionAvgOrderByAggregateInput
    _max?: TransactionMaxOrderByAggregateInput
    _min?: TransactionMinOrderByAggregateInput
    _sum?: TransactionSumOrderByAggregateInput
  }

  export type TransactionScalarWhereWithAggregatesInput = {
    AND?: TransactionScalarWhereWithAggregatesInput | TransactionScalarWhereWithAggregatesInput[]
    OR?: TransactionScalarWhereWithAggregatesInput[]
    NOT?: TransactionScalarWhereWithAggregatesInput | TransactionScalarWhereWithAggregatesInput[]
    transaction_id?: IntWithAggregatesFilter<"Transaction"> | number
    card_id?: IntNullableWithAggregatesFilter<"Transaction"> | number | null
    transaction_type?: EnumTransactionTypeWithAggregatesFilter<"Transaction"> | $Enums.TransactionType
    amount?: DecimalWithAggregatesFilter<"Transaction"> | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodWithAggregatesFilter<"Transaction"> | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusWithAggregatesFilter<"Transaction"> | $Enums.TransactionStatus
    timestamp?: DateTimeNullableWithAggregatesFilter<"Transaction"> | Date | string | null
  }

  export type UserCreateInput = {
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeCreateNestedOneWithoutUserInput
    playerCard?: PlayerCardCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserUncheckedCreateInput = {
    user_id?: number
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeUncheckedCreateNestedOneWithoutUserInput
    playerCard?: PlayerCardUncheckedCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineUncheckedCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserUpdateInput = {
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUpdateOneWithoutUserNestedInput
    playerCard?: PlayerCardUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUpdateManyWithoutCurrent_playerNestedInput
  }

  export type UserUncheckedUpdateInput = {
    user_id?: IntFieldUpdateOperationsInput | number
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUncheckedUpdateOneWithoutUserNestedInput
    playerCard?: PlayerCardUncheckedUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUncheckedUpdateManyWithoutCurrent_playerNestedInput
  }

  export type UserCreateManyInput = {
    user_id?: number
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    user_id?: IntFieldUpdateOperationsInput | number
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EmployeeCreateInput = {
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
    user: UserCreateNestedOneWithoutEmployeeInput
  }

  export type EmployeeUncheckedCreateInput = {
    employee_id?: number
    user_id: number
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
  }

  export type EmployeeUpdateInput = {
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    user?: UserUpdateOneRequiredWithoutEmployeeNestedInput
  }

  export type EmployeeUncheckedUpdateInput = {
    employee_id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type EmployeeCreateManyInput = {
    employee_id?: number
    user_id: number
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
  }

  export type EmployeeUpdateManyMutationInput = {
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type EmployeeUncheckedUpdateManyInput = {
    employee_id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type PlayerCardCreateInput = {
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
    user: UserCreateNestedOneWithoutPlayerCardInput
    transactions?: TransactionCreateNestedManyWithoutCardInput
  }

  export type PlayerCardUncheckedCreateInput = {
    card_id?: number
    user_id: number
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
    transactions?: TransactionUncheckedCreateNestedManyWithoutCardInput
  }

  export type PlayerCardUpdateInput = {
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
    user?: UserUpdateOneRequiredWithoutPlayerCardNestedInput
    transactions?: TransactionUpdateManyWithoutCardNestedInput
  }

  export type PlayerCardUncheckedUpdateInput = {
    card_id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
    transactions?: TransactionUncheckedUpdateManyWithoutCardNestedInput
  }

  export type PlayerCardCreateManyInput = {
    card_id?: number
    user_id: number
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
  }

  export type PlayerCardUpdateManyMutationInput = {
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
  }

  export type PlayerCardUncheckedUpdateManyInput = {
    card_id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
  }

  export type SlotMachineCreateInput = {
    machine_number: string
    location?: string | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
    current_player?: UserCreateNestedOneWithoutCurrent_machinesInput
  }

  export type SlotMachineUncheckedCreateInput = {
    machine_id?: number
    machine_number: string
    location?: string | null
    current_player_id?: number | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
  }

  export type SlotMachineUpdateInput = {
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    current_player?: UserUpdateOneWithoutCurrent_machinesNestedInput
  }

  export type SlotMachineUncheckedUpdateInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_player_id?: NullableIntFieldUpdateOperationsInput | number | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SlotMachineCreateManyInput = {
    machine_id?: number
    machine_number: string
    location?: string | null
    current_player_id?: number | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
  }

  export type SlotMachineUpdateManyMutationInput = {
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SlotMachineUncheckedUpdateManyInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_player_id?: NullableIntFieldUpdateOperationsInput | number | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TITOCreateInput = {
    machine_id: number
    unique_identifier: string
    barcode: string
    amount: Decimal | DecimalJsLike | number | string
    issued_at?: Date | string | null
    redeemed_at?: Date | string | null
    status?: $Enums.TITOStatus
  }

  export type TITOUncheckedCreateInput = {
    tito_id?: number
    machine_id: number
    unique_identifier: string
    barcode: string
    amount: Decimal | DecimalJsLike | number | string
    issued_at?: Date | string | null
    redeemed_at?: Date | string | null
    status?: $Enums.TITOStatus
  }

  export type TITOUpdateInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    unique_identifier?: StringFieldUpdateOperationsInput | string
    barcode?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    issued_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    redeemed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: EnumTITOStatusFieldUpdateOperationsInput | $Enums.TITOStatus
  }

  export type TITOUncheckedUpdateInput = {
    tito_id?: IntFieldUpdateOperationsInput | number
    machine_id?: IntFieldUpdateOperationsInput | number
    unique_identifier?: StringFieldUpdateOperationsInput | string
    barcode?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    issued_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    redeemed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: EnumTITOStatusFieldUpdateOperationsInput | $Enums.TITOStatus
  }

  export type TITOCreateManyInput = {
    tito_id?: number
    machine_id: number
    unique_identifier: string
    barcode: string
    amount: Decimal | DecimalJsLike | number | string
    issued_at?: Date | string | null
    redeemed_at?: Date | string | null
    status?: $Enums.TITOStatus
  }

  export type TITOUpdateManyMutationInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    unique_identifier?: StringFieldUpdateOperationsInput | string
    barcode?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    issued_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    redeemed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: EnumTITOStatusFieldUpdateOperationsInput | $Enums.TITOStatus
  }

  export type TITOUncheckedUpdateManyInput = {
    tito_id?: IntFieldUpdateOperationsInput | number
    machine_id?: IntFieldUpdateOperationsInput | number
    unique_identifier?: StringFieldUpdateOperationsInput | string
    barcode?: StringFieldUpdateOperationsInput | string
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    issued_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    redeemed_at?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    status?: EnumTITOStatusFieldUpdateOperationsInput | $Enums.TITOStatus
  }

  export type TransactionCreateInput = {
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
    card?: PlayerCardCreateNestedOneWithoutTransactionsInput
  }

  export type TransactionUncheckedCreateInput = {
    transaction_id?: number
    card_id?: number | null
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
  }

  export type TransactionUpdateInput = {
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    card?: PlayerCardUpdateOneWithoutTransactionsNestedInput
  }

  export type TransactionUncheckedUpdateInput = {
    transaction_id?: IntFieldUpdateOperationsInput | number
    card_id?: NullableIntFieldUpdateOperationsInput | number | null
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TransactionCreateManyInput = {
    transaction_id?: number
    card_id?: number | null
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
  }

  export type TransactionUpdateManyMutationInput = {
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TransactionUncheckedUpdateManyInput = {
    transaction_id?: IntFieldUpdateOperationsInput | number
    card_id?: NullableIntFieldUpdateOperationsInput | number | null
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type EnumGovtIDFilter<$PrismaModel = never> = {
    equals?: $Enums.GovtID | EnumGovtIDFieldRefInput<$PrismaModel>
    in?: $Enums.GovtID[]
    notIn?: $Enums.GovtID[]
    not?: NestedEnumGovtIDFilter<$PrismaModel> | $Enums.GovtID
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type EnumStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.Status | EnumStatusFieldRefInput<$PrismaModel>
    in?: $Enums.Status[]
    notIn?: $Enums.Status[]
    not?: NestedEnumStatusFilter<$PrismaModel> | $Enums.Status
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EmployeeNullableScalarRelationFilter = {
    is?: EmployeeWhereInput | null
    isNot?: EmployeeWhereInput | null
  }

  export type PlayerCardNullableScalarRelationFilter = {
    is?: PlayerCardWhereInput | null
    isNot?: PlayerCardWhereInput | null
  }

  export type SlotMachineListRelationFilter = {
    every?: SlotMachineWhereInput
    some?: SlotMachineWhereInput
    none?: SlotMachineWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type SlotMachineOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserOrderByRelevanceInput = {
    fields: UserOrderByRelevanceFieldEnum | UserOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UserCountOrderByAggregateInput = {
    user_id?: SortOrder
    full_name?: SortOrder
    address?: SortOrder
    date_of_birth?: SortOrder
    govt_id_number?: SortOrder
    govt_id_type?: SortOrder
    photo_url?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
  }

  export type UserAvgOrderByAggregateInput = {
    user_id?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    user_id?: SortOrder
    full_name?: SortOrder
    address?: SortOrder
    date_of_birth?: SortOrder
    govt_id_number?: SortOrder
    govt_id_type?: SortOrder
    photo_url?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    user_id?: SortOrder
    full_name?: SortOrder
    address?: SortOrder
    date_of_birth?: SortOrder
    govt_id_number?: SortOrder
    govt_id_type?: SortOrder
    photo_url?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    status?: SortOrder
    created_at?: SortOrder
  }

  export type UserSumOrderByAggregateInput = {
    user_id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type EnumGovtIDWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.GovtID | EnumGovtIDFieldRefInput<$PrismaModel>
    in?: $Enums.GovtID[]
    notIn?: $Enums.GovtID[]
    not?: NestedEnumGovtIDWithAggregatesFilter<$PrismaModel> | $Enums.GovtID
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumGovtIDFilter<$PrismaModel>
    _max?: NestedEnumGovtIDFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type EnumStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Status | EnumStatusFieldRefInput<$PrismaModel>
    in?: $Enums.Status[]
    notIn?: $Enums.Status[]
    not?: NestedEnumStatusWithAggregatesFilter<$PrismaModel> | $Enums.Status
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumStatusFilter<$PrismaModel>
    _max?: NestedEnumStatusFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type EmployeeOrderByRelevanceInput = {
    fields: EmployeeOrderByRelevanceFieldEnum | EmployeeOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type EmployeeCountOrderByAggregateInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    username?: SortOrder
    password_hash?: SortOrder
    access_level?: SortOrder
    role?: SortOrder
  }

  export type EmployeeAvgOrderByAggregateInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    access_level?: SortOrder
  }

  export type EmployeeMaxOrderByAggregateInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    username?: SortOrder
    password_hash?: SortOrder
    access_level?: SortOrder
    role?: SortOrder
  }

  export type EmployeeMinOrderByAggregateInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    username?: SortOrder
    password_hash?: SortOrder
    access_level?: SortOrder
    role?: SortOrder
  }

  export type EmployeeSumOrderByAggregateInput = {
    employee_id?: SortOrder
    user_id?: SortOrder
    access_level?: SortOrder
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type EnumTierFilter<$PrismaModel = never> = {
    equals?: $Enums.Tier | EnumTierFieldRefInput<$PrismaModel>
    in?: $Enums.Tier[]
    notIn?: $Enums.Tier[]
    not?: NestedEnumTierFilter<$PrismaModel> | $Enums.Tier
  }

  export type TransactionListRelationFilter = {
    every?: TransactionWhereInput
    some?: TransactionWhereInput
    none?: TransactionWhereInput
  }

  export type TransactionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PlayerCardOrderByRelevanceInput = {
    fields: PlayerCardOrderByRelevanceFieldEnum | PlayerCardOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PlayerCardCountOrderByAggregateInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    rfid_number?: SortOrder
    pin?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
    tier?: SortOrder
  }

  export type PlayerCardAvgOrderByAggregateInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
  }

  export type PlayerCardMaxOrderByAggregateInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    rfid_number?: SortOrder
    pin?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
    tier?: SortOrder
  }

  export type PlayerCardMinOrderByAggregateInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    rfid_number?: SortOrder
    pin?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
    tier?: SortOrder
  }

  export type PlayerCardSumOrderByAggregateInput = {
    card_id?: SortOrder
    user_id?: SortOrder
    balance?: SortOrder
    loyalty_points?: SortOrder
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type EnumTierWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Tier | EnumTierFieldRefInput<$PrismaModel>
    in?: $Enums.Tier[]
    notIn?: $Enums.Tier[]
    not?: NestedEnumTierWithAggregatesFilter<$PrismaModel> | $Enums.Tier
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTierFilter<$PrismaModel>
    _max?: NestedEnumTierFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type EnumMachineStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MachineStatus | EnumMachineStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MachineStatus[]
    notIn?: $Enums.MachineStatus[]
    not?: NestedEnumMachineStatusFilter<$PrismaModel> | $Enums.MachineStatus
  }

  export type UserNullableScalarRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type SlotMachineOrderByRelevanceInput = {
    fields: SlotMachineOrderByRelevanceFieldEnum | SlotMachineOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type SlotMachineCountOrderByAggregateInput = {
    machine_id?: SortOrder
    machine_number?: SortOrder
    location?: SortOrder
    current_player_id?: SortOrder
    current_balance?: SortOrder
    machine_status?: SortOrder
    last_updated?: SortOrder
  }

  export type SlotMachineAvgOrderByAggregateInput = {
    machine_id?: SortOrder
    current_player_id?: SortOrder
    current_balance?: SortOrder
  }

  export type SlotMachineMaxOrderByAggregateInput = {
    machine_id?: SortOrder
    machine_number?: SortOrder
    location?: SortOrder
    current_player_id?: SortOrder
    current_balance?: SortOrder
    machine_status?: SortOrder
    last_updated?: SortOrder
  }

  export type SlotMachineMinOrderByAggregateInput = {
    machine_id?: SortOrder
    machine_number?: SortOrder
    location?: SortOrder
    current_player_id?: SortOrder
    current_balance?: SortOrder
    machine_status?: SortOrder
    last_updated?: SortOrder
  }

  export type SlotMachineSumOrderByAggregateInput = {
    machine_id?: SortOrder
    current_player_id?: SortOrder
    current_balance?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type EnumMachineStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MachineStatus | EnumMachineStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MachineStatus[]
    notIn?: $Enums.MachineStatus[]
    not?: NestedEnumMachineStatusWithAggregatesFilter<$PrismaModel> | $Enums.MachineStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMachineStatusFilter<$PrismaModel>
    _max?: NestedEnumMachineStatusFilter<$PrismaModel>
  }

  export type EnumTITOStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.TITOStatus | EnumTITOStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TITOStatus[]
    notIn?: $Enums.TITOStatus[]
    not?: NestedEnumTITOStatusFilter<$PrismaModel> | $Enums.TITOStatus
  }

  export type TITOOrderByRelevanceInput = {
    fields: TITOOrderByRelevanceFieldEnum | TITOOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type TITOCountOrderByAggregateInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    unique_identifier?: SortOrder
    barcode?: SortOrder
    amount?: SortOrder
    issued_at?: SortOrder
    redeemed_at?: SortOrder
    status?: SortOrder
  }

  export type TITOAvgOrderByAggregateInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    amount?: SortOrder
  }

  export type TITOMaxOrderByAggregateInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    unique_identifier?: SortOrder
    barcode?: SortOrder
    amount?: SortOrder
    issued_at?: SortOrder
    redeemed_at?: SortOrder
    status?: SortOrder
  }

  export type TITOMinOrderByAggregateInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    unique_identifier?: SortOrder
    barcode?: SortOrder
    amount?: SortOrder
    issued_at?: SortOrder
    redeemed_at?: SortOrder
    status?: SortOrder
  }

  export type TITOSumOrderByAggregateInput = {
    tito_id?: SortOrder
    machine_id?: SortOrder
    amount?: SortOrder
  }

  export type EnumTITOStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TITOStatus | EnumTITOStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TITOStatus[]
    notIn?: $Enums.TITOStatus[]
    not?: NestedEnumTITOStatusWithAggregatesFilter<$PrismaModel> | $Enums.TITOStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTITOStatusFilter<$PrismaModel>
    _max?: NestedEnumTITOStatusFilter<$PrismaModel>
  }

  export type EnumTransactionTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionType | EnumTransactionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionType[]
    notIn?: $Enums.TransactionType[]
    not?: NestedEnumTransactionTypeFilter<$PrismaModel> | $Enums.TransactionType
  }

  export type EnumPaymentMethodFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentMethod | EnumPaymentMethodFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentMethod[]
    notIn?: $Enums.PaymentMethod[]
    not?: NestedEnumPaymentMethodFilter<$PrismaModel> | $Enums.PaymentMethod
  }

  export type EnumTransactionStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionStatus | EnumTransactionStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionStatus[]
    notIn?: $Enums.TransactionStatus[]
    not?: NestedEnumTransactionStatusFilter<$PrismaModel> | $Enums.TransactionStatus
  }

  export type TransactionCountOrderByAggregateInput = {
    transaction_id?: SortOrder
    card_id?: SortOrder
    transaction_type?: SortOrder
    amount?: SortOrder
    payment_method?: SortOrder
    transaction_status?: SortOrder
    timestamp?: SortOrder
  }

  export type TransactionAvgOrderByAggregateInput = {
    transaction_id?: SortOrder
    card_id?: SortOrder
    amount?: SortOrder
  }

  export type TransactionMaxOrderByAggregateInput = {
    transaction_id?: SortOrder
    card_id?: SortOrder
    transaction_type?: SortOrder
    amount?: SortOrder
    payment_method?: SortOrder
    transaction_status?: SortOrder
    timestamp?: SortOrder
  }

  export type TransactionMinOrderByAggregateInput = {
    transaction_id?: SortOrder
    card_id?: SortOrder
    transaction_type?: SortOrder
    amount?: SortOrder
    payment_method?: SortOrder
    transaction_status?: SortOrder
    timestamp?: SortOrder
  }

  export type TransactionSumOrderByAggregateInput = {
    transaction_id?: SortOrder
    card_id?: SortOrder
    amount?: SortOrder
  }

  export type EnumTransactionTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionType | EnumTransactionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionType[]
    notIn?: $Enums.TransactionType[]
    not?: NestedEnumTransactionTypeWithAggregatesFilter<$PrismaModel> | $Enums.TransactionType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTransactionTypeFilter<$PrismaModel>
    _max?: NestedEnumTransactionTypeFilter<$PrismaModel>
  }

  export type EnumPaymentMethodWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentMethod | EnumPaymentMethodFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentMethod[]
    notIn?: $Enums.PaymentMethod[]
    not?: NestedEnumPaymentMethodWithAggregatesFilter<$PrismaModel> | $Enums.PaymentMethod
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPaymentMethodFilter<$PrismaModel>
    _max?: NestedEnumPaymentMethodFilter<$PrismaModel>
  }

  export type EnumTransactionStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionStatus | EnumTransactionStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionStatus[]
    notIn?: $Enums.TransactionStatus[]
    not?: NestedEnumTransactionStatusWithAggregatesFilter<$PrismaModel> | $Enums.TransactionStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTransactionStatusFilter<$PrismaModel>
    _max?: NestedEnumTransactionStatusFilter<$PrismaModel>
  }

  export type EmployeeCreateNestedOneWithoutUserInput = {
    create?: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutUserInput
    connect?: EmployeeWhereUniqueInput
  }

  export type PlayerCardCreateNestedOneWithoutUserInput = {
    create?: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutUserInput
    connect?: PlayerCardWhereUniqueInput
  }

  export type SlotMachineCreateNestedManyWithoutCurrent_playerInput = {
    create?: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput> | SlotMachineCreateWithoutCurrent_playerInput[] | SlotMachineUncheckedCreateWithoutCurrent_playerInput[]
    connectOrCreate?: SlotMachineCreateOrConnectWithoutCurrent_playerInput | SlotMachineCreateOrConnectWithoutCurrent_playerInput[]
    createMany?: SlotMachineCreateManyCurrent_playerInputEnvelope
    connect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
  }

  export type EmployeeUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutUserInput
    connect?: EmployeeWhereUniqueInput
  }

  export type PlayerCardUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutUserInput
    connect?: PlayerCardWhereUniqueInput
  }

  export type SlotMachineUncheckedCreateNestedManyWithoutCurrent_playerInput = {
    create?: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput> | SlotMachineCreateWithoutCurrent_playerInput[] | SlotMachineUncheckedCreateWithoutCurrent_playerInput[]
    connectOrCreate?: SlotMachineCreateOrConnectWithoutCurrent_playerInput | SlotMachineCreateOrConnectWithoutCurrent_playerInput[]
    createMany?: SlotMachineCreateManyCurrent_playerInputEnvelope
    connect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type EnumGovtIDFieldUpdateOperationsInput = {
    set?: $Enums.GovtID
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type EnumStatusFieldUpdateOperationsInput = {
    set?: $Enums.Status
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EmployeeUpdateOneWithoutUserNestedInput = {
    create?: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutUserInput
    upsert?: EmployeeUpsertWithoutUserInput
    disconnect?: EmployeeWhereInput | boolean
    delete?: EmployeeWhereInput | boolean
    connect?: EmployeeWhereUniqueInput
    update?: XOR<XOR<EmployeeUpdateToOneWithWhereWithoutUserInput, EmployeeUpdateWithoutUserInput>, EmployeeUncheckedUpdateWithoutUserInput>
  }

  export type PlayerCardUpdateOneWithoutUserNestedInput = {
    create?: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutUserInput
    upsert?: PlayerCardUpsertWithoutUserInput
    disconnect?: PlayerCardWhereInput | boolean
    delete?: PlayerCardWhereInput | boolean
    connect?: PlayerCardWhereUniqueInput
    update?: XOR<XOR<PlayerCardUpdateToOneWithWhereWithoutUserInput, PlayerCardUpdateWithoutUserInput>, PlayerCardUncheckedUpdateWithoutUserInput>
  }

  export type SlotMachineUpdateManyWithoutCurrent_playerNestedInput = {
    create?: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput> | SlotMachineCreateWithoutCurrent_playerInput[] | SlotMachineUncheckedCreateWithoutCurrent_playerInput[]
    connectOrCreate?: SlotMachineCreateOrConnectWithoutCurrent_playerInput | SlotMachineCreateOrConnectWithoutCurrent_playerInput[]
    upsert?: SlotMachineUpsertWithWhereUniqueWithoutCurrent_playerInput | SlotMachineUpsertWithWhereUniqueWithoutCurrent_playerInput[]
    createMany?: SlotMachineCreateManyCurrent_playerInputEnvelope
    set?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    disconnect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    delete?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    connect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    update?: SlotMachineUpdateWithWhereUniqueWithoutCurrent_playerInput | SlotMachineUpdateWithWhereUniqueWithoutCurrent_playerInput[]
    updateMany?: SlotMachineUpdateManyWithWhereWithoutCurrent_playerInput | SlotMachineUpdateManyWithWhereWithoutCurrent_playerInput[]
    deleteMany?: SlotMachineScalarWhereInput | SlotMachineScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EmployeeUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
    connectOrCreate?: EmployeeCreateOrConnectWithoutUserInput
    upsert?: EmployeeUpsertWithoutUserInput
    disconnect?: EmployeeWhereInput | boolean
    delete?: EmployeeWhereInput | boolean
    connect?: EmployeeWhereUniqueInput
    update?: XOR<XOR<EmployeeUpdateToOneWithWhereWithoutUserInput, EmployeeUpdateWithoutUserInput>, EmployeeUncheckedUpdateWithoutUserInput>
  }

  export type PlayerCardUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutUserInput
    upsert?: PlayerCardUpsertWithoutUserInput
    disconnect?: PlayerCardWhereInput | boolean
    delete?: PlayerCardWhereInput | boolean
    connect?: PlayerCardWhereUniqueInput
    update?: XOR<XOR<PlayerCardUpdateToOneWithWhereWithoutUserInput, PlayerCardUpdateWithoutUserInput>, PlayerCardUncheckedUpdateWithoutUserInput>
  }

  export type SlotMachineUncheckedUpdateManyWithoutCurrent_playerNestedInput = {
    create?: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput> | SlotMachineCreateWithoutCurrent_playerInput[] | SlotMachineUncheckedCreateWithoutCurrent_playerInput[]
    connectOrCreate?: SlotMachineCreateOrConnectWithoutCurrent_playerInput | SlotMachineCreateOrConnectWithoutCurrent_playerInput[]
    upsert?: SlotMachineUpsertWithWhereUniqueWithoutCurrent_playerInput | SlotMachineUpsertWithWhereUniqueWithoutCurrent_playerInput[]
    createMany?: SlotMachineCreateManyCurrent_playerInputEnvelope
    set?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    disconnect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    delete?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    connect?: SlotMachineWhereUniqueInput | SlotMachineWhereUniqueInput[]
    update?: SlotMachineUpdateWithWhereUniqueWithoutCurrent_playerInput | SlotMachineUpdateWithWhereUniqueWithoutCurrent_playerInput[]
    updateMany?: SlotMachineUpdateManyWithWhereWithoutCurrent_playerInput | SlotMachineUpdateManyWithWhereWithoutCurrent_playerInput[]
    deleteMany?: SlotMachineScalarWhereInput | SlotMachineScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutEmployeeInput = {
    create?: XOR<UserCreateWithoutEmployeeInput, UserUncheckedCreateWithoutEmployeeInput>
    connectOrCreate?: UserCreateOrConnectWithoutEmployeeInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutEmployeeNestedInput = {
    create?: XOR<UserCreateWithoutEmployeeInput, UserUncheckedCreateWithoutEmployeeInput>
    connectOrCreate?: UserCreateOrConnectWithoutEmployeeInput
    upsert?: UserUpsertWithoutEmployeeInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutEmployeeInput, UserUpdateWithoutEmployeeInput>, UserUncheckedUpdateWithoutEmployeeInput>
  }

  export type UserCreateNestedOneWithoutPlayerCardInput = {
    create?: XOR<UserCreateWithoutPlayerCardInput, UserUncheckedCreateWithoutPlayerCardInput>
    connectOrCreate?: UserCreateOrConnectWithoutPlayerCardInput
    connect?: UserWhereUniqueInput
  }

  export type TransactionCreateNestedManyWithoutCardInput = {
    create?: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput> | TransactionCreateWithoutCardInput[] | TransactionUncheckedCreateWithoutCardInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutCardInput | TransactionCreateOrConnectWithoutCardInput[]
    createMany?: TransactionCreateManyCardInputEnvelope
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
  }

  export type TransactionUncheckedCreateNestedManyWithoutCardInput = {
    create?: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput> | TransactionCreateWithoutCardInput[] | TransactionUncheckedCreateWithoutCardInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutCardInput | TransactionCreateOrConnectWithoutCardInput[]
    createMany?: TransactionCreateManyCardInputEnvelope
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type EnumTierFieldUpdateOperationsInput = {
    set?: $Enums.Tier
  }

  export type UserUpdateOneRequiredWithoutPlayerCardNestedInput = {
    create?: XOR<UserCreateWithoutPlayerCardInput, UserUncheckedCreateWithoutPlayerCardInput>
    connectOrCreate?: UserCreateOrConnectWithoutPlayerCardInput
    upsert?: UserUpsertWithoutPlayerCardInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPlayerCardInput, UserUpdateWithoutPlayerCardInput>, UserUncheckedUpdateWithoutPlayerCardInput>
  }

  export type TransactionUpdateManyWithoutCardNestedInput = {
    create?: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput> | TransactionCreateWithoutCardInput[] | TransactionUncheckedCreateWithoutCardInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutCardInput | TransactionCreateOrConnectWithoutCardInput[]
    upsert?: TransactionUpsertWithWhereUniqueWithoutCardInput | TransactionUpsertWithWhereUniqueWithoutCardInput[]
    createMany?: TransactionCreateManyCardInputEnvelope
    set?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    disconnect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    delete?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    update?: TransactionUpdateWithWhereUniqueWithoutCardInput | TransactionUpdateWithWhereUniqueWithoutCardInput[]
    updateMany?: TransactionUpdateManyWithWhereWithoutCardInput | TransactionUpdateManyWithWhereWithoutCardInput[]
    deleteMany?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
  }

  export type TransactionUncheckedUpdateManyWithoutCardNestedInput = {
    create?: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput> | TransactionCreateWithoutCardInput[] | TransactionUncheckedCreateWithoutCardInput[]
    connectOrCreate?: TransactionCreateOrConnectWithoutCardInput | TransactionCreateOrConnectWithoutCardInput[]
    upsert?: TransactionUpsertWithWhereUniqueWithoutCardInput | TransactionUpsertWithWhereUniqueWithoutCardInput[]
    createMany?: TransactionCreateManyCardInputEnvelope
    set?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    disconnect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    delete?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    connect?: TransactionWhereUniqueInput | TransactionWhereUniqueInput[]
    update?: TransactionUpdateWithWhereUniqueWithoutCardInput | TransactionUpdateWithWhereUniqueWithoutCardInput[]
    updateMany?: TransactionUpdateManyWithWhereWithoutCardInput | TransactionUpdateManyWithWhereWithoutCardInput[]
    deleteMany?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutCurrent_machinesInput = {
    create?: XOR<UserCreateWithoutCurrent_machinesInput, UserUncheckedCreateWithoutCurrent_machinesInput>
    connectOrCreate?: UserCreateOrConnectWithoutCurrent_machinesInput
    connect?: UserWhereUniqueInput
  }

  export type EnumMachineStatusFieldUpdateOperationsInput = {
    set?: $Enums.MachineStatus
  }

  export type UserUpdateOneWithoutCurrent_machinesNestedInput = {
    create?: XOR<UserCreateWithoutCurrent_machinesInput, UserUncheckedCreateWithoutCurrent_machinesInput>
    connectOrCreate?: UserCreateOrConnectWithoutCurrent_machinesInput
    upsert?: UserUpsertWithoutCurrent_machinesInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCurrent_machinesInput, UserUpdateWithoutCurrent_machinesInput>, UserUncheckedUpdateWithoutCurrent_machinesInput>
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EnumTITOStatusFieldUpdateOperationsInput = {
    set?: $Enums.TITOStatus
  }

  export type PlayerCardCreateNestedOneWithoutTransactionsInput = {
    create?: XOR<PlayerCardCreateWithoutTransactionsInput, PlayerCardUncheckedCreateWithoutTransactionsInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutTransactionsInput
    connect?: PlayerCardWhereUniqueInput
  }

  export type EnumTransactionTypeFieldUpdateOperationsInput = {
    set?: $Enums.TransactionType
  }

  export type EnumPaymentMethodFieldUpdateOperationsInput = {
    set?: $Enums.PaymentMethod
  }

  export type EnumTransactionStatusFieldUpdateOperationsInput = {
    set?: $Enums.TransactionStatus
  }

  export type PlayerCardUpdateOneWithoutTransactionsNestedInput = {
    create?: XOR<PlayerCardCreateWithoutTransactionsInput, PlayerCardUncheckedCreateWithoutTransactionsInput>
    connectOrCreate?: PlayerCardCreateOrConnectWithoutTransactionsInput
    upsert?: PlayerCardUpsertWithoutTransactionsInput
    disconnect?: PlayerCardWhereInput | boolean
    delete?: PlayerCardWhereInput | boolean
    connect?: PlayerCardWhereUniqueInput
    update?: XOR<XOR<PlayerCardUpdateToOneWithWhereWithoutTransactionsInput, PlayerCardUpdateWithoutTransactionsInput>, PlayerCardUncheckedUpdateWithoutTransactionsInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedEnumGovtIDFilter<$PrismaModel = never> = {
    equals?: $Enums.GovtID | EnumGovtIDFieldRefInput<$PrismaModel>
    in?: $Enums.GovtID[]
    notIn?: $Enums.GovtID[]
    not?: NestedEnumGovtIDFilter<$PrismaModel> | $Enums.GovtID
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedEnumStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.Status | EnumStatusFieldRefInput<$PrismaModel>
    in?: $Enums.Status[]
    notIn?: $Enums.Status[]
    not?: NestedEnumStatusFilter<$PrismaModel> | $Enums.Status
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedEnumGovtIDWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.GovtID | EnumGovtIDFieldRefInput<$PrismaModel>
    in?: $Enums.GovtID[]
    notIn?: $Enums.GovtID[]
    not?: NestedEnumGovtIDWithAggregatesFilter<$PrismaModel> | $Enums.GovtID
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumGovtIDFilter<$PrismaModel>
    _max?: NestedEnumGovtIDFilter<$PrismaModel>
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedEnumStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Status | EnumStatusFieldRefInput<$PrismaModel>
    in?: $Enums.Status[]
    notIn?: $Enums.Status[]
    not?: NestedEnumStatusWithAggregatesFilter<$PrismaModel> | $Enums.Status
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumStatusFilter<$PrismaModel>
    _max?: NestedEnumStatusFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedEnumTierFilter<$PrismaModel = never> = {
    equals?: $Enums.Tier | EnumTierFieldRefInput<$PrismaModel>
    in?: $Enums.Tier[]
    notIn?: $Enums.Tier[]
    not?: NestedEnumTierFilter<$PrismaModel> | $Enums.Tier
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[]
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[]
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type NestedEnumTierWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Tier | EnumTierFieldRefInput<$PrismaModel>
    in?: $Enums.Tier[]
    notIn?: $Enums.Tier[]
    not?: NestedEnumTierWithAggregatesFilter<$PrismaModel> | $Enums.Tier
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTierFilter<$PrismaModel>
    _max?: NestedEnumTierFilter<$PrismaModel>
  }

  export type NestedEnumMachineStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.MachineStatus | EnumMachineStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MachineStatus[]
    notIn?: $Enums.MachineStatus[]
    not?: NestedEnumMachineStatusFilter<$PrismaModel> | $Enums.MachineStatus
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumMachineStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.MachineStatus | EnumMachineStatusFieldRefInput<$PrismaModel>
    in?: $Enums.MachineStatus[]
    notIn?: $Enums.MachineStatus[]
    not?: NestedEnumMachineStatusWithAggregatesFilter<$PrismaModel> | $Enums.MachineStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumMachineStatusFilter<$PrismaModel>
    _max?: NestedEnumMachineStatusFilter<$PrismaModel>
  }

  export type NestedEnumTITOStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.TITOStatus | EnumTITOStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TITOStatus[]
    notIn?: $Enums.TITOStatus[]
    not?: NestedEnumTITOStatusFilter<$PrismaModel> | $Enums.TITOStatus
  }

  export type NestedEnumTITOStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TITOStatus | EnumTITOStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TITOStatus[]
    notIn?: $Enums.TITOStatus[]
    not?: NestedEnumTITOStatusWithAggregatesFilter<$PrismaModel> | $Enums.TITOStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTITOStatusFilter<$PrismaModel>
    _max?: NestedEnumTITOStatusFilter<$PrismaModel>
  }

  export type NestedEnumTransactionTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionType | EnumTransactionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionType[]
    notIn?: $Enums.TransactionType[]
    not?: NestedEnumTransactionTypeFilter<$PrismaModel> | $Enums.TransactionType
  }

  export type NestedEnumPaymentMethodFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentMethod | EnumPaymentMethodFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentMethod[]
    notIn?: $Enums.PaymentMethod[]
    not?: NestedEnumPaymentMethodFilter<$PrismaModel> | $Enums.PaymentMethod
  }

  export type NestedEnumTransactionStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionStatus | EnumTransactionStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionStatus[]
    notIn?: $Enums.TransactionStatus[]
    not?: NestedEnumTransactionStatusFilter<$PrismaModel> | $Enums.TransactionStatus
  }

  export type NestedEnumTransactionTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionType | EnumTransactionTypeFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionType[]
    notIn?: $Enums.TransactionType[]
    not?: NestedEnumTransactionTypeWithAggregatesFilter<$PrismaModel> | $Enums.TransactionType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTransactionTypeFilter<$PrismaModel>
    _max?: NestedEnumTransactionTypeFilter<$PrismaModel>
  }

  export type NestedEnumPaymentMethodWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentMethod | EnumPaymentMethodFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentMethod[]
    notIn?: $Enums.PaymentMethod[]
    not?: NestedEnumPaymentMethodWithAggregatesFilter<$PrismaModel> | $Enums.PaymentMethod
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPaymentMethodFilter<$PrismaModel>
    _max?: NestedEnumPaymentMethodFilter<$PrismaModel>
  }

  export type NestedEnumTransactionStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TransactionStatus | EnumTransactionStatusFieldRefInput<$PrismaModel>
    in?: $Enums.TransactionStatus[]
    notIn?: $Enums.TransactionStatus[]
    not?: NestedEnumTransactionStatusWithAggregatesFilter<$PrismaModel> | $Enums.TransactionStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTransactionStatusFilter<$PrismaModel>
    _max?: NestedEnumTransactionStatusFilter<$PrismaModel>
  }

  export type EmployeeCreateWithoutUserInput = {
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
  }

  export type EmployeeUncheckedCreateWithoutUserInput = {
    employee_id?: number
    username: string
    password_hash: string
    access_level: number
    role: $Enums.Role
  }

  export type EmployeeCreateOrConnectWithoutUserInput = {
    where: EmployeeWhereUniqueInput
    create: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
  }

  export type PlayerCardCreateWithoutUserInput = {
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
    transactions?: TransactionCreateNestedManyWithoutCardInput
  }

  export type PlayerCardUncheckedCreateWithoutUserInput = {
    card_id?: number
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
    transactions?: TransactionUncheckedCreateNestedManyWithoutCardInput
  }

  export type PlayerCardCreateOrConnectWithoutUserInput = {
    where: PlayerCardWhereUniqueInput
    create: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
  }

  export type SlotMachineCreateWithoutCurrent_playerInput = {
    machine_number: string
    location?: string | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
  }

  export type SlotMachineUncheckedCreateWithoutCurrent_playerInput = {
    machine_id?: number
    machine_number: string
    location?: string | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
  }

  export type SlotMachineCreateOrConnectWithoutCurrent_playerInput = {
    where: SlotMachineWhereUniqueInput
    create: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput>
  }

  export type SlotMachineCreateManyCurrent_playerInputEnvelope = {
    data: SlotMachineCreateManyCurrent_playerInput | SlotMachineCreateManyCurrent_playerInput[]
    skipDuplicates?: boolean
  }

  export type EmployeeUpsertWithoutUserInput = {
    update: XOR<EmployeeUpdateWithoutUserInput, EmployeeUncheckedUpdateWithoutUserInput>
    create: XOR<EmployeeCreateWithoutUserInput, EmployeeUncheckedCreateWithoutUserInput>
    where?: EmployeeWhereInput
  }

  export type EmployeeUpdateToOneWithWhereWithoutUserInput = {
    where?: EmployeeWhereInput
    data: XOR<EmployeeUpdateWithoutUserInput, EmployeeUncheckedUpdateWithoutUserInput>
  }

  export type EmployeeUpdateWithoutUserInput = {
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type EmployeeUncheckedUpdateWithoutUserInput = {
    employee_id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    password_hash?: StringFieldUpdateOperationsInput | string
    access_level?: IntFieldUpdateOperationsInput | number
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
  }

  export type PlayerCardUpsertWithoutUserInput = {
    update: XOR<PlayerCardUpdateWithoutUserInput, PlayerCardUncheckedUpdateWithoutUserInput>
    create: XOR<PlayerCardCreateWithoutUserInput, PlayerCardUncheckedCreateWithoutUserInput>
    where?: PlayerCardWhereInput
  }

  export type PlayerCardUpdateToOneWithWhereWithoutUserInput = {
    where?: PlayerCardWhereInput
    data: XOR<PlayerCardUpdateWithoutUserInput, PlayerCardUncheckedUpdateWithoutUserInput>
  }

  export type PlayerCardUpdateWithoutUserInput = {
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
    transactions?: TransactionUpdateManyWithoutCardNestedInput
  }

  export type PlayerCardUncheckedUpdateWithoutUserInput = {
    card_id?: IntFieldUpdateOperationsInput | number
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
    transactions?: TransactionUncheckedUpdateManyWithoutCardNestedInput
  }

  export type SlotMachineUpsertWithWhereUniqueWithoutCurrent_playerInput = {
    where: SlotMachineWhereUniqueInput
    update: XOR<SlotMachineUpdateWithoutCurrent_playerInput, SlotMachineUncheckedUpdateWithoutCurrent_playerInput>
    create: XOR<SlotMachineCreateWithoutCurrent_playerInput, SlotMachineUncheckedCreateWithoutCurrent_playerInput>
  }

  export type SlotMachineUpdateWithWhereUniqueWithoutCurrent_playerInput = {
    where: SlotMachineWhereUniqueInput
    data: XOR<SlotMachineUpdateWithoutCurrent_playerInput, SlotMachineUncheckedUpdateWithoutCurrent_playerInput>
  }

  export type SlotMachineUpdateManyWithWhereWithoutCurrent_playerInput = {
    where: SlotMachineScalarWhereInput
    data: XOR<SlotMachineUpdateManyMutationInput, SlotMachineUncheckedUpdateManyWithoutCurrent_playerInput>
  }

  export type SlotMachineScalarWhereInput = {
    AND?: SlotMachineScalarWhereInput | SlotMachineScalarWhereInput[]
    OR?: SlotMachineScalarWhereInput[]
    NOT?: SlotMachineScalarWhereInput | SlotMachineScalarWhereInput[]
    machine_id?: IntFilter<"SlotMachine"> | number
    machine_number?: StringFilter<"SlotMachine"> | string
    location?: StringNullableFilter<"SlotMachine"> | string | null
    current_player_id?: IntNullableFilter<"SlotMachine"> | number | null
    current_balance?: DecimalFilter<"SlotMachine"> | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFilter<"SlotMachine"> | $Enums.MachineStatus
    last_updated?: DateTimeNullableFilter<"SlotMachine"> | Date | string | null
  }

  export type UserCreateWithoutEmployeeInput = {
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    playerCard?: PlayerCardCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserUncheckedCreateWithoutEmployeeInput = {
    user_id?: number
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    playerCard?: PlayerCardUncheckedCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineUncheckedCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserCreateOrConnectWithoutEmployeeInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutEmployeeInput, UserUncheckedCreateWithoutEmployeeInput>
  }

  export type UserUpsertWithoutEmployeeInput = {
    update: XOR<UserUpdateWithoutEmployeeInput, UserUncheckedUpdateWithoutEmployeeInput>
    create: XOR<UserCreateWithoutEmployeeInput, UserUncheckedCreateWithoutEmployeeInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutEmployeeInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutEmployeeInput, UserUncheckedUpdateWithoutEmployeeInput>
  }

  export type UserUpdateWithoutEmployeeInput = {
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    playerCard?: PlayerCardUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUpdateManyWithoutCurrent_playerNestedInput
  }

  export type UserUncheckedUpdateWithoutEmployeeInput = {
    user_id?: IntFieldUpdateOperationsInput | number
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    playerCard?: PlayerCardUncheckedUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUncheckedUpdateManyWithoutCurrent_playerNestedInput
  }

  export type UserCreateWithoutPlayerCardInput = {
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserUncheckedCreateWithoutPlayerCardInput = {
    user_id?: number
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeUncheckedCreateNestedOneWithoutUserInput
    current_machines?: SlotMachineUncheckedCreateNestedManyWithoutCurrent_playerInput
  }

  export type UserCreateOrConnectWithoutPlayerCardInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPlayerCardInput, UserUncheckedCreateWithoutPlayerCardInput>
  }

  export type TransactionCreateWithoutCardInput = {
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
  }

  export type TransactionUncheckedCreateWithoutCardInput = {
    transaction_id?: number
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
  }

  export type TransactionCreateOrConnectWithoutCardInput = {
    where: TransactionWhereUniqueInput
    create: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput>
  }

  export type TransactionCreateManyCardInputEnvelope = {
    data: TransactionCreateManyCardInput | TransactionCreateManyCardInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutPlayerCardInput = {
    update: XOR<UserUpdateWithoutPlayerCardInput, UserUncheckedUpdateWithoutPlayerCardInput>
    create: XOR<UserCreateWithoutPlayerCardInput, UserUncheckedCreateWithoutPlayerCardInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPlayerCardInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPlayerCardInput, UserUncheckedUpdateWithoutPlayerCardInput>
  }

  export type UserUpdateWithoutPlayerCardInput = {
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUpdateManyWithoutCurrent_playerNestedInput
  }

  export type UserUncheckedUpdateWithoutPlayerCardInput = {
    user_id?: IntFieldUpdateOperationsInput | number
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUncheckedUpdateOneWithoutUserNestedInput
    current_machines?: SlotMachineUncheckedUpdateManyWithoutCurrent_playerNestedInput
  }

  export type TransactionUpsertWithWhereUniqueWithoutCardInput = {
    where: TransactionWhereUniqueInput
    update: XOR<TransactionUpdateWithoutCardInput, TransactionUncheckedUpdateWithoutCardInput>
    create: XOR<TransactionCreateWithoutCardInput, TransactionUncheckedCreateWithoutCardInput>
  }

  export type TransactionUpdateWithWhereUniqueWithoutCardInput = {
    where: TransactionWhereUniqueInput
    data: XOR<TransactionUpdateWithoutCardInput, TransactionUncheckedUpdateWithoutCardInput>
  }

  export type TransactionUpdateManyWithWhereWithoutCardInput = {
    where: TransactionScalarWhereInput
    data: XOR<TransactionUpdateManyMutationInput, TransactionUncheckedUpdateManyWithoutCardInput>
  }

  export type TransactionScalarWhereInput = {
    AND?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
    OR?: TransactionScalarWhereInput[]
    NOT?: TransactionScalarWhereInput | TransactionScalarWhereInput[]
    transaction_id?: IntFilter<"Transaction"> | number
    card_id?: IntNullableFilter<"Transaction"> | number | null
    transaction_type?: EnumTransactionTypeFilter<"Transaction"> | $Enums.TransactionType
    amount?: DecimalFilter<"Transaction"> | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFilter<"Transaction"> | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFilter<"Transaction"> | $Enums.TransactionStatus
    timestamp?: DateTimeNullableFilter<"Transaction"> | Date | string | null
  }

  export type UserCreateWithoutCurrent_machinesInput = {
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeCreateNestedOneWithoutUserInput
    playerCard?: PlayerCardCreateNestedOneWithoutUserInput
  }

  export type UserUncheckedCreateWithoutCurrent_machinesInput = {
    user_id?: number
    full_name: string
    address?: string | null
    date_of_birth?: Date | string | null
    govt_id_number: string
    govt_id_type: $Enums.GovtID
    photo_url?: string | null
    email?: string | null
    phone: string
    role: $Enums.Role
    status?: $Enums.Status
    created_at?: Date | string
    employee?: EmployeeUncheckedCreateNestedOneWithoutUserInput
    playerCard?: PlayerCardUncheckedCreateNestedOneWithoutUserInput
  }

  export type UserCreateOrConnectWithoutCurrent_machinesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCurrent_machinesInput, UserUncheckedCreateWithoutCurrent_machinesInput>
  }

  export type UserUpsertWithoutCurrent_machinesInput = {
    update: XOR<UserUpdateWithoutCurrent_machinesInput, UserUncheckedUpdateWithoutCurrent_machinesInput>
    create: XOR<UserCreateWithoutCurrent_machinesInput, UserUncheckedCreateWithoutCurrent_machinesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCurrent_machinesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCurrent_machinesInput, UserUncheckedUpdateWithoutCurrent_machinesInput>
  }

  export type UserUpdateWithoutCurrent_machinesInput = {
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUpdateOneWithoutUserNestedInput
    playerCard?: PlayerCardUpdateOneWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutCurrent_machinesInput = {
    user_id?: IntFieldUpdateOperationsInput | number
    full_name?: StringFieldUpdateOperationsInput | string
    address?: NullableStringFieldUpdateOperationsInput | string | null
    date_of_birth?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    govt_id_number?: StringFieldUpdateOperationsInput | string
    govt_id_type?: EnumGovtIDFieldUpdateOperationsInput | $Enums.GovtID
    photo_url?: NullableStringFieldUpdateOperationsInput | string | null
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    status?: EnumStatusFieldUpdateOperationsInput | $Enums.Status
    created_at?: DateTimeFieldUpdateOperationsInput | Date | string
    employee?: EmployeeUncheckedUpdateOneWithoutUserNestedInput
    playerCard?: PlayerCardUncheckedUpdateOneWithoutUserNestedInput
  }

  export type PlayerCardCreateWithoutTransactionsInput = {
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
    user: UserCreateNestedOneWithoutPlayerCardInput
  }

  export type PlayerCardUncheckedCreateWithoutTransactionsInput = {
    card_id?: number
    user_id: number
    rfid_number: string
    pin: string
    balance?: Decimal | DecimalJsLike | number | string
    loyalty_points?: number
    tier?: $Enums.Tier
  }

  export type PlayerCardCreateOrConnectWithoutTransactionsInput = {
    where: PlayerCardWhereUniqueInput
    create: XOR<PlayerCardCreateWithoutTransactionsInput, PlayerCardUncheckedCreateWithoutTransactionsInput>
  }

  export type PlayerCardUpsertWithoutTransactionsInput = {
    update: XOR<PlayerCardUpdateWithoutTransactionsInput, PlayerCardUncheckedUpdateWithoutTransactionsInput>
    create: XOR<PlayerCardCreateWithoutTransactionsInput, PlayerCardUncheckedCreateWithoutTransactionsInput>
    where?: PlayerCardWhereInput
  }

  export type PlayerCardUpdateToOneWithWhereWithoutTransactionsInput = {
    where?: PlayerCardWhereInput
    data: XOR<PlayerCardUpdateWithoutTransactionsInput, PlayerCardUncheckedUpdateWithoutTransactionsInput>
  }

  export type PlayerCardUpdateWithoutTransactionsInput = {
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
    user?: UserUpdateOneRequiredWithoutPlayerCardNestedInput
  }

  export type PlayerCardUncheckedUpdateWithoutTransactionsInput = {
    card_id?: IntFieldUpdateOperationsInput | number
    user_id?: IntFieldUpdateOperationsInput | number
    rfid_number?: StringFieldUpdateOperationsInput | string
    pin?: StringFieldUpdateOperationsInput | string
    balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    loyalty_points?: IntFieldUpdateOperationsInput | number
    tier?: EnumTierFieldUpdateOperationsInput | $Enums.Tier
  }

  export type SlotMachineCreateManyCurrent_playerInput = {
    machine_id?: number
    machine_number: string
    location?: string | null
    current_balance?: Decimal | DecimalJsLike | number | string
    machine_status?: $Enums.MachineStatus
    last_updated?: Date | string | null
  }

  export type SlotMachineUpdateWithoutCurrent_playerInput = {
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SlotMachineUncheckedUpdateWithoutCurrent_playerInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type SlotMachineUncheckedUpdateManyWithoutCurrent_playerInput = {
    machine_id?: IntFieldUpdateOperationsInput | number
    machine_number?: StringFieldUpdateOperationsInput | string
    location?: NullableStringFieldUpdateOperationsInput | string | null
    current_balance?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    machine_status?: EnumMachineStatusFieldUpdateOperationsInput | $Enums.MachineStatus
    last_updated?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TransactionCreateManyCardInput = {
    transaction_id?: number
    transaction_type: $Enums.TransactionType
    amount: Decimal | DecimalJsLike | number | string
    payment_method: $Enums.PaymentMethod
    transaction_status?: $Enums.TransactionStatus
    timestamp?: Date | string | null
  }

  export type TransactionUpdateWithoutCardInput = {
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TransactionUncheckedUpdateWithoutCardInput = {
    transaction_id?: IntFieldUpdateOperationsInput | number
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type TransactionUncheckedUpdateManyWithoutCardInput = {
    transaction_id?: IntFieldUpdateOperationsInput | number
    transaction_type?: EnumTransactionTypeFieldUpdateOperationsInput | $Enums.TransactionType
    amount?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    payment_method?: EnumPaymentMethodFieldUpdateOperationsInput | $Enums.PaymentMethod
    transaction_status?: EnumTransactionStatusFieldUpdateOperationsInput | $Enums.TransactionStatus
    timestamp?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}