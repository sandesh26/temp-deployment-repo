
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('./runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 6.6.0
 * Query Engine version: f676762280b54cd07c770017ed3711ddde35f37a
 */
Prisma.prismaVersion = {
  client: "6.6.0",
  engine: "f676762280b54cd07c770017ed3711ddde35f37a"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.UserScalarFieldEnum = {
  user_id: 'user_id',
  full_name: 'full_name',
  address: 'address',
  date_of_birth: 'date_of_birth',
  govt_id_number: 'govt_id_number',
  govt_id_type: 'govt_id_type',
  photo_url: 'photo_url',
  email: 'email',
  phone: 'phone',
  role: 'role',
  status: 'status',
  created_at: 'created_at'
};

exports.Prisma.EmployeeScalarFieldEnum = {
  employee_id: 'employee_id',
  user_id: 'user_id',
  username: 'username',
  password_hash: 'password_hash',
  access_level: 'access_level',
  role: 'role'
};

exports.Prisma.PlayerCardScalarFieldEnum = {
  card_id: 'card_id',
  user_id: 'user_id',
  rfid_number: 'rfid_number',
  pin: 'pin',
  balance: 'balance',
  loyalty_points: 'loyalty_points',
  tier: 'tier'
};

exports.Prisma.SlotMachineScalarFieldEnum = {
  machine_id: 'machine_id',
  machine_number: 'machine_number',
  location: 'location',
  current_player_id: 'current_player_id',
  current_balance: 'current_balance',
  machine_status: 'machine_status',
  last_updated: 'last_updated'
};

exports.Prisma.TITOScalarFieldEnum = {
  tito_id: 'tito_id',
  machine_id: 'machine_id',
  unique_identifier: 'unique_identifier',
  barcode: 'barcode',
  amount: 'amount',
  issued_at: 'issued_at',
  redeemed_at: 'redeemed_at',
  status: 'status'
};

exports.Prisma.TransactionScalarFieldEnum = {
  transaction_id: 'transaction_id',
  card_id: 'card_id',
  transaction_type: 'transaction_type',
  amount: 'amount',
  payment_method: 'payment_method',
  transaction_status: 'transaction_status',
  timestamp: 'timestamp'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};

exports.Prisma.UserOrderByRelevanceFieldEnum = {
  full_name: 'full_name',
  address: 'address',
  govt_id_number: 'govt_id_number',
  photo_url: 'photo_url',
  email: 'email',
  phone: 'phone'
};

exports.Prisma.EmployeeOrderByRelevanceFieldEnum = {
  username: 'username',
  password_hash: 'password_hash'
};

exports.Prisma.PlayerCardOrderByRelevanceFieldEnum = {
  rfid_number: 'rfid_number',
  pin: 'pin'
};

exports.Prisma.SlotMachineOrderByRelevanceFieldEnum = {
  machine_number: 'machine_number',
  location: 'location'
};

exports.Prisma.TITOOrderByRelevanceFieldEnum = {
  unique_identifier: 'unique_identifier',
  barcode: 'barcode'
};
exports.GovtID = exports.$Enums.GovtID = {
  Aadhar: 'Aadhar',
  PAN: 'PAN',
  Passport: 'Passport',
  Driving_License: 'Driving_License'
};

exports.Role = exports.$Enums.Role = {
  Player: 'Player',
  Counter_Operator: 'Counter_Operator',
  Cage_Manager: 'Cage_Manager',
  Cage_Supervisor: 'Cage_Supervisor',
  Receptionist: 'Receptionist',
  Admin: 'Admin',
  SuperAdmin: 'SuperAdmin',
  Technical: 'Technical'
};

exports.Status = exports.$Enums.Status = {
  Active: 'Active',
  Inactive: 'Inactive',
  Banned: 'Banned'
};

exports.Tier = exports.$Enums.Tier = {
  VIP: 'VIP',
  VVIP: 'VVIP',
  Premium: 'Premium',
  Gold: 'Gold',
  Silver: 'Silver'
};

exports.MachineStatus = exports.$Enums.MachineStatus = {
  Active: 'Active',
  Inactive: 'Inactive',
  Under_Maintenance: 'Under_Maintenance'
};

exports.TITOStatus = exports.$Enums.TITOStatus = {
  Generated: 'Generated',
  Redeemed: 'Redeemed',
  Expired: 'Expired'
};

exports.TransactionType = exports.$Enums.TransactionType = {
  Credit: 'Credit',
  Debit: 'Debit',
  Encash: 'Encash',
  Balance_Inquiry: 'Balance_Inquiry'
};

exports.PaymentMethod = exports.$Enums.PaymentMethod = {
  Cash: 'Cash',
  Chips: 'Chips',
  UPI: 'UPI',
  Credit_Debit_Card: 'Credit_Debit_Card',
  TITO: 'TITO'
};

exports.TransactionStatus = exports.$Enums.TransactionStatus = {
  Pending: 'Pending',
  Completed: 'Completed',
  Failed: 'Failed'
};

exports.Prisma.ModelName = {
  User: 'User',
  Employee: 'Employee',
  PlayerCard: 'PlayerCard',
  SlotMachine: 'SlotMachine',
  TITO: 'TITO',
  Transaction: 'Transaction'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }

        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
