import { prisma } from '@prisma';

/**
 * Enriches CageVaultRequest records:
 * - `initiatedBy`, `reviewedBy`, and `confirmedBy` are fetched from the `Employee` table (with linked user full_name/role).
 */
export async function enrichCageVaultRequestsWithUsers<T extends { initiated_by?: number | null; reviewed_by?: number | null; confirmed_by?: number | null }>(
  requests: T[]
): Promise<Array<T & { initiatedBy: any; reviewedBy: any; confirmedBy: any }>> {
  if (!requests || requests.length === 0) return [];

  const employeeIds = Array.from(
    new Set(
      requests
        .flatMap((r) => [r.initiated_by, r.reviewed_by, r.confirmed_by])
        .filter((id): id is number => typeof id === 'number' && id > 0)
    )
  );

  const employees = employeeIds.length > 0
    ? await prisma.employee.findMany({
        where: { employee_id: { in: employeeIds } },
        select: {
          employee_id: true,
          user_id: true,
          role: true,
          username: true,
          user: {
            select: {
              full_name: true,
              role: true,
            },
          },
        },
      })
    : [];

  const employeeMap = new Map<number, any>();
  for (const emp of employees) {
    const fullName = emp.user?.full_name || emp.username;
    employeeMap.set(emp.employee_id, {
      employee_id: emp.employee_id,
      user_id: emp.user_id,
      username: emp.username,
      role: emp.role || emp.user?.role,
      full_name: fullName,
      user: {
        full_name: fullName,
        role: emp.role || emp.user?.role,
      },
    });
  }

  return requests.map((r) => ({
    ...r,
    initiatedBy: r.initiated_by ? employeeMap.get(r.initiated_by) || null : null,
    reviewedBy: r.reviewed_by ? employeeMap.get(r.reviewed_by) || null : null,
    confirmedBy: r.confirmed_by ? employeeMap.get(r.confirmed_by) || null : null,
  }));
}

/**
 * Enriches a single CageVaultRequest record with User details.
 */
export async function enrichSingleCageVaultRequestWithUsers<T extends { initiated_by?: number | null; reviewed_by?: number | null; confirmed_by?: number | null }>(
  request: T | null
): Promise<(T & { initiatedBy: any; reviewedBy: any; confirmedBy: any }) | null> {
  if (!request) return null;
  const [enriched] = await enrichCageVaultRequestsWithUsers([request]);
  return enriched || null;
}
