import { prisma } from '@prisma';

/**
 * Enriches CageVaultRequest records:
 * - `initiatedBy` and `confirmedBy` are fetched from the `User` table.
 * - `reviewedBy` is fetched from the `Employee` table (with linked user full_name/role).
 */
export async function enrichCageVaultRequestsWithUsers<T extends { initiated_by?: number | null; reviewed_by?: number | null; confirmed_by?: number | null }>(
  requests: T[]
): Promise<Array<T & { initiatedBy: any; reviewedBy: any; confirmedBy: any }>> {
  if (!requests || requests.length === 0) return [];

  const userIds = Array.from(
    new Set(
      requests
        .flatMap((r) => [r.initiated_by, r.confirmed_by])
        .filter((id): id is number => typeof id === 'number' && id > 0)
    )
  );

  const employeeIds = Array.from(
    new Set(
      requests
        .map((r) => r.reviewed_by)
        .filter((id): id is number => typeof id === 'number' && id > 0)
    )
  );

  const usersPromise = userIds.length > 0
    ? prisma.user.findMany({
        where: { user_id: { in: userIds } },
        select: { user_id: true, full_name: true, role: true },
      })
    : Promise.resolve([]);

  const employeesPromise = employeeIds.length > 0
    ? prisma.employee.findMany({
        where: { employee_id: { in: employeeIds } },
        select: {
          employee_id: true,
          user_id: true,
          role: true,
          username: true,
          user: {
            select: {
              full_name: true,
              role: true,
            },
          },
        },
      })
    : Promise.resolve([]);

  const [users, employees] = await Promise.all([usersPromise, employeesPromise]);

  const userMap = new Map<number, any>();
  for (const u of users) {
    userMap.set(u.user_id, {
      user_id: u.user_id,
      full_name: u.full_name,
      role: u.role,
      user: {
        full_name: u.full_name,
        role: u.role,
      },
    });
  }

  const employeeMap = new Map<number, any>();
  for (const emp of employees) {
    const fullName = emp.user?.full_name || emp.username;
    employeeMap.set(emp.employee_id, {
      employee_id: emp.employee_id,
      user_id: emp.user_id,
      role: emp.role,
      full_name: fullName,
      user: {
        full_name: fullName,
        role: emp.role,
      },
    });
  }

  return requests.map((r) => ({
    ...r,
    initiatedBy: r.initiated_by ? userMap.get(r.initiated_by) || null : null,
    reviewedBy: r.reviewed_by ? employeeMap.get(r.reviewed_by) || null : null,
    confirmedBy: r.confirmed_by ? userMap.get(r.confirmed_by) || null : null,
  }));
}

/**
 * Enriches a single CageVaultRequest record with User details.
 */
export async function enrichSingleCageVaultRequestWithUsers<T extends { initiated_by?: number | null; reviewed_by?: number | null; confirmed_by?: number | null }>(
  request: T | null
): Promise<(T & { initiatedBy: any; reviewedBy: any; confirmedBy: any }) | null> {
  if (!request) return null;
  const [enriched] = await enrichCageVaultRequestsWithUsers([request]);
  return enriched || null;
}
