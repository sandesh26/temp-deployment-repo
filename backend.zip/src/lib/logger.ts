import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';

const LOG_DIR = path.join(process.cwd(), 'logs');
const MAIN_LOG_FILE = path.join(LOG_DIR, 'api-requests.log');

// Ensure log directory exists
try {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
} catch (err) {
  console.error('Failed to create log directory:', err);
}

// Headers to ignore in the cURL command to keep it clean and directly runnable
const IGNORED_CURL_HEADERS = new Set([
  'host',
  'connection',
  'content-length',
  'x-forwarded-host',
  'x-forwarded-proto',
  'x-forwarded-port',
  'x-forwarded-for',
  'x-forwarded-server',
  'sec-ch-ua',
  'sec-ch-ua-mobile',
  'sec-ch-ua-platform',
  'sec-fetch-site',
  'sec-fetch-mode',
  'sec-fetch-dest',
  'user-agent',
  'referer',
  'accept-encoding',
  'accept-language',
  'priority'
]);

/**
 * Generates an executable, clean cURL command from a NextApiRequest
 */
export function generateCurl(req: NextApiRequest): string {
  const host = (req.headers['x-forwarded-host'] as string) || req.headers.host || 'localhost:3000';
  const proto = (req.headers['x-forwarded-proto'] as string) || 'http';
  const url = `${proto}://${host}${req.url || ''}`;
  const method = (req.method || 'GET').toUpperCase();

  const parts: string[] = [`curl -X ${method} "${url}"`];

  // Include relevant application and authentication headers
  for (const [key, value] of Object.entries(req.headers)) {
    const lowerKey = key.toLowerCase();
    if (!IGNORED_CURL_HEADERS.has(lowerKey) && value) {
      const valStr = Array.isArray(value) ? value.join(', ') : value;
      parts.push(`-H "${key}: ${valStr}"`);
    }
  }

  // Ensure JSON content-type if body is an object and header was omitted
  if (req.body && !req.headers['content-type'] && typeof req.body === 'object') {
    parts.push(`-H "Content-Type: application/json"`);
  }

  // Append payload if applicable
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method) && req.body !== undefined && req.body !== null && req.body !== '') {
    let bodyStr = '';
    if (typeof req.body === 'string') {
      bodyStr = req.body;
    } else {
      try {
        bodyStr = JSON.stringify(req.body);
      } catch {
        bodyStr = String(req.body);
      }
    }
    if (bodyStr.length > 0) {
      // Escape single quotes for safe shell copy-pasting
      const escapedBody = bodyStr.replace(/'/g, `'\\''`);
      parts.push(`-d '${escapedBody}'`);
    }
  }

  return parts.join(' \\\n  ');
}

/**
 * Appends a log entry to the log files asynchronously
 */
function appendLogToFile(logEntry: string) {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const dailyLogFile = path.join(LOG_DIR, `api-requests-${today}.log`);

    fs.appendFile(MAIN_LOG_FILE, logEntry + '\n', (err) => {
      if (err) console.error('[Logger] Error writing to main log file:', err);
    });

    fs.appendFile(dailyLogFile, logEntry + '\n', (err) => {
      if (err) console.error('[Logger] Error writing to daily log file:', err);
    });
  } catch (err) {
    console.error('[Logger] Failed to write log:', err);
  }
}

/**
 * Attaches request/response logging to Next.js API lifecycle
 */
export function attachApiLogger(req: NextApiRequest, res: NextApiResponse) {
  // Prevent attaching multiple times to the same request
  if ((res as any).__loggerAttached) return;
  (res as any).__loggerAttached = true;

  const url = req.url || '';
  const pathname = url.split('?')[0];

  // Skip OPTIONS preflight requests and health check endpoint
  if (req.method === 'OPTIONS' || pathname === '/api/health' || pathname.startsWith('/api/health/')) return;

  const startTime = Date.now();
  const timestamp = new Date().toISOString();
  const method = (req.method || 'GET').toUpperCase();

  // Capture response payload
  let responseBody: any = null;

  const originalJson = res.json.bind(res);
  res.json = function (body: any) {
    responseBody = body;
    return originalJson(body);
  };

  const originalSend = res.send.bind(res);
  res.send = function (body: any) {
    if (responseBody === null || responseBody === undefined) {
      responseBody = body;
    }
    return originalSend(body);
  };

  const originalEnd = res.end.bind(res);
  res.end = function (chunk?: any, ...rest: any[]) {
    if (chunk && (responseBody === null || responseBody === undefined)) {
      if (typeof chunk === 'string') {
        responseBody = chunk;
      } else if (Buffer.isBuffer(chunk)) {
        responseBody = chunk.toString('utf-8');
      }
    }
    return (originalEnd as any)(chunk, ...rest);
  };

  // Listen for request completion
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const statusCode = res.statusCode;
    const curlCommand = generateCurl(req);

    let formattedReqPayload = '';
    if (req.body !== undefined && req.body !== null && req.body !== '') {
      try {
        formattedReqPayload = typeof req.body === 'string' ? req.body : JSON.stringify(req.body, null, 2);
      } catch {
        formattedReqPayload = String(req.body);
      }
    }

    let formattedResPayload = '';
    if (responseBody !== null && responseBody !== undefined) {
      try {
        formattedResPayload = typeof responseBody === 'string' ? responseBody : JSON.stringify(responseBody, null, 2);
      } catch {
        formattedResPayload = String(responseBody);
      }
    }

    const logLines = [
      '================================================================================',
      `[${timestamp}] [${method}] ${url} -> Status: ${statusCode} (${duration}ms)`,
      '--------------------------------------------------------------------------------',
      'CURL COMMAND (Ready to execute):',
      curlCommand,
      '',
      formattedReqPayload ? `REQUEST PAYLOAD:\n${formattedReqPayload}\n` : 'REQUEST PAYLOAD: (none)\n',
      `RESPONSE STATUS: ${statusCode}`,
      formattedResPayload ? `RESPONSE BODY:\n${formattedResPayload}` : 'RESPONSE BODY: (none)',
      '================================================================================\n'
    ];

    const logEntry = logLines.join('\n');

    // Write to log files
    appendLogToFile(logEntry);

    // Also log a concise summary to console for live monitoring
    const statusColor = statusCode >= 500 ? '\x1b[31m' : statusCode >= 400 ? '\x1b[33m' : '\x1b[32m';
    const resetColor = '\x1b[0m';
    console.log(`[API Log] ${method} ${url} - ${statusColor}${statusCode}${resetColor} (${duration}ms) -> logged to logs/api-requests.log`);
  });
}
