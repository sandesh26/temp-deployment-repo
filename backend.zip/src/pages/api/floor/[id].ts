import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const floor = await prisma.floor.findUnique({ where: { floor_id: Number(id) } });
      if (!floor) return res.status(404).json({ error: 'Floor not found' });
      return res.status(200).json(floor);
    }
    case 'PUT': {
      const data = req.body;
      try {
        const floor = await prisma.floor.update({
          where: { floor_id: Number(id) },
          data,
        });
        return res.status(200).json(floor);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.floor.delete({ where: { floor_id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}