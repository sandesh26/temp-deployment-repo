import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { name } = req.query;
      const where: any = {};
      if (name !== undefined) where.name = name as string;

      const games = await prisma.tableGames.findMany({
        where,
        orderBy: { game_id: 'asc' },
        include: { tables: { select: { table_id: true, name: true } } },
      });
      return res.status(200).json(games);
    }
    case 'POST': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        if (!data || !data.name) {
          return res.status(400).json({ error: 'Game name is required' });
        }

        // If client provides `tables` as array of table ids to connect
        const createData: any = {
          name: data.name,
          description: data.description || undefined,
        };

        if (Array.isArray(data.tables) && data.tables.length > 0) {
          createData.tables = { connect: data.tables.map((id: any) => ({ table_id: Number(id) })) };
        }

        const game = await prisma.tableGames.create({ data: createData, include: { tables: { select: { table_id: true, name: true } } } });
        return res.status(201).json(game);
      } catch (error: any) {
        console.error('POST /api/table-games error:', error);
        return res.status(400).json({ error: error.message || 'Creation failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
