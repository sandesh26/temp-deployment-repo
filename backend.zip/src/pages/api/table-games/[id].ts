import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, name } = req.query;

  switch (req.method) {
    case 'GET': {
      if (typeof id === 'string' && !isNaN(Number(id))) {
        const game = await prisma.tableGames.findUnique({
          where: { game_id: Number(id) },
          include: { tables: { select: { table_id: true, name: true } } },
        });
        return res.status(200).json(game);
      }

      const where: any = {};
      if (name !== undefined) where.name = name as string;
      if (Object.keys(where).length === 0) {
        return res.status(400).json({ error: 'Invalid ID or missing filter parameters' });
      }
      const games = await prisma.tableGames.findMany({ where, include: { tables: { select: { table_id: true, name: true } } } });
      return res.status(200).json(games);
    }
    case 'PUT': {
      if (typeof id !== 'string' || isNaN(Number(id))) return res.status(400).json({ error: 'Invalid ID' });
      let data = req.body;
      if (typeof data === 'string') data = JSON.parse(data);

      // Handle tables connect/disconnect if provided
      const updateData: any = { name: data.name, description: data.description };
      if (Array.isArray(data.tables)) {
        updateData.tables = { set: [] };
        if (data.tables.length > 0) {
          updateData.tables = { set: data.tables.map((t: any) => ({ table_id: Number(t) })) };
        }
      }

      const game = await prisma.tableGames.update({ where: { game_id: Number(id) }, data: updateData, include: { tables: { select: { table_id: true, name: true } } } });
      return res.status(200).json(game);
    }
    case 'PATCH': {
      if (typeof id !== 'string' || isNaN(Number(id))) return res.status(400).json({ error: 'Invalid ID' });
      const body = req.body || {};
      const data: any = {};
      if (body.name !== undefined) data.name = body.name;
      if (body.description !== undefined) data.description = body.description;

      // support connecting/disconnecting tables via arrays
      if (Array.isArray(body.connectTables) && body.connectTables.length > 0) {
        data.tables = { connect: body.connectTables.map((t: any) => ({ table_id: Number(t) })) };
      }
      if (Array.isArray(body.disconnectTables) && body.disconnectTables.length > 0) {
        data.tables = data.tables || {};
        data.tables.disconnect = (body.disconnectTables || []).map((t: any) => ({ table_id: Number(t) }));
      }

      if (Object.keys(data).length === 0) return res.status(400).json({ error: 'No valid fields provided for patch' });

      const game = await prisma.tableGames.update({ where: { game_id: Number(id) }, data, include: { tables: { select: { table_id: true, name: true } } } });
      return res.status(200).json(game);
    }
    case 'DELETE': {
      if (typeof id !== 'string' || isNaN(Number(id))) return res.status(400).json({ error: 'Invalid ID' });
      await prisma.tableGames.delete({ where: { game_id: Number(id) } });
      return res.status(204).end();
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
