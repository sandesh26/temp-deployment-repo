import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const balance = await prisma.vaultBalance.findUnique({
        where: { vault_id: Number(id) },
      });
      if (!balance) return res.status(404).json({ error: 'VaultBalance not found' });
      return res.status(200).json(balance);
    }
    case 'PUT': {
      try {
        const data = req.body;
        const balance = await prisma.vaultBalance.update({
          where: { vault_id: Number(id) },
          data,
        });
        return res.status(200).json(balance);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.vaultBalance.delete({ where: { vault_id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}