import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { cage_id } = req.query;
      const where: any = {};
      if (cage_id !== undefined) {
        where.cage_id = Number(cage_id);
      }
      const sessions = await prisma.cageSession.findMany({ where });
      return res.status(200).json(sessions);
    }
    case 'POST': {
      const data = req.body;
      const session = await prisma.cageSession.create({ data });
      return res.status(201).json(session);
    }
    case 'PATCH': {
      try {
        let data: any = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        // Form A: array of { session_id, data }
        if (Array.isArray(data)) {
          if (!data.length) return res.status(400).json({ error: 'Empty array' });
          const updates = data.map((item: any) => {
            if (!item || !item.session_id) throw new Error('Each item must include session_id and data');
            return prisma.cageSession.update({ where: { session_id: Number(item.session_id) }, data: item.data });
          });
          const result = await prisma.$transaction(updates);
          return res.status(200).json(result);
        }

        // Form B: { where, data } -> updateMany
        if (data && typeof data === 'object' && data.where && data.data) {
          const result = await prisma.cageSession.updateMany({ where: data.where, data: data.data });
          return res.status(200).json(result);
        }

        // Form C: shorthand single-object update by cage_id
        // e.g. { "cage_id": 9, "ended_at": "...", "closed_by": 3 }
        if (data && typeof data === 'object' && data.cage_id && !data.where && !data.data && !data.session_id) {
          // Find the most recent OPEN session for this cage (preferred) or the latest session
          const cageIdNum = Number(data.cage_id);
          let session = await prisma.cageSession.findFirst({
            where: { cage_id: cageIdNum, status: 'OPEN' },
            orderBy: { session_id: 'desc' },
          });

          if (!session) {
            // fallback to any latest session for cage
            session = await prisma.cageSession.findFirst({
              where: { cage_id: cageIdNum },
              orderBy: { session_id: 'desc' },
            });
          }

          if (!session) return res.status(404).json({ error: 'No session found for this cage_id' });

          // Build update payload; do not include cage_id in the update
          const updateData: any = { ...data };
          delete updateData.cage_id;

          // If ended_at is provided, set status to CLOSED by default
          if (updateData.ended_at && !updateData.status) updateData.status = 'CLOSED';

          try {
            const updated = await prisma.cageSession.update({
              where: { session_id: session.session_id },
              data: updateData,
              include: {
                openedBy: { select: { full_name: true } },
                closedBy: { select: { full_name: true } },
              },
            });

            const { ended_at, started_at, openedBy, closedBy, ...rest } = updated as any;
            const result = {
              ...rest,
              started_at: started_at ? formatDate(started_at) : null,
              ended_at: ended_at ? formatDate(ended_at) : null,
              opened_by: openedBy?.full_name ?? null,
              closed_by: closedBy?.full_name ?? null,
            };
            return res.status(200).json(result);
          } catch (error) {
            if (error instanceof Error) return res.status(400).json({ error: error.message });
            return res.status(400).json({ error: 'Unknown error' });
          }
        }

        return res.status(400).json({ error: 'Invalid PATCH payload. Provide an array of { session_id, data } or an object { where, data }.' });
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PATCH']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}