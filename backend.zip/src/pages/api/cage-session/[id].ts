import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, cage_id } = req.query;

  if (req.method === 'GET') {
    // Fetch by session_id
    if (typeof id === 'string' && !isNaN(Number(id))) {
      const session = await prisma.cageSession.findUnique({
        where: { session_id: Number(id) },
        include: {
          openedBy: { select: { full_name: true } },
          closedBy: { select: { full_name: true } },
        },
      });
      if (!session) return res.status(404).json({ error: 'Session not found' });
      const { ended_at, started_at, openedBy, closedBy, ...rest } = session;
      const result = {
        ...rest,
        started_at: started_at ? formatDate(started_at) : null,
        ended_at: ended_at ? formatDate(ended_at) : null,
        opened_by: openedBy?.full_name ?? null,
        closed_by: closedBy?.full_name ?? null,
      };
      return res.status(200).json(result);
    }

    // Fetch by cage_id
    if (id === 'cage' && typeof cage_id === 'string' && !isNaN(Number(cage_id))) {
      const sessions = await prisma.cageSession.findMany({
        where: { cage_id: Number(cage_id) },
        orderBy: { ended_at: 'desc' },
        include: {
          openedBy: { select: { full_name: true } },
          closedBy: { select: { full_name: true } },
        },
      });
      if (!sessions.length) return res.status(404).json({ error: 'No sessions found for this cage_id' });

      const formattedSessions = sessions.map((session: any) => ({
        ...session,
        started_at: formatDate(session.started_at),
        ended_at: formatDate(session.ended_at),
        opened_by: session.openedBy?.full_name ?? null,
        closed_by: session.closedBy?.full_name ?? null,
      }));

      return res.status(200).json(formattedSessions);
    }

    return res.status(400).json({ error: 'Invalid session_id or cage_id' });
  }

  // PUT and DELETE only allowed for session_id (not for cage_id)
  const sessionId = typeof id === 'string' && !isNaN(Number(id)) ? Number(id) : undefined;

  switch (req.method) {
    case 'PUT': {
      if (!sessionId) {
        return res.status(400).json({ error: 'Invalid session ID' });
      }
      const data = req.body;
      try {
        const session = await prisma.cageSession.update({
          where: { session_id: sessionId },
          data,
          include: {
            openedBy: { select: { full_name: true } },
            closedBy: { select: { full_name: true } },
          },
        });
        const { ended_at, started_at, openedBy, closedBy, ...rest } = session;
        const result = {
          ...rest,
          started_at: started_at ? formatDate(started_at) : null,
          ended_at: ended_at ? formatDate(ended_at) : null,
          opened_by: openedBy?.full_name ?? null,
          closed_by: closedBy?.full_name ?? null,
        };
        return res.status(200).json(result);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      if (!sessionId) {
        return res.status(400).json({ error: 'Invalid session ID' });
      }
      try {
        await prisma.cageSession.delete({
          where: { session_id: sessionId },
        });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}