import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../lib/cors';

const prisma = new PrismaClient();

type HealthResponse = {
  status: 'ok' | 'error';
  time: string;
  prisma?: { ok: boolean; pingTimeMs?: number };
};

export default async function handler(req: NextApiRequest, res: NextApiResponse<HealthResponse>) {
  if (cors(req, res)) return;
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const now = new Date().toISOString();
  try {
    const start = Date.now();
    // simple lightweight DB check
    await prisma.$queryRaw`SELECT 1`;
    const pingTimeMs = Date.now() - start;
    return res.status(200).json({ status: 'ok', time: now, prisma: { ok: true, pingTimeMs } });
  } catch (err) {
    console.error('health: prisma ping failed', err);
    return res.status(500).json({ status: 'error', time: now, prisma: { ok: false } });
  }
}
