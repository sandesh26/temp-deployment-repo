import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method === 'GET') {
    try {
      const filters: any = req.query;

      const transactions = await prisma.transaction.findMany({
        where: { ...filters },
        orderBy: { transaction_id: 'desc' },
      });

      return res.status(200).json(transactions);
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch transactions' });
    }
  }

  if (req.method === 'POST') {
    try {
      const data = req.body;

      const newTransaction = await prisma.transaction.create({ data });
      return res.status(201).json(newTransaction);
    } catch (error) {
      return res.status(400).json({ error: 'Transaction creation failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}