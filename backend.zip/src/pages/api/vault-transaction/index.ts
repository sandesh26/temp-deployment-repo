import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      // Pagination and date range filter
      const { page = '1', pageSize = '20', startDate, endDate } = req.query;
      const pageNum = Math.max(1, Number(page));
      const pageSizeNum = Math.max(1, Number(pageSize));
      const where: any = {};
      if (startDate || endDate) {
        where.transaction_time = {};
        if (startDate) {
          where.transaction_time.gte = new Date(startDate as string);
        }
        if (endDate) {
          where.transaction_time.lte = new Date(endDate as string);
        }
      }
      const [transactions, total] = await Promise.all([
        prisma.vaultTransaction.findMany({
          where,
          include: {
            authorizedBy: { select: { user: { select: { full_name: true } } } },
            performedBy: { select: { user: { select: { full_name: true } } } },
          },
          orderBy: { transaction_id: 'desc' },
          skip: (pageNum - 1) * pageSizeNum,
          take: pageSizeNum,
        }),
        prisma.vaultTransaction.count({ where }),
      ]);
      const result = transactions.map((tx: any) => ({
        ...tx,
        authorized_by: tx.authorizedBy?.user?.full_name ?? null,
        performed_by: tx.performedBy?.user?.full_name ?? null,
      }));
      return res.status(200).json({
        data: result,
        page: pageNum,
        pageSize: pageSizeNum,
        total,
        totalPages: Math.ceil(total / pageSizeNum)
      });
    }
    case 'POST': {
      try {
        const data = req.body;
        const transaction = await prisma.vaultTransaction.create({ data });
        return res.status(201).json(transaction);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}