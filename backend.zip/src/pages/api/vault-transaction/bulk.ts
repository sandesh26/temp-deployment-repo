import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  let data = req.body;
  if (typeof data === 'string') data = JSON.parse(data);

  if (!Array.isArray(data)) {
    return res.status(400).json({ error: 'Request body must be an array of objects.' });
  }

  try {
    // Use createMany for bulk insert
    const result = await prisma.vaultTransaction.createMany({
      data,
      skipDuplicates: false,
    });
    return res.status(201).json({ inserted: result.count });
  } catch (error: any) {
    return res.status(400).json({ error: error.message || 'Bulk insert failed' });
  }
}