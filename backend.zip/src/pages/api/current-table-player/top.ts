import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }

  try {
    const { top, gaming_day_id } = req.query;

    const currentGamingDay = gaming_day_id
      ? await prisma.gamingDay.findUnique({ where: { gaming_day_id: Number(gaming_day_id) } })
      : await prisma.gamingDay.findFirst({
          where: { status: 'OPEN' },
          orderBy: { created_at: 'desc' },
        });

    if (!currentGamingDay) {
      return res.status(200).json([]);
    }

    const parsedTop = top !== undefined ? Number(top) : 10;
    const take = Number.isFinite(parsedTop) && parsedTop > 0 ? Math.min(100, Math.floor(parsedTop)) : 10;

    const players = await prisma.currentTablePlayer.findMany({
      where: {
        gaming_day_id: currentGamingDay.gaming_day_id,
      },
      orderBy: {
        current_bet: 'desc',
      },
      take,
      include: {
        player: { select: { user_id: true, full_name: true } },
        table: { select: { table_id: true, name: true } },
      },
    });

    const result = players.map((player: any) => ({
      ...player,
      player_name: player.player?.full_name ?? null,
      table_name: player.table?.name ?? null,
    }));

    return res.status(200).json(result);
  } catch (error: any) {
    console.error('current-table-player top error:', error);
    return res.status(500).json({ error: error.message || 'Failed to fetch top current table players' });
  }
}
