import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  try {
    if (req.method === 'GET') {
      const { page: pageQ, pageSize: pageSizeQ, table_id, player_id, gaming_day_id, status, seat_number, is_active, orderBy } = req.query as any;
      const page = Math.max(1, Number(pageQ ?? 1));
      const pageSize = Math.min(100, Math.max(1, Number(pageSizeQ ?? 50)));

      const where: any = {};
      if (table_id) where.table_id = Number(table_id);
      if (player_id) where.player_id = Number(player_id);
      if (gaming_day_id) where.gaming_day_id = Number(gaming_day_id);
      if (status) where.status = String(status);
      if (seat_number) where.seat_number = Number(seat_number);
      if (is_active !== undefined) where.is_active = is_active === 'true' || is_active === true;

      const total = await prisma.currentTablePlayer.count({ where });

      const order: any = {};
      if (orderBy === 'joined_at') order.joined_at = 'desc';
      else if (orderBy === 'last_seen') order.last_seen = 'desc';
      else order.id = 'desc';

      const items = await prisma.currentTablePlayer.findMany({
        where,
        orderBy: order,
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { player: { select: { user_id: true, full_name: true } } },
      });

      // attach player_name for convenience
      const data = items.map((it) => ({
        ...it,
        player_name: it.player?.full_name ?? null,
      }));

      return res.status(200).json({ data, meta: { total, page, pageSize, totalPages: Math.ceil(total / pageSize) } });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const required = ['table_id', 'player_id'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) {
          return res.status(400).json({ error: `${k} is required` });
        }
      }

      const created = await prisma.currentTablePlayer.create({
        data: {
          table_id: Number(body.table_id),
          player_id: Number(body.player_id),
          seat_number: body.seat_number !== undefined ? Number(body.seat_number) : undefined,
          joined_at: body.joined_at ? new Date(body.joined_at) : undefined,
          last_seen: body.last_seen ? new Date(body.last_seen) : undefined,
          current_stack: body.current_stack ?? undefined,
          current_bet: body.current_bet ?? undefined,
          is_active: body.is_active !== undefined ? Boolean(body.is_active) : undefined,
          status: body.status ?? undefined,
          notes: body.notes ?? undefined,
          gaming_day_id: body.gaming_day_id !== undefined ? Number(body.gaming_day_id) : undefined,
        },
      });

      return res.status(201).json(created);
    }

    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('current-table-player index error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
