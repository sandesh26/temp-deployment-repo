import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  try {
    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

      const required = ['table_id', 'seat_number'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) {
          return res.status(400).json({ error: `${k} is required` });
        }
      }

      const table_id = Number(body.table_id);
      const seat_number = Number(body.seat_number);
      const player_id = body.player_id === null ? null : body.player_id === undefined ? undefined : Number(body.player_id);
      const gaming_day_id = body.gaming_day_id !== undefined ? Number(body.gaming_day_id) : undefined;
      const joined_at = body.joined_at ? new Date(body.joined_at) : undefined;

      try {
        const createData: any = {
          table_id,
          seat_number,
          joined_at,
          last_seen: body.last_seen ? new Date(body.last_seen) : undefined,
          current_stack: body.current_stack ?? undefined,
          current_bet: body.current_bet ?? undefined,
          is_active: body.is_active !== undefined ? Boolean(body.is_active) : true,
          status: body.status ?? undefined,
          notes: body.notes ?? undefined,
          gaming_day_id,
        };
        if (player_id !== undefined) createData.player_id = player_id; // allow null

        const updateData: any = {
          last_seen: body.last_seen ? new Date(body.last_seen) : new Date(),
          current_stack: body.current_stack ?? undefined,
          current_bet: body.current_bet ?? undefined,
          is_active: body.is_active !== undefined ? Boolean(body.is_active) : true,
          status: body.status ?? undefined,
          notes: body.notes ?? undefined,
          gaming_day_id,
        };
        if (player_id !== undefined) updateData.player_id = player_id; // allow null

        const rec = await prisma.currentTablePlayer.upsert({
          where: { table_id_seat_number: { table_id, seat_number } },
          create: createData,
          update: updateData,
        });

        return res.status(200).json(rec);
      } catch (err: any) {
        // Prisma unique constraint or other DB errors
        if (err?.code === 'P2002') {
          return res.status(409).json({ error: 'Seat already taken', meta: err.meta });
        }
        console.error('upsert error', err);
        if (err instanceof Error) return res.status(400).json({ error: err.message });
        return res.status(500).json({ error: 'Unknown DB error' });
      }
    }

    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('current-table-player upsert error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
