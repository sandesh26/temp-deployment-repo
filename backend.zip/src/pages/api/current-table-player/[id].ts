import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const id = Number(req.query.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  try {
    if (req.method === 'GET') {
      const item = await prisma.currentTablePlayer.findUnique({
        where: { id },
        include: { player: { select: { user_id: true, full_name: true } } },
      });
      if (!item) return res.status(404).json({ error: 'Not found' });

      const out = { ...item, player_name: item.player?.full_name ?? null };
      return res.status(200).json(out);
    }

    if (req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const required = ['table_id', 'player_id'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) {
          return res.status(400).json({ error: `${k} is required` });
        }
      }

      const updated = await prisma.currentTablePlayer.update({
        where: { id },
        data: ({
          table_id: Number(body.table_id),
          player_id: Number(body.player_id),
          seat_number: body.seat_number !== undefined ? Number(body.seat_number) : null,
          joined_at:
            body.joined_at === undefined
              ? undefined
              : body.joined_at === null
              ? { set: null }
              : new Date(body.joined_at),
          last_seen:
            body.last_seen === undefined
              ? undefined
              : body.last_seen === null
              ? { set: null }
              : new Date(body.last_seen),
          current_stack: body.current_stack ?? null,
          current_bet: body.current_bet ?? null,
          is_active: body.is_active !== undefined ? Boolean(body.is_active) : null,
          status: body.status ?? null,
          notes: body.notes ?? null,
          gaming_day_id: body.gaming_day_id !== undefined ? Number(body.gaming_day_id) : null,
        } as any),
      });

      return res.status(200).json(updated);
    }

    if (req.method === 'PATCH') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const updateData: any = {};
      if (body.table_id !== undefined) updateData.table_id = Number(body.table_id);
      if (body.player_id !== undefined) updateData.player_id = Number(body.player_id);
      if (body.seat_number !== undefined) updateData.seat_number = body.seat_number === null ? null : Number(body.seat_number);
      if (body.joined_at !== undefined) updateData.joined_at = body.joined_at ? new Date(body.joined_at) : null;
      if (body.last_seen !== undefined) updateData.last_seen = body.last_seen ? new Date(body.last_seen) : null;
      if (body.current_stack !== undefined) updateData.current_stack = body.current_stack;
      if (body.current_bet !== undefined) updateData.current_bet = body.current_bet;
      if (body.is_active !== undefined) updateData.is_active = Boolean(body.is_active);
      if (body.status !== undefined) updateData.status = body.status;
      if (body.notes !== undefined) updateData.notes = body.notes;
      if (body.gaming_day_id !== undefined) updateData.gaming_day_id = body.gaming_day_id === null ? null : Number(body.gaming_day_id);

      const updated = await prisma.currentTablePlayer.update({ where: { id }, data: updateData });
      return res.status(200).json(updated);
    }

    if (req.method === 'DELETE') {
      await prisma.currentTablePlayer.delete({ where: { id } });
      return res.status(204).end();
    }

    res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('current-table-player id error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
