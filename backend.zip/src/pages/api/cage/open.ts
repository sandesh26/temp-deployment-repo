import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const body = req.body;
    // Accept JSON string (edge case) or object
    const payload = typeof body === 'string' ? JSON.parse(body) : body;

    const {
      module: moduleIn,
      cage_id,
      table_id,
      gaming_day_id,
      opening_cash,
      opening_chips,
      opening_total,
      // New separate arrays approach
      opening_cash_denominations, // array of { cash_denomination_id, opening_quantity, opening_total } or { denomination, currency_code }
      opening_chip_denominations, // array of chip breakdowns (kept in JSON snapshot)
      // Backwards-compat: allow older `opening_denominations` too
      opening_denominations,
      opening_recorded_by,
      notes,
    } = payload;

    const moduleType = String(moduleIn ?? 'CAGE').toUpperCase();
    if (moduleType !== 'CAGE' && moduleType !== 'TABLE') {
      return res.status(400).json({ error: 'module must be CAGE or TABLE' });
    }

    if (!gaming_day_id) {
      return res.status(400).json({ error: 'gaming_day_id is required' });
    }

    if (moduleType === 'CAGE' && !cage_id) {
      return res.status(400).json({ error: 'cage_id is required for module CAGE' });
    }
    if (moduleType === 'TABLE' && !table_id) {
      return res.status(400).json({ error: 'table_id is required for module TABLE' });
    }

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      // 1) Create FloatBalance (base record)
      const floatCreateData: any = {
        module: moduleType,
        gaming_day_id: Number(gaming_day_id),
        opening_cash: opening_cash ?? 0,
        opening_chips: opening_chips ?? 0,
        opening_total: opening_total ?? (opening_cash ?? 0) + (opening_chips ?? 0),
        opening_recorded_by: opening_recorded_by ?? null,
        // store a JSON snapshot containing both cash and chips breakdowns for audit
        opening_denominations: (function () {
          const cash = opening_cash_denominations ?? opening_denominations ?? null;
          const chips = opening_chip_denominations ?? null;
          if (!cash && !chips) return null;
          return JSON.stringify({ cash, chips });
        })(),
        notes: notes ?? null,
      };

      if (moduleType === 'CAGE') floatCreateData.cage_id = Number(cage_id);
      if (moduleType === 'TABLE') floatCreateData.table_id = Number(table_id);

      const floatRecord = await tx.floatBalance.create({ data: floatCreateData });

      // 2) Ensure CashDenomination rows exist / update them if denomination value provided
      // Process cash denominations (either from new `opening_cash_denominations` or legacy `opening_denominations`)
      const cashArray = opening_cash_denominations ?? opening_denominations ?? [];
      if (cashArray && Array.isArray(cashArray)) {
        for (const d of cashArray) {
          // If a cash_denomination_id is provided, optionally update its description
            if (d.cash_denomination_id) {
            const updateData: any = {};
            if (d.description) updateData.description = d.description;
            if (d.currency_code) updateData.currency_code = d.currency_code;
            if (Object.keys(updateData).length > 0) {
              await tx.cashDenomination.update({ where: { id: Number(d.cash_denomination_id) }, data: updateData });
            }
            } else if (d.denomination) {
            // find or create by currency_code + denomination
            const currency = d.currency_code ?? 'INR';
            const denomValue = d.denomination;
            let cd = await tx.cashDenomination.findFirst({ where: { currency_code: currency, denomination: denomValue } });
            if (!cd) {
              cd = await tx.cashDenomination.create({ data: { currency_code: currency, denomination: denomValue, description: d.description ?? null } });
            }
            d.cash_denomination_id = cd.id; // inject for next step
          }

          // 3) Upsert FloatBalanceDenomination row for this float + cash denomination
            if (d.cash_denomination_id) {
            const cashId = Number(d.cash_denomination_id);
            await tx.floatBalanceDenomination.upsert({
              where: {
                float_balance_id_cash_denomination_id: {
                  float_balance_id: floatRecord.id,
                  cash_denomination_id: cashId,
                },
              },
              create: {
                float_balance_id: floatRecord.id,
                cash_denomination_id: cashId,
                opening_quantity: d.opening_quantity ?? 0,
                opening_total: d.opening_total ?? null,
              },
              update: {
                opening_quantity: d.opening_quantity ?? undefined,
                opening_total: d.opening_total ?? undefined,
              },
            });
          }
        }
      }

      // For chip breakdowns, we currently persist them inside the FloatBalance.opening_denominations JSON snapshot only.
      // (If you later want normalized chip rows, we can add a FloatBalanceChipDenomination model.)

      return { floatRecord };
    });

    return res.status(201).json(result);
  } catch (error) {
    console.error('cage open failed', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
