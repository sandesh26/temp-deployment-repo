import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const cage = await prisma.cage.findUnique({
        include: {
          changedBy: { select: { full_name: true } },
          gamingDay: { select: { start_time: true } },
        },
        where: { cage_id: Number(id) }
      });

      if (!cage) return res.status(404).json({ error: 'Cage not found' });

      const { changedBy, gamingDay, last_change, balance, chip_balance, online_balance, tito_balance, card_balance, ...rest } = cage;
      const result = {
        ...rest,
        balance: {
          cash: balance !== undefined && balance !== null ? balance.toString() : null,
          chips: chip_balance !== undefined && chip_balance !== null ? chip_balance.toString() : null,
          online: online_balance !== undefined && online_balance !== null ? online_balance.toString() : null,
          tito: tito_balance !== undefined && tito_balance !== null ? tito_balance.toString() : null,
          card: card_balance !== undefined && card_balance !== null ? card_balance.toString() : null,
        },
        last_change: last_change ? formatDate(last_change) : null,
        changed_by: changedBy?.full_name ?? null,
        gaming_day: gamingDay?.start_time ? formatDate(gamingDay.start_time) : null,
      };

      return res.status(200).json(result);
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        if (typeof data?.allowed_operations === 'string') {
          try {
            data.allowed_operations = JSON.parse(data.allowed_operations);
          } catch {
            // keep as is
          }
        }

        const {
          cage_id,
          changedBy,
          gamingDay,
          transactions,
          sessions,
          cageVaultRequests,
          floatBalances,
          floor,
          cageChipDenominations,
          ...updateData
        } = data;

        if (updateData.balance && typeof updateData.balance === 'object') {
          if (updateData.balance.cash !== undefined) updateData.balance = updateData.balance.cash;
          if (updateData.balance.chips !== undefined && updateData.chip_balance === undefined) {
            updateData.chip_balance = updateData.balance.chips;
          }
          if (updateData.balance.online !== undefined && updateData.online_balance === undefined) {
            updateData.online_balance = updateData.balance.online;
          }
          if (updateData.balance.tito !== undefined && updateData.tito_balance === undefined) {
            updateData.tito_balance = updateData.balance.tito;
          }
        }

        if (updateData.last_change) {
          updateData.last_change = new Date(updateData.last_change);
        }
        if (updateData.changed_by !== undefined && updateData.changed_by !== null) {
          updateData.changed_by = Number(updateData.changed_by);
        }
        if (updateData.gaming_day_id !== undefined && updateData.gaming_day_id !== null) {
          updateData.gaming_day_id = Number(updateData.gaming_day_id);
        }
        if (updateData.floor_id !== undefined && updateData.floor_id !== null) {
          updateData.floor_id = Number(updateData.floor_id);
        }

        const cage = await prisma.cage.update({
          where: { cage_id: Number(id) },
          data: updateData,
        });
        return res.status(200).json(cage);
      } catch (error: any) {
        console.error('Cage update error:', error);
        return res.status(400).json({ error: error.message || 'Failed to update cage' });
      }
    }
    case 'PATCH': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        if (typeof data?.allowed_operations === 'string') {
          try {
            data.allowed_operations = JSON.parse(data.allowed_operations);
          } catch {
            // keep as is
          }
        }

        const {
          cage_id,
          changedBy,
          gamingDay,
          transactions,
          sessions,
          cageVaultRequests,
          floatBalances,
          floor,
          cageChipDenominations,
          ...updateData
        } = data;

        if (updateData.balance && typeof updateData.balance === 'object') {
          if (updateData.balance.cash !== undefined) updateData.balance = updateData.balance.cash;
          if (updateData.balance.chips !== undefined && updateData.chip_balance === undefined) {
            updateData.chip_balance = updateData.balance.chips;
          }
          if (updateData.balance.online !== undefined && updateData.online_balance === undefined) {
            updateData.online_balance = updateData.balance.online;
          }
          if (updateData.balance.tito !== undefined && updateData.tito_balance === undefined) {
            updateData.tito_balance = updateData.balance.tito;
          }
        }

        if (updateData.last_change) {
          updateData.last_change = new Date(updateData.last_change);
        }
        if (updateData.changed_by !== undefined && updateData.changed_by !== null) {
          updateData.changed_by = Number(updateData.changed_by);
        }
        if (updateData.gaming_day_id !== undefined && updateData.gaming_day_id !== null) {
          updateData.gaming_day_id = Number(updateData.gaming_day_id);
        }
        if (updateData.floor_id !== undefined && updateData.floor_id !== null) {
          updateData.floor_id = Number(updateData.floor_id);
        }

        const updated = await prisma.cage.update({
          where: { cage_id: Number(id) },
          data: updateData,
        });
        return res.status(200).json(updated);
      } catch (err: any) {
        console.error('Cage patch error:', err);
        return res.status(400).json({ error: err.message || 'Patch failed' });
      }
    }
    case 'DELETE': {
      await prisma.cage.delete({ where: { cage_id: Number(id) } });
      return res.status(204).end();
    }
    default:
  res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}