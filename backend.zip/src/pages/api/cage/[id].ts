import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const cage = await prisma.cage.findUnique({
        include: {
          changedBy: { select: { full_name: true } },
          gamingDay: { select: { start_time: true } },
        },
        where: { cage_id: Number(id) }
      });

      if (!cage) return res.status(404).json({ error: 'Cage not found' });

      const { changedBy, gamingDay, last_change, balance, chip_balance, online_balance, tito_balance, ...rest } = cage;
      const result = {
        ...rest,
        balance: {
          cash: balance !== undefined && balance !== null ? balance.toString() : null,
          chips: chip_balance !== undefined && chip_balance !== null ? chip_balance.toString() : null,
          online: online_balance !== undefined && online_balance !== null ? online_balance.toString() : null,
          tito: tito_balance !== undefined && tito_balance !== null ? tito_balance.toString() : null,
        },
        last_change: last_change ? formatDate(last_change) : null,
        changed_by: changedBy?.full_name ?? null,
        gaming_day: gamingDay?.start_time ? formatDate(gamingDay.start_time) : null,
      };

      return res.status(200).json(result);
    }
    case 'PUT': {
      const data = req.body;
      const cage = await prisma.cage.update({ where: { cage_id: Number(id) }, data });
      return res.status(200).json(cage);
    }
    case 'DELETE': {
      await prisma.cage.delete({ where: { cage_id: Number(id) } });
      return res.status(204).end();
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}