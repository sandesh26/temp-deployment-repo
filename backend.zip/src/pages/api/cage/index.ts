import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'GET': {
      const { floor } = req.query;
      const where: any = {};

      if (floor !== undefined) {
        const floorNum = Number(floor);
        if (!isNaN(floorNum)) {
          where.floor_id = floorNum;
        }
      }

      const cages = await prisma.cage.findMany({
        where,
        orderBy: { cage_id: 'asc' },
        include: {
          changedBy: { select: { full_name: true } },
          gamingDay: { select: { start_time: true } },
        },
      });

      type CageWithRelations = {
        changedBy?: { full_name?: string } | null;
        gamingDay?: { start_time?: string | Date } | null;
        gaming_day_id?: number;
        last_change?: string | Date | null;
        balance?: any;
        chip_balance?: any;
        online_balance?: any;
        tito_balance?: any;
        [key: string]: any;
      };

      const result = cages.map((cage) => {
        return {
          ...cage,
          balance: {
            cash: cage.balance !== undefined && cage.balance !== null ? cage.balance.toString() : null,
            chips: cage.chip_balance !== undefined && cage.chip_balance !== null ? cage.chip_balance.toString() : null,
            online: cage.online_balance !== undefined && cage.online_balance !== null ? cage.online_balance.toString() : null,
            tito: cage.tito_balance !== undefined && cage.tito_balance !== null ? cage.tito_balance.toString() : null,
          },
          last_change: cage.last_change ? formatDate(cage.last_change) : null,
          changed_by: cage.changedBy?.full_name ?? null,
          gaming_day: cage.gamingDay?.start_time ? formatDate(cage.gamingDay.start_time) : null,
        };
      });

      return res.status(200).json(result);
    }
    case 'POST': {
      const data = req.body;
      const cage = await prisma.cage.create({ data });
      return res.status(201).json(cage);
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}