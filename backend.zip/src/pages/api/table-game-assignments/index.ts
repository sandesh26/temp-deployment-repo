import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  try {
    if (req.method === 'GET') {
      const { page: pageQ, pageSize: pageSizeQ, table_id, game_id, active, orderBy } = req.query as any;
      const page = Math.max(1, Number(pageQ ?? 1));
      const pageSize = Math.min(100, Math.max(1, Number(pageSizeQ ?? 20)));

      const where: any = {};
      if (table_id !== undefined) where.table_id = Number(table_id);
      if (game_id !== undefined) where.game_id = Number(game_id);
      if (active !== undefined) where.active = active === 'true' || active === true;

      const total = await prisma.tableGameAssignment.count({ where });

      const order: any = {};
      if (orderBy === 'assigned_at') order.assigned_at = 'desc';
      else order.id = 'desc';

      const items = await prisma.tableGameAssignment.findMany({
        where,
        orderBy: order,
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          table: { select: { table_id: true, name: true } },
          game: { select: { game_id: true, name: true } },
          assignedBy: { select: { employee_id: true, username: true } },
        },
      });

      return res.status(200).json({ data: items, meta: { total, page, pageSize, totalPages: Math.ceil(total / pageSize) } });
    }

    if (req.method === 'POST') {
      const bodyRaw = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const entries = Array.isArray(bodyRaw) ? bodyRaw : [bodyRaw];

      const required = ['table_id', 'game_id'];
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        for (const k of required) if (entry[k] === undefined || entry[k] === null) return res.status(400).json({ error: `${k} is required for item ${i}` });
      }

      const createOps = entries.map((entry: any) =>
        prisma.tableGameAssignment.create({
          data: {
            table_id: Number(entry.table_id),
            game_id: Number(entry.game_id),
            assigned_by: entry.assigned_by ? Number(entry.assigned_by) : undefined,
            assigned_at: entry.assigned_at ? new Date(entry.assigned_at) : undefined,
            active: entry.active !== undefined ? Boolean(entry.active) : undefined,
            notes: entry.notes ?? undefined,
          },
          include: {
            table: { select: { table_id: true, name: true } },
            game: { select: { game_id: true, name: true } },
            assignedBy: { select: { employee_id: true, username: true } },
          },
        })
      );

      const created = await prisma.$transaction(createOps);

      return res.status(201).json(Array.isArray(bodyRaw) ? created : created[0]);
    }

    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('table-game-assignments index error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
