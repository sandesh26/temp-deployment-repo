import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const id = Number(req.query.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  try {
    if (req.method === 'GET') {
      const item = await prisma.tableGameAssignment.findUnique({ where: { id }, include: { table: { select: { table_id: true, name: true } }, game: { select: { game_id: true, name: true } }, assignedBy: { select: { employee_id: true, username: true } } } });
      if (!item) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(item);
    }

    if (req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const required = ['table_id', 'game_id'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) return res.status(400).json({ error: `${k} is required` });
      }

      const updated = await prisma.tableGameAssignment.update({
        where: { id },
        data: {
          table_id: Number(body.table_id),
          game_id: Number(body.game_id),
          assigned_by: body.assigned_by ? Number(body.assigned_by) : null,
          assigned_at: body.assigned_at ? new Date(body.assigned_at) : undefined,
          active: body.active !== undefined ? Boolean(body.active) : undefined,
          notes: body.notes ?? undefined,
        },
      });

      return res.status(200).json(updated);
    }

    if (req.method === 'PATCH') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const updateData: any = {};
      if (body.table_id !== undefined) updateData.table_id = Number(body.table_id);
      if (body.game_id !== undefined) updateData.game_id = Number(body.game_id);
      if (body.assigned_by !== undefined) updateData.assigned_by = body.assigned_by === null ? null : Number(body.assigned_by);
      if (body.assigned_at !== undefined) updateData.assigned_at = body.assigned_at ? new Date(body.assigned_at) : null;
      if (body.active !== undefined) updateData.active = Boolean(body.active);
      if (body.notes !== undefined) updateData.notes = body.notes;

      if (Object.keys(updateData).length === 0) return res.status(400).json({ error: 'No valid fields provided for patch' });

      const updated = await prisma.tableGameAssignment.update({ where: { id }, data: updateData });
      return res.status(200).json(updated);
    }

    if (req.method === 'DELETE') {
      await prisma.tableGameAssignment.delete({ where: { id } });
      return res.status(204).end();
    }

    res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('table-game-assignments id error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
