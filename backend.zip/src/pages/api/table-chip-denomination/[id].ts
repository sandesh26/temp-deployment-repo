import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const id = Number(req.query.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  try {
    if (req.method === 'GET') {
      const item = await prisma.tableChipDenomination.findUnique({ where: { id } });
      if (!item) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(item);
    }

    if (req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const required = ['table_id', 'gaming_day_id', 'chip_denomination', 'chip_color', 'quantity'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) {
          return res.status(400).json({ error: `${k} is required` });
        }
      }

      const updated = await prisma.tableChipDenomination.update({
        where: { id },
        data: {
          chip_id: Number(body.chip_id ?? 0),
          table_id: Number(body.table_id),
          gaming_day_id: Number(body.gaming_day_id),
          chip_denomination: body.chip_denomination,
          chip_color: String(body.chip_color),
          quantity: Number(body.quantity),
          total_value: body.total_value ?? undefined,
          recorded_at: body.recorded_at ? new Date(body.recorded_at) : undefined,
        },
      });

      return res.status(200).json(updated);
    }

    if (req.method === 'PATCH') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const updateData: any = {};
      if (body.chip_id !== undefined) updateData.chip_id = Number(body.chip_id);
      if (body.table_id !== undefined) updateData.table_id = Number(body.table_id);
      if (body.gaming_day_id !== undefined) updateData.gaming_day_id = Number(body.gaming_day_id);
      if (body.chip_denomination !== undefined) updateData.chip_denomination = body.chip_denomination;
      if (body.chip_color !== undefined) updateData.chip_color = String(body.chip_color);
      if (body.quantity !== undefined) updateData.quantity = Number(body.quantity);
      if (body.total_value !== undefined) updateData.total_value = body.total_value;
      if (body.recorded_at !== undefined) updateData.recorded_at = body.recorded_at ? new Date(body.recorded_at) : null;

      const updated = await prisma.tableChipDenomination.update({ where: { id }, data: updateData });
      return res.status(200).json(updated);
    }

    if (req.method === 'DELETE') {
      await prisma.tableChipDenomination.delete({ where: { id } });
      return res.status(204).end();
    }

    res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('table-chip-denomination id error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
