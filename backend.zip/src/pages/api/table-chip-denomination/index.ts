import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  try {
    if (req.method === 'GET') {
      // Pagination params
      const { page: pageQ, pageSize: pageSizeQ, table_id, gaming_day_id, chip_color, denom_min, denom_max, orderBy } = req.query as any;
      const page = Math.max(1, Number(pageQ ?? 1));
      const pageSize = Math.min(100, Math.max(1, Number(pageSizeQ ?? 20)));

      const where: any = {};
      if (table_id) where.table_id = Number(table_id);
      if (gaming_day_id) where.gaming_day_id = Number(gaming_day_id);
      if (chip_color) where.chip_color = String(chip_color);
      if (denom_min || denom_max) {
        where.chip_denomination = {};
        if (denom_min) where.chip_denomination.gte = Number(denom_min);
        if (denom_max) where.chip_denomination.lte = Number(denom_max);
      }

      // total count for meta
      const total = await prisma.tableChipDenomination.count({ where });

      // ordering
      const order: any = {};
      if (orderBy === 'quantity') order.quantity = 'desc';
      else if (orderBy === 'recorded_at') order.recorded_at = 'desc';
      else order.id = 'desc';

      const items = await prisma.tableChipDenomination.findMany({
        where,
        orderBy: order,
        skip: (page - 1) * pageSize,
        take: pageSize,
      });

      return res.status(200).json({ data: items, meta: { total, page, pageSize, totalPages: Math.ceil(total / pageSize) } });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

      const required = ['table_id', 'gaming_day_id', 'chip_denomination', 'chip_color', 'quantity'];
      for (const k of required) {
        if (body[k] === undefined || body[k] === null) {
          return res.status(400).json({ error: `${k} is required` });
        }
      }

      const created = await prisma.tableChipDenomination.create({
        data: {
          chip_id: Number(body.chip_id ?? 0),
          table_id: Number(body.table_id),
          gaming_day_id: Number(body.gaming_day_id),
          chip_denomination: body.chip_denomination,
          chip_color: String(body.chip_color),
          quantity: Number(body.quantity),
          total_value: body.total_value ?? undefined,
          recorded_at: body.recorded_at ? new Date(body.recorded_at) : undefined,
        },
      });

      return res.status(201).json(created);
    }

    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error) {
    console.error('table-chip-denomination index error', error);
    if (error instanceof Error) return res.status(400).json({ error: error.message });
    return res.status(500).json({ error: 'Unknown server error' });
  }
}
