// pages/api/employee/[id].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const employee = await prisma.employee.findUnique({
        where: { employee_id: Number(id) },
      });

      return employee
        ? res.status(200).json(employee)
        : res.status(404).json({ error: 'Employee not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching employee' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.employee.update({
        where: { employee_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch {
      return res.status(400).json({ error: 'Update failed' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.employee.delete({
        where: { employee_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}