// pages/api/employee/[id].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const employee = await prisma.employee.findUnique({
        where: { employee_id: Number(id) },
      });

      return employee
        ? res.status(200).json(employee)
        : res.status(404).json({ error: 'Employee not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching employee' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.employee.update({
        where: { employee_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch {
      return res.status(400).json({ error: 'Update failed' });
    }
  }

  if (req.method === 'PATCH') {
    try {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const updateData: any = {};

      if (body.user_id !== undefined) updateData.user_id = Number(body.user_id);
      if (body.username !== undefined) updateData.username = body.username;
      if (body.password_hash !== undefined) updateData.password_hash = body.password_hash;
      if (body.role !== undefined) updateData.role = body.role;
      if (body.access_level !== undefined) updateData.access_level = Number(body.access_level);
      if (body.rfid_number !== undefined) updateData.rfid_number = body.rfid_number ?? null;
      if (body.company_id !== undefined) updateData.company_id = body.company_id ?? null;
      if (body.gender !== undefined) updateData.gender = body.gender ?? null;
      if (body.pin !== undefined) updateData.pin = body.pin ?? null;

      const updated = await prisma.employee.update({
        where: { employee_id: Number(id) },
        data: updateData,
      });

      return res.status(200).json(updated);
    } catch (error: any) {
      console.error('PATCH /api/employee/[id] error:', error);
      return res.status(400).json({ error: 'Patch update failed', details: error?.message || String(error) });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.employee.delete({
        where: { employee_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}