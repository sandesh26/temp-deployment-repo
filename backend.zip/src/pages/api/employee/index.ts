// pages/api/employee/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma'; // your custom Prisma client instance
import { withAuth } from '../../../middleware/auth';
import { validateRequest, employeeSchema, createRateLimiter } from '../../../middleware/validation';
import { createRouter } from 'next-connect';
import { cors } from '../../../lib/cors';

// Create a custom handler type that works with next-connect
type Handler = (req: NextApiRequest, res: NextApiResponse) => Promise<void>;

// Create a middleware wrapper for rate limiter
const rateLimiterMiddleware = (req: NextApiRequest, res: NextApiResponse, next: () => void) => {
  const limiter = createRateLimiter();
  return new Promise((resolve, reject) => {
    limiter(req as any, res as any, (error?: any) => {
      if (error) reject(error);
      resolve(next());
    });
  });
};

const handler = createRouter<NextApiRequest, NextApiResponse>()
  .use(rateLimiterMiddleware)
  .get(async (req, res) => {
    try {
      const filters = req.query;
      // Only allow specific fields for filtering
      const allowedFilters = ['role', 'access_level', 'username'];
      const sanitizedFilters = Object.keys(filters)
        .filter(key => allowedFilters.includes(key))
        .reduce((obj: any, key) => {
          obj[key] = filters[key];
          return obj;
        }, {});

      const employees = await prisma.employee.findMany({
        where: sanitizedFilters,
        select: {
          employee_id: true,
          username: true,
          role: true,
          access_level: true,
          user: {
            select: {
              full_name: true,
              email: true,
              phone: true,
              status: true
            }
          }
        },
        orderBy: { employee_id: 'desc' },
      });

      return res.status(200).json(employees);
    } catch (error) {
      console.error('Error fetching employees:', error);
      return res.status(500).json({ error: 'Failed to fetch employee records' });
    }
  })
  .post(async (req, res) => {
    try {
      const { user_id, role, username, password_hash, access_level = 0 } = req.body;
      
      // Validate required fields
      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required' });
      }
      
      if (!role) {
        return res.status(400).json({ error: 'role is required' });
      }
      
      if (!username) {
        return res.status(400).json({ error: 'username is required' });
      }
      
      // Validate user_id is a number
      const parsedUserId = parseInt(user_id);
      if (isNaN(parsedUserId)) {
        return res.status(400).json({ error: 'user_id must be a valid number' });
      }
      
      // Fetch user to verify it exists
      const user = await prisma.user.findUnique({
        where: { user_id: parsedUserId },
        select: { user_id: true, full_name: true, role: true }
      });
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Use provided password_hash or hash the provided password, or use default
      let hashedPassword: string;
      
      if (password_hash) {
        // If password_hash is provided, check if it's already hashed or plain text
        const bcrypt = require('bcrypt');
        if (password_hash.startsWith('$2b$') || password_hash.startsWith('$2a$')) {
          // Already hashed
          hashedPassword = password_hash;
        } else {
          // Plain text password, hash it
          hashedPassword = await bcrypt.hash(password_hash, 10);
        }
      } else {
        // Use default password
        const bcrypt = require('bcrypt');
        const defaultPassword = 'casinopassword';
        hashedPassword = await bcrypt.hash(defaultPassword, 10);
      }
      
      // Create employee linked to existing user
      const newEmployee = await prisma.employee.create({
        data: {
          user_id: parsedUserId,
          username: username,
          password_hash: hashedPassword,
          role: role as string,
          access_level: access_level || 0
        },
        select: {
          employee_id: true,
          username: true,
          role: true,
          access_level: true,
          user: {
            select: {
              user_id: true,
              full_name: true,
              email: true,
              phone: true,
              role: true,
              status: true
            }
          }
        }
      });
      
      return res.status(201).json(newEmployee);
    } catch (error) {
      console.error('Error creating employee:', error);
      if ((error as any).code === 'P2002') {
        return res.status(400).json({ error: 'Username already exists or user is already an employee' });
      }
      return res.status(400).json({ error: 'Employee creation failed' });
    }
  });

// Wrap the handler with authentication middleware
// Only allow Admin role to access employee management
// TODO: Implement proper authentication middleware that sets req.user
const authenticatedHandler = handler; // Temporarily bypass auth for testing
// const authenticatedHandler = withAuth(handler as unknown as Handler, ['Admin']);

// Export a function that handles CORS before authentication
export default async function finalHandler(req: NextApiRequest, res: NextApiResponse) {
  // Handle CORS first, before any authentication
  if (cors(req, res)) return;
  
  // Then proceed with the handler
  return handler.run(req, res);
}