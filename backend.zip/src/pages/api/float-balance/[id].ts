import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../../src/lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const item = await prisma.floatBalance.findUnique({
        where: { id: Number(id) },
        include: { denominations: { include: { cashDenomination: true } }, gamingDay: true, cage: true, table: true, openedBy: true, closedBy: true },
      });
      if (!item) return res.status(404).json({ error: 'FloatBalance not found' });
      return res.status(200).json(item);
    }
    case 'PUT': {
      try {
        let body = req.body;
        if (typeof body === 'string') body = JSON.parse(body);

        const {
          id: _id,
          denominations,
          gamingDay,
          cage,
          table,
          openedBy,
          closedBy,
          created_at,
          updated_at,
          ...rest
        } = body;

        const updateData: any = { ...rest };

        // Parse JSON fields if passed as object or string
        if (updateData.opening_denominations && typeof updateData.opening_denominations === 'object') {
          updateData.opening_denominations = updateData.opening_denominations;
        }
        if (updateData.closing_denominations && typeof updateData.closing_denominations === 'object') {
          updateData.closing_denominations = updateData.closing_denominations;
        }

        // Parse date strings safely if provided
        if (updateData.opening_recorded_at) {
          updateData.opening_recorded_at = new Date(updateData.opening_recorded_at);
        }
        if (updateData.closing_recorded_at) {
          updateData.closing_recorded_at = new Date(updateData.closing_recorded_at);
        }

        // Numeric fields casting
        if (updateData.gaming_day_id !== undefined && updateData.gaming_day_id !== null) {
          updateData.gaming_day_id = Number(updateData.gaming_day_id);
        }
        if (updateData.cage_id !== undefined && updateData.cage_id !== null) {
          updateData.cage_id = Number(updateData.cage_id);
        }
        if (updateData.table_id !== undefined && updateData.table_id !== null) {
          updateData.table_id = Number(updateData.table_id);
        }
        if (updateData.opening_recorded_by !== undefined && updateData.opening_recorded_by !== null) {
          updateData.opening_recorded_by = Number(updateData.opening_recorded_by);
        }
        if (updateData.closing_recorded_by !== undefined && updateData.closing_recorded_by !== null) {
          updateData.closing_recorded_by = Number(updateData.closing_recorded_by);
        }

        // Update base fields
        await prisma.floatBalance.update({ where: { id: Number(id) }, data: updateData });

        // Handle denominations: delete existing and recreate if provided
        if (denominations && Array.isArray(denominations)) {
          await prisma.floatBalanceDenomination.deleteMany({ where: { float_balance_id: Number(id) } });
          if (denominations.length > 0) {
            const createMany = denominations.map((d: any) => ({
              float_balance_id: Number(id),
              cash_denomination_id: Number(d.cash_denomination_id),
              opening_quantity: d.opening_quantity ?? 0,
              opening_total: d.opening_total ?? null,
              closing_quantity: d.closing_quantity ?? 0,
              closing_total: d.closing_total ?? null,
            }));
            await prisma.floatBalanceDenomination.createMany({ data: createMany });
          }
        }

        const result = await prisma.floatBalance.findUnique({
          where: { id: Number(id) },
          include: {
            denominations: { include: { cashDenomination: true } },
            gamingDay: true,
            cage: true,
            table: true,
            openedBy: true,
            closedBy: true,
          },
        });
        return res.status(200).json(result);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'PATCH': {
      try {
        let body = req.body;
        if (typeof body === 'string') body = JSON.parse(body);

        const {
          id: _id,
          denominations,
          gamingDay,
          cage,
          table,
          openedBy,
          closedBy,
          created_at,
          updated_at,
          ...rest
        } = body;

        const updateData: any = { ...rest };

        // Parse JSON fields if passed as object or string
        if (updateData.opening_denominations && typeof updateData.opening_denominations === 'object') {
          updateData.opening_denominations = updateData.opening_denominations;
        }
        if (updateData.closing_denominations && typeof updateData.closing_denominations === 'object') {
          updateData.closing_denominations = updateData.closing_denominations;
        }

        // Parse date strings safely if provided
        if (updateData.opening_recorded_at) {
          updateData.opening_recorded_at = new Date(updateData.opening_recorded_at);
        }
        if (updateData.closing_recorded_at) {
          updateData.closing_recorded_at = new Date(updateData.closing_recorded_at);
        }

        // Numeric fields casting
        if (updateData.gaming_day_id !== undefined && updateData.gaming_day_id !== null) {
          updateData.gaming_day_id = Number(updateData.gaming_day_id);
        }
        if (updateData.cage_id !== undefined && updateData.cage_id !== null) {
          updateData.cage_id = Number(updateData.cage_id);
        }
        if (updateData.table_id !== undefined && updateData.table_id !== null) {
          updateData.table_id = Number(updateData.table_id);
        }
        if (updateData.opening_recorded_by !== undefined && updateData.opening_recorded_by !== null) {
          updateData.opening_recorded_by = Number(updateData.opening_recorded_by);
        }
        if (updateData.closing_recorded_by !== undefined && updateData.closing_recorded_by !== null) {
          updateData.closing_recorded_by = Number(updateData.closing_recorded_by);
        }

        // Update only provided base fields
        if (Object.keys(updateData).length > 0) {
          await prisma.floatBalance.update({ where: { id: Number(id) }, data: updateData });
        }

        // Handle denominations: upsert per-denomination when provided
        if (denominations && Array.isArray(denominations)) {
          for (const d of denominations) {
            const cashId = Number(d.cash_denomination_id);
            if (!cashId) continue;
            await prisma.floatBalanceDenomination.upsert({
              where: {
                float_balance_id_cash_denomination_id: {
                  float_balance_id: Number(id),
                  cash_denomination_id: cashId,
                },
              },
              create: {
                float_balance_id: Number(id),
                cash_denomination_id: cashId,
                opening_quantity: d.opening_quantity ?? 0,
                opening_total: d.opening_total ?? null,
                closing_quantity: d.closing_quantity ?? 0,
                closing_total: d.closing_total ?? null,
              },
              update: {
                opening_quantity: d.opening_quantity ?? undefined,
                opening_total: d.opening_total ?? undefined,
                closing_quantity: d.closing_quantity ?? undefined,
                closing_total: d.closing_total ?? undefined,
              },
            });
          }
        }

        const result = await prisma.floatBalance.findUnique({
          where: { id: Number(id) },
          include: {
            denominations: { include: { cashDenomination: true } },
            gamingDay: true,
            cage: true,
            table: true,
            openedBy: true,
            closedBy: true,
          },
        });
        return res.status(200).json(result);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.floatBalance.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
