import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../../src/lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const item = await prisma.floatBalance.findUnique({
        where: { id: Number(id) },
        include: { denominations: { include: { cashDenomination: true } }, gamingDay: true, cage: true, table: true, openedBy: true, closedBy: true },
      });
      if (!item) return res.status(404).json({ error: 'FloatBalance not found' });
      return res.status(200).json(item);
    }
    case 'PUT': {
      try {
        const body = req.body;
        const { denominations, ...rest } = body;

        // Update base fields
        const updated = await prisma.floatBalance.update({ where: { id: Number(id) }, data: rest });

        // Handle denominations: simple approach - delete existing and recreate if provided
        if (denominations && Array.isArray(denominations)) {
          await prisma.floatBalanceDenomination.deleteMany({ where: { float_balance_id: Number(id) } });
          if (denominations.length > 0) {
            const createMany = denominations.map((d: any) => ({
              float_balance_id: Number(id),
              cash_denomination_id: Number(d.cash_denomination_id),
              opening_quantity: d.opening_quantity ?? 0,
              opening_total: d.opening_total ?? null,
              closing_quantity: d.closing_quantity ?? 0,
              closing_total: d.closing_total ?? null,
            }));
            // Use createMany for performance
            await prisma.floatBalanceDenomination.createMany({ data: createMany });
          }
        }

        const result = await prisma.floatBalance.findUnique({ where: { id: Number(id) }, include: { denominations: { include: { cashDenomination: true } } } });
        return res.status(200).json(result);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'PATCH': {
      try {
        const body = req.body;
        const { denominations, ...rest } = body;

        // Update only provided base fields
        if (Object.keys(rest).length > 0) {
          await prisma.floatBalance.update({ where: { id: Number(id) }, data: rest });
        }

        // Handle denominations: upsert per-denomination when provided
        if (denominations && Array.isArray(denominations)) {
          for (const d of denominations) {
            const cashId = Number(d.cash_denomination_id);
            if (!cashId) continue;
            await prisma.floatBalanceDenomination.upsert({
              where: {
                float_balance_id_cash_denomination_id: {
                  float_balance_id: Number(id),
                  cash_denomination_id: cashId,
                },
              },
              create: {
                float_balance_id: Number(id),
                cash_denomination_id: cashId,
                opening_quantity: d.opening_quantity ?? 0,
                opening_total: d.opening_total ?? null,
                closing_quantity: d.closing_quantity ?? 0,
                closing_total: d.closing_total ?? null,
              },
              update: {
                opening_quantity: d.opening_quantity ?? undefined,
                opening_total: d.opening_total ?? undefined,
                closing_quantity: d.closing_quantity ?? undefined,
                closing_total: d.closing_total ?? undefined,
              },
            });
          }
        }

        const result = await prisma.floatBalance.findUnique({ where: { id: Number(id) }, include: { denominations: { include: { cashDenomination: true } } } });
        return res.status(200).json(result);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.floatBalance.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
