import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../../src/lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      try {
        const { module, cage_id, table_id, limit, offset, gaming_day, latest } = req.query;
        const where: any = {};

        if (module) where.module = module as any;
        if (module === 'CAGE' && cage_id) where.cage_id = Number(cage_id);
        if (module === 'TABLE' && table_id) where.table_id = Number(table_id);
        if (!module) {
          if (cage_id) where.cage_id = Number(cage_id);
          if (table_id) where.table_id = Number(table_id);
        }

        // optional gaming_day filter (gaming_day is gaming_day_id)
        if (gaming_day) where.gaming_day_id = Number(gaming_day);

        const includeObj = {
          denominations: { include: { cashDenomination: true } },
          gamingDay: true,
          cage: true,
          table: true,
          openedBy: true,
          closedBy: true,
        };

        // If latest flag provided, return the single most recent record matching criteria
        if (latest === 'true' || latest === '1') {
          // Special handling: support cage_id=all -> return latest per cage
          if (module === 'CAGE' && String(cage_id).toLowerCase() === 'all') {
            const cages = await prisma.cage.findMany({ select: { cage_id: true } });
            const results: any[] = [];
            for (const c of cages) {
              const w = { ...where, cage_id: c.cage_id };
              const item = await prisma.floatBalance.findFirst({ where: w, orderBy: { created_at: 'desc' }, include: includeObj });
              if (item) results.push(item);
            }
            return res.status(200).json(results);
          }

          const item = await prisma.floatBalance.findFirst({ where, orderBy: { created_at: 'desc' }, include: includeObj });
          return res.status(200).json(item);
        }

        // Support cage_id=all for list queries as well: return latest per cage (paginated params ignored)
        if (module === 'CAGE' && String(cage_id).toLowerCase() === 'all') {
          const cages = await prisma.cage.findMany({ select: { cage_id: true } });
          const results: any[] = [];
          for (const c of cages) {
            const w = { ...where, cage_id: c.cage_id };
            const item = await prisma.floatBalance.findFirst({ where: w, orderBy: { created_at: 'desc' }, include: includeObj });
            if (item) results.push(item);
          }
          return res.status(200).json(results);
        }

        const items = await prisma.floatBalance.findMany({
          where,
          orderBy: { created_at: 'desc' },
          include: includeObj,
          take: limit ? Number(limit) : undefined,
          skip: offset ? Number(offset) : undefined,
        });

        return res.status(200).json(items);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'POST': {
      try {
        const body = req.body;
        const { denominations, ...rest } = body;

        const data: any = { ...rest };
        if (denominations && Array.isArray(denominations) && denominations.length > 0) {
          data.denominations = {
            create: denominations.map((d: any) => ({
              cash_denomination_id: Number(d.cash_denomination_id),
              opening_quantity: d.opening_quantity ?? 0,
              opening_total: d.opening_total ?? null,
              closing_quantity: d.closing_quantity ?? 0,
              closing_total: d.closing_total ?? null,
            })),
          };
        }

        const item = await prisma.floatBalance.create({ data });
        const created = await prisma.floatBalance.findUnique({ where: { id: item.id }, include: { denominations: { include: { cashDenomination: true } } } });
        return res.status(201).json(created);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
