import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    const { id, gameDetails } = req.query;
  if (!id || isNaN(Number(id))) return res.status(400).json({ error: 'Invalid id' });

  switch (req.method) {
    case 'GET': {
      const include = (typeof gameDetails === 'string' && gameDetails.toLowerCase() === 'true')
        ? { game: true }
        : undefined;
      const record = await prisma.machineGame.findUnique({
        where: { id: Number(id) },
        include,
      });
      if (!record) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(record);
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const updated = await prisma.machineGame.update({
          where: { id: Number(id) },
          data,
        });
        return res.status(200).json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Update failed' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.machineGame.delete({
          where: { id: Number(id) },
        });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Delete failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}