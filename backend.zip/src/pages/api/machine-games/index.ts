import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    switch (req.method) {
    case 'GET': {
      const { slot_machine_id, game_id, gameDetails } = req.query;
      const where: any = {};
      if (slot_machine_id) where.slot_machine_id = Number(slot_machine_id);
      if (game_id) where.game_id = Number(game_id);

      const include = (typeof gameDetails === 'string' && gameDetails.toLowerCase() === 'true')
        ? { game: true }
        : undefined;

      const records = await prisma.machineGame.findMany({
        where,
        include,
        orderBy: { id: 'asc' },
      });
      return res.status(200).json(records);
    }
    case 'POST': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const record = await prisma.machineGame.create({ data });
        return res.status(201).json(record);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Creation failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
