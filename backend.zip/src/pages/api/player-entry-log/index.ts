import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient, Tier, Prisma } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'POST': {
      // Create new entry log, fetch tier from PlayerCard
      const { player_id, login_time, logout_time, status } = req.body;
      if (!player_id) {
        return res.status(400).json({ error: 'player_id is required' });
      }
      try {
        // Fetch tier from PlayerCard
        let currentGamingDay = await prisma.gamingDay.findFirst({
          where: { status: 'OPEN' },
          orderBy: { gaming_day_id: 'desc' },
        });
        const playerCard = await prisma.playerCard.findUnique({ where: { user_id: player_id } });
        const tier = playerCard ? playerCard.tier : 'Silver';
        const entry = await prisma.playerEntryLog.create({
          data: {
            player_id,
            tier,
            login_time: login_time ? new Date(login_time) : undefined,
            logout_time: logout_time ? new Date(logout_time) : undefined,
            status: status || 'INSIDE',
            gaming_day_id: currentGamingDay?.gaming_day_id || undefined
          },
        });
        return res.status(201).json(entry);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'PUT': {
      // Update entry log
      const { id, ...updateData } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }
      try {
        const updated = await prisma.playerEntryLog.update({
          where: { id: Number(id) },
          data: updateData,
        });
        return res.status(200).json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'GET': {
      // All counts and logs are filtered by the current gaming day's gaming_day_id
      try {
        const { logsByCategory, logsOnly } = req.query;
        // Find the current gaming day (OPEN, or latest by start_time)
        let currentGamingDay = await prisma.gamingDay.findFirst({
          where: { status: 'OPEN' },
          orderBy: { gaming_day_id: 'desc' },
        });
        if (!currentGamingDay) {
          currentGamingDay = await prisma.gamingDay.findFirst({ orderBy: { gaming_day_id: 'desc' } });
        }
        if (!currentGamingDay) {
          return res.status(404).json({ error: 'No gaming day found' });
        }
        const gamingDayId = currentGamingDay.gaming_day_id;

        // Always compute summary, filtered by gaming_day_id
        const vipCount = await prisma.playerEntryLog.count({ where: { gaming_day_id: gamingDayId, tier: { in: [Tier.VIP, Tier.VVIP] } } });
        const normalCount = await prisma.playerEntryLog.count({ where: { gaming_day_id: gamingDayId, tier: { in: [Tier.Silver, Tier.Gold, Tier.Premium] } } });
        const insideCount = await prisma.playerEntryLog.count({ where: { gaming_day_id: gamingDayId, status: 'INSIDE' } });
        let todaysCount = 0;
        if (currentGamingDay.start_time) {
          todaysCount = await prisma.playerEntryLog.count({
            where: {
              gaming_day_id: gamingDayId,
              login_time: {
                gte: currentGamingDay.start_time,
              },
            },
          });
        }
        const summary = { vipCount, normalCount, insideCount, todaysCount };
        if (logsOnly) {
          // Fetch all logs with user info, not grouped, filtered by gaming_day_id
          const logs = await prisma.playerEntryLog.findMany({
            where: { gaming_day_id: gamingDayId },
            include: {
              player: {
                select: { user_id: true, full_name: true }
              }
            }
          });
          const logsList = logs.map(log => ({
            id: log.id,
            player_id: log.player_id,
            full_name: log.player?.full_name ?? null,
            tier: log.tier,
            login_time: log.login_time,
            logout_time: log.logout_time,
            status: log.status,
          }));
          return res.status(200).json({ summary, logs: logsList });
        }
        if (logsByCategory) {
          // Fetch all logs with user info, filtered by gaming_day_id
          const logs = await prisma.playerEntryLog.findMany({
            where: { gaming_day_id: gamingDayId },
            include: {
              player: {
                select: { user_id: true, full_name: true }
              }
            }
          });
          // Group logs by tier
          const grouped: Record<string, any[]> = {};
          for (const log of logs) {
            const tier = log.tier;
            if (!grouped[tier]) grouped[tier] = [];
            grouped[tier].push({
              id: log.id,
              player_id: log.player_id,
              user_id: log.player?.user_id ?? null,
              full_name: log.player?.full_name ?? null,
              login_time: log.login_time,
              logout_time: log.logout_time,
              status: log.status,
            });
          }
          return res.status(200).json({ summary, logsByCategory: grouped });
        }
        // Default: summary only
        return res.status(200).json({ summary });
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'DELETE': {
      // Delete entry log
      const { id } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }
      try {
        await prisma.playerEntryLog.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    default:
      res.setHeader('Allow', ['POST', 'PUT', 'GET', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
