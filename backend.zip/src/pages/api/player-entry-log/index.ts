import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient, Tier, Prisma } from '@prisma/client';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'POST': {
      // Create new entry log, fetch tier from PlayerCard
      const { player_id, login_time, logout_time, status } = req.body;
      if (!player_id) {
        return res.status(400).json({ error: 'player_id is required' });
      }
      try {
        // Fetch tier from PlayerCard
        let currentGamingDay = await prisma.gamingDay.findFirst({
          where: { status: 'OPEN' },
          orderBy: { gaming_day_id: 'desc' },
        });
        const playerCard = await prisma.playerCard.findFirst({
          where: { user_id: player_id, status: 'Active' },
          orderBy: { card_id: 'desc' },
        }) || await prisma.playerCard.findFirst({
          where: { user_id: player_id },
          orderBy: { card_id: 'desc' },
        });
        const tier = playerCard ? playerCard.tier : 'Silver';
        const entry = await prisma.playerEntryLog.create({
          data: {
            player_id,
            tier,
            login_time: login_time ? new Date(login_time) : undefined,
            logout_time: logout_time ? new Date(logout_time) : undefined,
            status: status || 'INSIDE',
            gaming_day_id: currentGamingDay?.gaming_day_id || undefined
          },
        });
        return res.status(201).json(entry);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'PUT': {
      // Update entry log
      const { id, ...updateData } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }
      try {
        const updated = await prisma.playerEntryLog.update({
          where: { id: Number(id) },
          data: updateData,
        });
        return res.status(200).json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'GET': {
      // All counts and logs are filtered by the current gaming day's gaming_day_id
      try {
        const { logsByCategory, logsOnly } = req.query;
        // Find the current gaming day (OPEN, or latest by start_time)
        let currentGamingDay = await prisma.gamingDay.findFirst({
          where: { status: 'OPEN' },
          orderBy: { gaming_day_id: 'desc' },
        });
        if (!currentGamingDay) {
          currentGamingDay = await prisma.gamingDay.findFirst({ orderBy: { gaming_day_id: 'desc' } });
        }
        if (!currentGamingDay) {
          return res.status(404).json({ error: 'No gaming day found' });
        }
        const gamingDayId = currentGamingDay.gaming_day_id;

        // Always compute summary and logs based on unique players for the gaming day
        const allLogs = await prisma.playerEntryLog.findMany({
          where: { gaming_day_id: gamingDayId },
          include: {
            player: {
              select: { user_id: true, full_name: true, tier: true }
            }
          },
          orderBy: [
            { login_time: 'desc' },
            { id: 'desc' }
          ]
        });

        // Deduplicate by player_id so each distinct person is only evaluated once (using their latest entry)
        const latestLogByPlayer = new Map<number, typeof allLogs[0]>();
        for (const log of allLogs) {
          if (!latestLogByPlayer.has(log.player_id)) {
            latestLogByPlayer.set(log.player_id, log);
          }
        }
        const uniquePlayers = Array.from(latestLogByPlayer.values());

        const isVipTier = (tier?: string | null) => {
          const t = String(tier || '').trim().toUpperCase();
          return t === 'VIP' || t === 'VVIP';
        };

        let vipCount = 0;
        let normalCount = 0;
        let insideCount = 0;
        let todaysCount = 0;

        const gamingDayStartTime = currentGamingDay.start_time
          ? new Date(currentGamingDay.start_time).getTime()
          : 0;

        for (const log of uniquePlayers) {
          const effectiveTier = log.tier || log.player?.tier;
          if (isVipTier(effectiveTier)) {
            vipCount++;
          } else {
            normalCount++;
          }

          if (String(log.status).toUpperCase() === 'INSIDE') {
            insideCount++;
          }

          if (!gamingDayStartTime || (log.login_time && new Date(log.login_time).getTime() >= gamingDayStartTime)) {
            todaysCount++;
          }
        }

        const summary = { vipCount, normalCount, insideCount, todaysCount };

        if (logsOnly) {
          const logsList = uniquePlayers.map(log => ({
            id: log.id,
            player_id: log.player_id,
            full_name: log.player?.full_name ?? null,
            tier: isVipTier(log.tier || log.player?.tier) ? 'VIP' : (log.tier || log.player?.tier || 'Silver'),
            login_time: log.login_time,
            logout_time: log.logout_time,
            status: log.status,
          }));

          const allLogsList = allLogs.map(log => ({
            id: log.id,
            player_id: log.player_id,
            full_name: log.player?.full_name ?? null,
            tier: isVipTier(log.tier || log.player?.tier) ? 'VIP' : (log.tier || log.player?.tier || 'Silver'),
            login_time: log.login_time,
            logout_time: log.logout_time,
            status: log.status,
          }));

          return res.status(200).json({ summary, logs: logsList, allLogs: allLogsList });
        }

        if (logsByCategory) {
          const grouped: Record<string, any[]> = {};
          for (const log of uniquePlayers) {
            const tier = isVipTier(log.tier || log.player?.tier) ? 'VIP' : String(log.tier || log.player?.tier || 'Silver');
            if (!grouped[tier]) grouped[tier] = [];
            grouped[tier].push({
              id: log.id,
              player_id: log.player_id,
              user_id: log.player?.user_id ?? null,
              full_name: log.player?.full_name ?? null,
              login_time: log.login_time,
              logout_time: log.logout_time,
              status: log.status,
            });
          }
          return res.status(200).json({ summary, logsByCategory: grouped });
        }

        // Default: summary only
        return res.status(200).json({ summary });
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    case 'DELETE': {
      // Delete entry log
      const { id } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }
      try {
        await prisma.playerEntryLog.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    }
    default:
      res.setHeader('Allow', ['POST', 'PUT', 'GET', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
