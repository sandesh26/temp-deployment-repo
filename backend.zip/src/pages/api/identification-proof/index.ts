import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { search, take, skip } = req.query as any;
      const where: any = {};
      if (search) {
        where.name = { contains: String(search), mode: 'insensitive' };
      }

      const items = await (prisma as any).identificationProof.findMany({
        where,
        orderBy: { identification_id: 'asc' },
        take: take ? Number(take) : undefined,
        skip: skip ? Number(skip) : undefined,
      });
      return res.status(200).json(items);
    } catch (error: any) {
      console.error('IdentificationProof GET error', error);
      return res.status(500).json({ error: error.message || 'Failed to fetch identification proofs' });
    }
  }

  if (req.method === 'POST') {
    try {
      const body = req.body;
      const name = (body.name || '').toString().trim();
      if (!name) return res.status(400).json({ error: 'name is required' });

      const created = await (prisma as any).identificationProof.create({ data: { name } });
      return res.status(201).json(created);
    } catch (error: any) {
      console.error('IdentificationProof POST error', error);
      return res.status(400).json({ error: error.message || 'Failed to create identification proof' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
