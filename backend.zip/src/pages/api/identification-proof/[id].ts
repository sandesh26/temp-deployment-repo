import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const identId = Number(id);
  if (Number.isNaN(identId)) return res.status(400).json({ error: 'Invalid id' });

  try {
    if (req.method === 'GET') {
      const item = await (prisma as any).identificationProof.findUnique({ where: { identification_id: identId } });
      if (!item) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(item);
    }

    if (req.method === 'PUT') {
      const body = req.body;
      const name = body.name ? String(body.name).trim() : undefined;
      if (!name) return res.status(400).json({ error: 'name is required' });
      const updated = await (prisma as any).identificationProof.update({ where: { identification_id: identId }, data: { name } });
      return res.status(200).json(updated);
    }

    if (req.method === 'PATCH') {
      const body = req.body;
      const data: any = {};
      if (body.name !== undefined) data.name = String(body.name).trim();

      const updated = await (prisma as any).identificationProof.update({ where: { identification_id: identId }, data });
      return res.status(200).json(updated);
    }

    if (req.method === 'DELETE') {
      await (prisma as any).identificationProof.delete({ where: { identification_id: identId } });
      return res.status(204).end();
    }

    res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error: any) {
    console.error('IdentificationProof [id] error', error);
    return res.status(500).json({ error: error.message || 'Server error' });
  }
}
