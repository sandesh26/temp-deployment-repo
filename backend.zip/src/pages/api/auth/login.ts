// pages/api/auth/login.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '../../../../lib/prisma';
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { createRateLimiter } from '../../../middleware/validation';
import { cors } from '../../../lib/cors';

interface LoginRequest {
  username: string;
  password: string;
  // If true, the client has pre-hashed the password with SHA-256 and sends hex string
  password_hashed?: boolean;
}

interface LoginResponse {
  success: boolean;
  token?: string;
  employee?: {
    employee_id: number;
    username: string;
    role: string;
    access_level: number;
    user: {
  user_id: number;
  full_name: string | null;
      email: string | null;
      phone: string;
      role: string;
      status: string;
    };
  };
  message?: string;
}

// Create rate limiter for login attempts
const rateLimiter = createRateLimiter();

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<LoginResponse>
) {
  // Handle CORS
  if (cors(req, res)) return;

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed. Use POST.',
    });
  }

  // Apply rate limiting
  try {
    await new Promise((resolve, reject) => {
      rateLimiter(req as any, res as any, (error?: any) => {
        if (error) reject(error);
        else resolve(undefined);
      });
    });
  } catch (error) {
    return res.status(429).json({
      success: false,
      message: 'Too many login attempts. Please try again later.',
    });
  }

  try {
    const { username, password }: LoginRequest = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.',
      });
    }

    // Validate input types and format
    if (typeof username !== 'string' || typeof password !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Invalid input format.',
      });
    }

    // Sanitize username (trim whitespace)
    const sanitizedUsername = username.trim();

    if (sanitizedUsername.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Username cannot be empty.',
      });
    }

    // Find employee by username
    const employee = await prisma.employee.findUnique({
      where: {
        username: sanitizedUsername,
      },
      select: {
        employee_id: true,
        username: true,
        password_hash: true,
        role: true,
        access_level: true,
        user: {
          select: {
            user_id: true,
            full_name: true,
            email: true,
            phone: true,
            role: true,
            status: true,
          },
        },
      },
    });

    // Check if employee exists
    if (!employee) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    // Check if user account is active
    if (employee.user.status !== 'Active') {
      return res.status(401).json({
        success: false,
        message: 'Account is not active. Please contact administrator.',
      });
    }

    // Determine whether client sent a pre-hashed (SHA-256 hex) password
    const passwordHashed = Boolean((req.body && (req.body as any).password_hashed) ?? false);

    // Basic validation for hashed password format when flagged
    if (passwordHashed && !/^[a-fA-F0-9]{64}$/.test(String(password))) {
      return res.status(400).json({ success: false, message: 'Invalid hashed password format.' });
    }

    const candidate = String(password);

    const storedHash = String(employee.password_hash || '');
    const isBcrypt = storedHash.startsWith('$2');
    const isStoredSha256 = /^[a-fA-F0-9]{64}$/.test(storedHash);

    let isPasswordValid = false;

    if (isBcrypt) {
      // stored as bcrypt (could be bcrypt(plaintext) or bcrypt(sha256))
      isPasswordValid = await bcrypt.compare(candidate, storedHash);
      console.log('[DEBUG] bcrypt.compare result:', isPasswordValid);
    } else if (isStoredSha256) {
      // stored as raw sha256 hex
      if (/^[a-fA-F0-9]{64}$/.test(candidate)) {
        // client already sent sha256 hex — compare case-insensitive
        isPasswordValid = candidate.toLowerCase() === storedHash.toLowerCase();
        console.log('[DEBUG] raw-sha256 direct compare result:', isPasswordValid);
      } else {
        // client sent plaintext — compute sha256 and compare
        const sha = crypto.createHash('sha256').update(candidate, 'utf8').digest('hex');
        isPasswordValid = sha.toLowerCase() === storedHash.toLowerCase();
        console.log('[DEBUG] raw-sha256 computed compare result:', isPasswordValid);
      }
    } else {
      // Unknown stored format: try bcrypt first (best-effort), then fallback to direct equality
      try {
        isPasswordValid = await bcrypt.compare(candidate, storedHash);
      } catch (e) {
        // ignore
      }
      if (!isPasswordValid) {
        isPasswordValid = candidate === storedHash;
      }
      console.log('[DEBUG] fallback compare result:', isPasswordValid);
    }

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    // Optional migration: if user logged in with plaintext (client did not hash) but you want to
    // move to client-side hashing going forward, re-hash and store bcrypt(SHA256(plaintext)).
    // Enable by setting MIGRATE_TO_CLIENT_HASH=true in env. This step is safe because it only
    // runs after successful authentication.
    try {
      const migrate = String(process.env.MIGRATE_TO_CLIENT_HASH ?? '').toLowerCase() === 'true';
      if (migrate && !passwordHashed) {
        // compute sha256 hex of plaintext
        const sha = crypto.createHash('sha256').update(candidate, 'utf8').digest('hex');
        const newHash = await bcrypt.hash(sha, 10);
        await prisma.employee.update({ where: { employee_id: employee.employee_id }, data: { password_hash: newHash } });
      }
    } catch (mErr) {
      // Migration failure should not block login; log and continue
      console.error('Password migration warning:', mErr);
    }

    // Get JWT secret
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      console.error('JWT_SECRET is not defined in environment variables');
      return res.status(500).json({
        success: false,
        message: 'Server configuration error.',
      });
    }

    // Create JWT payload
    const tokenPayload: any = {
      user_id: employee.user.user_id,
      employee_id: employee.employee_id,
      role: employee.role,
      access_level: employee.access_level,
    };

    // Enforce single-machine login: require client to send machine_id (or header)
    const incomingMachineId = (req.body && (req.body as any).machine_id) || req.headers['x-machine-id'] || null;
    const incomingDeviceId = (req.body && (req.body as any).device_id) || req.headers['x-device-id'] || null;

    // Acquire advisory lock to avoid race conditions when checking/creating sessions
    const lockName = `login_emp_${employee.employee_id}`;
    let gotLock = 0;
    try {
      // Attempt GET_LOCK for up to 3 seconds
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const resLock: any = await (prisma as any).$executeRaw`SELECT GET_LOCK(${lockName}, 3)`;
      // Different Prisma versions return different shapes; coerce to number
      gotLock = Number(resLock ?? 0);
    } catch (lockErr) {
      console.error('Lock acquisition failed:', lockErr);
      // proceed without lock if DB doesn't support it
      gotLock = 0;
    }

    try {
      // Query for existing active session
      const now = new Date();
      const activeSession = await (prisma as any).loginSession.findFirst({
        where: {
          employee_id: employee.employee_id,
          revoked: false,
          OR: [{ expires_at: null }, { expires_at: { gt: now } }],
        },
        orderBy: { created_at: 'desc' },
      });

      if (activeSession) {
        // If session exists on different machine, deny login
        if (incomingMachineId && activeSession.machine_id && String(activeSession.machine_id) !== String(incomingMachineId)) {
          // release lock if we got it
          try { if (gotLock === 1) await (prisma as any).$executeRaw`SELECT RELEASE_LOCK(${lockName})`; } catch (e) {}
          return res.status(409).json({ success: false, message: 'Already logged in on another machine.' });
        }
        // otherwise, allow (same machine) — we may refresh session below
      }

      // Create session entry and include jti in token
      const jti = crypto.randomBytes(16).toString('hex');
      tokenPayload.jti = jti;
      const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000); // 8 hours

      try {
        await (prisma as any).loginSession.create({
          data: {
            employee_id: employee.employee_id,
            jti,
            device_id: incomingDeviceId ? String(incomingDeviceId) : null,
            machine_id: incomingMachineId ? String(incomingMachineId) : null,
            ip_address: (req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : (req.socket.remoteAddress || null)) as any,
            user_agent: req.headers['user-agent'] ? String(req.headers['user-agent']) : null,
            expires_at: expiresAt,
          },
        });
      } catch (createErr) {
        console.error('Failed to create login session record:', createErr);
      }
    } finally {
      // Release advisory lock if held
      try { if (gotLock === 1) await (prisma as any).$executeRaw`SELECT RELEASE_LOCK(${lockName})`; } catch (e) {}
    }

    // Generate JWT token (expires in 8 hours)
    const token = jwt.sign(tokenPayload, jwtSecret, {
      expiresIn: '8h',
      issuer: 'casino-management-system',
      audience: 'casino-employees',
    });

    // Return success response with token and employee data
    const responseData = {
      employee_id: employee.employee_id,
      username: employee.username,
      role: employee.role,
      access_level: employee.access_level,
      user: employee.user,
    };

    return res.status(200).json({
      success: true,
      token,
      employee: responseData,
      message: 'Login successful.',
    });

  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error. Please try again later.',
    });
  }
}