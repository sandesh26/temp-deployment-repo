import type { NextApiRequest, NextApiResponse } from 'next';
import crypto from 'crypto';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';
import { createRateLimiter } from '../../../middleware/validation';

// Simple response shape
type PinResponse = {
  Validation?: string;
  success?: boolean;
  token?: string;
  employee?: any;
  message?: string;
};

const rateLimiter = createRateLimiter();

export default async function handler(req: NextApiRequest, res: NextApiResponse<PinResponse>) {
  if (cors(req, res)) return;

  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  try {
    await new Promise((resolve, reject) => {
      rateLimiter(req as any, res as any, (err?: any) => (err ? reject(err) : resolve(undefined)));
    });
  } catch (err) {
    return res.status(429).json({ success: false, message: 'Too many requests' });
  }

  try {
    const { pin, employee_pin } = req.body || {};
    const pinValue = pin ?? employee_pin;
    const rawPin = String(pinValue ?? '').trim();

    if (!rawPin) {
      return res.status(400).json({ success: false, message: 'pin is required in request body' });
    }

    const candidateHash = crypto.createHash('sha256').update(rawPin, 'utf8').digest('hex').toLowerCase();
    const candidatePlain = rawPin.toLowerCase();

    const employees = await prisma.employee.findMany({
      include: { user: true },
    });

    const employee = employees.find((entry: any) => {
      const stored = String(entry.pin ?? '').trim();
      if (!stored) return false;

      const storedLower = stored.toLowerCase();
      return storedLower === candidatePlain || storedLower === candidateHash;
    });

    if (!employee) {
      return res.status(404).json({ success: false, message: 'PIN not found' });
    }

    if ((employee as any).user?.status && (employee as any).user.status !== 'Active') {
      return res.status(401).json({ success: false, message: 'Employee account not active' });
    }

    const employeeOut = {
      employee_id: employee.employee_id,
      username: employee.username,
      role: employee.role,
      access_level: employee.access_level,
      user: employee.user,
    };

    return res.status(200).json({ Validation: 'True', employee: employeeOut });
  } catch (err: any) {
    console.error('/api/auth/pin error:', err);
    return res.status(200).json({ Validation: 'False' });
  }
}

// Sample request (JSON):
// POST /api/auth/pin
// { "pin": "<sha256 hex value or plain pin>" }
