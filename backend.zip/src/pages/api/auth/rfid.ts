import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '../../../../lib/prisma';
import { cors } from '../../../lib/cors';
import { createRateLimiter } from '../../../middleware/validation';

// Simple response shape
type RfidResponse = {
  Validation?: string;
  success?: boolean;
  token?: string;
  employee?: any;
  message?: string;
};

const rateLimiter = createRateLimiter();

export default async function handler(req: NextApiRequest, res: NextApiResponse<RfidResponse>) {
  if (cors(req, res)) return;

  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ success: false, message: 'Method Not Allowed' });
  }

  // Rate limit to avoid abuse
  try {
    await new Promise((resolve, reject) => {
      rateLimiter(req as any, res as any, (err?: any) => (err ? reject(err) : resolve(undefined)));
    });
  } catch (err) {
    return res.status(429).json({ success: false, message: 'Too many requests' });
  }

  try {
    const { rfid, rfid_number } = req.body || {};
    const tokenStr = String(rfid ?? rfid_number ?? '').trim();
    if (!tokenStr) return res.status(400).json({ success: false, message: 'rfid is required in request body' });

    // Look up employee by rfid_number directly on employee table
    let employee: any = null;
    try {
      employee = await prisma.employee.findFirst({ where: { rfid_number: tokenStr }, include: { user: true } });
    } catch (e) {
      // If the Employee model doesn't have rfid_number or the client/runtime doesn't support this
      // field, fall back to trying prefixed/endsWith queries via raw lookup on employee table.
      try {
        // try equality with prefix
        employee = await prisma.employee.findFirst({ where: { rfid_number: `RFID${tokenStr}` }, include: { user: true } });
      } catch (e2) {
        // ignore - we'll try findFirst below
      }
    }

    // Final fallback: find an employee whose rfid_number ends with the provided token
    if (!employee) {
      try {
        const maybe = await prisma.employee.findFirst({ where: { rfid_number: { endsWith: tokenStr } }, include: { user: true } });
        if (maybe) employee = maybe;
      } catch (e) {
        // ignore - fall through to playerCard lookup as last resort
      }
    }

    // Last resort: if employee not found on employee table, try the previous playerCard -> user -> employee flow
    if (!employee) {
      // Look up player card by rfid_number
      let card = await prisma.playerCard.findUnique({ where: { rfid_number: tokenStr }, include: { user: true } });
      if (!card) {
        try {
          card = await prisma.playerCard.findUnique({ where: { rfid_number: `RFID${tokenStr}` }, include: { user: true } });
        } catch (e) {
          // ignore
        }
      }
      if (!card) {
        const maybe = await prisma.playerCard.findFirst({ where: { rfid_number: { endsWith: tokenStr } }, include: { user: true } });
        if (maybe) card = maybe;
      }
      if (!card || !card.user) {
        return res.status(404).json({ success: false, message: 'RFID not found' });
      }
      // map to employee via user
      employee = await prisma.employee.findUnique({ where: { user_id: card.user.user_id }, include: { user: true } });
    }

    if (!employee) {
      // Found a player card but not an employee account
      return res.status(403).json({ success: false, message: 'RFID not associated with an employee' });
    }

    // Check user status if present
    if ((employee as any).user?.status && (employee as any).user.status !== 'Active') {
      return res.status(401).json({ success: false, message: 'Employee account not active' });
    }

    // Return a simple Validation flag string and employee details as requested.
    // We do not issue JWT here. Return 200 with Validation: "True" and employee info on success.
    const employeeOut = {
      employee_id: employee.employee_id,
      username: employee.username,
      role: employee.role,
      access_level: employee.access_level,
      user: employee.user,
    };

    return res.status(200).json({ Validation: 'True', employee: employeeOut });
  } catch (err: any) {
    console.error('/api/auth/rfid error:', err);
    // On error, return Validation: 'False' to the caller per requested format
    return res.status(200).json({ Validation: 'False' });
  }
}

// Sample request (JSON):
// POST /api/auth/rfid
// { "rfid": "RFID0001" }
