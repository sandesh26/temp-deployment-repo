// pages/api/auth/logout.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { cors } from '../../../lib/cors';

interface LogoutResponse {
  success: boolean;
  message: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<LogoutResponse>
) {
  // Handle CORS
  if (cors(req, res)) return;

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed. Use POST.',
    });
  }

  // Since JWTs are stateless, logout is handled on the client side
  // by removing the token from storage
  // We can log the logout event here if needed
  
  return res.status(200).json({
    success: true,
    message: 'Logout successful. Please remove the token from client storage.',
  });
}