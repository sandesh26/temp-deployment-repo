import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (!id || Array.isArray(id)) {
    return res.status(400).json({ error: 'Invalid permission_id' });
  }
  const permissionId = Number(id);
  switch (req.method) {
    case 'GET': {
      // Get user permission by id
      const permission = await prisma.userPermissions.findUnique({ where: { permission_id: permissionId } });
      if (!permission) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(permission);
    }
    case 'PUT': {
      // Update user permission by id
      try {
        const body = req.body;

        // If body is an array, perform bulk updates using transaction
        if (Array.isArray(body)) {
          if (body.length === 0) return res.status(400).json({ error: 'Empty array' });
          const MAX_BATCH = 100; // safety limit
          if (body.length > MAX_BATCH) return res.status(400).json({ error: `Batch size limit exceeded (${MAX_BATCH})` });

          // Each item must include permission_id and at least one updatable field
          const updates = body.map((item: any) => {
            const pid = item.permission_id ?? item.permissionId ?? null;
            if (!pid) throw new Error('permission_id is required for each item');
            const d: any = {};
            if (item.role_name !== undefined || item.roleName !== undefined) d.role_name = item.role_name ?? item.roleName;
            if (item.module_name !== undefined || item.moduleName !== undefined) d.module_name = item.module_name ?? item.moduleName;
            if (item.can_view !== undefined || item.canView !== undefined) d.can_view = typeof (item.can_view ?? item.canView) === 'boolean' ? (item.can_view ?? item.canView) : (item.can_view ?? item.canView) === 'true';
            if (item.can_create !== undefined || item.canCreate !== undefined) d.can_create = typeof (item.can_create ?? item.canCreate) === 'boolean' ? (item.can_create ?? item.canCreate) : (item.can_create ?? item.canCreate) === 'true';
            if (item.can_edit !== undefined || item.canEdit !== undefined) d.can_edit = typeof (item.can_edit ?? item.canEdit) === 'boolean' ? (item.can_edit ?? item.canEdit) : (item.can_edit ?? item.canEdit) === 'true';
            if (item.can_action !== undefined || item.canAction !== undefined) d.can_action = typeof (item.can_action ?? item.canAction) === 'boolean' ? (item.can_action ?? item.canAction) : (item.can_action ?? item.canAction) === 'true';
            if (Object.keys(d).length === 0) throw new Error('No updatable fields provided for permission_id ' + pid);
            return { where: { permission_id: Number(pid) }, data: d };
          });

          // Run transaction of updates and return updated rows
          const tx = await prisma.$transaction(updates.map(u => prisma.userPermissions.update(u as any)));
          return res.status(200).json(tx);
        }

        // Single update (existing behavior)
        const data: any = {};
        if (body.role_name !== undefined || body.roleName !== undefined) data.role_name = body.role_name ?? body.roleName;
        if (body.module_name !== undefined || body.moduleName !== undefined) data.module_name = body.module_name ?? body.moduleName;
        if (body.can_view !== undefined || body.canView !== undefined) data.can_view = typeof (body.can_view ?? body.canView) === 'boolean' ? (body.can_view ?? body.canView) : (body.can_view ?? body.canView) === 'true';
        if (body.can_create !== undefined || body.canCreate !== undefined) data.can_create = typeof (body.can_create ?? body.canCreate) === 'boolean' ? (body.can_create ?? body.canCreate) : (body.can_create ?? body.canCreate) === 'true';
        if (body.can_edit !== undefined || body.canEdit !== undefined) data.can_edit = typeof (body.can_edit ?? body.canEdit) === 'boolean' ? (body.can_edit ?? body.canEdit) : (body.can_edit ?? body.canEdit) === 'true';
        if (body.can_action !== undefined || body.canAction !== undefined) data.can_action = typeof (body.can_action ?? body.canAction) === 'boolean' ? (body.can_action ?? body.canAction) : (body.can_action ?? body.canAction) === 'true';

        const updated = await prisma.userPermissions.update({ where: { permission_id: permissionId }, data: data as any });
        return res.status(200).json(updated);
      } catch (error) {
        return res.status(400).json({ error: (error as Error).message });
      }
    }
    case 'DELETE': {
      // Delete user permission by id
      try {
        await prisma.userPermissions.delete({ where: { permission_id: permissionId } });
        return res.status(204).end();
      } catch (error) {
        return res.status(400).json({ error: (error as Error).message });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
