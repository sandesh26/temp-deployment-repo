import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      // Get all user permissions or filter by role_name/roleName (case-insensitive exact match)
      const { role_name, roleName } = req.query;
      const roleFilter = (role_name as string) ?? (roleName as string) ?? null;
      if (roleFilter) {
        // Prisma 'mode: insensitive' may not be available on all connectors; do a JS-based case-insensitive filter
        const all = await prisma.userPermissions.findMany({ orderBy: { permission_id: 'asc' } });
        const lf = roleFilter.toLowerCase();
        const filtered = all.filter((p) => (p.role_name ?? '').toLowerCase() === lf);
        return res.status(200).json(filtered);
      }

      // No filter - return all
      const permissions = await prisma.userPermissions.findMany({ orderBy: { permission_id: 'asc' } });
      return res.status(200).json(permissions);
    }
    case 'POST': {
      // Create single or bulk user permissions
      try {
        const body = req.body;
        if (Array.isArray(body)) {
          // Bulk create - map and normalize boolean values (accept snake_case or camelCase)
          const data = body.map((item) => ({
            role_name: item.role_name ?? item.roleName,
            module_name: item.module_name ?? item.moduleName,
            can_view: typeof (item.can_view ?? item.canView) === 'boolean' ? (item.can_view ?? item.canView) : (item.can_view ?? item.canView) === 'true',
            can_create: typeof (item.can_create ?? item.canCreate) === 'boolean' ? (item.can_create ?? item.canCreate) : (item.can_create ?? item.canCreate) === 'true',
            can_edit: typeof (item.can_edit ?? item.canEdit) === 'boolean' ? (item.can_edit ?? item.canEdit) : (item.can_edit ?? item.canEdit) === 'true',
            can_action: typeof (item.can_action ?? item.canAction) === 'boolean' ? (item.can_action ?? item.canAction) : (item.can_action ?? item.canAction) === 'true',
          }));
          const result = await prisma.userPermissions.createMany({ data: data as any });
          return res.status(201).json({ count: result.count });
        }

        const role_name = body.role_name ?? body.roleName;
        const module_name = body.module_name ?? body.moduleName;
        const can_view = typeof (body.can_view ?? body.canView) === 'boolean' ? (body.can_view ?? body.canView) : (body.can_view ?? body.canView) === 'true';
        const can_create = typeof (body.can_create ?? body.canCreate) === 'boolean' ? (body.can_create ?? body.canCreate) : (body.can_create ?? body.canCreate) === 'true';
        const can_edit = typeof (body.can_edit ?? body.canEdit) === 'boolean' ? (body.can_edit ?? body.canEdit) : (body.can_edit ?? body.canEdit) === 'true';
        const can_action = typeof (body.can_action ?? body.canAction) === 'boolean' ? (body.can_action ?? body.canAction) : (body.can_action ?? body.canAction) === 'true';

        if (!role_name || !module_name) {
          return res.status(400).json({ error: 'role_name and module_name are required' });
        }

        const createData = {
          role_name,
          module_name,
          can_view,
          can_create,
          can_edit,
          can_action,
        };
        const single = await prisma.userPermissions.create({ data: createData as any });
        return res.status(201).json(single);
      } catch (error) {
        return res.status(400).json({ error: (error as Error).message });
      }
    }
    case 'PUT': {
      // Bulk update user permissions
      try {
        const body = req.body;
        
        if (!Array.isArray(body)) {
          return res.status(400).json({ error: 'PUT requires an array of permission objects' });
        }
        
        if (body.length === 0) {
          return res.status(400).json({ error: 'Empty array' });
        }
        
        const MAX_BATCH = 100;
        if (body.length > MAX_BATCH) {
          return res.status(400).json({ error: `Batch size limit exceeded (${MAX_BATCH})` });
        }

        // Each item must include permission_id and at least one updatable field
        const updates = body.map((item: any) => {
          const pid = item.permission_id ?? item.permissionId ?? null;
          if (!pid) throw new Error('permission_id is required for each item');
          
          const data: any = {};
          if (item.role_name !== undefined || item.roleName !== undefined) data.role_name = item.role_name ?? item.roleName;
          if (item.module_name !== undefined || item.moduleName !== undefined) data.module_name = item.module_name ?? item.moduleName;
          if (item.can_view !== undefined || item.canView !== undefined) data.can_view = typeof (item.can_view ?? item.canView) === 'boolean' ? (item.can_view ?? item.canView) : (item.can_view ?? item.canView) === 'true';
          if (item.can_create !== undefined || item.canCreate !== undefined) data.can_create = typeof (item.can_create ?? item.canCreate) === 'boolean' ? (item.can_create ?? item.canCreate) : (item.can_create ?? item.canCreate) === 'true';
          if (item.can_edit !== undefined || item.canEdit !== undefined) data.can_edit = typeof (item.can_edit ?? item.canEdit) === 'boolean' ? (item.can_edit ?? item.canEdit) : (item.can_edit ?? item.canEdit) === 'true';
          if (item.can_action !== undefined || item.canAction !== undefined) data.can_action = typeof (item.can_action ?? item.canAction) === 'boolean' ? (item.can_action ?? item.canAction) : (item.can_action ?? item.canAction) === 'true';
          
          if (Object.keys(data).length === 0) throw new Error('No updatable fields provided for permission_id ' + pid);
          
          return { where: { permission_id: Number(pid) }, data };
        });

        // Run transaction of updates and return updated rows
        const updatedPermissions = await prisma.$transaction(
          updates.map(u => prisma.userPermissions.update(u as any))
        );
        
        return res.status(200).json(updatedPermissions);
      } catch (error) {
        return res.status(400).json({ error: (error as Error).message });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
