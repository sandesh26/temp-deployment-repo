import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

const validFilters = [
  'machine_id',
  'machine_number',
  'location',
  'current_player_id',
  'current_balance',
  'machine_status',
  'last_updated',
  'floor_id'
];

const validStatuses = [
  'Active', 'Inactive', 'Under_Maintenance',
  'Discoverable', 'Prepared', 'Test', 'Live', 'Warehouse', 'Removed'
];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { floor, top, ...otherFilters } = req.query;
      const where: any = {};

      for (const key of Object.keys(otherFilters)) {
        if (!validFilters.includes(key)) continue;
        let value = otherFilters[key];
        if (value === undefined || (typeof value === 'string' && value.trim() === '')) continue;
        if (Array.isArray(value)) {
          value = value.filter((v) => v && v.trim() !== '');
          if (value.length === 0) continue;
          if (value.length === 1) value = value[0];
        }
        if (['machine_id', 'current_player_id', 'floor_id'].includes(key)) {
          const num = Number(value);
          if (!isNaN(num)) where[key] = num;
        } else if (key === 'machine_status') {
          if (Array.isArray(value)) {
            const filtered = value.filter((v) => validStatuses.includes(v));
            if (filtered.length === 0) continue;
            where[key] = filtered.length === 1 ? filtered[0] : { in: filtered };
          } else if (typeof value === 'string' && validStatuses.includes(value)) {
            where[key] = value;
          } else {
            continue;
          }
        } else {
          where[key] = value;
        }
      }

      if (floor !== undefined) {
        const floorNum = Number(floor);
        if (!isNaN(floorNum)) {
          where.floor_id = floorNum;
        }
      }

      let topN: number | undefined = undefined;
      if (top !== undefined) {
        const parsedTop = Number(top);
        if (!isNaN(parsedTop) && parsedTop > 0) {
          topN = parsedTop;
        }
      }

      //const includeGames = typeof gamesdata === 'string' && gamesdata.toLowerCase() === 'true';

      const machines = await prisma.slotMachine.findMany({
        where,
        orderBy: { current_balance: 'desc' },
        take: topN,
        include: //includeGames ? { current_player: { select: { user_id: true, full_name: true } }, games: true }
                               { current_player: { select: { user_id: true, full_name: true } } },
      });

      const result = machines.map((machine: any) => ({
        ...machine,
        current_player_id: machine.current_player_id ?? null,
        current_player_name: machine.current_player?.full_name ?? null,
      }));

      return res.status(200).json(result);
    } catch (error: any) {
      console.error('SlotMachine GET error:', error);
      return res.status(500).json({ error: error.message || 'Failed to fetch slot machines' });
    }
  }

  if (req.method === 'POST') {
    try {
      let data = req.body;
      if (typeof data === 'string') data = JSON.parse(data);

      const newMachine = await prisma.slotMachine.create({ data });
      return res.status(201).json(newMachine);
    } catch (error: any) {
      console.error('SlotMachine POST error:', error);
      return res.status(400).json({ error: error.message || 'Slot machine creation failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}