import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../../lib/cors';

// Returns requests for a specific cage. Query param `open=true` will exclude closed ones.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { cageId } = req.query;
  const cage_id = Number(cageId);
  if (isNaN(cage_id)) return res.status(400).json({ error: 'Invalid cageId' });

  try {
    const openOnly = String(req.query.open || 'false').toLowerCase() === 'true';

    const where: any = { cage_id };
    if (openOnly) {
      where.NOT = { status: { in: ['CLOSED_CONFIRMED', 'CLOSED_REJECTED'] } };
    }

    const requests = await prisma.cageVaultRequest.findMany({
      where,
      orderBy: { requested_at: 'desc' },
      include: {
        initiatedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
        reviewedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
        confirmedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
      },
    });

    return res.status(200).json(requests);
  } catch (error: any) {
    console.error('CageVaultRequests by cage error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
