import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const requestId = Number(id);
  if (isNaN(requestId)) return res.status(400).json({ error: 'Invalid id' });

  try {
    switch (req.method) {
      case 'GET': {
        const reqRec = await prisma.cageVaultRequest.findUnique({
          where: { request_id: requestId },
          include: {
            cage: true,
            initiatedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
            reviewedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
            confirmedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
          },
        });
        if (!reqRec) return res.status(404).json({ error: 'Not found' });
        return res.status(200).json(reqRec);
      }

  case 'PATCH':
  case 'PUT': {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        // Allowed updatable fields
        const allowed: any = {}
        const fields = [
          'status', 'reviewed_by', 'reviewed_at', 'confirmed_by', 'confirmed_at',
          'remarks', 'rejection_reason', 'linked_vault_tx_id', 'performed_at', 'completed_at',
          'cash_amount', 'chip_amount', 'chip_denominations', 'attachment_path', 'priority'
        ];

        for (const f of fields) {
          if (data[f] !== undefined) allowed[f] = data[f];
        }

        // Convert numeric fields
        if (allowed.reviewed_by) allowed.reviewed_by = Number(allowed.reviewed_by);
        if (allowed.confirmed_by) allowed.confirmed_by = Number(allowed.confirmed_by);
        if (allowed.linked_vault_tx_id) allowed.linked_vault_tx_id = Number(allowed.linked_vault_tx_id);
        if (allowed.priority) allowed.priority = Number(allowed.priority);

        const updated = await prisma.cageVaultRequest.update({
          where: { request_id: requestId },
          data: allowed as any,
        });
        return res.status(200).json(updated);
      }

      case 'DELETE': {
        await prisma.cageVaultRequest.delete({ where: { request_id: requestId } });
        return res.status(204).end();
      }

      default:
        res.setHeader('Allow', ['GET', 'PATCH', 'PUT', 'DELETE']);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (error: any) {
    console.error('CageVaultRequests id error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
