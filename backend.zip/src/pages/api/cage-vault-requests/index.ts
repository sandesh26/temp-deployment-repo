import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

// List and create cage -> vault requests
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  try {
    switch (req.method) {
      case 'GET': {
        const { status, cage_id, vault_id, from, to } = req.query;
        const where: any = {};
        if (status) where.status = status as string;
        if (cage_id) where.cage_id = Number(cage_id);
        if (vault_id) where.vault_id = Number(vault_id);
        if (from || to) where.requested_at = {};
        if (from) where.requested_at.gte = new Date(String(from));
        if (to) where.requested_at.lte = new Date(String(to));

        const requests = await prisma.cageVaultRequest.findMany({
          where,
          orderBy: { requested_at: 'desc' },
          include: {
            cage: { select: { name: true, cage_id: true } },
            initiatedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
            reviewedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
            confirmedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
          },
        });

        return res.status(200).json(requests);
      }

      case 'POST': {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        // Validate required fields
        const required = ['request_type', 'cage_id', 'vault_id', 'amount', 'initiated_by'];
        for (const f of required) {
          if (data[f] === undefined || data[f] === null) {
            return res.status(400).json({ error: `${f} is required` });
          }
        }

        // Accept cash_amount and chip_amount; if not provided use 0
        const cash_amount = data.cash_amount !== undefined ? data.cash_amount : 0.00;
        const chip_amount = data.chip_amount !== undefined ? data.chip_amount : 0.00;

        // Optional chip_denominations should be JSON object or stringified JSON
        let chip_denominations = data.chip_denominations ?? null;
        if (typeof chip_denominations === 'string') {
          try { chip_denominations = JSON.parse(chip_denominations); } catch (err) { /* keep as string */ }
        }

        const newReq = await prisma.cageVaultRequest.create({
          // cast to any because prisma client types may not be regenerated yet
          data: {
            request_type: data.request_type,
            cage_id: Number(data.cage_id),
            vault_id: Number(data.vault_id),
            amount: data.amount,
            cash_amount,
            chip_amount,
            chip_denominations,
            initiated_by: Number(data.initiated_by),
            remarks: data.remarks || null,
            attachment_path: data.attachment_path || null,
            priority: data.priority || 2,
            status: data.status || 'PENDING_VAULT_ACTION',
          } as any,
        });

        return res.status(201).json(newReq);
      }

      default:
        res.setHeader('Allow', ['GET', 'POST']);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (error: any) {
    console.error('CageVaultRequests index error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
