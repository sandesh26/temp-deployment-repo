import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const chips = await prisma.vaultChipDenomination.findMany({
        orderBy: { chip_denomination: 'desc' },
      });
      const result = chips.map((chip: any) => ({
        ...chip,
        amount: chip.amount !== undefined && chip.amount !== null ? Number(chip.amount).toFixed(2) : null,
      }));
      return res.status(200).json(result);
    }
    case 'POST': {
      try {
        const data = req.body;
        const chip = await prisma.vaultChipDenomination.create({ data });
        return res.status(201).json(chip);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}