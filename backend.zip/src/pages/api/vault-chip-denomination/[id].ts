import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const chip = await prisma.vaultChipDenomination.findUnique({
        where: { id: Number(id) },
      });
      if (!chip) return res.status(404).json({ error: 'VaultChipDenomination not found' });
      return res.status(200).json(chip);
    }
    case 'PUT': {
      try {
        const data = req.body;
        const chip = await prisma.vaultChipDenomination.update({
          where: { id: Number(id) },
          data,
        });
        return res.status(200).json(chip);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.vaultChipDenomination.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}