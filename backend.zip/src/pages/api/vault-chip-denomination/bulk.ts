import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
if (cors(req, res)) return;
    if (req.method !== 'PUT') {
    res.setHeader('Allow', ['PUT']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  let updates = req.body;
  if (typeof updates === 'string') updates = JSON.parse(updates);

  if (!Array.isArray(updates)) {
    return res.status(400).json({ error: 'Request body must be an array of objects.' });
  }

  try {
    const results = [];
    for (const update of updates) {
      const { id, ...data } = update;
      if (!id) continue; // skip if no id
      const updated = await prisma.vaultChipDenomination.update({
        where: { id: Number(id) },
        data,
      });
      results.push(updated);
    }
    return res.status(200).json({ updated: results.length, records: results });
  } catch (error: any) {
    return res.status(400).json({ error: error.message || 'Bulk update failed' });
  }
}