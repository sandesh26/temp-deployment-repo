import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { configured, slot_machine_id } = req.query;
      const where: any = {};
      if (configured !== undefined) where.configured = configured;
      if (slot_machine_id !== undefined) {
        const id = Number(slot_machine_id);
        if (!isNaN(id)) where.slot_machine_id = id;
      }
      const configs = await prisma.slotMachineConfiguration.findMany({
        where,
        orderBy: { slot_machine_id: 'asc' },
      });
      return res.status(200).json(configs);
    }
    case 'POST': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const config = await prisma.slotMachineConfiguration.create({ data });
        return res.status(201).json(config);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Creation failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}