import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const config = await prisma.slotMachineConfiguration.findUnique({
        where: { slot_machine_id: Number(id) },
      });
      if (!config) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(config);
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const config = await prisma.slotMachineConfiguration.update({
          where: { slot_machine_id: Number(id) },
          data,
        });
        return res.status(200).json(config);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Update failed' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.slotMachineConfiguration.delete({
          where: { slot_machine_id: Number(id) },
        });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Delete failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}