import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

type VerifyResponse = { status: 'OK' | 'FAIL'; message?: string };

export default async function handler(req: NextApiRequest, res: NextApiResponse<VerifyResponse>) {
  if (cors(req, res)) return;

  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ status: 'FAIL', message: 'Method Not Allowed' });
  }

  try {
    const { rfid, pin, rfid_number } = req.body || {};
    const token = String(rfid ?? rfid_number ?? '').trim();
    const pinStr = typeof pin === 'number' ? String(pin) : (pin ?? '').toString();

    if (!token || !pinStr) return res.status(200).json({ status: 'FAIL', message: 'rfid and pin required' });

    // Try exact match on playerCard.rfid_number
    let card = await prisma.playerCard.findUnique({ where: { rfid_number: token } });

    // Fallbacks
    if (!card) {
      card = await prisma.playerCard.findUnique({ where: { rfid_number: `RFID${token}` } }).catch(() => null);
    }
    if (!card) {
      card = await prisma.playerCard.findFirst({ where: { rfid_number: { endsWith: token } } }).catch(() => null);
    }

    if (!card) return res.status(200).json({ status: 'FAIL' });

    // Compare pin (stored as plain string in DB)
    if ((card.pin ?? '').toString() === pinStr) {
      return res.status(200).json({ status: 'OK' });
    }

    return res.status(200).json({ status: 'FAIL' });
  } catch (err) {
    console.error('/api/playercard/verify-pin error:', err);
    return res.status(200).json({ status: 'FAIL' });
  }
}
