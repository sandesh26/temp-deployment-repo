import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

function normalizeStatus(status?: any): 'Active' | 'Inactive' | 'Banned' | undefined {
  if (!status) return undefined;
  const s = String(status).trim().toLowerCase();
  if (s === 'active') return 'Active';
  if (s === 'inactive') return 'Inactive';
  if (s === 'banned') return 'Banned';
  return undefined;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const card = await prisma.playerCard.findUnique({
        where: { card_id: Number(id) },
      });

      return card
        ? res.status(200).json(card)
        : res.status(404).json({ error: 'Player card not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching player card' });
    }
  }

  if (req.method === 'PUT' || req.method === 'PATCH') {
    try {
      const data = { ...req.body };
      if (data.status) {
        const norm = normalizeStatus(data.status);
        if (norm) data.status = norm;
      }
      const updated = await prisma.playerCard.update({
        where: { card_id: Number(id) },
        data,
      });
      return res.status(200).json(updated);
    } catch (err: any) {
      return res.status(400).json({ error: err?.message || 'Update failed' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.playerCard.delete({
        where: { card_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}