import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { user_id, ...otherFilters } = req.query;
      const where: any = { ...otherFilters };

      if (user_id !== undefined) {
        where.user_id = Number(user_id);
        const playerCard = await prisma.playerCard.findFirst({
          where,
          orderBy: { card_id: 'desc' },
        });
        return res.status(200).json(playerCard);
      } else {
        const playerCards = await prisma.playerCard.findMany({
          where,
          orderBy: { card_id: 'desc' },
        });
        return res.status(200).json(playerCards);
      }
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch player cards' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { user_id, rfid_number, pin, balance, loyalty_points, tier } = req.body;

      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required' });
      }
      if (!rfid_number || typeof rfid_number !== 'string') {
        return res.status(400).json({ error: 'rfid_number is required and must be a string' });
      }
      if (pin === undefined || pin === null || (typeof pin !== 'string' && typeof pin !== 'number')) {
        return res.status(400).json({ error: 'pin is required and must be a string or number' });
      }

      const newCard = await prisma.playerCard.create({
        data: {
          user_id: Number(user_id),
          rfid_number: String(rfid_number),
          pin: String(pin),
          balance: balance !== undefined ? balance : 0,
          loyalty_points: loyalty_points !== undefined ? loyalty_points : 0,
          tier: tier ?? 'Silver',
        },
      });
      return res.status(201).json(newCard);
    } catch (error) {
      // If Prisma unique constraint or other DB error, surface message
      const msg = (error as any)?.message ? String((error as any).message) : 'Player card creation failed';
      return res.status(400).json({ error: msg });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { user_id, ...updateData } = req.body;
      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required for update' });
      }

      const updated = await prisma.playerCard.updateMany({
        where: { user_id: Number(user_id) },
        data: updateData,
      });

      return res.status(200).json(updated);
    } catch (error) {
      return res.status(400).json({ error: 'Player card update failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST', 'PUT']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}