import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { user_id, ...otherFilters } = req.query;
      const where: any = { ...otherFilters };

      if (user_id !== undefined) {
        where.user_id = Number(user_id);
        const playerCard = await prisma.playerCard.findFirst({
          where,
          orderBy: { card_id: 'desc' },
        });
        return res.status(200).json(playerCard);
      } else {
        const playerCards = await prisma.playerCard.findMany({
          where,
          orderBy: { card_id: 'desc' },
        });
        return res.status(200).json(playerCards);
      }
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch player cards' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { user_id } = req.body;
      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required' });
      }

      // Find the max numeric part of existing RFID numbers
      const lastCard = await prisma.playerCard.findFirst({
        orderBy: { card_id: 'desc' },
        select: { rfid_number: true },
      });
      let nextNumber = 1;
      if (lastCard && lastCard.rfid_number && /^RFID\d+$/.test(lastCard.rfid_number)) {
        const numPart = parseInt(lastCard.rfid_number.replace('RFID', ''), 10);
        if (!isNaN(numPart)) nextNumber = numPart + 1;
      }
      // Minimum length 8 including 'RFID' (so at least 4 digits)
      const numDigits = Math.max(4, 8 - 4); // 4 for 'RFID', 4 for digits
      const rfid_number = 'RFID' + String(nextNumber).padStart(numDigits, '0');

      const newCard = await prisma.playerCard.create({
        data: {
          user_id: Number(user_id),
          rfid_number,
          pin: '1234',
          balance: 0,
          loyalty_points: 0,
          tier: 'Silver',
        },
      });
      return res.status(201).json(newCard);
    } catch (error) {
      return res.status(400).json({ error: 'Player card creation failed' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { user_id, ...updateData } = req.body;
      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required for update' });
      }

      const updated = await prisma.playerCard.updateMany({
        where: { user_id: Number(user_id) },
        data: updateData,
      });

      return res.status(200).json(updated);
    } catch (error) {
      return res.status(400).json({ error: 'Player card update failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST', 'PUT']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}