import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

function normalizeStatus(status?: any): 'Active' | 'Inactive' | 'Banned' | undefined {
  if (!status) return undefined;
  const s = String(status).trim().toLowerCase();
  if (s === 'active') return 'Active';
  if (s === 'inactive') return 'Inactive';
  if (s === 'banned') return 'Banned';
  return undefined;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { user_id, status, ...otherFilters } = req.query;
      const where: any = { ...otherFilters };

      const normStatus = normalizeStatus(status);
      if (normStatus) {
        where.status = normStatus;
      }

      if (user_id !== undefined) {
        const parsedUserId = Number(user_id);
        if (isNaN(parsedUserId)) {
          return res.status(400).json({ message: 'Invalid user_id', error: 'Invalid user_id' });
        }
        where.user_id = parsedUserId;
        where.status = normStatus || 'Active';

        const playerCard = await prisma.playerCard.findFirst({
          where,
          orderBy: { card_id: 'desc' },
        });

        if (!playerCard) {
          return res.status(404).json({ message: 'Player Card Not Found', error: 'Player Card Not Found' });
        }

        return res.status(200).json(playerCard);
      } else {
        const playerCards = await prisma.playerCard.findMany({
          where,
          orderBy: { card_id: 'desc' },
        });
        return res.status(200).json(playerCards);
      }
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch player cards' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { user_id, rfid_number, pin, balance, loyalty_points, tier, status } = req.body;

      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required' });
      }
      if (!rfid_number || typeof rfid_number !== 'string') {
        return res.status(400).json({ error: 'rfid_number is required and must be a string' });
      }
      if (pin === undefined || pin === null || (typeof pin !== 'string' && typeof pin !== 'number')) {
        return res.status(400).json({ error: 'pin is required and must be a string or number' });
      }

      const userIdNum = Number(user_id);

      // 1. Mark all existing cards of this user as Inactive
      await prisma.playerCard.updateMany({
        where: { user_id: userIdNum },
        data: { status: 'Inactive' },
      });

      // 2. Set status for the new card (default: Active)
      const cardStatus = normalizeStatus(status) || 'Active';

      const newCard = await prisma.playerCard.create({
        data: {
          user_id: userIdNum,
          rfid_number: String(rfid_number).trim(),
          pin: String(pin).trim(),
          balance: balance !== undefined ? balance : 0,
          loyalty_points: loyalty_points !== undefined ? loyalty_points : 0,
          tier: tier ?? 'Silver',
          status: cardStatus,
        },
      });
      return res.status(201).json(newCard);
    } catch (error) {
      // If Prisma unique constraint or other DB error, surface message
      const msg = (error as any)?.message ? String((error as any).message) : 'Player card creation failed';
      return res.status(400).json({ error: msg });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { user_id, ...updateData } = req.body;
      if (!user_id) {
        return res.status(400).json({ error: 'user_id is required for update' });
      }

      if (updateData.status) {
        const norm = normalizeStatus(updateData.status);
        if (norm) updateData.status = norm;
      }

      const updated = await prisma.playerCard.updateMany({
        where: { user_id: Number(user_id) },
        data: updateData,
      });

      return res.status(200).json(updated);
    } catch (error) {
      return res.status(400).json({ error: 'Player card update failed' });
    }
  }

  if (req.method === 'PATCH') {
    try {
      const { card_id, user_id, ...updateData } = req.body;

      if (updateData.status) {
        const norm = normalizeStatus(updateData.status);
        if (norm) updateData.status = norm;
      }

      if (card_id !== undefined && card_id !== null) {
        const updated = await prisma.playerCard.update({
          where: { card_id: Number(card_id) },
          data: updateData,
        });
        return res.status(200).json(updated);
      }

      if (user_id !== undefined && user_id !== null) {
        const updated = await prisma.playerCard.updateMany({
          where: { user_id: Number(user_id) },
          data: updateData,
        });
        return res.status(200).json(updated);
      }

      return res.status(400).json({ error: 'card_id or user_id is required for PATCH' });
    } catch (error) {
      return res.status(400).json({ error: 'Player card patch failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST', 'PUT', 'PATCH']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}