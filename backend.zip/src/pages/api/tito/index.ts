import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method === 'GET') {
    try {
      const filters: any = req.query;

      const vouchers = await prisma.tITO.findMany({
        where: { ...filters },
        orderBy: { tito_id: 'desc' },
      });

      return res.status(200).json(vouchers);
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch TITO vouchers' });
    }
  }

  if (req.method === 'POST') {
    try {
      let { amount, issued_location } = req.body;
      if (typeof amount === 'string') amount = parseFloat(amount);
      if (!amount || !issued_location) {
        return res.status(400).json({ error: 'amount and issued_location are required' });
      }

      // Generate unique 16-char alphanumeric barcode and unique_identifier
      function generateRandomString(length = 16) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }

      let barcode, unique_identifier;
      let isUnique = false;
      for (let i = 0; i < 5 && !isUnique; i++) {
        barcode = generateRandomString().toUpperCase();
        unique_identifier = generateRandomString();
        const exists = await prisma.tITO.findFirst({ where: { OR: [{ barcode }, { unique_identifier }] } });
        if (!exists) isUnique = true;
      }
      if (!isUnique) {
        return res.status(500).json({ error: 'Failed to generate unique barcode/identifier' });
      }

      const now = new Date();
      const validUpto = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

      const tito = await prisma.tITO.create({
        data: {
          machine_id: 0,
          unique_identifier: unique_identifier || '',
          barcode: barcode || '',
          amount,
          issued_location,
          issued_at: now,
          valid_upto: validUpto,
        },
      });

      return res.status(201).json({ barcode: barcode || '' });
    } catch (error: any) {
      console.error('TITO POST error:', error);
      return res.status(400).json({ error: error.message || 'TITO Creation Failed' });
    }
  }
  res.status(405).end(`Method ${req.method} Not Allowed`);
}