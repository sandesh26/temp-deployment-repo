import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, gaming_day_id, cage_id } = req.query;

  switch (req.method) {
    case 'GET': {
      // If id is a number, fetch by id
      if (typeof id === 'string' && !isNaN(Number(id))) {
        const rec = await prisma.cageChipDenomination.findUnique({
          where: { id: Number(id) },
          include: {
            cage: { select: { name: true } },
            gamingDay: { select: { start_time: true, end_time: true } },
          },
        });
        if (!rec) return res.status(404).json({ error: 'Record not found' });
        const result = {
          ...rec,
          cage: rec.cage?.name ?? null,
          gaming_day_start: rec.gamingDay?.start_time ?? null,
          gaming_day_end: rec.gamingDay?.end_time ?? null,
          chip_denomination: Number(rec.chip_denomination).toFixed(2),
          total_value: Number(rec.total_value).toFixed(2),
        };
        return res.status(200).json(result);
      }

      // If id is not a number, fallback to filter by gaming_day_id/cage_id/both
      const where: any = {};
      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }
      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }
      if (Object.keys(where).length === 0) {
        return res.status(400).json({ error: 'Invalid ID or missing filter parameters' });
      }

      const records = await prisma.cageChipDenomination.findMany({
        where,
        include: {
          cage: { select: { name: true } },
          gamingDay: { select: { start_time: true, end_time: true } },
        },
        orderBy: { recorded_at: 'desc' },
      });
      const result = records.map((rec: any) => ({
        ...rec,
        cage: rec.cage?.name ?? null,
        gaming_day_start: rec.gamingDay?.start_time ?? null,
        gaming_day_end: rec.gamingDay?.end_time ?? null,
        chip_denomination: Number(rec.chip_denomination).toFixed(2),
        total_value: Number(rec.total_value).toFixed(2),
      }));
      return res.status(200).json(result);
    }
    case 'PUT': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      try {
        const data = req.body;
        const rec = await prisma.cageChipDenomination.update({
          where: { id: Number(id) },
          data,
        });
        return res.status(200).json(rec);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      try {
        await prisma.cageChipDenomination.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}