import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const body = req.body;
    const payload = typeof body === 'string' ? JSON.parse(body) : body;

    const {
      table_id,
      gaming_day_id,
      vault_id,
      opening_cash,
      opening_chips,
      opening_total,
      opening_cash_denominations,
      opening_chip_denominations,
      opening_recorded_by,
      notes,
      opened_by,
      operation_id,
    } = payload;

    if (!table_id) return res.status(400).json({ error: 'table_id is required' });

    // Resolve gaming day if not provided
    let gamingDayId = gaming_day_id;
    if (!gamingDayId) {
      const current = await prisma.gamingDay.findFirst({ where: { status: 'OPEN' }, orderBy: { created_at: 'desc' } });
      if (!current) return res.status(400).json({ error: 'No active gaming day found' });
      gamingDayId = current.gaming_day_id;
    }

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      const tId = Number(table_id);

      // 1) Lock table row to avoid concurrent opens
      const tableLock: any = await tx.$queryRaw`
        SELECT status FROM \`Table\` WHERE table_id = ${tId} FOR UPDATE
      `;
      if (!tableLock || tableLock.length === 0) throw new Error('Table not found');
      if (tableLock[0].status === 'OPEN') throw Object.assign(new Error('Table already open'), { status: 409 });

      // 2) Compute totals
      const cashAmt = opening_cash !== undefined ? Number(opening_cash) : 0;
      const chipsAmt = opening_chips !== undefined ? Number(opening_chips) : 0;
      const totalAmt = opening_total !== undefined ? Number(opening_total) : (cashAmt + chipsAmt);

      // 3) Generate auto-descriptive notes if caller didn't provide `notes` (used by vault transactions)
      let generatedNotes: string | null = notes ?? null;
      if (!generatedNotes) {
        const tableRec = await tx.table.findUnique({ where: { table_id: tId }, select: { name: true } });
        const actorId = opened_by ?? opening_recorded_by ?? null;
        let actorName: string | null = null;
        if (actorId) {
          const actor = await tx.user.findUnique({ where: { user_id: Number(actorId) }, select: { full_name: true } });
          actorName = actor?.full_name ?? null;
        }
        generatedNotes = `Open ${tableRec?.name ?? `Table ${tId}`} by ${actorName ?? 'Unknown'}: cash ${cashAmt}, chips ${chipsAmt}, total ${totalAmt}${operation_id ? `, op ${operation_id}` : ''}`;
      }

      // 4) If vault involved, lock and validate

      let vaultTxs: any[] = [];
      if (vault_id && (cashAmt > 0 || chipsAmt > 0)) {
        const vId = Number(vault_id);
        const vaultLock: any = await tx.$queryRaw`
          SELECT * FROM VaultBalance WHERE vault_id = ${vId} FOR UPDATE
        `;
        if (!vaultLock || vaultLock.length === 0) throw new Error('Vault not found');
        const vault = vaultLock[0];
        const newCash = Number(vault.total_cash) - cashAmt;
        const newChips = Number(vault.total_chips) - chipsAmt;
        if (newCash < 0 || newChips < 0) throw new Error('Insufficient vault funds');

        await tx.vaultBalance.update({ where: { vault_id: vId }, data: { total_cash: String(newCash), total_chips: String(newChips), total_assets: String(Number(vault.total_assets) - (cashAmt + chipsAmt)) } });

        // Adjust vault chip denominations if chip breakdown provided
        if (Array.isArray(opening_chip_denominations)) {
          for (const cd of opening_chip_denominations) {
            const denom = Number(cd.chip_denomination);
            const qty = Number(cd.quantity || 0);
            if (!isFinite(denom) || !isFinite(qty)) continue;
            let existing: any = null;
            if (cd.chip_id) {
              existing = await tx.vaultChipDenomination.findUnique({ where: { id: Number(cd.chip_id) } });
            }
            if (!existing) existing = await tx.vaultChipDenomination.findFirst({ where: { vault_id: vId, chip_denomination: denom } });
            if (!existing) throw new Error(`Vault chip denomination ${denom} not found`);
            const newQty = Number(existing.actual_quantity) - qty;
            if (newQty < 0) throw new Error(`Insufficient vault chip quantity for denom ${denom}`);
            await tx.vaultChipDenomination.update({ where: { id: existing.id }, data: { actual_quantity: newQty, total_value: String(newQty * Number(existing.chip_denomination)), last_updated: now } });
            if (!cd.chip_id) cd.chip_id = existing.id;
          }
        }

        // Create vault transaction(s)
        if (cashAmt > 0) {
          const vt = await tx.vaultTransaction.create({ data: {
            vault_id: Number(vault_id),
            transaction_type: 'WITHDRAWAL',
            asset_type: 'CASH',
            denomination: cashAmt,
            quantity: 1,
            total_value: String(cashAmt),
            currency_code: 'INR',
            source: 'VAULT',
            destination: `TABLE ${tId}`,
            authorized_by: opening_recorded_by ?? opened_by ?? null,
            performed_by: opened_by ?? opening_recorded_by ?? null,
            gaming_day_id: Number(gamingDayId),
            notes: generatedNotes,
            table_id: Number(table_id),
          }});
          vaultTxs.push(vt);
        }

        // For chips, if a denomination breakdown was provided create one VaultTransaction per denom
        if (Array.isArray(opening_chip_denominations) && opening_chip_denominations.length > 0) {
          for (const cd of opening_chip_denominations) {
            const denom = Number(cd.chip_denomination || 0);
            const qty = Number(cd.quantity || 0);
            if (!isFinite(denom) || !isFinite(qty) || qty <= 0) continue;
            const total = denom * qty;
            const vt = await tx.vaultTransaction.create({ data: {
              vault_id: Number(vault_id),
              transaction_type: 'WITHDRAWAL',
              asset_type: 'CHIP',
              denomination: denom,
              quantity: qty,
              total_value: String(total),
              currency_code: 'INR',
              source: 'VAULT',
              destination: `TABLE ${tId}`,
              authorized_by: opening_recorded_by ?? opened_by ?? null,
              performed_by: opened_by ?? opening_recorded_by ?? null,
              gaming_day_id: Number(gamingDayId),
              notes: generatedNotes ?? `Withdraw ${qty} x ${denom} chips for Table ${tId}`,
              table_id: Number(table_id),
            }});
            vaultTxs.push(vt);
          }
        } else if (chipsAmt > 0) {
          const vt2 = await tx.vaultTransaction.create({ data: {
            vault_id: Number(vault_id),
            transaction_type: 'WITHDRAWAL',
            asset_type: 'CHIP',
            denomination: chipsAmt,
            quantity: 1,
            total_value: String(chipsAmt),
            currency_code: 'INR',
            source: 'VAULT',
            destination: `TABLE ${tId}`,
            authorized_by: opening_recorded_by ?? opened_by ?? null,
            performed_by: opened_by ?? opening_recorded_by ?? null,
            gaming_day_id: Number(gamingDayId),
            notes: generatedNotes,
            table_id: Number(table_id),
          }});
          vaultTxs.push(vt2);
        }
      }

      // 4) Create FloatBalance (snapshot of denominations)
      const floatCreateData: any = {
        module: 'TABLE',
        table_id: Number(table_id),
        gaming_day_id: Number(gamingDayId),
        opening_cash: String(cashAmt),
        opening_chips: String(chipsAmt),
        opening_total: String(totalAmt),
        // For cash we store only the numeric value; chips keep detailed breakdown if provided
        opening_denominations: JSON.stringify({ chips: opening_chip_denominations ?? null }),
        opening_recorded_by: opening_recorded_by ?? opened_by ?? null,
        notes: notes ?? null,
      };

      const floatRecord = await tx.floatBalance.create({ data: floatCreateData });

      // enrich opening_chip_denominations with chip_id when possible and update float snapshot
      if (Array.isArray(opening_chip_denominations) && opening_chip_denominations.length > 0) {
        const enriched: any[] = [];
        for (const cd of opening_chip_denominations) {
          if (!cd.chip_id) {
            let resolved: any = null;
            if (vault_id) resolved = await tx.vaultChipDenomination.findFirst({ where: { vault_id: Number(vault_id), chip_denomination: Number(cd.chip_denomination) } });
            if (!resolved) resolved = await tx.tableChipDenomination.findFirst({ where: { table_id: Number(table_id), gaming_day_id: Number(gamingDayId), chip_denomination: Number(cd.chip_denomination) } });
            if (resolved) cd.chip_id = resolved.id;
          }
          enriched.push(cd);
        }
        await tx.floatBalance.update({ where: { id: floatRecord.id }, data: { opening_denominations: JSON.stringify({ chips: enriched }) } });
      }

      // 6) Upsert TableChipDenomination rows (normalized) if chip breakdown provided
      if (Array.isArray(opening_chip_denominations)) {
        for (const cd of opening_chip_denominations) {
          const denom = Number(cd.chip_denomination);
          const qty = Number(cd.quantity || 0);
          const chipId = cd.chip_id ? Number(cd.chip_id) : null;
          const typeOfChip = cd.type_of_chip ?? 'General';
          const totalVal = cd.total_value !== undefined ? String(cd.total_value) : String(qty * denom);
          let existing: any = null;
          if (cd.chip_id) existing = await tx.tableChipDenomination.findUnique({ where: { id: Number(cd.chip_id) } });
          if (!existing) existing = await tx.tableChipDenomination.findFirst({ where: { table_id: Number(table_id), gaming_day_id: Number(gamingDayId), chip_denomination: denom } });
          if (existing) {
            await tx.tableChipDenomination.update({ where: { id: existing.id }, data: { quantity: qty, total_value: totalVal, recorded_at: now, chip_id: chipId ?? existing.chip_id ?? undefined } });
          } else {
            const created = await tx.tableChipDenomination.create({
              data: {
                table_id: Number(table_id),
                chip_id: chipId ?? undefined,
                gaming_day_id: Number(gamingDayId),
                chip_denomination: denom,
                type_of_chip: typeOfChip,
                chip_color: cd.chip_color ?? '',
                quantity: qty,
                total_value: totalVal,
                recorded_at: now,
              },
            });
            cd.chip_id = created.id;
          }
        }
      }

      // 7) Update Table status and balances
      const updatedTable = await tx.table.update({ where: { table_id: Number(table_id) }, data: { status: 'OPEN', cash_drop_balance: String("0"), chip_balance: String(chipsAmt), opening_chip_balance: String(chipsAmt), last_change: now, changed_by: opened_by ?? opening_recorded_by ?? undefined, gaming_day_id: Number(gamingDayId) } });

      // 8) Create TableTransaction(s) to record opening/fills
      const tableTxs: any[] = [];

      // Generate an auto-descriptive notes string if caller didn't provide `notes`₹₹
      if (!generatedNotes) {
        const tableRec = await tx.table.findUnique({ where: { table_id: tId }, select: { name: true } });
        const actorId = opened_by ?? opening_recorded_by ?? null;
        let actorName: string | null = null;
        if (actorId) {
          const actor = await tx.user.findUnique({ where: { user_id: Number(actorId) }, select: { full_name: true } });
          actorName = actor?.full_name ?? null;
        }
        generatedNotes = `Open ${tableRec?.name ?? `Table ${tId}`} by ${actorName ?? 'Unknown'}: cash ${cashAmt}, chips ${chipsAmt}, total ${totalAmt}${operation_id ? `, op ${operation_id}` : ''}`;
      }
      if (cashAmt > 0) {
        const ttx = await tx.tableTransaction.create({ data: {
          table_id: Number(table_id),
          amount: String(cashAmt),
          transaction_type: 'FILL',
          payment_method: 'Cash',
          performed_by: opened_by ?? opening_recorded_by ?? 0,
          gaming_day_id: Number(gamingDayId),
          notes: generatedNotes,
        } });
        tableTxs.push(ttx);
      }
      if (chipsAmt > 0) {
        const ttx2 = await tx.tableTransaction.create({ data: {
          table_id: Number(table_id),
          amount: String(chipsAmt),
          transaction_type: 'CHIP_FILL',
          payment_method: 'Chips',
          performed_by: opened_by ?? opening_recorded_by ?? 0,
          gaming_day_id: Number(gamingDayId),
          notes: generatedNotes,
        } });
        tableTxs.push(ttx2);
      }

      return { updatedTable, floatRecord, vaultTxs, tableTxs };
    });

    return res.status(201).json(result);
  } catch (err: any) {
    console.error('table open failed', err);
    if (err && (err.status === 409 || err.message === 'Table already open')) return res.status(409).json({ error: err.message });
    return res.status(400).json({ error: err?.message ?? 'Unknown error' });
  }
}
