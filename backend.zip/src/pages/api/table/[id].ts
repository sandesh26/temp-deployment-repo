import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

function formatDate(dateString: string | Date | null | undefined) {
  if (!dateString) return null;
  const date = new Date(dateString);
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string' || isNaN(Number(id))) return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const table = await prisma.table.findUnique({
        include: {
          changedBy: { select: { full_name: true } },
          gamingDay: { select: { start_time: true } },
        },
        where: { table_id: Number(id) },
      });
      if (!table) return res.status(404).json({ error: 'Not found' });

      const { changedBy,gamingDay,last_change, ...rest } = table;
      const result = {
        ...rest,
        last_change: last_change ? formatDate(last_change) : null,
        changed_by: changedBy?.full_name ?? null,
        gaming_day: gamingDay?.start_time ? formatDate(gamingDay.start_time) : null,
      };
      return res.status(200).json(result);
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const table = await prisma.table.update({
          where: { table_id: Number(id) },
          data,
        });
        return res.status(200).json(table);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Update failed' });
      }
    }
    case 'PATCH': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const updated = await prisma.table.update({
          where: { table_id: Number(id) },
          data,
        });
        return res.status(200).json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Patch failed' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.table.delete({
          where: { table_id: Number(id) },
        });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Delete failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
