import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const body = req.body;
    const payload = typeof body === 'string' ? JSON.parse(body) : body;

    const {
      table_id,
      gaming_day_id,
      cash_amount,
      chip_denominations,
      performed_by,
      notes,
      operation_id,
    } = payload;

    if (!table_id) return res.status(400).json({ error: 'table_id is required' });

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      const tId = Number(table_id);

      // Lock table row
      const tableLock: any = await tx.$queryRaw`
        SELECT * FROM \`Table\` WHERE table_id = ${tId} FOR UPDATE
      `;
      if (!tableLock || tableLock.length === 0) throw new Error('Table not found');
      const tableRow = tableLock[0];
    
      // Determine previous balances
      const prevChipBal = Number(tableRow.chip_balance ?? 0);
      const prevCashDrop = Number(tableRow.cash_drop_balance ?? 0);
      let gamingDayId = tableRow.gaming_day_id || gaming_day_id;
      // New amounts (treat undefined as no-change)
      const newCash = cash_amount !== undefined && cash_amount > 0 ? Number(cash_amount) : prevCashDrop;

      // For chips, compute total from denominations if provided, otherwise leave as-is
      let newChips = prevChipBal;
      if (Array.isArray(chip_denominations) && chip_denominations.length > 0) {
        let sum = 0;
        for (const cd of chip_denominations) {
          const denom = Number(cd.chip_denomination || 0);
          const qty = Number(cd.quantity || 0);
          if (!isFinite(denom) || !isFinite(qty)) continue;
          sum += denom * qty;
        }
        newChips = sum;
      }

      // 1) Replace TableChipDenomination rows for this table+gaming day with provided denominations
      const updatedDenoms: any[] = [];
      if (Array.isArray(chip_denominations) && chip_denominations.length > 0) {
        // ensure we have a gamingDayId to use
        if (!gamingDayId) {
          const currentGD = await tx.gamingDay.findFirst({ where: { status: 'OPEN' }, orderBy: { created_at: 'desc' } });
          if (!currentGD) throw new Error('No active gaming day found');
          gamingDayId = currentGD.gaming_day_id;
        }

        // Delete existing denominations for table + gaming day
        await tx.tableChipDenomination.deleteMany({ where: { table_id: tId, gaming_day_id: Number(gamingDayId) } });

        // Insert fresh rows from payload
        for (const cd of chip_denominations) {
          const denom = Number(cd.chip_denomination);
          const qty = Number(cd.quantity || 0);
          const chipId = cd.chip_id ? Number(cd.chip_id) : undefined;
          const totalVal = cd.total_value !== undefined ? String(cd.total_value) : String(qty * denom);
          const created = await tx.tableChipDenomination.create({ data: { table_id: tId, chip_id: chipId, gaming_day_id: Number(gamingDayId), chip_denomination: denom, type_of_chip: cd.type_of_chip ?? 'General', chip_color: cd.chip_color ?? '', quantity: qty, total_value: totalVal, recorded_at: now } });
          updatedDenoms.push(created);
          cd.chip_id = created.id;
        }
      }

      // 2) Update Table balances
      const updatedTable = await tx.table.update({ where: { table_id: tId }, data: { chip_balance: String(newChips), cash_drop_balance: String(newCash), last_change: now, changed_by: performed_by ?? undefined } });

      // 3) Create TableTransaction(s) to record adjustments (if there's a change)
      const tableTxs: any[] = [];

      // Cash change
      if (cash_amount !== undefined && Number(cash_amount) > 0) {
          const txType = 'DROPBOX_CASH';
          const ttx = await tx.tableTransaction.create({ data: { table_id: tId, amount: String(Math.abs(cash_amount)), transaction_type: txType as any, payment_method: 'Cash', performed_by: performed_by ?? 0, gaming_day_id: Number(gamingDayId), notes: `Cash Balance Update of Amount ${Math.abs(cash_amount)} at Table ${tId}` } });
          tableTxs.push(ttx);
      }

      // Chips change
      if (Array.isArray(chip_denominations) && chip_denominations.length > 0) {
        const txType = 'CHIPS_UPDATE';
        const ttx = await tx.tableTransaction.create({ data: { table_id: tId, amount: String(Math.abs(newChips)), transaction_type: txType as any, payment_method: 'Chips', performed_by: performed_by ?? 0, gaming_day_id: Number(gamingDayId), notes: `Chips Balance Update of Amount ${Math.abs(newChips)} at Table ${tId}` } });
        tableTxs.push(ttx);
      }

      return { updatedTable, tableTxs, updatedDenoms };
    });

    return res.status(200).json(result);
  } catch (err: any) {
    console.error('table update failed', err);
    return res.status(400).json({ error: err?.message ?? 'Unknown error' });
  }
}
