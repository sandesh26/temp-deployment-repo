import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient, Prisma } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const body = req.body;
    const payload = typeof body === 'string' ? JSON.parse(body) : body;

    const {
      table_id,
      gaming_day_id,
      vault_id,
      closing_cash,
      closing_chips,
      closing_total,
      closing_cash_denominations,
      closing_chip_denominations: _closing_chip_denominations,
      chip_denominations: _chip_denominations,
      closing_recorded_by,
      closed_by,
      notes,
      operation_id,
    } = payload;

    // Accept both "closing_chip_denominations" and "chip_denominations" as payload keys
    const closing_chip_denominations: any[] =
      Array.isArray(_closing_chip_denominations) && _closing_chip_denominations.length > 0
        ? _closing_chip_denominations
        : Array.isArray(_chip_denominations)
          ? _chip_denominations
          : [];

    if (!table_id) return res.status(400).json({ error: 'table_id is required' });

    // Resolve gaming day — use provided value or fall back to the Table's own gaming_day_id
    let gamingDayId: number;
    if (gaming_day_id) {
      gamingDayId = Number(gaming_day_id);
    } else {
      const tableRec = await prisma.table.findUnique({ where: { table_id: Number(table_id) }, select: { gaming_day_id: true } });
      if (!tableRec) return res.status(404).json({ error: 'Table not found' });
      gamingDayId = tableRec.gaming_day_id;
    }

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      const tId = Number(table_id);

      // ── 1) Lock table row ──────────────────────────────────────────────
      const tableLock: any = await tx.$queryRaw`
        SELECT status FROM \`Table\` WHERE table_id = ${tId} FOR UPDATE
      `;
      if (!tableLock || tableLock.length === 0) throw new Error('Table not found');
      if (tableLock[0].status !== 'OPEN') throw Object.assign(new Error('Table is not open'), { status: 409 });

      // ── 2) Compute totals ──────────────────────────────────────────────
      // closing_cash is always 0 for a table close (cash handled separately)
      const cashAmt = 0;
      let chipsAmt = 0;
      if (Array.isArray(closing_chip_denominations) && closing_chip_denominations.length > 0) {
        for (const cd of closing_chip_denominations) {
          const d = Number(cd.chip_denomination || 0);
          const q = Number(cd.quantity || 0);
          if (isFinite(d) && isFinite(q)) chipsAmt += d * q;
        }
      } else if (closing_chips !== undefined) {
        chipsAmt = Number(closing_chips);
      }
      const totalAmt = cashAmt + chipsAmt;

      // ── 3) Auto-generate notes ─────────────────────────────────────────
      let generatedNotes: string | null = notes ?? null;
      if (!generatedNotes) {
        const tableRec = await tx.table.findUnique({ where: { table_id: tId }, select: { name: true } });
        const actorId = closed_by ?? closing_recorded_by ?? null;
        let actorName: string | null = null;
        if (actorId) {
          const actor = await tx.user.findUnique({ where: { user_id: Number(actorId) }, select: { full_name: true } });
          actorName = actor?.full_name ?? null;
        }
        generatedNotes = `Close ${tableRec?.name ?? `Table ${tId}`} by ${actorName ?? 'Unknown'}: cash ${cashAmt}, chips ${chipsAmt}, total ${totalAmt}${operation_id ? `, op ${operation_id}` : ''}`;
      }

      // ── 4) Vault: lock, update totals, update per-chip denominations ───
      const vaultTxs: any[] = [];
      if (vault_id && chipsAmt > 0) {
        const vId = Number(vault_id);
        const vaultLock: any = await tx.$queryRaw`
          SELECT * FROM VaultBalance WHERE vault_id = ${vId} FOR UPDATE
        `;
        if (!vaultLock || vaultLock.length === 0) throw new Error('Vault not found');
        const vault = vaultLock[0];

        // Credit chips back to vault totals (always, regardless of denomination breakdown)
        await tx.vaultBalance.update({
          where: { vault_id: vId },
          data: {
            total_chips: Number(vault.total_chips) + chipsAmt,
            total_assets: Number(vault.total_assets) + chipsAmt,
          },
        });

        // Update actual_quantity on each VaultChipDenomination by matching chip_id from payload
        if (closing_chip_denominations.length > 0) {
          for (const cd of closing_chip_denominations) {
            const qty = Number(cd.quantity || 0);
            const denom = Number(cd.chip_denomination || 0);
            if (!isFinite(qty) || qty <= 0 || !isFinite(denom) || denom <= 0) continue;

            // Resolve the vault denomination record:
            // 1) prefer explicit chip_id match on this vault
            // 2) fall back to denomination match on this vault
            let vaultDenom: any = null;
            if (cd.chip_id) {
              vaultDenom = await tx.vaultChipDenomination.findFirst({
                where: { id: Number(cd.chip_id), vault_id: vId },
              });
            }
            if (!vaultDenom) {
              vaultDenom = await tx.vaultChipDenomination.findFirst({
                where: { vault_id: vId, chip_denomination: denom },
              });
            }

            if (vaultDenom) {
              // Atomically increment actual_quantity
              await tx.$executeRaw`
                UPDATE VaultChipDenomination
                SET actual_quantity = COALESCE(actual_quantity, 0) + ${qty},
                    total_value     = (COALESCE(actual_quantity, 0) + ${qty}) * chip_denomination,
                    last_updated    = ${now}
                WHERE id = ${vaultDenom.id}
              `;
            }

            // Create one VaultTransaction per denomination regardless of vaultDenom lookup
            const vt = await tx.vaultTransaction.create({
              data: {
                vault_id: vId,
                transaction_type: 'DEPOSIT',
                asset_type: 'CHIP',
                denomination: denom,
                quantity: qty,
                total_value: String(denom * qty),
                currency_code: 'INR',
                source: `TABLE ${tId}`,
                destination: 'VAULT',
                authorized_by: closing_recorded_by ?? closed_by ?? null,
                performed_by: closed_by ?? closing_recorded_by ?? null,
                gaming_day_id: gamingDayId,
                notes: generatedNotes,
                table_id: tId,
              },
            });
            vaultTxs.push(vt);
          }
        }
      }

      // ── 5) TableChipDenomination — upsert every chip from payload ──────
      const tableChipRows: any[] = [];
      if (Array.isArray(closing_chip_denominations) && closing_chip_denominations.length > 0) {
        for (const cd of closing_chip_denominations) {
          const denom = Number(cd.chip_denomination);
          const qty = Number(cd.quantity || 0);
          if (!isFinite(denom) || !isFinite(qty)) continue;
          const totalVal = String(denom * qty);
          const chipId = cd.chip_id ? Number(cd.chip_id) : undefined;

          // Check for an existing row for this table + gaming day + denomination
          const existing = await tx.tableChipDenomination.findFirst({
            where: { table_id: tId, gaming_day_id: gamingDayId, chip_denomination: denom },
          });

          if (existing) {
            const updated = await tx.tableChipDenomination.update({
              where: { id: existing.id },
              data: {
                quantity: qty,
                total_value: totalVal,
                chip_id: chipId ?? existing.chip_id ?? undefined,
                recorded_at: now,
              },
            });
            tableChipRows.push(updated);
          } else {
            const created = await tx.tableChipDenomination.create({
              data: {
                table_id: tId,
                gaming_day_id: gamingDayId,
                chip_denomination: denom,
                quantity: qty,
                total_value: totalVal,
                chip_id: chipId ?? undefined,
                chip_color: cd.chip_color ?? '',
                type_of_chip: cd.type_of_chip ?? 'General',
                recorded_at: now,
              },
            });
            tableChipRows.push(created);
          }
        }
      }

      // ── 6) FloatBalance — find by table_id + gaming_day_id, update closing columns ──
      const chipsJson = Array.isArray(closing_chip_denominations) && closing_chip_denominations.length > 0
        ? closing_chip_denominations
        : tableChipRows.length > 0
          ? tableChipRows
          : null;

      let floatRecord: any = await tx.floatBalance.findFirst({
        where: { module: 'TABLE', table_id: tId, gaming_day_id: gamingDayId },
        orderBy: { created_at: 'desc' },
      });

      if (floatRecord) {
        await tx.floatBalance.update({
          where: { id: floatRecord.id },
          data: {
            closing_cash: 0,
            closing_chips: chipsAmt,
            closing_total: chipsAmt,            // closing_total = 0 (cash) + chipsAmt
            closing_denominations: chipsJson ? JSON.stringify({ chips: chipsJson }) : Prisma.JsonNull,
            closing_recorded_by: closing_recorded_by ?? closed_by ?? null,
            closing_recorded_at: now,
            status: 'CLOSED',
          },
        });
        floatRecord = await tx.floatBalance.findUnique({ where: { id: floatRecord.id } });
      } else {
        // No opening float found — create a standalone closing record
        floatRecord = await tx.floatBalance.create({
          data: {
            module: 'TABLE',
            table_id: tId,
            gaming_day_id: gamingDayId,
            opening_cash: 0,
            opening_chips: 0,
            opening_total: 0,
            closing_cash: 0,
            closing_chips: chipsAmt,
            closing_total: chipsAmt,
            closing_denominations: chipsJson ? JSON.stringify({ chips: chipsJson }) : Prisma.JsonNull,
            closing_recorded_by: closing_recorded_by ?? closed_by ?? null,
            closing_recorded_at: now,
            status: 'CLOSED',
          },
        });
      }

      // ── 7) Update Table status ─────────────────────────────────────────
      const updatedTable = await tx.table.update({
        where: { table_id: tId },
        data: {
          status: 'SOFT_CLOSED',
          chip_balance: '0',
          cash_drop_balance: '0',
          last_change: now,
          changed_by: closed_by ?? closing_recorded_by ?? undefined,
        },
      });

      // ── 8) TableTransaction records ────────────────────────────────────
      const tableTxs: any[] = [];
      if (chipsAmt > 0) {
        const ttx = await tx.tableTransaction.create({
          data: {
            table_id: tId,
            amount: String(chipsAmt),
            transaction_type: 'CHIPS_WITHDRAW',
            payment_method: 'Chips',
            performed_by: closed_by ?? closing_recorded_by ?? 0,
            gaming_day_id: gamingDayId,
            notes: `Chips Balance Update of Amount ${chipsAmt} at Table ${table_id}`,
          },
        });
        tableTxs.push(ttx);
      }

      return { updatedTable, floatRecord, vaultTxs, tableChipRows, tableTxs };
    });

    return res.status(201).json(result);
  } catch (err: any) {
    console.error('table close failed', err);
    if (err && (err.status === 409 || err.message === 'Table is not open')) return res.status(409).json({ error: err.message });
    return res.status(400).json({ error: err?.message ?? 'Unknown error' });
  }
}
