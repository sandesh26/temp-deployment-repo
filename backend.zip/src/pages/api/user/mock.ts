// pages/api/users/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';

let mockUsers = [
  {
    id: 1,
    name: 'Alice Smith',
    email: 'alice@example.com',
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: 'Bob Johnson',
    email: 'bob@example.com',
    created_at: new Date().toISOString(),
  },
];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const filters: any = req.query;

      // Simple filter simulation
      let users = mockUsers;
      if (filters.name) {
        users = users.filter((u) =>
          u.name.toLowerCase().includes(filters.name.toLowerCase())
        );
      }

      // Sort by created_at descending
      users.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      return res.status(200).json(users);
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch users' });
    }
  }

  if (req.method === 'POST') {
    try {
      const data = req.body;
      const newUser = {
        id: mockUsers.length + 1,
        name: data.name || 'Unnamed',
        email: data.email || 'noemail@example.com',
        created_at: new Date().toISOString(),
      };
      mockUsers.push(newUser);

      return res.status(201).json(newUser);
    } catch (error) {
      return res.status(400).json({ error: 'User creation failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}