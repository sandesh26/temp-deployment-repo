import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method === 'GET') {
    try {
      const employees = await prisma.user.findMany({
        where: {
          role: {
            not: 'Player',
          },
        },
        orderBy: { created_at: 'desc' },
      });
      return res.status(200).json(employees);
    } catch (error) {
      console.error('Employees GET error:', error);
      return res.status(500).json({ error: 'Failed to fetch employees' });
    }
  }
  res.setHeader('Allow', ['GET']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
