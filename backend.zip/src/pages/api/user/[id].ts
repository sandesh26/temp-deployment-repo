// pages/api/user/[id].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';
import { error } from 'console';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const user = await prisma.user.findUnique({ where: { user_id: Number(id) } });
      const employee = await prisma.employee.findUnique({ where: { user_id: Number(id) } });
      return user ? res.status(200).json({ ...user, employee }) : res.status(404).json({ error: 'User not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching user' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const data = { ...body };
      if (data.date_of_birth !== undefined) data.date_of_birth = data.date_of_birth ? new Date(data.date_of_birth) : null;
      if (data.last_visited !== undefined) data.last_visited = data.last_visited ? new Date(data.last_visited) : null;
      if (data.last_updated_time !== undefined) data.last_updated_time = data.last_updated_time ? new Date(data.last_updated_time) : null;
      if (data.last_updated_by !== undefined) data.last_updated_by = data.last_updated_by ? String(data.last_updated_by) : null;

      const updated = await prisma.user.update({
        where: { user_id: Number(id) },
        data,
      });
      return res.status(200).json(updated);
    } catch (error: any) {
      console.error('PUT /api/user/[id] error:', error);
      return res.status(400).json({ error: 'Update failed', details: error?.message || String(error) });
    }
  }

  if (req.method === 'PATCH') {
    try {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const updateData: any = {};

      if (body.firstName !== undefined) updateData.firstName = body.firstName;
      if (body.lastName !== undefined) updateData.lastName = body.lastName;
      if (body.full_name !== undefined) updateData.full_name = body.full_name;
      if (body.address !== undefined) updateData.address = body.address;
      if (body.date_of_birth !== undefined) updateData.date_of_birth = body.date_of_birth ? new Date(body.date_of_birth) : null;
      if (body.govt_id_number !== undefined) updateData.govt_id_number = body.govt_id_number;
      if (body.govt_id_type !== undefined) updateData.govt_id_type = body.govt_id_type;
      if (body.photo_url !== undefined) updateData.photo_url = body.photo_url;
      if (body.govt_id_proof !== undefined) updateData.govt_id_proof = body.govt_id_proof;
      if (body.email !== undefined) updateData.email = body.email;
      if (body.phone !== undefined) updateData.phone = body.phone;
      if (body.role !== undefined) updateData.role = body.role;
      if (body.tier !== undefined) updateData.tier = body.tier;
      if (body.status !== undefined) updateData.status = body.status;
      if (body.barringNotes !== undefined) updateData.barringNotes = body.barringNotes;
      if (body.favouriteGames !== undefined) updateData.favouriteGames = body.favouriteGames;
      if (body.duration !== undefined) updateData.duration = body.duration;
      if (body.loyality_points !== undefined) updateData.loyality_points = body.loyality_points;
      if (body.last_visited !== undefined) updateData.last_visited = body.last_visited ? new Date(body.last_visited) : null;
      if (body.last_updated_time !== undefined) {
        updateData.last_updated_time = body.last_updated_time ? new Date(body.last_updated_time) : null;
      }
      if (body.last_updated_by !== undefined) updateData.last_updated_by = body.last_updated_by ? String(body.last_updated_by) : null;

      const updated = await prisma.user.update({ where: { user_id: Number(id) }, data: updateData });
      return res.status(200).json(updated);
    } catch (error: any) {
      console.error('PATCH /api/user/[id] error:', error);
      return res.status(400).json({ error: 'Patch update failed', details: error?.message || String(error) });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.user.delete({ where: { user_id: Number(id) } });
      return res.status(204).end();
    } catch (error: any) {
      console.error('DELETE /api/user/[id] error:', error);
      return res.status(400).json({ error: 'Delete failed', details: error?.message || String(error) });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}