// pages/api/user/[id].ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';
import { error } from 'console';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const user = await prisma.user.findUnique({ where: { user_id: Number(id) } });
      return user ? res.status(200).json(user) : res.status(404).json({ error: 'User not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching user' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.user.update({
        where: { user_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch (error: any) {
      console.error('PUT /api/user/[id] error:', error);
      return res.status(400).json({ error: 'Update failed', details: error?.message || String(error) });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.user.delete({ where: { user_id: Number(id) } });
      return res.status(204).end();
    } catch (error: any) {
      console.error('DELETE /api/user/[id] error:', error);
      return res.status(400).json({ error: 'Delete failed', details: error?.message || String(error) });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}