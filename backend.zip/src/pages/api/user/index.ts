// pages/api/users/index.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

const validFilters = [
  'user_id', 'full_name', 'address', 'date_of_birth', 'govt_id_number',
  'govt_id_type', 'photo_url', 'email', 'phone', 'role', 'status'
];

const stringFields = [
  'full_name', 'address', 'govt_id_number', 'govt_id_type',
  'photo_url', 'email', 'phone'
];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method === 'GET') {
    try {
      const { search, ...filters } = req.query;
      const where: any = {};

      // Only add valid filters, make string filters case-insensitive
      for (const key of Object.keys(filters)) {
        if (validFilters.includes(key)) {
          let value = filters[key];
          if (Array.isArray(value)) {
            value = value[0];
          }
          if (stringFields.includes(key) && typeof value === 'string') {
            where[key] = { equals: value };
          } else {
            // For enums and other types, do not use mode
            where[key] = { equals: value };
          }
        }
      }

      if (search && typeof search === 'string') {
        // First, try to find a PlayerCard with matching rfid_number
        const playerCard = await prisma.playerCard.findUnique({
          where: { rfid_number: search },
        });
        if (playerCard) {
          // If found, get the user details by user_id
          const user = await prisma.user.findUnique({
            where: { user_id: playerCard.user_id },
          });
          return res.status(200).json(user ? [user] : []);
        }
        // Otherwise, fallback to searching full_name
        where.full_name = { contains: search };
      }

      const users = await prisma.user.findMany({
        where,
        orderBy: { created_at: 'desc' },
      });

      return res.status(200).json(users);
    } catch (error) {
      console.error('User GET error:', error);
      return res.status(500).json({ error: 'Failed to fetch users' });
    }
  }

  if (req.method === 'POST') {
    try {
      const data = req.body;

      const newUser = await prisma.user.create({ data });
      return res.status(201).json(newUser);
    } catch (error) {
      console.error('User POST error:', error);
      if ((error as any).code === 'P2002') {
        return res.status(400).json({ error: 'User with this email, phone, or govt_id_number already exists' });
      }
      return res.status(400).json({ error: 'User creation failed: ' + (error as Error).message });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}