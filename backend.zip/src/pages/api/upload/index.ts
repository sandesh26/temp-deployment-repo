import type { NextApiRequest, NextApiResponse } from 'next';
import formidable, { File } from 'formidable';
import fs from 'fs';
import path from 'path';
import { cors } from '../../../lib/cors';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  // Parse multipart/form-data
  const form = formidable({ multiples: false, keepExtensions: true });
  form.parse(req, async (err: any, fields: formidable.Fields, files: formidable.Files) => {
    if (err) {
      return res.status(400).json({ error: 'File upload failed' });
    }
    // Get custom folder from form field, default to ''
    const folder = Array.isArray(fields.folder) ? fields.folder[0] : fields.folder || '';
    const uploadDir = path.join(process.cwd(), 'public', 'uploads', folder);
    await fs.promises.mkdir(uploadDir, { recursive: true });

    // Move file to custom location
    const file = Array.isArray(files.file) ? files.file[0] : files.file;
    if (!file || !('filepath' in file)) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    const fileName = path.basename((file as File).filepath);
    const destPath = path.join(uploadDir, fileName);
    await fs.promises.rename((file as File).filepath, destPath);

    // Return public URL
    const fileUrl = `/uploads/${folder ? folder + '/' : ''}${fileName}`;
    return res.status(200).json({ url: fileUrl });
  });
}
