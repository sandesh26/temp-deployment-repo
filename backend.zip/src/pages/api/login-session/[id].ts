import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '../../../../lib/prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const idNum = Number(id);
  if (isNaN(idNum)) return res.status(400).json({ error: 'Invalid id' });

  switch (req.method) {
    case 'GET':
      try {
        const session = await (prisma as any).loginSession.findUnique({ where: { id: idNum } });
        if (!session) return res.status(404).json({ error: 'Not found' });
        return res.status(200).json(session);
      } catch (err) {
        console.error('login-session GET id error', err);
        return res.status(500).json({ error: 'Failed to fetch session' });
      }

    case 'PATCH':
      try {
        const { revoked, reason } = req.body;
        const data: any = {};
        if (revoked !== undefined) data.revoked = Boolean(revoked);
        if (reason !== undefined) data.reason = reason;
        if (data.revoked) data.logout_at = new Date();
        const updated = await (prisma as any).loginSession.update({ where: { id: idNum }, data });
        return res.status(200).json(updated);
      } catch (err) {
        console.error('login-session PATCH error', err);
        return res.status(500).json({ error: 'Failed to update session' });
      }

    case 'DELETE':
      try {
        await (prisma as any).loginSession.delete({ where: { id: idNum } });
        return res.status(204).end();
      } catch (err) {
        console.error('login-session DELETE error', err);
        return res.status(500).json({ error: 'Failed to delete session' });
      }

    default:
      res.setHeader('Allow', ['GET', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
