import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '../../../../lib/prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { employee_id } = req.query;
      const where: any = {};
      if (employee_id !== undefined) {
        where.employee_id = Number(employee_id);
      }
      const sessions = await (prisma as any).loginSession.findMany({ where, orderBy: { created_at: 'desc' } });
      return res.status(200).json(sessions);
    } catch (err) {
      console.error('login-session GET error', err);
      return res.status(500).json({ error: 'Failed to fetch sessions' });
    }
  }

  if (req.method === 'POST') {
    try {
      // Admin action: revoke all sessions for an employee
      const { employee_id, action } = req.body;
      if (!employee_id || action !== 'revoke_all') {
        return res.status(400).json({ error: 'employee_id and action=revoke_all required' });
      }
      const updated = await (prisma as any).loginSession.updateMany({ where: { employee_id: Number(employee_id), revoked: false }, data: { revoked: true, reason: 'revoked_by_admin', logout_at: new Date() } });
      return res.status(200).json({ count: updated.count });
    } catch (err) {
      console.error('login-session POST error', err);
      return res.status(500).json({ error: 'Failed to perform action' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
