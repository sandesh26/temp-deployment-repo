// pages/api/gamingday/current.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

const IST_TIMEZONE = 'Asia/Kolkata';
const IST_OFFSET_MS = (5 * 60 + 30) * 60 * 1000;

function getISTDateParts(date: Date) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: IST_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);

  const year = Number(parts.find((p) => p.type === 'year')?.value);
  const month = Number(parts.find((p) => p.type === 'month')?.value);
  const day = Number(parts.find((p) => p.type === 'day')?.value);

  return { year, month, day };
}

function toISTDateKey(date: Date) {
  const { year, month, day } = getISTDateParts(date);
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

function getISTMidnightAsUTCDate(date: Date) {
  const { year, month, day } = getISTDateParts(date);
  return new Date(Date.UTC(year, month - 1, day) - IST_OFFSET_MS);
}

function getYesterdayISTEndAsUTCDate(date: Date) {
  const istMidnightUTC = getISTMidnightAsUTCDate(date);
  return new Date(istMidnightUTC.getTime() - 1000);
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }

  try {
    const latestGamingDay = await prisma.gamingDay.findFirst({
      orderBy: { start_time: 'desc' },
    });

    const now = new Date();
    const todayISTKey = toISTDateKey(now);

    if (!latestGamingDay) {
      const createdGamingDay = await prisma.gamingDay.create({
        data: {
          start_time: getISTMidnightAsUTCDate(now),
          status: 'OPEN',
        },
      });
      return res.status(200).json(createdGamingDay);
    }

    const latestISTKey = toISTDateKey(latestGamingDay.start_time);

    if (todayISTKey > latestISTKey) {
      const yesterdayISTEndUTC = getYesterdayISTEndAsUTCDate(now);
      const todayISTMidnightUTC = getISTMidnightAsUTCDate(now);

      const createdGamingDay = await prisma.$transaction(async (tx) => {
        await tx.gamingDay.updateMany({
          where: {
            status: 'OPEN',
            start_time: { lt: todayISTMidnightUTC },
          },
          data: {
            status: 'CLOSED',
            end_time: yesterdayISTEndUTC,
            closed_at: now,
          },
        });

        return tx.gamingDay.create({
          data: {
            start_time: todayISTMidnightUTC,
            status: 'OPEN',
          },
        });
      });

      return res.status(200).json(createdGamingDay);
    }

    return res.status(200).json(latestGamingDay);
  } catch {
    return res.status(500).json({ error: 'Error fetching current gaming day' });
  }
}
