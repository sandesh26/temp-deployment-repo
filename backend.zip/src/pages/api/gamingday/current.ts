// pages/api/gamingday/current.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  try {
    const currentGamingDay = await prisma.gamingDay.findFirst({
      where: { status: 'OPEN' },
      orderBy: { start_time: 'desc' },
    });

    if (!currentGamingDay) {
      return res.status(404).json({ error: 'No active gaming day' });
    }

    return res.status(200).json(currentGamingDay);
  } catch (error) {
    return res.status(500).json({ error: 'Error fetching current gaming day' });
  }
}