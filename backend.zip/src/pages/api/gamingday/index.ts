import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { verifyToken } from '@auth';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  // Middleware to check JWT and user role
  // const user = await verifyToken(req);

  // // Check if the user is authenticated and has 'Supervisor' role
  // if (!user) {
  //   return res.status(401).json({ error: 'Unauthorized, token missing or invalid' });
  // }

  // if (user.role !== 'Supervisor') {
  //   return res.status(403).json({ error: 'Forbidden, supervisors only' });
  // }

  // POST: Create a new Gaming Day
  if (req.method === 'POST') {
    try {
      const data = req.body;

      const newGamingDay = await prisma.gamingDay.create({ data });
      return res.status(201).json(newGamingDay);
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Failed to create gaming day' });
    }
  }

  // PUT: Update an existing Gaming Day
  if (req.method === 'PUT') {
    try {
      const { id } = req.query;
      const updated = await prisma.gamingDay.update({
        where: { gaming_day_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Failed to update gaming day' });
    }
  }

  res.setHeader('Allow', ['POST', 'PUT']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}