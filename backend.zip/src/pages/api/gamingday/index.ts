import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { verifyToken } from '@auth';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  // Middleware to check JWT and user role
  // const user = await verifyToken(req);

  // // Check if the user is authenticated and has 'Supervisor' role
  // if (!user) {
  //   return res.status(401).json({ error: 'Unauthorized, token missing or invalid' });
  // }

  // if (user.role !== 'Supervisor') {
  //   return res.status(403).json({ error: 'Forbidden, supervisors only' });
  // }

  // POST: Create a new Gaming Day
  if (req.method === 'POST') {
    try {
      const data = req.body;

      const newGamingDay = await prisma.gamingDay.create({ data });
      return res.status(201).json(newGamingDay);
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Failed to create gaming day' });
    }
  }

  // PUT: Update an existing Gaming Day
  if (req.method === 'PUT') {
    try {
      const { id } = req.query;
      const updated = await prisma.gamingDay.update({
        where: { gaming_day_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Failed to update gaming day' });
    }
  }

  // GET: list gaming days with optional filters
  if (req.method === 'GET') {
    try {
      const { status, limit, offset, start_after, start_before } = req.query;

      const where: any = {};

      if (status !== undefined) {
        where.status = String(status);
      }

      // Allow filtering by start_time range
      if (start_after !== undefined || start_before !== undefined) {
        where.start_time = {} as any;
        if (start_after !== undefined) {
          const d = new Date(String(start_after));
          if (!isNaN(d.getTime())) where.start_time.gte = d;
        }
        if (start_before !== undefined) {
          const d = new Date(String(start_before));
          if (!isNaN(d.getTime())) where.start_time.lte = d;
        }
      }

      const take = limit !== undefined && Number.isFinite(Number(limit)) ? Number(limit) : undefined;
      const skip = offset !== undefined && Number.isFinite(Number(offset)) ? Number(offset) : undefined;

      const gamingDays = await prisma.gamingDay.findMany({
        where,
        orderBy: { start_time: 'desc' },
        ...(take !== undefined ? { take } : {}),
        ...(skip !== undefined ? { skip } : {}),
      });

      return res.status(200).json(gamingDays);
    } catch (error) {
      console.error(error);
      return res.status(500).json({ error: 'Failed to fetch gaming days' });
    }
  }

  res.setHeader('Allow', ['POST', 'PUT']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}