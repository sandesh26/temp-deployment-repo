import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'GET': {
      // Get all settings or by id
      const { id } = req.query;
      if (id) {
        const setting = await prisma.casinoSettings.findUnique({ where: { id: Number(id) } });
        return setting ? res.json(setting) : res.status(404).json({ error: 'Not found' });
      } else {
        // Return the first (and only) settings object, or 404 if none exists
        const setting = await prisma.casinoSettings.findFirst();
        return setting ? res.json(setting) : res.status(404).json({ error: 'Not found' });
      }
    }
    case 'POST': {
      try {
  const created = await prisma.casinoSettings.create({ data: req.body });
        return res.status(201).json(created);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || error });
      }
    }
    case 'PUT': {
      try {
        const { id } = req.query;
        if (!id) return res.status(400).json({ error: 'id is required' });
        const updated = await prisma.casinoSettings.update({
          where: { id: Number(id) },
          data: req.body,
        });
        return res.json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || error });
      }
    }
    case 'DELETE': {
      try {
        const { id } = req.query;
        if (!id) return res.status(400).json({ error: 'id is required' });
  await prisma.casinoSettings.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || error });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
