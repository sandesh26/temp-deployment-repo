import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../../src/lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const items = await prisma.cashDenomination.findMany({ orderBy: { denomination: 'desc' } });
      return res.status(200).json(items);
    }
    case 'POST': {
      try {
        const data = req.body;
        const item = await prisma.cashDenomination.create({ data });
        return res.status(201).json(item);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
