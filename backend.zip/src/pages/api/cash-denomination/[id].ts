import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../../src/lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const item = await prisma.cashDenomination.findUnique({ where: { id: Number(id) } });
      if (!item) return res.status(404).json({ error: 'CashDenomination not found' });
      return res.status(200).json(item);
    }
    case 'PUT': {
      try {
        const data = req.body;
        const item = await prisma.cashDenomination.update({ where: { id: Number(id) }, data });
        return res.status(200).json(item);
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.cashDenomination.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) return res.status(400).json({ error: error.message });
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'PATCH': {
      try {
        const data = req.body;
        const chip = await prisma.vaultChipDenomination.update({
          where: { id: Number(id) },
          data,
        });
        return res.status(200).json(chip);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
