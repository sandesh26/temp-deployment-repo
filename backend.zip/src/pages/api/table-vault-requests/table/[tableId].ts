import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../../lib/cors';

// Returns requests for a specific table. Query param `open=true` will exclude closed ones.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { tableId } = req.query;
  const table_id = Number(tableId);
  if (isNaN(table_id)) return res.status(400).json({ error: 'Invalid tableId' });

  try {
    const openOnly = String(req.query.open || 'false').toLowerCase() === 'true';

    const where: any = { table_id };
    if (openOnly) {
      where.NOT = { status: { in: ['CLOSED_CONFIRMED', 'CLOSED_REJECTED'] } };
    }

    const requests = await prisma.tableVaultRequest.findMany({
      where,
      orderBy: { requested_at: 'desc' },
      include: {
        initiatedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
        reviewedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
        confirmedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
      },
    });

    return res.status(200).json(requests);
  } catch (error: any) {
    console.error('tableVaultRequests by table error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
