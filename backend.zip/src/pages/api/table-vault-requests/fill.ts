import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const body = req.body;
    const payload = typeof body === 'string' ? JSON.parse(body) : body;

    const {
      table_id,
      gaming_day_id,
      vault_id,
      // new "fill" keys (preferred) and legacy "opening" keys (fallback)
      fill_cash,
      fill_chips,
      fill_total,
      fill_cash_denominations,
      fill_chip_denominations,
      fill_recorded_by,
      filled_by,
      opening_cash,
      opening_chips,
      opening_total,
      opening_cash_denominations,
      opening_chip_denominations,
      opening_recorded_by,
      opened_by,
      notes,
      operation_id,
    } = payload;

    if (!table_id) return res.status(400).json({ error: 'table_id is required' });

    // Resolve gaming day if not provided — prefer the Table's gaming_day_id
    let gamingDayId = gaming_day_id;
    if (!gamingDayId) {
      const tableRec = await prisma.table.findUnique({ where: { table_id: Number(table_id) }, select: { gaming_day_id: true } });
      if (!tableRec) return res.status(404).json({ error: 'Table not found' });
      gamingDayId = tableRec.gaming_day_id;
    }

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      const tId = Number(table_id);

      // 1) Lock table row to avoid concurrent fills and read current balances
      const tableLock: any = await tx.$queryRaw`
        SELECT status, chip_balance, cash_drop_balance, opening_chip_balance FROM \`Table\` WHERE table_id = ${tId} FOR UPDATE
      `;
      if (!tableLock || tableLock.length === 0) throw new Error('Table not found');
      const currentTableRec = tableLock[0];
      const currentChipBalance = Number(currentTableRec.chip_balance ?? 0);
      const currentCashDrop = Number(currentTableRec.cash_drop_balance ?? 0);
      const currentOpeningChipBalance = currentTableRec.opening_chip_balance;
      
      // 2) Compute totals (prefer `fill_*` keys, fall back to legacy `opening_*`)
      const fillCash  = fill_cash !== undefined ? Number(fill_cash) : (opening_cash !== undefined ? Number(opening_cash) : 0);
      const fillChips = fill_chips !== undefined ? Number(fill_chips) : (opening_chips !== undefined ? Number(opening_chips) : 0);
      const fillTotal = fill_total !== undefined ? Number(fill_total) : (opening_total !== undefined ? Number(opening_total) : (fillCash + fillChips));

      // canonical names used throughout the handler
      const cashAmt = fillCash;
      const chipsAmt = fillChips;
      const totalAmt = fillTotal;

      // canonical denominations array (prefer `fill_chip_denominations`)
      const chipDenoms: any[] = Array.isArray(fill_chip_denominations) && fill_chip_denominations.length > 0
        ? fill_chip_denominations
        : Array.isArray(opening_chip_denominations) ? opening_chip_denominations : [];

      const recorder = fill_recorded_by ?? opening_recorded_by ?? null;
      const performer = filled_by ?? opened_by ?? null;

      // 3) Generate auto-descriptive notes if caller didn't provide `notes` (used by vault transactions)
      let generatedNotes: string | null = notes ?? null;
      if (!generatedNotes) {
        const tableRec = await tx.table.findUnique({ where: { table_id: tId }, select: { name: true } });
        const actorId = opened_by ?? opening_recorded_by ?? null;
        let actorName: string | null = null;
        if (actorId) {
          const actor = await tx.user.findUnique({ where: { user_id: Number(actorId) }, select: { full_name: true } });
          actorName = actor?.full_name ?? null;
        }
        generatedNotes = `Fill ${tableRec?.name ?? `Table ${tId}`} by ${actorName ?? 'Unknown'}: cash ${cashAmt}, chips ${chipsAmt}, total ${totalAmt}${operation_id ? `, op ${operation_id}` : ''}`;
      }

      // Before performing any state changes, ensure there's a pending TableVaultRequest to confirm
      let linkedRequestId: number | null = null;
      if (operation_id) linkedRequestId = Number(operation_id);
      else if (vault_id) {
        const pending = await tx.tableVaultRequest.findFirst({
          where: { table_id: tId, vault_id: Number(vault_id), NOT: { status: { in: ['CLOSED_CONFIRMED', 'CLOSED_REJECTED'] } } },
          orderBy: { requested_at: 'desc' },
        });
        if (!pending) throw Object.assign(new Error('No pending TableVaultRequest found'), { status: 400 });
        linkedRequestId = pending.request_id;
      } else {
        // if vault_id not provided and no operation_id, cannot proceed
        throw Object.assign(new Error('No TableVaultRequest found (missing vault_id or operation_id)'), { status: 400 });
      }

      // 4) If vault involved, lock and validate

      let vaultTxs: any[] = [];
      if (vault_id && (cashAmt > 0 || chipsAmt > 0)) {
        const vId = Number(vault_id);
        const vaultLock: any = await tx.$queryRaw`
          SELECT * FROM VaultBalance WHERE vault_id = ${vId} FOR UPDATE
        `;
        if (!vaultLock || vaultLock.length === 0) throw new Error('Vault not found');
        const vault = vaultLock[0];
        const newCash = Number(vault.total_cash) - cashAmt;
        const newChips = Number(vault.total_chips) - chipsAmt;
        if (newCash < 0 || newChips < 0) throw new Error('Insufficient vault funds');

        await tx.vaultBalance.update({ where: { vault_id: vId }, data: { total_cash: String(newCash), total_chips: String(newChips), total_assets: String(Number(vault.total_assets) - (cashAmt + chipsAmt)) } });

        // Adjust vault chip denominations if chip breakdown provided
        if (Array.isArray(chipDenoms) && chipDenoms.length > 0) {
          for (const cd of chipDenoms) {
            const denom = Number(cd.chip_denomination);
            const qty = Number(cd.quantity || 0);
            if (!isFinite(denom) || !isFinite(qty)) continue;
            let existing: any = null;
            if (cd.chip_id) {
              existing = await tx.vaultChipDenomination.findUnique({ where: { id: Number(cd.chip_id) } });
            }
            if (!existing) existing = await tx.vaultChipDenomination.findFirst({ where: { vault_id: vId, chip_denomination: denom } });
            if (!existing) throw new Error(`Vault chip denomination ${denom} not found`);
            const newQty = Number(existing.actual_quantity) - qty;
            if (newQty < 0) throw new Error(`Insufficient vault chip quantity for denom ${denom}`);
            await tx.vaultChipDenomination.update({ where: { id: existing.id }, data: { actual_quantity: newQty, total_value: String(newQty * Number(existing.chip_denomination)), last_updated: now } });
            if (!cd.chip_id) cd.chip_id = existing.id;
          }
        }

        // Create vault transaction(s)
        if (cashAmt > 0) {
          const vt = await tx.vaultTransaction.create({ data: {
            vault_id: Number(vault_id),
            transaction_type: 'WITHDRAWAL',
            asset_type: 'CASH',
            denomination: cashAmt,
            quantity: 1,
            total_value: String(cashAmt),
            currency_code: 'INR',
            source: 'VAULT',
            destination: `TABLE ${tId}`,
            authorized_by: recorder ?? performer ?? 0,
            performed_by: performer ?? recorder ?? 0,
            gaming_day_id: Number(gamingDayId),
            notes: generatedNotes,
            table_id: Number(table_id),
          }});
          vaultTxs.push(vt);
        }

        // For chips, if a denomination breakdown was provided create one VaultTransaction per denom
        if (Array.isArray(chipDenoms) && chipDenoms.length > 0) {
          for (const cd of chipDenoms) {
            const denom = Number(cd.chip_denomination || 0);
            const qty = Number(cd.quantity || 0);
            if (!isFinite(denom) || !isFinite(qty) || qty <= 0) continue;
            const total = denom * qty;
            const vt = await tx.vaultTransaction.create({ data: {
              vault_id: Number(vault_id),
              transaction_type: 'WITHDRAWAL',
              asset_type: 'CHIP',
              denomination: denom,
              quantity: qty,
              total_value: String(total),
              currency_code: 'INR',
              source: 'VAULT',
              destination: `TABLE ${tId}`,
              authorized_by: recorder ?? performer ?? 0,
              performed_by: performer ?? recorder ?? 0,
              gaming_day_id: Number(gamingDayId),
              notes: generatedNotes ?? `Withdraw ${qty} x ${denom} chips for Table ${tId}`,
              table_id: Number(table_id),
            }});
            vaultTxs.push(vt);
          }
        } else if (chipsAmt > 0) {
          const vt2 = await tx.vaultTransaction.create({ data: {
            vault_id: Number(vault_id),
            transaction_type: 'WITHDRAWAL',
            asset_type: 'CHIP',
            denomination: chipsAmt,
            quantity: 1,
            total_value: String(chipsAmt),
            currency_code: 'INR',
            source: 'VAULT',
            destination: `TABLE ${tId}`,
            authorized_by: recorder ?? performer ?? 0,
            performed_by: performer ?? recorder ?? 0,
            gaming_day_id: Number(gamingDayId),
            notes: generatedNotes,
            table_id: Number(table_id),
          }});
          vaultTxs.push(vt2);
        }
      }

      // After creating vault transactions, update the linked TableVaultRequest to CLOSED_CONFIRMED
      if (linkedRequestId) {
        try {
          await tx.tableVaultRequest.update({
            where: { request_id: linkedRequestId },
            data: {
              status: 'CLOSED_CONFIRMED',
              confirmed_by: performer ?? recorder ?? undefined,
              confirmed_at: now,
              completed_at: now,
              linked_vault_tx_id: vaultTxs.length > 0 ? Number(vaultTxs[0].transaction_id) : undefined,
              remarks: generatedNotes ?? undefined,
            },
          });
        } catch (e) {
          // non-fatal
        }
      }

        // FloatBalance updates are skipped for FILL requests (per spec)

      // 6) Upsert TableChipDenomination rows (normalized) if chip breakdown provided
      if (Array.isArray(chipDenoms) && chipDenoms.length > 0) {
        const tableChipRows: any[] = [];
        for (const cd of chipDenoms) {
          const denom = Number(cd.chip_denomination);
          const qty = Number(cd.quantity || 0);
          if (!isFinite(denom) || !isFinite(qty) || qty <= 0) continue;
          const chipId = cd.chip_id ? Number(cd.chip_id) : null;
          const typeOfChip = cd.type_of_chip ?? 'General';
          const totalVal = String(qty * denom);
          let existing: any = null;
          if (cd.chip_id) existing = await tx.tableChipDenomination.findUnique({ where: { id: Number(cd.chip_id) } });
          if (!existing) existing = await tx.tableChipDenomination.findFirst({ where: { table_id: Number(table_id), gaming_day_id: Number(gamingDayId), chip_denomination: denom } });
          if (existing) {
            const newQty = Number(existing.quantity || 0) + qty;
            const newTotal = String(Number(existing.total_value || 0) + qty * denom);
            const updated = await tx.tableChipDenomination.update({ where: { id: existing.id }, data: { quantity: newQty, total_value: newTotal, recorded_at: now, chip_id: chipId ?? existing.chip_id ?? undefined } });
            tableChipRows.push(updated);
            cd.chip_id = updated.id;
          } else {
            const created = await tx.tableChipDenomination.create({
              data: {
                table_id: Number(table_id),
                chip_id: chipId ?? undefined,
                gaming_day_id: Number(gamingDayId),
                chip_denomination: denom,
                type_of_chip: typeOfChip,
                chip_color: cd.chip_color ?? '',
                quantity: qty,
                total_value: totalVal,
                recorded_at: now,
              },
            });
            tableChipRows.push(created);
            cd.chip_id = created.id;
          }
        }
      }

      // 7) Update Table status and balances — add fill amounts to existing balances; do NOT change opening_chip_balance
      const newChipBalance = currentChipBalance + chipsAmt;
      const newCashDrop = currentCashDrop + cashAmt;
      const updatedTable = await tx.table.update({ where: { table_id: Number(table_id) }, data: { status: 'OPEN', cash_drop_balance: String(newCashDrop), chip_balance: String(newChipBalance), last_change: now, changed_by: performer ?? recorder ?? undefined, gaming_day_id: Number(gamingDayId) } });

      // 8) Create TableTransaction(s) to record opening/fills
      const tableTxs: any[] = [];

      // generatedNotes already created above (Fill ...). Reuse it for table transactions.
      if (cashAmt > 0) {
        const ttx = await tx.tableTransaction.create({ data: {
          table_id: Number(table_id),
          amount: String(cashAmt),
          transaction_type: 'VAULT_MONEY_FILL',
          payment_method: 'Cash',
          performed_by: opened_by ?? opening_recorded_by ?? 0,
          gaming_day_id: Number(gamingDayId),
          notes: generatedNotes,
        } });
        tableTxs.push(ttx);
      }
      if (chipsAmt > 0) {
        const ttx2 = await tx.tableTransaction.create({ data: {
          table_id: Number(table_id),
          amount: String(chipsAmt),
          transaction_type: 'VAULT_MONEY_FILL',
          payment_method: 'Chips',
          performed_by: opened_by ?? opening_recorded_by ?? 0,
          gaming_day_id: Number(gamingDayId),
          notes: generatedNotes,
        } });
        tableTxs.push(ttx2);
      }

      return { updatedTable, vaultTxs, tableTxs };
    });

    return res.status(201).json(result);
  } catch (err: any) {
    console.error('table open failed', err);
    if (err && (err.status === 409 || err.message === 'Table already open')) return res.status(409).json({ error: err.message });
    return res.status(400).json({ error: err?.message ?? 'Unknown error' });
  }
}
