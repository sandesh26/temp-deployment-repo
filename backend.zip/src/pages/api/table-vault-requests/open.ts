import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

// Returns all requests which do not have status CLOSED_CONFIRMED or CLOSED_REJECTED
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  try {
    const { table_id } = req.query as any;
    const where: any = {
      NOT: {
        status: { in: ['CLOSED_CONFIRMED', 'CLOSED_REJECTED'] },
      },
    };

    if (table_id !== undefined) {
      const cid = Number(table_id);
      if (!Number.isFinite(cid)) return res.status(400).json({ error: 'table_id must be a number' });
      where.table_id = cid;
    }

    const requests = await prisma.tableVaultRequest.findMany({
      where,
      orderBy: { requested_at: 'desc' },
      include: {
        table: { select: { table_id: true, name: true } },
        initiatedBy: { select: { employee_id: true, user: { select: { full_name: true } } } },
      },
    });

    return res.status(200).json(requests);
  } catch (error: any) {
    console.error('tableVaultRequests open error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
