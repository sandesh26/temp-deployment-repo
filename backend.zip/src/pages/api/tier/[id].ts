import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const idNum = Number(id);
  if (isNaN(idNum)) return res.status(400).json({ error: 'Invalid id' });

  switch (req.method) {
    case 'GET':
      try {
        const record = await (prisma as any).tierTable.findUnique({ where: { tierid: idNum } });
        if (!record) return res.status(404).json({ error: 'Not found' });
        return res.status(200).json(record);
      } catch (err) {
        console.error('tier GET id error', err);
        return res.status(500).json({ error: 'Failed to fetch tier' });
      }

    case 'PUT':
      try {
        const { tiername, loyality_percentage, threshold_amount, threshold_duration } = req.body;
        if (!tiername || typeof tiername !== 'string') {
          return res.status(400).json({ error: 'tiername is required' });
        }
        const updated = await (prisma as any).tierTable.update({ where: { tierid: idNum }, data: { tiername: String(tiername), loyality_percentage: loyality_percentage !== undefined ? loyality_percentage : null, threshold_amount: threshold_amount !== undefined ? threshold_amount : null, threshold_duration: threshold_duration !== undefined ? (Number(threshold_duration) || 0) : 0 } });
        return res.status(200).json(updated);
      } catch (err: any) {
        console.error('tier PUT error', err);
        return res.status(400).json({ error: err.message || 'Failed to update tier' });
      }

    case 'PATCH':
      try {
        const body = req.body || {};
        const data: any = {};
        if (body.tiername !== undefined) data.tiername = String(body.tiername);
        if (body.loyality_percentage !== undefined) data.loyality_percentage = body.loyality_percentage;
        if (body.threshold_amount !== undefined) data.threshold_amount = body.threshold_amount;
        if (body.threshold_duration !== undefined) data.threshold_duration = Number(body.threshold_duration) || 0;
        if (Object.keys(data).length === 0) return res.status(400).json({ error: 'No fields to update' });
        const patched = await (prisma as any).tierTable.update({ where: { tierid: idNum }, data });
        return res.status(200).json(patched);
      } catch (err: any) {
        console.error('tier PATCH error', err);
        return res.status(400).json({ error: err.message || 'Failed to patch tier' });
      }

    case 'DELETE':
      try {
        await (prisma as any).tierTable.delete({ where: { tierid: idNum } });
        return res.status(204).end();
      } catch (err) {
        console.error('tier DELETE error', err);
        return res.status(400).json({ error: 'Failed to delete tier' });
      }

    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
