import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { page = '1', pageSize = '50' } = req.query;
      const pageNum = Math.max(1, Number(page));
      const pageSizeNum = Math.max(1, Number(pageSize));
      const [data, total] = await Promise.all([
        (prisma as any).tierTable.findMany({
          skip: (pageNum - 1) * pageSizeNum,
          take: pageSizeNum,
          orderBy: { tierid: 'asc' },
        }),
        (prisma as any).tierTable.count(),
      ]);
      return res.status(200).json({ data, page: pageNum, pageSize: pageSizeNum, total, totalPages: Math.ceil(total / pageSizeNum) });
    } catch (err) {
      console.error('tier GET error', err);
      return res.status(500).json({ error: 'Failed to fetch tiers' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { tiername, loyality_percentage, threshold_amount, threshold_duration } = req.body;
      if (!tiername || typeof tiername !== 'string') {
        return res.status(400).json({ error: 'tiername is required' });
      }
      const created = await (prisma as any).tierTable.create({
        data: {
          tiername: String(tiername),
          loyality_percentage: loyality_percentage !== undefined ? loyality_percentage : null,
          threshold_amount: threshold_amount !== undefined ? threshold_amount : null,
          threshold_duration: threshold_duration !== undefined ? (Number(threshold_duration) || 0) : 0,
                  },
      });
      return res.status(201).json(created);
    } catch (err: any) {
      console.error('tier POST error', err);
      return res.status(400).json({ error: err.message || 'Failed to create tier' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
