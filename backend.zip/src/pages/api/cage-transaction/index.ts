import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { cage_id, gaming_day_id } = req.query;
      const where: any = {};

      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }
      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }

      const transactions = await prisma.cageTransaction.findMany({
        where,
        orderBy: { transaction_id: 'desc' },
        include: {
          performedBy: { select: { full_name: true } },
          player: { select: { full_name: true } },
          verifier: { select: { full_name: true } },
        },
      });

      const result = transactions.map((tx: any) => ({
        ...tx,
        performed_by_id: tx.performed_by,
        performed_by: tx.performedBy?.full_name ?? null,
        player: tx.player?.full_name ?? null,
        verifier: tx.verifier?.full_name ?? null,
      }));

      return res.status(200).json(result);
    }
    case 'POST': {
      try {
        const body = req.body || {};

        const asNumber = (v: any) => {
          const n = Number(v);
          return Number.isFinite(n) ? n : undefined;
        };

        const data: any = {};
        // Required numeric fields
        data.cage_id = asNumber(body.cage_id);
        // amount: keep as string for Prisma Decimal compatibility
        data.amount = body.amount !== undefined ? String(body.amount) : undefined;
        data.transaction_type = body.transaction_type;
        data.payment_method = body.payment_method;
        data.performed_by = asNumber(body.performed_by);

        // Optional fields
        if (body.player_id !== undefined) data.player_id = asNumber(body.player_id);
        if (body.is_manual !== undefined) data.is_manual = Boolean(body.is_manual);
        if (body.requires_verification !== undefined) data.requires_verification = Boolean(body.requires_verification);
        if (body.verified_by !== undefined) data.verified_by = asNumber(body.verified_by);
        if (body.session_start !== undefined) {
          const d = new Date(body.session_start);
          if (!isNaN(d.getTime())) data.session_start = d;
        }
        if (body.session_end !== undefined) {
          const d = new Date(body.session_end);
          if (!isNaN(d.getTime())) data.session_end = d;
        }
        if (body.timestamp !== undefined) {
          const d = new Date(body.timestamp);
          if (!isNaN(d.getTime())) data.timestamp = d;
        }
        if (body.notes !== undefined) data.notes = body.notes;
        if (body.gaming_day_id !== undefined) data.gaming_day_id = asNumber(body.gaming_day_id);
        if (body.session_id !== undefined) data.session_id = asNumber(body.session_id);

        // Validation: required fields must be present and valid
        const missing: string[] = [];
        if (data.cage_id === undefined) missing.push('cage_id');
        if (data.amount === undefined) missing.push('amount');
        if (!data.transaction_type) missing.push('transaction_type');
        if (!data.payment_method) missing.push('payment_method');
        if (data.performed_by === undefined) missing.push('performed_by');

        if (missing.length > 0) {
          return res.status(400).json({ error: 'Missing or invalid fields', missing });
        }

        const transaction = await prisma.cageTransaction.create({ data });
        return res.status(201).json(transaction);
      } catch (err: any) {
        console.error('POST /api/cage-transaction error:', err);
        return res.status(400).json({ error: 'Create failed', details: err?.message ?? String(err) });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}