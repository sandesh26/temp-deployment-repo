import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { cage_id, gaming_day_id } = req.query;
      const where: any = {};

      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }
      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }

      const transactions = await prisma.cageTransaction.findMany({
        where,
        orderBy: { transaction_id: 'desc' },
        include: {
          performedBy: { select: { full_name: true } },
          player: { select: { full_name: true } },
          verifier: { select: { full_name: true } },
        },
      });

      const result = transactions.map((tx: any) => ({
        ...tx,
        performed_by_id: tx.performed_by,
        performed_by: tx.performedBy?.full_name ?? null,
        player: tx.player?.full_name ?? null,
        verifier: tx.verifier?.full_name ?? null,
      }));

      return res.status(200).json(result);
    }
    case 'POST': {
      const data = req.body;
      const transaction = await prisma.cageTransaction.create({ data });
      return res.status(201).json(transaction);
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}