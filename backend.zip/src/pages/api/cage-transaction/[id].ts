import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, cage_id, gaming_day_id } = req.query;

  switch (req.method) {
    case 'GET': {
      // If id is a valid number, fetch by transaction_id
      if (typeof id === 'string' && !isNaN(Number(id))) {
        const transaction = await prisma.cageTransaction.findUnique({
          where: { transaction_id: Number(id) },
        });
        return res.status(200).json(transaction);
      }

      // Otherwise, filter by cage_id and/or gaming_day_id
      const where: any = {};
      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }
      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }
      if (Object.keys(where).length === 0) {
        return res.status(400).json({ error: 'Invalid ID or missing filter parameters' });
      }

      const transactions = await prisma.cageTransaction.findMany({
        where,
        orderBy: { transaction_id: 'desc' },
      });
      return res.status(200).json(transactions);
    }
    case 'PUT': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      const data = req.body;
      const transaction = await prisma.cageTransaction.update({
        where: { transaction_id: Number(id) },
        data,
      });
      return res.status(200).json(transaction);
    }
    case 'PATCH': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      try {
        const body = req.body || {};

        // Coerce and sanitize known fields to avoid common client mistakes
        const data: any = {};

        const asNumber = (v: any) => {
          const n = Number(v);
          return Number.isFinite(n) ? n : undefined;
        };

        if (body.cage_id !== undefined) data.cage_id = asNumber(body.cage_id);
        if (body.player_id !== undefined) data.player_id = asNumber(body.player_id);
        if (body.verified_by !== undefined) data.verified_by = asNumber(body.verified_by);
        if (body.performed_by !== undefined) data.performed_by = asNumber(body.performed_by);
        if (body.session_id !== undefined) data.session_id = asNumber(body.session_id);
        if (body.gaming_day_id !== undefined) data.gaming_day_id = asNumber(body.gaming_day_id);

        // amount: Prisma Decimal fields accept string or number; preserve as string to be safe
        if (body.amount !== undefined) data.amount = String(body.amount);

        if (body.transaction_type !== undefined) data.transaction_type = body.transaction_type;
        if (body.payment_method !== undefined) data.payment_method = body.payment_method;

        if (body.is_manual !== undefined) data.is_manual = Boolean(body.is_manual);
        if (body.requires_verification !== undefined) data.requires_verification = Boolean(body.requires_verification);

        // date fields: try to coerce to Date
        const parseDate = (v: any) => {
          if (v == null) return undefined;
          const d = new Date(v);
          return isNaN(d.getTime()) ? undefined : d;
        };

        if (body.session_start !== undefined) data.session_start = parseDate(body.session_start);
        if (body.session_end !== undefined) data.session_end = parseDate(body.session_end);
        if (body.timestamp !== undefined) data.timestamp = parseDate(body.timestamp);

        if (body.notes !== undefined) data.notes = body.notes;
        if (body.transaction_type !== undefined) data.transaction_type = body.transaction_type;

        // Remove undefined values
        Object.keys(data).forEach((k) => data[k] === undefined && delete data[k]);

        if (Object.keys(data).length === 0) {
          return res.status(400).json({ error: 'No valid fields provided for patch' });
        }

        const transaction = await prisma.cageTransaction.update({
          where: { transaction_id: Number(id) },
          data,
        });
        return res.status(200).json(transaction);
      } catch (err: any) {
        console.error('PATCH /api/cage-transaction/[id] error:', err);
        // Return Prisma error message to help debugging in dev. In production you may want
        // to return a more generic message.
        return res.status(400).json({ error: 'Patch failed', details: err?.message ?? String(err) });
      }
    }
    case 'DELETE': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      await prisma.cageTransaction.delete({ where: { transaction_id: Number(id) } });
      return res.status(204).end();
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}