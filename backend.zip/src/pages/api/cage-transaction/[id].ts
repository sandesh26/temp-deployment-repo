import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, cage_id, gaming_day_id } = req.query;

  switch (req.method) {
    case 'GET': {
      // If id is a valid number, fetch by transaction_id
      if (typeof id === 'string' && !isNaN(Number(id))) {
        const transaction = await prisma.cageTransaction.findUnique({
          where: { transaction_id: Number(id) },
        });
        return res.status(200).json(transaction);
      }

      // Otherwise, filter by cage_id and/or gaming_day_id
      const where: any = {};
      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }
      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }
      if (Object.keys(where).length === 0) {
        return res.status(400).json({ error: 'Invalid ID or missing filter parameters' });
      }

      const transactions = await prisma.cageTransaction.findMany({
        where,
        orderBy: { transaction_id: 'desc' },
      });
      return res.status(200).json(transactions);
    }
    case 'PUT': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      const data = req.body;
      const transaction = await prisma.cageTransaction.update({
        where: { transaction_id: Number(id) },
        data,
      });
      return res.status(200).json(transaction);
    }
    case 'DELETE': {
      if (typeof id !== 'string' || isNaN(Number(id))) {
        return res.status(400).json({ error: 'Invalid ID' });
      }
      await prisma.cageTransaction.delete({ where: { transaction_id: Number(id) } });
      return res.status(204).end();
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}