import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

// GET: list DefaultFloat entries (filters: module, reference_id, type, take, skip)
// POST: create a DefaultFloat { module: 'CAGE'|'TABLE', reference_id: number, type: 'CASH'|'CHIP', value: number/string, quantity?: number }
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method === 'GET') {
    try {
      const { module: moduleRaw, reference_id, cage_id, table_id, type, take, skip } = req.query as any;
      const moduleParam = moduleRaw ? String(moduleRaw).trim().toUpperCase() : undefined;
      const where: any = {};
      if (moduleParam) where.module = moduleParam;
      if (type) where.type = type;

      // Normalize reference filters: the schema now uses `reference_id` only.
      if (reference_id !== undefined) {
        where.reference_id = Number(reference_id);
      }
      // Accept legacy cage_id/table_id query params and map to reference_id
      if (cage_id !== undefined) where.reference_id = Number(cage_id);
      if (table_id !== undefined) where.reference_id = Number(table_id);

      const items = await (prisma as any).defaultFloat.findMany({
        where,
        orderBy: { id: 'desc' },
        take: take ? Number(take) : undefined,
        skip: skip ? Number(skip) : undefined,
      });
      return res.status(200).json(items);
    } catch (error: any) {
      console.error('DefaultFloat GET error', error);
      return res.status(500).json({ error: error.message || 'Failed to fetch default floats' });
    }
  }

  if (req.method === 'POST') {
    try {
      const body = req.body;

      // Support batch create: { records: [ { ... }, ... ] }
      const records = Array.isArray(body?.records) ? body.records : null;

      const buildCreateData = (rec: any, idx?: number) => {
        const module = (rec.module || '').toString().trim().toUpperCase();
        const reference_id = rec.reference_id !== undefined ? Number(rec.reference_id) : undefined;
        const cage_id = rec.cage_id !== undefined ? Number(rec.cage_id) : undefined;
        const table_id = rec.table_id !== undefined ? Number(rec.table_id) : undefined;
        // accept item_type or type
        const type = (rec.type || rec.item_type || '').toString().trim().toUpperCase();
  const value = rec.amount ?? rec.value;
  const quantity = rec.quantity !== undefined ? (rec.quantity === null ? null : Number(rec.quantity)) : undefined;
  const chip_denomination_id = rec.chip_denomination_id ?? rec.chipDenominationId ?? rec.chip_denomination ?? null;

        if (!module || (module !== 'CAGE' && module !== 'TABLE')) throw new Error(`record ${idx ?? ''}: module must be CAGE or TABLE`);

        // resolve reference id based on module
        let cageIdToUse: number | null = null;
        let tableIdToUse: number | null = null;
        if (module === 'CAGE') {
          const resolved = reference_id ?? cage_id ?? null;
          if (resolved === null || resolved === undefined || !Number.isFinite(Number(resolved))) throw new Error(`record ${idx ?? ''}: reference_id (cage id) is required and must be a number`);
          cageIdToUse = Number(resolved);
        } else if (module === 'TABLE') {
          const resolved = reference_id ?? table_id ?? null;
          if (resolved === null || resolved === undefined || !Number.isFinite(Number(resolved))) throw new Error(`record ${idx ?? ''}: reference_id (table id) is required and must be a number`);
          tableIdToUse = Number(resolved);
        }

        if (!type || (type !== 'CASH' && type !== 'CHIP')) throw new Error(`record ${idx ?? ''}: type must be CASH or CHIP`);
        if (value === undefined || value === null || value === '') {
          // allow null amount for CHIP when quantity provided — enforce at least one of amount/quantity
          if (type === 'CHIP' && (quantity !== undefined && quantity !== null)) {
            // allow null amount
          } else {
            throw new Error(`record ${idx ?? ''}: amount is required`);
          }
        }

        const data: any = {
          module,
          type,
          amount: value ?? null,
          quantity: quantity ?? null,
          reference_id: module === 'CAGE' ? cageIdToUse : tableIdToUse,
          chip_denomination_id: chip_denomination_id ?? null,
        };

        return data;
      };

      if (records) {
        // validate and build data for all records first
        const datas = records.map((r: any, i: number) => buildCreateData(r, i));

        // collect unique refs per module and validate referenced cages/tables exist
        const cageRefs = Array.from(new Set(datas.filter((d: any) => d.module === 'CAGE').map((d: any) => d.reference_id)));
        const tableRefs = Array.from(new Set(datas.filter((d: any) => d.module === 'TABLE').map((d: any) => d.reference_id)));

        if (cageRefs.length > 0) {
          const existing = await (prisma as any).cage.findMany({ where: { cage_id: { in: cageRefs } }, select: { cage_id: true } });
          const found = new Set(existing.map((e: any) => e.cage_id));
          const missing = cageRefs.filter((id) => !found.has(id));
          if (missing.length) throw new Error(`Missing cage ids: ${missing.join(',')}`);
        }
        if (tableRefs.length > 0) {
          const existing = await (prisma as any).table.findMany({ where: { table_id: { in: tableRefs } }, select: { table_id: true } });
          const found = new Set(existing.map((e: any) => e.table_id));
          const missing = tableRefs.filter((id) => !found.has(id));
          if (missing.length) throw new Error(`Missing table ids: ${missing.join(',')}`);
        }

  // run delete ops (remove existing default floats for these refs), create ops and set defaultFloat flag for affected cages/tables in one transaction
  const deleteOps: any[] = [];
  for (const cid of cageRefs) deleteOps.push((prisma as any).defaultFloat.deleteMany({ where: { module: 'CAGE', reference_id: cid } }));
  for (const tid of tableRefs) deleteOps.push((prisma as any).defaultFloat.deleteMany({ where: { module: 'TABLE', reference_id: tid } }));

  const createOps = datas.map((d: any) => (prisma as any).defaultFloat.create({ data: d }));
  const updateOps: any[] = [];
  for (const cid of cageRefs) updateOps.push((prisma as any).cage.update({ where: { cage_id: cid }, data: { defaultFloat: true } }));
  for (const tid of tableRefs) updateOps.push((prisma as any).table.update({ where: { table_id: tid }, data: { defaultFloat: true } }));

  const created = await (prisma as any).$transaction([...deleteOps, ...createOps, ...updateOps]);
        // created contains created records followed by update results; return only created DefaultFloat records
        const createdRecords = created.slice(0, createOps.length);
        return res.status(201).json(createdRecords);
      }

      // Single record fallback (existing shape)
      const module = (body.module || '').toString().trim().toUpperCase();
      const reference_id = Number(body.reference_id);
  const type = (body.type || body.item_type || '').toString().trim().toUpperCase();
  const value = body.amount ?? body.value;
  const quantity = body.quantity !== undefined ? Number(body.quantity) : undefined;

      if (!module || (module !== 'CAGE' && module !== 'TABLE')) return res.status(400).json({ error: 'module must be CAGE or TABLE' });
      if (!Number.isFinite(reference_id)) return res.status(400).json({ error: 'reference_id is required and must be a number' });
      if (!type || (type !== 'CASH' && type !== 'CHIP')) return res.status(400).json({ error: 'type must be CASH or CHIP' });
      if (value === undefined || value === null || value === '') return res.status(400).json({ error: 'amount is required' });

      const data: any = {
        module,
        type,
        amount: value,
        quantity: quantity ?? null,
      };

      // map reference id depending on module into the single `reference_id` column
      if (module === 'CAGE') {
        const resolved = reference_id ?? body.reference_id ?? body.cage_id;
        if (resolved === undefined || resolved === null || !Number.isFinite(Number(resolved))) return res.status(400).json({ error: 'reference_id (cage id) is required and must be a number' });
        data.reference_id = Number(resolved);
        data.chip_denomination_id = body.chip_denomination_id ?? body.chipDenominationId ?? body.chip_denomination ?? null;
      } else if (module === 'TABLE') {
        const resolved = reference_id ?? body.reference_id ?? body.table_id;
        if (resolved === undefined || resolved === null || !Number.isFinite(Number(resolved))) return res.status(400).json({ error: 'reference_id (table id) is required and must be a number' });
        data.reference_id = Number(resolved);
        data.chip_denomination_id = body.chip_denomination_id ?? body.chipDenominationId ?? body.chip_denomination ?? null;
      }

      // validate referenced cage/table exists before create
      if (module === 'CAGE') {
        const cid = Number(data.reference_id);
        const found = await (prisma as any).cage.findUnique({ where: { cage_id: cid } });
        if (!found) return res.status(400).json({ error: `cage id ${cid} not found` });
      } else if (module === 'TABLE') {
        const tid = Number(data.reference_id);
        const found = await (prisma as any).table.findUnique({ where: { table_id: tid } });
        if (!found) return res.status(400).json({ error: `table id ${tid} not found` });
      }

      const created = await (prisma as any).defaultFloat.create({ data });
      // set defaultFloat flag on the referenced cage/table
      if (module === 'CAGE') {
        await (prisma as any).cage.update({ where: { cage_id: Number(data.reference_id) }, data: { defaultFloat: true } });
      } else if (module === 'TABLE') {
        await (prisma as any).table.update({ where: { table_id: Number(data.reference_id) }, data: { defaultFloat: true } });
      }

      return res.status(201).json(created);
    } catch (error: any) {
      console.error('DefaultFloat POST error', error);
      return res.status(400).json({ error: error.message || 'Failed to create default float' });
    }
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
}
