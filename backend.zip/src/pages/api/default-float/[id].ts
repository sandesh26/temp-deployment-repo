import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const recordId = Number(id);
  if (Number.isNaN(recordId)) return res.status(400).json({ error: 'Invalid id' });

  try {
    if (req.method === 'GET') {
      const item = await (prisma as any).defaultFloat.findUnique({ where: { id: recordId } });
      if (!item) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(item);
    }

    if (req.method === 'PUT') {
      const body = req.body;
      // fetch existing record to handle clearing old reference flag if needed
      const existing = await (prisma as any).defaultFloat.findUnique({ where: { id: recordId } });
      if (!existing) return res.status(404).json({ error: 'Not found' });
      const module = (body.module || '').toString().trim().toUpperCase();
      const reference_id = body.reference_id !== undefined ? Number(body.reference_id) : undefined;
      const cage_id = body.cage_id !== undefined ? Number(body.cage_id) : undefined;
      const table_id = body.table_id !== undefined ? Number(body.table_id) : undefined;
      const type = (body.type || '').toString().trim().toUpperCase();
      const amount = body.amount ?? body.value;
      const quantity = body.quantity !== undefined ? Number(body.quantity) : undefined;

      if (!module || (module !== 'CAGE' && module !== 'TABLE')) return res.status(400).json({ error: 'module must be CAGE or TABLE' });
      // determine reference_id to use
      let refToUse: number | null = null;
      if (module === 'CAGE') {
        const resolved = reference_id ?? cage_id ?? null;
        if (resolved === null || resolved === undefined || !Number.isFinite(resolved)) return res.status(400).json({ error: 'reference_id (cage id) is required and must be a number' });
        refToUse = Number(resolved);
      } else if (module === 'TABLE') {
        const resolved = reference_id ?? table_id ?? null;
        if (resolved === null || resolved === undefined || !Number.isFinite(resolved)) return res.status(400).json({ error: 'reference_id (table id) is required and must be a number' });
        refToUse = Number(resolved);
      }

      if (!type || (type !== 'CASH' && type !== 'CHIP')) return res.status(400).json({ error: 'type must be CASH or CHIP' });
      if (amount === undefined || amount === null || amount === '') return res.status(400).json({ error: 'amount is required' });

      const updateData: any = { module, type, amount, quantity: quantity ?? null, reference_id: refToUse };

      // validate new referenced entity exists
      if (module === 'CAGE') {
        const found = await (prisma as any).cage.findUnique({ where: { cage_id: refToUse } });
        if (!found) return res.status(400).json({ error: `cage id ${refToUse} not found` });
      } else if (module === 'TABLE') {
        const found = await (prisma as any).table.findUnique({ where: { table_id: refToUse } });
        if (!found) return res.status(400).json({ error: `table id ${refToUse} not found` });
      }

      const updated = await (prisma as any).defaultFloat.update({ where: { id: recordId }, data: updateData });

      // ensure new reference has defaultFloat = true
      if (module === 'CAGE') {
        await (prisma as any).cage.update({ where: { cage_id: Number(refToUse) }, data: { defaultFloat: true } });
      } else if (module === 'TABLE') {
        await (prisma as any).table.update({ where: { table_id: Number(refToUse) }, data: { defaultFloat: true } });
      }

      // if module/reference changed from existing, clear old flag if no other DefaultFloat rows remain
      try {
        const oldModule = existing.module as string;
        const oldRef = existing.reference_id as number | null;
        if (oldRef !== null && (oldModule !== module || oldRef !== refToUse)) {
          const cnt = await (prisma as any).defaultFloat.count({ where: { module: oldModule, reference_id: oldRef } });
          if (cnt === 0) {
            if (oldModule === 'CAGE') await (prisma as any).cage.update({ where: { cage_id: Number(oldRef) }, data: { defaultFloat: false } });
            if (oldModule === 'TABLE') await (prisma as any).table.update({ where: { table_id: Number(oldRef) }, data: { defaultFloat: false } });
          }
        }
      } catch (e) {
        // best-effort cleanup; log and continue
        console.warn('DefaultFloat PUT: cleanup failed', e);
      }

      return res.status(200).json(updated);
    }

    if (req.method === 'PATCH') {
      const body = req.body;
      // fetch existing to compute changes
      const existing = await (prisma as any).defaultFloat.findUnique({ where: { id: recordId } });
      if (!existing) return res.status(404).json({ error: 'Not found' });

      const data: any = {};
      if (body.module !== undefined) data.module = String(body.module).toUpperCase();
      // allow updating cage_id or table_id directly
      if (body.reference_id !== undefined) {
        data.reference_id = Number(body.reference_id);
      }
      if (body.cage_id !== undefined) data.reference_id = Number(body.cage_id);
      if (body.table_id !== undefined) data.reference_id = Number(body.table_id);
      if (body.type !== undefined) data.type = String(body.type).toUpperCase();
      if (body.amount !== undefined) data.amount = body.amount;
      if (body.value !== undefined && body.amount === undefined) data.amount = body.value;
      if (body.quantity !== undefined) data.quantity = Number(body.quantity);

      // compute target module/ref after patch (merge existing + data)
      const newModule = data.module ?? existing.module;
      const newRef = data.reference_id ?? existing.reference_id;

      // validate referenced entity exists if reference changed
      if (data.reference_id !== undefined || data.module !== undefined) {
        if (newModule === 'CAGE') {
          const found = await (prisma as any).cage.findUnique({ where: { cage_id: Number(newRef) } });
          if (!found) return res.status(400).json({ error: `cage id ${newRef} not found` });
        } else if (newModule === 'TABLE') {
          const found = await (prisma as any).table.findUnique({ where: { table_id: Number(newRef) } });
          if (!found) return res.status(400).json({ error: `table id ${newRef} not found` });
        }
      }

      const updated = await (prisma as any).defaultFloat.update({ where: { id: recordId }, data });

      // ensure new reference has defaultFloat = true
      if (newModule === 'CAGE') {
        await (prisma as any).cage.update({ where: { cage_id: Number(newRef) }, data: { defaultFloat: true } });
      } else if (newModule === 'TABLE') {
        await (prisma as any).table.update({ where: { table_id: Number(newRef) }, data: { defaultFloat: true } });
      }

      // if ref/module changed, clear old flag if no remaining DefaultFloat rows
      try {
        const oldModule = existing.module as string;
        const oldRef = existing.reference_id as number | null;
        if (oldRef !== null && (oldModule !== newModule || oldRef !== newRef)) {
          const cnt = await (prisma as any).defaultFloat.count({ where: { module: oldModule, reference_id: oldRef } });
          if (cnt === 0) {
            if (oldModule === 'CAGE') await (prisma as any).cage.update({ where: { cage_id: Number(oldRef) }, data: { defaultFloat: false } });
            if (oldModule === 'TABLE') await (prisma as any).table.update({ where: { table_id: Number(oldRef) }, data: { defaultFloat: false } });
          }
        }
      } catch (e) {
        console.warn('DefaultFloat PATCH: cleanup failed', e);
      }

      return res.status(200).json(updated);
    }

    if (req.method === 'DELETE') {
      // fetch existing record to know module/reference
      const existing = await (prisma as any).defaultFloat.findUnique({ where: { id: recordId } });
      if (!existing) return res.status(404).json({ error: 'Not found' });

      await (prisma as any).defaultFloat.delete({ where: { id: recordId } });

      // if no more default floats exist for that reference, clear the flag
      try {
        const cnt = await (prisma as any).defaultFloat.count({ where: { module: existing.module, reference_id: existing.reference_id } });
        if (cnt === 0) {
          if (existing.module === 'CAGE') await (prisma as any).cage.update({ where: { cage_id: Number(existing.reference_id) }, data: { defaultFloat: false } });
          if (existing.module === 'TABLE') await (prisma as any).table.update({ where: { table_id: Number(existing.reference_id) }, data: { defaultFloat: false } });
        }
      } catch (e) {
        console.warn('DefaultFloat DELETE: cleanup failed', e);
      }

      return res.status(204).end();
    }

    res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  } catch (error: any) {
    console.error('DefaultFloat [id] error', error);
    return res.status(500).json({ error: error.message || 'Server error' });
  }
}
