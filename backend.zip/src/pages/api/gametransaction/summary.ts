import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { playerId, month, year, day } = req.query;
  if (!playerId) {
    return res.status(400).json({ error: 'playerId is required' });
  }
  const playerIdNum = Number(playerId);
  let monthNum: number | undefined = undefined;
  let yearNum: number | undefined = undefined;
  let dayNum: number | undefined = undefined;
  if (month !== undefined) {
    monthNum = Number(month);
    if (isNaN(monthNum)) {
      return res.status(400).json({ error: 'Invalid month' });
    }
  }
  if (year !== undefined) {
    yearNum = Number(year);
    if (isNaN(yearNum)) {
      return res.status(400).json({ error: 'Invalid year' });
    }
  }
  if (day !== undefined) {
    dayNum = Number(day);
    if (isNaN(dayNum)) {
      return res.status(400).json({ error: 'Invalid day' });
    }
  }
  if (isNaN(playerIdNum)) {
    return res.status(400).json({ error: 'Invalid playerId' });
  }

  let dateFilter = undefined;
  if (yearNum !== undefined && monthNum !== undefined) {
    let startDate: Date, endDate: Date;
    if (dayNum !== undefined) {
      startDate = new Date(yearNum, monthNum - 1, dayNum);
      endDate = new Date(yearNum, monthNum - 1, dayNum + 1);
    } else {
      startDate = new Date(yearNum, monthNum - 1, 1);
      endDate = new Date(yearNum, monthNum, 1);
    }
    dateFilter = { gte: startDate, lt: endDate };
  }

  // Fetch all transactions for player in the period (or lifetime)
  const transactions = await prisma.gameTransaction.findMany({
    where: {
      playerId: playerIdNum,
      ...(dateFilter ? { createdAt: dateFilter } : {}),
    },
    select: {
      betAmount: true,
      resultAmount: true,
      gameName: true,
    },
  });

  let totalProfit = 0;
  let totalLoss = 0;
  let totalWagered = 0;
  const gameCount: Record<string, number> = {};
  for (const t of transactions) {
    // Count games
    if (t.gameName) {
      gameCount[t.gameName] = (gameCount[t.gameName] || 0) + 1;
    }
    // Wagered
    if (t.betAmount !== null && t.betAmount !== undefined) {
      totalWagered += Number(t.betAmount);
    }
    // Profit/loss
    if (t.resultAmount !== null && t.resultAmount !== undefined) {
      const diff = Number(t.resultAmount) - Number(t.betAmount);
      if (diff > 0) totalProfit += diff;
      else if (diff < 0) totalLoss += Math.abs(diff);
    }
  }

  // Find favourite game
  let favouriteGame = null;
  let maxCount = 0;
  for (const [game, count] of Object.entries(gameCount)) {
    if (count > maxCount) {
      maxCount = count;
      favouriteGame = game;
    }
  }

  return res.json({
    playerId: playerIdNum,
    year: yearNum,
    month: monthNum,
    day: dayNum,
    totalProfit,
    totalLoss,
    totalWagered,
    favouriteGame,
    lifetime: yearNum === undefined && monthNum === undefined && dayNum === undefined
  });
}