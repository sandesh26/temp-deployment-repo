import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  const { id } = req.query;
  const idNum = Number(id);
  if (isNaN(idNum)) {
    return res.status(400).json({ error: 'Invalid id' });
  }

  switch (req.method) {
    case 'GET':
      try {
        const gameTransaction = await prisma.gameTransaction.findUnique({ where: { id: idNum } });
        if (!gameTransaction) return res.status(404).json({ error: 'Not found' });
        return res.json(gameTransaction);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }

    case 'PUT':
      try {
        const body = req.body || {};
        const updated = await prisma.gameTransaction.update({ where: { id: idNum }, data: body });
        return res.json(updated);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }

    case 'PATCH':
      try {
        const body = req.body || {};
        // Only include provided fields
        const data: any = {};
        for (const key of Object.keys(body)) {
          data[key] = body[key];
        }
        const patched = await prisma.gameTransaction.update({ where: { id: idNum }, data });
        return res.json(patched);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }

    case 'DELETE':
      try {
        await prisma.gameTransaction.delete({ where: { id: idNum } });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }

    default:
      res.setHeader('Allow', ['GET', 'PUT', 'PATCH', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
