import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    switch (req.method) {
    case 'GET': {
      const { status, name } = req.query;
      const where: any = {};
      if (status !== undefined) where.status = status;
      if (name !== undefined) where.name = name;
      const games = await prisma.gameCatalog.findMany({
        where,
        orderBy: { game_id: 'asc' },
      });
      return res.status(200).json(games);
    }
    case 'POST': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const game = await prisma.gameCatalog.create({ data });
        return res.status(201).json(game);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Creation failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
