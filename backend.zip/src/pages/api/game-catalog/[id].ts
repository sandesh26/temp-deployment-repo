import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const game = await prisma.gameCatalog.findUnique({
        where: { game_id: Number(id) },
      });
      if (!game) return res.status(404).json({ error: 'Not found' });
      return res.status(200).json(game);
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        const game = await prisma.gameCatalog.update({
          where: { game_id: Number(id) },
          data,
        });
        return res.status(200).json(game);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Update failed' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.gameCatalog.delete({
          where: { game_id: Number(id) },
        });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Delete failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
