import type { NextApiRequest, NextApiResponse } from 'next';

export function cors(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*'); // Change '*' to your frontend URL in production
  // Allow PATCH as it's used for partial updates; add other common headers if needed
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,POST,PUT,PATCH,DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,If-Match');
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true; // Indicates that the response has ended
  }
  return false;
}