import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'GET': {
      const { status, name, gaming_day_id, floor } = req.query;
      const where: any = {};
      if (status !== undefined) where.status = status;
      if (name !== undefined) where.name = name;
      if (gaming_day_id !== undefined) where.gaming_day_id = Number(gaming_day_id);
      if (floor !== undefined) {
        const floorNum = Number(floor);
        if (!isNaN(floorNum)) {
          where.floor_id = floorNum;
        }
      }

      const tables = await prisma.table.findMany({
        where,
        orderBy: { table_id: 'asc' },
        include: {
          changedBy: { select: { full_name: true } },
          gamingDay: { select: { start_time: true } },
        },
      });

      type TableWithRelations = {
        changedBy?: { full_name?: string } | null;
        gamingDay?: { start_time?: string | Date } | null;
        gaming_day_id?: number;
        last_change?: string | Date | null;
        chip_balance?: any;
        opening_chip_balance?: any;
        [key: string]: any;
      };

      function formatDate(dateString: string | Date | null | undefined) {
        if (!dateString) return null;
        const date = new Date(dateString);
        const pad = (n: number) => n.toString().padStart(2, '0');
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
      }

      const result = tables.map((table: TableWithRelations) => {
        const { changedBy, gamingDay, gaming_day_id, last_change, chip_balance, opening_chip_balance, ...rest } = table;
        return {
          ...rest,
          chip_balance: chip_balance !== undefined && chip_balance !== null ? chip_balance.toString() : null,
          opening_chip_balance: opening_chip_balance !== undefined && opening_chip_balance !== null ? opening_chip_balance.toString() : null,
          last_change: last_change ? formatDate(last_change) : null,
          changed_by: changedBy?.full_name ?? null,
          gaming_day: gamingDay?.start_time ? formatDate(gamingDay.start_time) : null,
        };
      });

      return res.status(200).json(result);
    }
    case 'POST': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        // Validate required fields
        if (!data.name) {
          return res.status(400).json({ error: 'Table name is required' });
        }

        // Check if this is a simple creation (only name and floor_id) or full details
        const isSimpleCreation = Object.keys(data).length <= 3 && // name, floor_id, and optionally gaming_day_id
          data.name && 
          (data.floor_id !== undefined || data.floor_id === null) &&
          !data.chip_balance && 
          !data.cash_drop_balance && 
          !data.opening_chip_balance;

        let tableData;

        if (isSimpleCreation) {
          // Simple creation: only name and floor_id
          // Get current gaming day for the table
          const currentGamingDay = await prisma.gamingDay.findFirst({
            where: { status: 'OPEN' },
            orderBy: { created_at: 'desc' }
          });

          if (!currentGamingDay) {
            return res.status(400).json({ 
              error: 'No active gaming day found. Please create a gaming day first.' 
            });
          }

          tableData = {
            name: data.name,
            floor_id: data.floor_id || null,
            gaming_day_id: currentGamingDay.gaming_day_id,
            status: 'CLOSED', // Default status for new tables
            chip_balance: 0.00,
            cash_drop_balance: 0.00,
            opening_chip_balance: 0.00,
            last_change: new Date(),
            changed_by: data.changed_by || null
          };
        } else {
          // Full details creation: use all provided data
          // Ensure required fields have defaults if not provided
          tableData = {
            ...data,
            status: data.status || 'CLOSED',
            chip_balance: data.chip_balance || 0.00,
            cash_drop_balance: data.cash_drop_balance || 0.00,
            opening_chip_balance: data.opening_chip_balance || 0.00,
            last_change: data.last_change || new Date(),
            gaming_day_id: data.gaming_day_id || (() => {
              // If gaming_day_id not provided, we need to get current gaming day
              throw new Error('gaming_day_id is required for full table creation');
            })()
          };
        }

        // Create the table
        const table = await prisma.table.create({ 
          data: tableData,
          include: {
            changedBy: { select: { full_name: true } },
            gamingDay: { select: { start_time: true } },
          }
        });

        // Format the response
        const formattedTable = {
          ...table,
          chip_balance: table.chip_balance?.toString() || '0.00',
          cash_drop_balance: table.cash_drop_balance?.toString() || '0.00',
          opening_chip_balance: table.opening_chip_balance?.toString() || '0.00',
          last_change: table.last_change ? new Date(table.last_change).toISOString() : null,
          changed_by: table.changedBy?.full_name || null,
          gaming_day: table.gamingDay?.start_time ? new Date(table.gamingDay.start_time).toISOString() : null
        };

        return res.status(201).json({
          ...formattedTable,
          creation_type: isSimpleCreation ? 'simple' : 'full'
        });

      } catch (error: any) {
        console.error('Table creation error:', error);
        return res.status(400).json({ 
          error: error.message || 'Table creation failed' 
        });
      }
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);
        if (!data.table_id) return res.status(400).json({ error: 'table_id is required for update' });
  const table = await prisma.table.update({
          where: { table_id: Number(data.table_id) },
          data,
        });
        return res.status(200).json(table);
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Update failed' });
      }
    }
    case 'DELETE': {
      try {
        const { table_id } = req.body;
        if (!table_id) return res.status(400).json({ error: 'table_id is required for delete' });
  await prisma.table.delete({
          where: { table_id: Number(table_id) },
        });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message || 'Delete failed' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
