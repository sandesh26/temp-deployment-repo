import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  switch (req.method) {
    case 'GET': {
      // Pagination and sorting
      const { id, playerId, page = '1', pageSize = '20' } = req.query;
      const pageNum = Math.max(1, Number(page));
      const pageSizeNum = Math.max(1, Number(pageSize));

      if (id) {
        const gameTransaction = await prisma.gameTransaction.findUnique({ where: { id: Number(id) } });
        if (!gameTransaction) return res.status(404).json({ error: 'Not found' });
        return res.json(gameTransaction);
      } else {
        const where: any = {};
        if (playerId) {
          const pid = Number(playerId);
          if (isNaN(pid)) return res.status(400).json({ error: 'Invalid playerId' });
          where.playerId = pid;
        }
        const [gameTransactions, total] = await Promise.all([
          prisma.gameTransaction.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            skip: (pageNum - 1) * pageSizeNum,
            take: pageSizeNum,
          }),
          prisma.gameTransaction.count({ where }),
        ]);
        return res.json({
          data: gameTransactions,
          page: pageNum,
          pageSize: pageSizeNum,
          total,
          totalPages: Math.ceil(total / pageSizeNum)
        });
      }
    }
    case 'POST':
      try {
        if (Array.isArray(req.body)) {
          // Bulk insert with custom dates support
          const data = req.body.map((item) => {
            const record: any = {
              playerId: item.playerId,
              gameName: item.gameName,
              betAmount: item.betAmount,
              resultAmount: item.resultAmount,
              outcome: item.outcome,
              status: item.status || 'Pending',
            };
            if (item.createdAt) record.createdAt = new Date(item.createdAt);
            if (item.updatedAt) record.updatedAt = new Date(item.updatedAt);
            return record;
          });
          const result = await prisma.gameTransaction.createMany({ data });
          return res.status(201).json({ count: result.count });
        } else {
          // Single insert with custom dates support
          const { playerId, gameName, betAmount, resultAmount, outcome, status, createdAt, updatedAt } = req.body;
          const data: any = {
            playerId,
            gameName,
            betAmount,
            resultAmount,
            outcome,
            status: status || 'Pending',
          };
          if (createdAt) data.createdAt = new Date(createdAt);
          if (updatedAt) data.updatedAt = new Date(updatedAt);
          const gameTransaction = await prisma.gameTransaction.create({ data });
          return res.status(201).json(gameTransaction);
        }
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    case 'PUT':
      try {
        const { id, ...data } = req.body;
  const gameTransaction = await prisma.gameTransaction.update({
          where: { id: Number(id) },
          data,
        });
        return res.json(gameTransaction);
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    case 'DELETE':
      try {
        const { id } = req.body;
  await prisma.gameTransaction.delete({ where: { id: Number(id) } });
        return res.status(204).end();
      } catch (error: any) {
        return res.status(400).json({ error: error.message });
      }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
