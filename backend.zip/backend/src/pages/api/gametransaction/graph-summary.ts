import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;

  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const { playerId } = req.query;
  if (!playerId) {
    return res.status(400).json({ error: 'playerId is required' });
  }
  const playerIdNum = Number(playerId);
  if (isNaN(playerIdNum)) {
    return res.status(400).json({ error: 'Invalid playerId' });
  }

  // Calculate the last 6 months (including current month)
  const now = new Date();
  const months: { year: number, month: number, start: Date, end: Date }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const year = d.getFullYear();
    const month = d.getMonth() + 1; // 1-based
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 1);
    months.push({ year, month, start, end });
  }

  // Fetch all transactions for the player in the last 6 months
  const minDate = months[0].start;
  const transactions = await prisma.gameTransaction.findMany({
    where: {
      playerId: playerIdNum,
      createdAt: { gte: minDate }
    },
    select: {
      betAmount: true,
      resultAmount: true,
      createdAt: true,
    },
  });

  // Group and summarize by month
  const summary: Array<{
    year: number,
    month: number,
    totalProfit: number,
    totalLoss: number,
    totalWagered: number
  }> = months.map(({ year, month, start, end }) => {
    let totalProfit = 0;
    let totalLoss = 0;
    let totalWagered = 0;
    for (const t of transactions) {
      if (t.createdAt >= start && t.createdAt < end) {
        if (t.betAmount !== null && t.betAmount !== undefined) {
          totalWagered += Number(t.betAmount);
        }
        if (t.resultAmount !== null && t.resultAmount !== undefined) {
          const diff = Number(t.resultAmount) - Number(t.betAmount);
          if (diff > 0) totalProfit += diff;
          else if (diff < 0) totalLoss += Math.abs(diff);
        }
      }
    }
    return { year, month, totalProfit, totalLoss, totalWagered };
  });

  return res.json({ playerId: playerIdNum, summary });
}