import type { NextApiRequest, NextApiResponse } from 'next';
import os from 'os';
import { cors } from '../../lib/cors';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
    const interfaces = os.networkInterfaces();
  let mac = null;
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name] || []) {
      if (!net.internal && net.mac && net.mac !== '00:00:00:00:00:00') {
        mac = net.mac;
        break;
      }
    }
    if (mac) break;
  }
  if (mac) {
    res.status(200).json({ mac });
  } else {
    res.status(404).json({ error: 'MAC address not found' });
  }
}
