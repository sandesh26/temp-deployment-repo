import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id, gamesdata } = req.query;

  //const includeGames = typeof gamesdata === 'string' && gamesdata.toLowerCase() === 'true';

  if (req.method === 'GET') {
    try {
      const machine = await prisma.slotMachine.findUnique({
        where: { machine_id: Number(id) },
        //include: includeGames ? { games: true } : undefined,
      });

      return machine
        ? res.status(200).json(machine)
        : res.status(404).json({ error: 'Slot machine not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching slot machine' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.slotMachine.update({
        where: { machine_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch {
      return res.status(400).json({ error: 'Update failed' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.slotMachine.delete({
        where: { machine_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}