import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { cors } from '../../../lib/cors';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  if (req.method === 'GET') {
    try {
      const txn = await prisma.transaction.findUnique({
        where: { transaction_id: Number(id) },
      });

      return txn
        ? res.status(200).json(txn)
        : res.status(404).json({ error: 'Transaction not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching transaction' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.transaction.update({
        where: { transaction_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch {
      return res.status(400).json({ error: 'Update failed' });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.transaction.delete({
        where: { transaction_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}