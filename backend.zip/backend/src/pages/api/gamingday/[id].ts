import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import { verifyToken } from '@auth';
import { cors } from '../../../lib/cors';
import { error } from 'console';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;

  // Middleware to check JWT and user role
//   const user = await verifyToken(req);

//   console.log('Authenticated user:', user);

//   // Check if the user is authenticated and has 'Supervisor' role for PUT and DELETE
//   if (['PUT', 'DELETE'].includes(req.method as string) && (!user || user.role !== 'Admin')) {
//     return res.status(403).json({ error: 'Unauthorized, supervisors only' });
// }

  if (req.method === 'GET') {
    try {
      const gamingDay = await prisma.gamingDay.findUnique({
        where: { gaming_day_id: Number(id) },
      });

      return gamingDay
        ? res.status(200).json(gamingDay)
        : res.status(404).json({ error: 'Gaming day not found' });
    } catch {
      return res.status(500).json({ error: 'Error fetching gaming day' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const updated = await prisma.gamingDay.update({
        where: { gaming_day_id: Number(id) },
        data: req.body,
      });
      return res.status(200).json(updated);
    } catch (error: any) {
      return res.status(400).json({ error: 'Update failed', details: error?.message || String(error) });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.gamingDay.delete({
        where: { gaming_day_id: Number(id) },
      });
      return res.status(204).end();
    } catch {
      return res.status(400).json({ error: 'Delete failed' });
    }
  }

  res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}