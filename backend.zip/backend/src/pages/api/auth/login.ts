// pages/api/auth/login.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { prisma } from '@prisma';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { createRateLimiter } from '../../../middleware/validation';
import { cors } from '../../../lib/cors';

interface LoginRequest {
  username: string;
  password: string;
}

interface LoginResponse {
  success: boolean;
  token?: string;
  employee?: {
    employee_id: number;
    username: string;
    role: string;
    access_level: number;
    user: {
      user_id: number;
      full_name: string;
      email: string | null;
      phone: string;
      role: string;
      status: string;
    };
  };
  message?: string;
}

// Create rate limiter for login attempts
const rateLimiter = createRateLimiter();

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<LoginResponse>
) {
  // Handle CORS
  if (cors(req, res)) return;

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed. Use POST.',
    });
  }

  // Apply rate limiting
  try {
    await new Promise((resolve, reject) => {
      rateLimiter(req as any, res as any, (error?: any) => {
        if (error) reject(error);
        else resolve(undefined);
      });
    });
  } catch (error) {
    return res.status(429).json({
      success: false,
      message: 'Too many login attempts. Please try again later.',
    });
  }

  try {
    const { username, password }: LoginRequest = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.',
      });
    }

    // Validate input types and format
    if (typeof username !== 'string' || typeof password !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Invalid input format.',
      });
    }

    // Sanitize username (trim whitespace)
    const sanitizedUsername = username.trim();

    if (sanitizedUsername.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Username cannot be empty.',
      });
    }

    // Find employee by username
    const employee = await prisma.employee.findUnique({
      where: {
        username: sanitizedUsername,
      },
      select: {
        employee_id: true,
        username: true,
        password_hash: true,
        role: true,
        access_level: true,
        user: {
          select: {
            user_id: true,
            full_name: true,
            email: true,
            phone: true,
            role: true,
            status: true,
          },
        },
      },
    });

    // Check if employee exists
    if (!employee) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    // Check if user account is active
    if (employee.user.status !== 'Active') {
      return res.status(401).json({
        success: false,
        message: 'Account is not active. Please contact administrator.',
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, employee.password_hash);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    // Get JWT secret
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      console.error('JWT_SECRET is not defined in environment variables');
      return res.status(500).json({
        success: false,
        message: 'Server configuration error.',
      });
    }

    // Create JWT payload
    const tokenPayload = {
      user_id: employee.user.user_id,
      employee_id: employee.employee_id,
      role: employee.role,
      access_level: employee.access_level,
    };

    // Generate JWT token (expires in 8 hours)
    const token = jwt.sign(tokenPayload, jwtSecret, {
      expiresIn: '8h',
      issuer: 'casino-management-system',
      audience: 'casino-employees',
    });

    // Return success response with token and employee data
    const responseData = {
      employee_id: employee.employee_id,
      username: employee.username,
      role: employee.role,
      access_level: employee.access_level,
      user: employee.user,
    };

    return res.status(200).json({
      success: true,
      token,
      employee: responseData,
      message: 'Login successful.',
    });

  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error. Please try again later.',
    });
  }
}