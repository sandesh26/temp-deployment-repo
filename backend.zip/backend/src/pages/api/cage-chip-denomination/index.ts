import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  switch (req.method) {
    case 'GET': {
      const { gaming_day_id, cage_id } = req.query;
      const where: any = {};

      if (gaming_day_id !== undefined) {
        const gId = Number(gaming_day_id);
        if (!isNaN(gId)) where.gaming_day_id = gId;
      }
      if (cage_id !== undefined) {
        const cId = Number(cage_id);
        if (!isNaN(cId)) where.cage_id = cId;
      }

      const records = await prisma.cageChipDenomination.findMany({
        where,
        include: {
          cage: { select: { name: true } },
          gamingDay: { select: { start_time: true, end_time: true } },
        },
        orderBy: { recorded_at: 'desc' },
      });
      const result = records.map((rec: any) => ({
        ...rec,
        cage: rec.cage?.name ?? null,
        gaming_day_start: rec.gamingDay?.start_time ?? null,
        gaming_day_end: rec.gamingDay?.end_time ?? null,
        chip_denomination: Number(rec.chip_denomination).toFixed(2),
        total_value: Number(rec.total_value).toFixed(2),
      }));
      return res.status(200).json(result);
    }
    case 'POST': {
      try {
        let data = req.body;
        // If data is a string (Next.js edge case), parse it
        if (typeof data === 'string') data = JSON.parse(data);

        if (Array.isArray(data)) {
          const records = await prisma.cageChipDenomination.createMany({
            data,
            skipDuplicates: false,
          });
          return res.status(201).json({ count: records.count });
        } else {
          const record = await prisma.cageChipDenomination.create({ data });
          return res.status(201).json(record);
        }
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'PUT': {
      try {
        let data = req.body;
        if (typeof data === 'string') data = JSON.parse(data);

        if (!Array.isArray(data)) {
          return res.status(400).json({ error: 'Bulk update expects an array of objects' });
        }

        let updatedCount = 0;
        for (const entry of data) {
          // Use your unique identifier(s) here. Example uses id:
          const { id, ...updateFields } = entry;
          if (!id) continue; // Skip if no id

          const updated = await prisma.cageChipDenomination.update({
            where: { id: Number(id) },
            data: updateFields,
          });
          if (updated) updatedCount++;
        }

        return res.status(200).json({ count: updatedCount });
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}