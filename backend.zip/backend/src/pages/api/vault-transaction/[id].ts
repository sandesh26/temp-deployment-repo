import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';
import { cors } from '../../../lib/cors';

const prisma = new PrismaClient();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (cors(req, res)) return;
  const { id } = req.query;
  if (typeof id !== 'string') return res.status(400).json({ error: 'Invalid ID' });

  switch (req.method) {
    case 'GET': {
      const tx = await prisma.vaultTransaction.findUnique({
        where: { transaction_id: Number(id) },
        include: {
          authorizedBy: { select: { user: { select: { full_name: true } } } },
          performedBy: { select: { user: { select: { full_name: true } } } },
        },
      });
      if (!tx) return res.status(404).json({ error: 'VaultTransaction not found' });
      const result = {
        ...tx,
        authorized_by: tx.authorizedBy?.user?.full_name ?? null,
        performed_by: tx.performedBy?.user?.full_name ?? null,
      };
      return res.status(200).json(result);
    }
    case 'PUT': {
      try {
        const data = req.body;
        const tx = await prisma.vaultTransaction.update({
          where: { transaction_id: Number(id) },
          data,
        });
        return res.status(200).json(tx);
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    case 'DELETE': {
      try {
        await prisma.vaultTransaction.delete({ where: { transaction_id: Number(id) } });
        return res.status(204).end();
      } catch (error) {
        if (error instanceof Error) {
          return res.status(400).json({ error: error.message });
        }
        return res.status(400).json({ error: 'Unknown error' });
      }
    }
    default:
      res.setHeader('Allow', ['GET', 'PUT', 'DELETE']);
      return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}