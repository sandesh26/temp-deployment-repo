-- CreateTable
CREATE TABLE `User` (
    `user_id` INTEGER NOT NULL AUTO_INCREMENT,
    `full_name` VARCHAR(191) NOT NULL,
    `address` VARCHAR(191) NULL,
    `date_of_birth` DATETIME(3) NULL,
    `govt_id_number` VARCHAR(191) NOT NULL,
    `govt_id_type` ENUM('Aadhar', 'PAN', 'Passport', 'Driving_License') NOT NULL,
    `photo_url` VARCHAR(191) NULL,
    `email` VARCHAR(191) NULL,
    `phone` VARCHAR(191) NOT NULL,
    `role` ENUM('Player', 'Counter_Operator', 'Cage_Manager', 'Cage_Supervisor', 'Receptionist', 'Admin', 'SuperAdmin', 'Technical') NOT NULL,
    `status` ENUM('Active', 'Inactive', 'Banned') NOT NULL DEFAULT 'Active',
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `User_govt_id_number_key`(`govt_id_number`),
    UNIQUE INDEX `User_email_key`(`email`),
    UNIQUE INDEX `User_phone_key`(`phone`),
    PRIMARY KEY (`user_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Employee` (
    `employee_id` INTEGER NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER NOT NULL,
    `username` VARCHAR(191) NOT NULL,
    `password_hash` VARCHAR(191) NOT NULL,
    `role` VARCHAR(191) NOT NULL,
    `access_level` INTEGER NOT NULL,

    UNIQUE INDEX `Employee_user_id_key`(`user_id`),
    UNIQUE INDEX `Employee_username_key`(`username`),
    PRIMARY KEY (`employee_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `PlayerCard` (
    `card_id` INTEGER NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER NOT NULL,
    `rfid_number` VARCHAR(191) NOT NULL,
    `pin` VARCHAR(191) NOT NULL,
    `balance` DECIMAL(65, 30) NOT NULL DEFAULT 0.00,
    `loyalty_points` INTEGER NOT NULL DEFAULT 0,
    `tier` ENUM('VIP', 'VVIP', 'Premium', 'Gold', 'Silver') NOT NULL DEFAULT 'Silver',

    UNIQUE INDEX `PlayerCard_user_id_key`(`user_id`),
    UNIQUE INDEX `PlayerCard_rfid_number_key`(`rfid_number`),
    INDEX `PlayerCard_rfid_number_idx`(`rfid_number`),
    PRIMARY KEY (`card_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `SlotMachine` (
    `machine_id` INTEGER NOT NULL AUTO_INCREMENT,
    `machine_number` VARCHAR(191) NOT NULL,
    `location` VARCHAR(191) NULL,
    `current_player_id` INTEGER NULL,
    `current_balance` DECIMAL(65, 30) NOT NULL DEFAULT 0.00,
    `machine_status` ENUM('Active', 'Inactive', 'Under_Maintenance') NOT NULL DEFAULT 'Active',
    `last_updated` DATETIME(3) NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `SlotMachine_machine_number_key`(`machine_number`),
    INDEX `SlotMachine_machine_number_idx`(`machine_number`),
    INDEX `SlotMachine_current_player_id_idx`(`current_player_id`),
    PRIMARY KEY (`machine_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `TITO` (
    `tito_id` INTEGER NOT NULL AUTO_INCREMENT,
    `machine_id` INTEGER NOT NULL,
    `unique_identifier` VARCHAR(191) NOT NULL,
    `barcode` VARCHAR(191) NOT NULL,
    `amount` DECIMAL(65, 30) NOT NULL,
    `issued_at` DATETIME(3) NULL DEFAULT CURRENT_TIMESTAMP(3),
    `redeemed_at` DATETIME(3) NULL,
    `status` ENUM('Generated', 'Redeemed', 'Expired') NOT NULL DEFAULT 'Generated',

    UNIQUE INDEX `TITO_unique_identifier_key`(`unique_identifier`),
    UNIQUE INDEX `TITO_barcode_key`(`barcode`),
    INDEX `TITO_unique_identifier_idx`(`unique_identifier`),
    PRIMARY KEY (`tito_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Transaction` (
    `transaction_id` INTEGER NOT NULL AUTO_INCREMENT,
    `card_id` INTEGER NULL,
    `transaction_type` ENUM('Credit', 'Debit', 'Encash', 'Balance_Inquiry') NOT NULL,
    `amount` DECIMAL(65, 30) NOT NULL,
    `payment_method` ENUM('Cash', 'Chips', 'UPI', 'Credit_Debit_Card', 'TITO') NOT NULL,
    `transaction_status` ENUM('Pending', 'Completed', 'Failed') NOT NULL DEFAULT 'Pending',
    `timestamp` DATETIME(3) NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `Transaction_card_id_idx`(`card_id`),
    PRIMARY KEY (`transaction_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `GamingDay` (
    `gaming_day_id` INTEGER NOT NULL AUTO_INCREMENT,
    `start_time` DATETIME(3) NOT NULL,
    `end_time` DATETIME(3) NOT NULL,
    `status` VARCHAR(191) NOT NULL,
    `closed_by` INTEGER NULL,
    `closed_at` DATETIME(3) NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    PRIMARY KEY (`gaming_day_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Employee` ADD CONSTRAINT `Employee_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `PlayerCard` ADD CONSTRAINT `PlayerCard_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `SlotMachine` ADD CONSTRAINT `SlotMachine_current_player_id_fkey` FOREIGN KEY (`current_player_id`) REFERENCES `User`(`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Transaction` ADD CONSTRAINT `Transaction_card_id_fkey` FOREIGN KEY (`card_id`) REFERENCES `PlayerCard`(`card_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GamingDay` ADD CONSTRAINT `GamingDay_closed_by_fkey` FOREIGN KEY (`closed_by`) REFERENCES `Employee`(`employee_id`) ON DELETE SET NULL ON UPDATE CASCADE;
