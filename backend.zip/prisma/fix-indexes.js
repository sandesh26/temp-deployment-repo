const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('=== Starting Database Foreign Key & Index Fix ===');
  try {
    // 1. Query information_schema to find all foreign key constraints on PlayerCard(user_id)
    const fks = await prisma.$queryRawUnsafe(`
      SELECT CONSTRAINT_NAME 
      FROM information_schema.KEY_COLUMN_USAGE 
      WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'PlayerCard' 
        AND COLUMN_NAME = 'user_id' 
        AND REFERENCED_TABLE_NAME IS NOT NULL
    `);

    console.log('Found Foreign Key Constraints on PlayerCard(user_id):', fks);

    for (const row of fks) {
      const fkName = row.CONSTRAINT_NAME;
      console.log(`Dropping foreign key constraint: ${fkName}...`);
      try {
        await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` DROP FOREIGN KEY \`${fkName}\``);
        console.log(`✓ Dropped foreign key ${fkName}`);
      } catch (err) {
        console.error(`Failed to drop foreign key ${fkName}:`, err.message);
      }
    }

    // 2. Query all indexes on PlayerCard
    const indexes = await prisma.$queryRawUnsafe(`
      SELECT DISTINCT INDEX_NAME, NON_UNIQUE 
      FROM information_schema.STATISTICS 
      WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'PlayerCard'
    `);
    console.log('Current indexes on PlayerCard:', indexes);

    // Drop unique index on user_id if present
    const hasUniqueUserId = indexes.some(i => i.INDEX_NAME === 'PlayerCard_user_id_key');
    if (hasUniqueUserId) {
      console.log('Dropping unique index PlayerCard_user_id_key...');
      try {
        await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` DROP INDEX \`PlayerCard_user_id_key\``);
        console.log('✓ Dropped unique index PlayerCard_user_id_key');
      } catch (err) {
        console.error('Failed to drop unique index:', err.message);
      }
    }

    // Ensure non-unique index exists
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` ADD INDEX \`PlayerCard_user_id_idx\` (\`user_id\`)`);
      console.log('✓ Added non-unique index PlayerCard_user_id_idx');
    } catch (err) {
      console.log('Index PlayerCard_user_id_idx already exists or notice:', err.message);
    }

    // 3. Re-create foreign key constraint
    try {
      await prisma.$executeRawUnsafe(`
        ALTER TABLE \`PlayerCard\` 
        ADD CONSTRAINT \`PlayerCard_user_id_fkey\` 
        FOREIGN KEY (\`user_id\`) REFERENCES \`User\`(\`user_id\`) 
        ON DELETE CASCADE
      `);
      console.log('✓ Re-created foreign key constraint PlayerCard_user_id_fkey');
    } catch (err) {
      console.log('Foreign key constraint re-creation notice:', err.message);
    }

    console.log('\n=== Fix Complete! Now run `npx prisma db push` ===');
  } catch (error) {
    console.error('Migration error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
