const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Starting index migration for PlayerCard...');
  try {
    // 1. Temporarily drop foreign key constraint if it references the unique index
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` DROP FOREIGN KEY \`PlayerCard_user_id_fkey\`;`);
    } catch (e) {
      try {
        await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` DROP FOREIGN KEY \`PlayerCard_ibfk_1\`;`);
      } catch (e2) {
        // Foreign key might have a different name or already dropped
      }
    }

    // 2. Drop the old unique index
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` DROP INDEX \`PlayerCard_user_id_key\`;`);
      console.log('Dropped unique index PlayerCard_user_id_key');
    } catch (e) {
      console.log('PlayerCard_user_id_key already dropped or not present');
    }

    // 3. Add the non-unique index
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` ADD INDEX \`PlayerCard_user_id_idx\` (\`user_id\`);`);
      console.log('Added non-unique index PlayerCard_user_id_idx');
    } catch (e) {
      console.log('PlayerCard_user_id_idx already present');
    }

    // 4. Re-add foreign key constraint
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE \`PlayerCard\` ADD CONSTRAINT \`PlayerCard_user_id_fkey\` FOREIGN KEY (\`user_id\`) REFERENCES \`User\`(\`user_id\`) ON DELETE CASCADE;`);
      console.log('Re-added foreign key constraint PlayerCard_user_id_fkey');
    } catch (e) {
      console.log('Foreign key constraint notice:', e.message);
    }

    console.log('Successfully updated PlayerCard indexes. You can now run: npx prisma db push');
  } catch (error) {
    console.error('Error during index migration:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
