export const API_DEV_HOSTNAME  = process.env.NEXT_PUBLIC_API_DEV_HOSTNAME;
export const API_PROD_HOSTNAME = process.env.NEXT_PUBLIC_API_PROD_HOSTNAME;
export const API_PORT          = process.env.NEXT_PUBLIC_API_PORT || "";
export const API_ENVIRONMENT   = process.env.NEXT_PUBLIC_API_ENVIRONMENT || "DEV";

export const API_BASE_URL =
  API_ENVIRONMENT && API_ENVIRONMENT == "DEV"
    ? `http://${API_DEV_HOSTNAME}:${API_PORT}`
    : `https://${API_PROD_HOSTNAME}`;