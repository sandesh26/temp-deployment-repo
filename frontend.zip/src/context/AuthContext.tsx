"use client";
import React, { createContext, useContext, useEffect, useState } from "react";
import { API_BASE_URL } from "@/config/api";

type User = {
  id: string;
  name?: string;
  email?: string;
  // other fields from API
};

type Session = {
  user: User | null;
  role: string | null;
  permissions: string[];
  createdAt?: string;
  token?: string | null;
};

type AuthContextType = {
  session: Session | null;
  loading: boolean;
  loginAs: (userId: string, roleName: string, token?: string | null) => Promise<void>;
  logout: () => void;
  hasPermission: (permission: string) => boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const STORAGE_KEY = "casino_session_v1";

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setSession(JSON.parse(raw));
      }
    } catch (err) {
      localStorage.removeItem(STORAGE_KEY);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (session) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [session]);

  async function fetchUser(userId: string, token?: string | null) {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(`${API_BASE_URL}/api/user/${userId}`, { headers });
    if (!res.ok) {
      throw new Error("Failed to fetch user");
    }
    return res.json();
  }

  async function fetchPermissions(roleName: string, token?: string | null) {
    // Try a few role name variants because backend may expect different casing (e.g. 'Admin')
    const candidates = Array.from(new Set([
      roleName,
      roleName.charAt(0).toUpperCase() + roleName.slice(1),
      roleName.toUpperCase(),
      roleName.toLowerCase(),
    ]));

    for (const candidate of candidates) {
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        const res = await fetch(
          `${API_BASE_URL}/api/user-permissions?role_name=${encodeURIComponent(candidate)}`,
          { headers }
        );
        if (!res.ok) {
          // try next candidate
          continue;
        }
        const data = await res.json();
        // If API returns an array of objects, extract module_name where can_view is true
        if (Array.isArray(data) && data.length > 0) {
          try {
            const modules = data
              .filter((p: any) => p && (p.can_view === true || p.can_view === "true"))
              .map((p: any) => String(p.module_name).trim());
            if (modules.length > 0) return modules;
            // if modules empty, continue to next candidate
            continue;
          } catch (e) {
            continue;
          }
        }

        // Fallback if API returns object with permissions property
        const perms = data.permissions ?? [];
        if (Array.isArray(perms) && perms.length > 0) return perms;
      } catch (e) {
        // network or parse error, try next candidate
        continue;
      }
    }

    return [];
  }

  const loginAs = async (userId: string, roleName: string, token?: string | null) => {
    setLoading(true);
    try {
      const [user, permissions] = await Promise.all([
        fetchUser(userId, token),
        fetchPermissions(roleName, token),
      ]);
      // permissions is normalized to an array of module names (strings)
      const newSession: Session = {
        user: { ...user, id: user.id, name: user.name ?? user.email },
        role: roleName,
        permissions: permissions as string[],
        createdAt: new Date().toISOString(),
        token: token ?? null,
      };
      setSession(newSession);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    // Attempt server-side logout if token available
    try {
      const token = session?.token;
      if (token) {
        await fetch(`${API_BASE_URL}/api/auth/logout`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
      }
    } catch (e) {
      // ignore network errors during logout
    } finally {
      setSession(null);
    }
  };

  const hasPermission = (permission: string) => {
    if (!session) return false;
    return session.permissions.includes(permission);
  };

  return (
    <AuthContext.Provider value={{ session, loading, loginAs, logout, hasPermission }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export default AuthContext;
