import { API_BASE_URL } from '@/config/api';

export type ChipEntry = { id: number; denomination: number; quantity: number; color?: string };

/**
 * Perform a cage top-up by orchestrating the same steps used for Start Session / Fill Up.
 * This helper mirrors the existing inline logic in `CageDetails` and centralizes it.
 * Returns the updated cage and vault objects along with a reference id.
 */
export async function performCageTopUp(options: {
  cageId: number;
  cashAmount?: number;
  chips?: ChipEntry[];
  performedBy: number;
  authorizedBy?: number;
  gamingDayId?: number;
  referenceId?: string;
  note?: string;
}) {
  const {
    cageId,
    cashAmount = 0,
    chips = [],
    performedBy,
    authorizedBy,
    gamingDayId,
    referenceId,
    note = ''
  } = options;

  const now = new Date().toISOString();
  const cage_id = Number(cageId);
  const cash_total = Number(cashAmount) || 0;

  // 1) Save chip denominations (if present)
  if (chips.length > 0) {
    const chipEntries = chips
      .filter(c => c.quantity > 0)
      .map(c => ({
        cage_id,
        chip_id: c.id,
        gaming_day_id: gamingDayId,
        chip_denomination: c.denomination,
        chip_color: c.color || '',
        quantity: c.quantity,
        total_value: Number(c.denomination) * Number(c.quantity),
        recorded_at: now,
      }));

    await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(chipEntries),
    });
  }

  // 2) Update cage balances
  const chip_total = chips.reduce((s, c) => s + (Number(c.denomination) * Number(c.quantity || 0)), 0);
  await fetch(`${API_BASE_URL}/api/cage/${cage_id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      status: 'OPEN',
      balance: cash_total,
      chip_balance: chip_total,
      opening_balance: cash_total,
      opening_chip_balance: chip_total,
      last_change: now,
      gaming_day_id: gamingDayId,
      changed_by: performedBy,
    }),
  });

  // 3) Fetch & update vault balances
  const vaultResp = await fetch(`${API_BASE_URL}/api/vault-balance/1`);
  const vault = await vaultResp.json();

  const new_total_cash = Number(vault.total_cash) - cash_total;
  const new_total_chips = Number(vault.total_chips) - chip_total;
  const new_total_assets = Number(vault.total_assets) - (cash_total + chip_total);

  await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      total_cash: new_total_cash,
      total_chips: new_total_chips,
      total_assets: new_total_assets,
      last_updated: now,
    }),
  });

  // 4) Update vault chip denominations inventory (bulk)
  if (chips.length > 0) {
    const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
    const vaultChips = await vaultChipRes.json();
    const vaultChipUpdates = chips.map(c => {
      const vaultChip = vaultChips.find((vc: any) => vc.id === c.id);
      const prevQuantity = Number(vaultChip?.quantity) || 0;
      const prevTotalValue = Number(vaultChip?.total_value) || 0;
      const denomination = Number(c.denomination);
      return {
        id: c.id,
        quantity: prevQuantity - c.quantity,
        total_value: prevTotalValue - (c.quantity * denomination),
      };
    });

    await fetch(`${API_BASE_URL}/api/vault-chip-denomination/bulk`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(vaultChipUpdates),
    });
  }

  // 5) Create vault transaction records
  const reference = referenceId || `${Date.now()}-${Math.random().toString(36).slice(2,8).toUpperCase()}`;
  const transaction_time = now;
  const destination = `Cage ${cage_id}`;
  const performed_by = performedBy;
  const authorized_by = authorizedBy;

  const vaultTransactions: any[] = [];
  if (cash_total > 0) {
    vaultTransactions.push({
      vault_id: 1,
      transaction_type: 'TRANSFER',
      asset_type: 'CASH',
      denomination: 0,
      quantity: 0,
      total_value: cash_total,
      currency_code: 'INR',
      source: 'Vault',
      destination,
      reference_id: reference,
      authorized_by,
      performed_by,
      transaction_time,
      cage_id,
      notes: note || `Cash of INR ${cash_total} added to Cage ${cage_id}`,
      gaming_day_id: gamingDayId,
    });
  }
  if (chips.reduce((s,c)=>s + (c.quantity||0), 0) > 0) {
    chips.filter(c => c.quantity > 0).forEach(c => {
      vaultTransactions.push({
        vault_id: 1,
        transaction_type: 'TRANSFER',
        asset_type: 'CHIP',
        denomination: Number(c.denomination),
        quantity: c.quantity,
        total_value: Number(c.denomination) * c.quantity,
        currency_code: 'INR',
        source: 'Vault',
        destination,
        reference_id: reference,
        authorized_by,
        performed_by,
        transaction_time,
        cage_id,
        notes: `${c.quantity} Quantity of ${c.denomination} Denomination added to Cage ${cage_id}`,
        gaming_day_id: gamingDayId,
      });
    });
  }

  if (vaultTransactions.length > 0) {
    await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(vaultTransactions),
    });
  }

  // Fetch updated cage & vault and return
  const [updatedCageResp, updatedVaultResp] = await Promise.all([
    fetch(`${API_BASE_URL}/api/cage/${cage_id}`),
    fetch(`${API_BASE_URL}/api/vault-balance/1`),
  ]);
  const updatedCage = await updatedCageResp.json();
  const updatedVault = await updatedVaultResp.json();

  return { cage: updatedCage, vault: updatedVault, reference_id: reference };
}
