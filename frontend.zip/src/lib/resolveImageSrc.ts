import { API_BASE_URL } from "@/config/api";

// resolveImageSrc: Accepts data URIs, absolute URLs, or API-relative paths and returns a usable src string
export const resolveImageSrc = (path?: string | null) => {
  if (!path) return "";
  const trimmed = path.trim();
  if (
    trimmed.startsWith("data:") ||
    trimmed.startsWith("http://") ||
    trimmed.startsWith("https://")
  )
    return trimmed;
  return `${API_BASE_URL}${trimmed.startsWith("/") ? "" : "/"}${trimmed}`;
};

export default resolveImageSrc;
