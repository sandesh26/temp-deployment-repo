import { API_BASE_URL } from "@/config/api";

export async function getUser(userId: string) {
  const res = await fetch(`${API_BASE_URL}/api/user/${userId}`);
  if (!res.ok) throw new Error("getUser failed");
  return res.json();
}

export async function getPermissions(roleName: string) {
  const res = await fetch(
    `${API_BASE_URL}/api/user-permissions?role_name=${encodeURIComponent(roleName)}`
  );
  if (!res.ok) throw new Error("getPermissions failed");
  const data = await res.json();
  if (Array.isArray(data)) return data;
  return data.permissions ?? [];
}
