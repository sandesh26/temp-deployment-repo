import { useSidebar } from "@/context/SidebarContext";
import { useAuth } from "@/context/AuthContext";
import React from "react";

const Backdrop: React.FC = () => {
  const { isMobileOpen, toggleMobileSidebar } = useSidebar();
  const { session } = useAuth();

  // If the logged-in user is exactly 'Cage_Executive', do not render backdrop
  const userRole = session?.role ?? null;
  if (userRole === 'Cage_Executive') return null;

  if (!isMobileOpen) return null;

  return (
    <div
      className="fixed inset-0 z-40 bg-gray-900/50 lg:hidden"
      onClick={toggleMobileSidebar}
    />
  );
};

export default Backdrop;
