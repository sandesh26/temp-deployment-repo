"use client";
import React, { useEffect, useRef, useState,useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useSidebar } from "../context/SidebarContext";
import {
  BoxCubeIcon,
  CalenderIcon,
  ChevronDownIcon,
  GridIcon,
  HorizontaLDots,
  ListIcon,
  PageIcon,
  PieChartIcon,
  PlugInIcon,
  TableIcon,
  UserCircleIcon,
  DollarLineIcon,
  UserIcon,
  GroupIcon,
  CustomerIcon,
  NotificationIcon,
  MoneyIcon,
  VaultIcon,
  MachineIcon,
  CageIcon,
  SlotMachineIcon,
  DashboardIcon,
  EmployeeIcon,
  TransactionIcon,
  ReceptionIcon,
  CasinoTableIcon,
  SettingsIcon
} from "../icons/index";
import SidebarWidget from "./SidebarWidget";
import { useAuth } from "@/context/AuthContext";
import { API_BASE_URL } from '@/config/api';

type NavItem = {
  name: string;
  icon?: React.ReactNode;
  path?: string;
  pro?: boolean;
  new?: boolean;
  subItems?: NavItem[];
  permission?: string;
};

type MenuSection = {
  title: string;
  items: NavItem[];
};

const menuSections: MenuSection[] = [
  {
    title: "Operations",
    items: [
      {
        icon: <DashboardIcon />,
        name: "Dashboard",
        permission: "view_dashboard",
        path: "/",
      },
      {
        icon: <ReceptionIcon />,
        name: "Reception",
        path: "/reception",
        permission: "view_reception",
      },
      // {
      //   name: "Chips Management",
      //   icon: <MoneyIcon />,
      //   path: "/chips-management",
      // },
      {
        name: "Vault Management",
        icon: <VaultIcon />,
        path: "/vault",
        permission: "view_vault",
      },
      {
        name: "Employees",
        icon: <EmployeeIcon />,
        path: "/employee-table",
        permission: "view_employees",
      },
      {
        name: "Players",
        icon: <CustomerIcon />,
        path: "/player-table",
        permission: "view_players",
      },
    ]
  },
  {
    title: "Configuration",
    items: [
      {
        name: "Casino Cages",
        icon: <CageIcon />,
        permission: "view_cages",
        subItems: [
          // {
          //   name: "First Floor",
          //   icon: <CageIcon />,
          //   path: "/cages/floor/1",
          //   permission: "view_cages",
          // },
          // {
          //   name: "Second Floor",
          //   icon: <CageIcon />,
          //   path: "/cages/floor/2",
          //   permission: "view_cages",
          // }
        ],
      },
      {
        name: "Slot Machines",
        icon: <SlotMachineIcon />,
        permission: "view_slot_machines",
        subItems: [
          { name: "Live", path: "/slot-machines?machine_status=Live", permission: "view_slot_machines" },
          { name: "Offline", path: "/slot-machines?machine_status=Inactive", permission: "view_slot_machines" },
          { name: "Maintenance", path: "/slot-machines?machine_status=Under_Maintenance", permission: "view_slot_machines" },
        ],
      },
      {
        name: "Casino Tables",
        icon: <CasinoTableIcon />,
        permission: "view_tables",
        subItems: [
          // {
          //   name: "First Floor",
          //   icon: <CasinoTableIcon />,
          //   path: "/tables/floor/1",
          //   permission: "view_tables",
          // },
          // {
          //   name: "Second Floor",
          //   icon: <CasinoTableIcon />,
          //   path: "/tables/floor/2",
          //   permission: "view_tables",
          // }
        ],
      },
      {
        name: "Casino Configuration",
        icon: <SettingsIcon />,
        path: "/casino-configuration",
        permission: "view_config",
      },
    ]
  },
  {
    title: "Administration",
    items: [
      {
        name: "User Management",
        icon: <UserIcon />,
        permission: "manage_users",
        subItems: [
          { name: "Cage", path: "/user-management?department=cage", permission: "manage_users" },
          { name: "Slots", path: "/user-management?department=slot", permission: "manage_users" },
          { name: "Reception", path: "/user-management?department=reception", permission: "manage_users" },
          { name: "Gaming", path: "/user-management?department=gaming", permission: "manage_users" },
          { name: "Admin", path: "/user-management?department=admin", permission: "manage_users" },
        ],
      },
      {
        name: "Notifications",
        icon: <NotificationIcon />,
        path: "/notification-table",
        permission: "view_notifications",
      },
      {
        name: "Transactions",
        icon: <TransactionIcon />,
        path: "/transaction-table",
        permission: "view_transactions",
      },
    ]
  }
];

const AppSidebar: React.FC = () => {
  const { isExpanded, isMobileOpen, isHovered, setIsHovered } = useSidebar();
  const pathname = usePathname();
  const router = useRouter();

  
  // Map UI menu names to permission module_name values returned by the permissions API.
  // Special cases where the displayed name doesn't match the backend module_name.
  const MODULE_NAME_MAP: Record<string, string> = {
    "Casino Cages": "Cages",
    "Casino Tables": "Tables",
    "Vault Management": "Vault",
    // add more mappings here if backend module_name differs from UI label
  };

  const getModuleName = (displayName?: string): string => {
    if (!displayName) return "";
    return MODULE_NAME_MAP[displayName] ?? displayName;
  };

  // Normalize names for comparison: lowercase, remove spaces, underscores and hyphens
  const normalizeName = (s?: string) => (s || "").toString().toLowerCase().replace(/[_\s-]+/g, "");

  const { hasPermission, session } = useAuth();

  // dynamic floors for Casino Tables (fetched from /api/table/)
  const [tableFloors, setTableFloors] = useState<number[] | null>(null);
  useEffect(() => {
    let mounted = true;
    // use canonical endpoint without trailing slash
    fetch(`${API_BASE_URL}/api/table`)
      .then((res) => {
        if (!res.ok) throw new Error('failed');
        return res.json();
      })
      .then((data) => {
        if (!mounted) return;
        if (!Array.isArray(data)) {
          console.debug('AppSidebar: /api/table returned non-array', data);
          setTableFloors([1]);
          return;
        }
        const floors = Array.from(
          new Set(
            data
              .map((t: any) => Number(t.floor_id))
              .filter((n: number) => Number.isFinite(n) && n > 0)
          )
        ).sort((a: number, b: number) => a - b);
        console.debug('AppSidebar: table floors extracted', floors, 'raw:', data.slice(0,5));
        if (floors.length === 0) setTableFloors([1]);
        else setTableFloors(floors);
      })
      .catch(() => {
        if (!mounted) return;
        console.debug('AppSidebar: /api/table fetch failed');
        setTableFloors([1]);
      });
    return () => {
      mounted = false;
    };
  }, []);

  // dynamic floors for Casino Cages (fetched from /api/cage)
  const [cageFloors, setCageFloors] = useState<number[] | null>(null);
  useEffect(() => {
    let mounted = true;
    fetch(`${API_BASE_URL}/api/cage`)
      .then((res) => {
        if (!res.ok) throw new Error('failed');
        return res.json();
      })
      .then((data) => {
        if (!mounted) return;
        if (!Array.isArray(data)) {
          console.debug('AppSidebar: /api/cage returned non-array', data);
          setCageFloors([1]);
          return;
        }
        const floors = Array.from(
          new Set(
            data
              .map((t: any) => Number(t.floor_id))
              .filter((n: number) => Number.isFinite(n) && n > 0)
          )
        ).sort((a: number, b: number) => a - b);
        console.debug('AppSidebar: cage floors extracted', floors, 'raw:', data.slice(0,5));
        if (floors.length === 0) setCageFloors([1]);
        else setCageFloors(floors);
      })
      .catch(() => {
        if (!mounted) return;
        console.debug('AppSidebar: /api/cage fetch failed');
        setCageFloors([1]);
      });
    return () => {
      mounted = false;
    };
  }, []);

  // Build a derived menuSections with dynamic Casino Tables subItems
  const builtMenuSections = React.useMemo(() => {
    // prepare dynamic subitems for Casino Tables
    const dynamicTableSubItems = (tableFloors && tableFloors.length > 0)
      ? tableFloors.map((floorId) => ({
          name: `Floor ${floorId}`,
          icon: <CasinoTableIcon />,
          path: `/tables/floor/${floorId}`,
          permission: 'view_tables',
        }))
      : [
          { name: 'First Floor', icon: <CasinoTableIcon />, path: '/tables/floor/1', permission: 'view_tables' }
        ];

    // prepare dynamic subitems for Casino Cages
    const dynamicCageSubItems = (cageFloors && cageFloors.length > 0)
      ? cageFloors.map((floorId) => ({
          name: `Floor ${floorId}`,
          icon: <CageIcon />,
          path: `/cages/floor/${floorId}`,
          permission: 'view_cages',
        }))
      : [
          { name: 'First Floor', icon: <CageIcon />, path: '/cages/floor/1', permission: 'view_cages' }
        ];

    return menuSections.map((section) => ({
      ...section,
      items: section.items.map((it) => {
        if (it.name === 'Casino Tables') {
          return { ...it, subItems: dynamicTableSubItems };
        }
        if (it.name === 'Casino Cages') {
          return { ...it, subItems: dynamicCageSubItems };
        }
        return it;
      }),
    }));
  }, [tableFloors, cageFloors]);

  // build a fast lookup set of normalized permission names
  const normalizedPerms = new Set<string>((session?.permissions || []).map((p) => normalizeName(p)));

  const visibleSections = builtMenuSections
    .map((section) => {
      const items = section.items
        .map((it) => {
          // derive the module_name/key we should check permissions against
          const parentModule = getModuleName(it.name);
          const normalizedParent = normalizeName(parentModule);

          // if an explicit permission key is provided on the menu item, prefer that.
          const requiredParentPermission = it.permission ? normalizeName(it.permission) : normalizedParent;
          const hasParentPerm = normalizedPerms.has(requiredParentPermission) || normalizedPerms.has(normalizedParent);

          // for subItems, only keep those where normalized permissions include either the parent module
          // (common case like "Cages") or the specific subItem module name if mapped
          if (it.subItems) {
            const subItems = it.subItems.filter((s) => {
              if (!session) return false;
              const subModule = getModuleName(s.name);
              const normalizedSub = normalizeName(subModule);
              const requiredSubPermission = s.permission ? normalizeName(s.permission) : normalizedSub;
              return hasParentPerm || normalizedPerms.has(requiredSubPermission) || normalizedPerms.has(normalizedSub);
            });
            // Special-case: require explicit parent permission for User Management menu
            if (it.name === 'User Management') {
              if (!hasParentPerm) return null;
            } else {
              // If parent item itself doesn't have access AND no visible subitems, hide it
              if (it.name && session && !hasParentPerm && subItems.length === 0) return null;
            }
            return { ...it, subItems };
          }

          // Non-subItem: check permission against mapped module name (normalized) or explicit permission
          if (it.name && session) {
            const required = it.permission ? normalizeName(it.permission) : normalizedParent;
            if (!(normalizedPerms.has(required) || normalizedPerms.has(normalizedParent))) return null;
          }
          return it;
        })
        .filter(Boolean) as NavItem[];

      return { ...section, items };
    })
    .filter((s) => s.items && s.items.length > 0);

  // If user lands on root ("/") but doesn't have Dashboard permission, redirect
  // them to the first available menu path from visibleSections.
  useEffect(() => {
    if (!session) return;
    if (!pathname) return;
    // only redirect when user is on the root path
    if (pathname !== "/") return;

    const dashboardVisible = visibleSections.some((sec) =>
      sec.items.some((it) => it.name === "Dashboard")
    );

    if (!dashboardVisible && visibleSections.length > 0) {
      // find the first path
      let firstPath: string | undefined;
      outer: for (const sec of visibleSections) {
        for (const it of sec.items) {
          if (it.path) {
            firstPath = it.path;
            break outer;
          }
          if (it.subItems && it.subItems.length) {
            for (const s of it.subItems) {
              if (s.path) {
                firstPath = s.path;
                break outer;
              }
            }
          }
        }
      }
      if (firstPath && firstPath !== pathname) {
        router.replace(firstPath);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, pathname, visibleSections]);

  const renderMenuSections = () => {
    return (
      <div className="flex flex-col gap-6">
        {visibleSections.map((section, sectionIndex) => (
          <div key={section.title}>
            {(isExpanded || isHovered || isMobileOpen) && (
              <h2 className="mb-3 text-xs uppercase text-gray-400 font-semibold tracking-wider">
                {section.title}
              </h2>
            )}
            <ul className="flex flex-col gap-2">
              {section.items.map((nav, index) => {
                const itemKey = `${sectionIndex}-${index}`;
                return (
                  <li key={nav.name}>
                    {nav.subItems ? (
                      <button
                        onClick={() => handleSubmenuToggle(itemKey)}
                        className={`menu-item group w-full ${
                          openSubmenu === itemKey
                            ? "menu-item-active"
                            : "menu-item-inactive"
                        } cursor-pointer ${
                          !isExpanded && !isHovered
                            ? "lg:justify-center"
                            : "lg:justify-start"
                        }`}
                      >
                        <span
                          className={`${
                            openSubmenu === itemKey
                              ? "menu-item-icon-active"
                              : "menu-item-icon-inactive"
                          }`}
                        >
                          {nav.icon}
                        </span>
                        {(isExpanded || isHovered || isMobileOpen) && (
                          <span className="menu-item-text">{nav.name}</span>
                        )}
                        {(isExpanded || isHovered || isMobileOpen) && (
                          <ChevronDownIcon
                            className={`ml-auto w-5 h-5 transition-transform duration-200 ${
                              openSubmenu === itemKey
                                ? "rotate-180 text-brand-500"
                                : ""
                            }`}
                          />
                        )}
                      </button>
                    ) : (
                      nav.path && (
                        <Link
                          href={nav.path}
                          className={`menu-item group ${
                            isActive(nav.path) ? "menu-item-active" : "menu-item-inactive"
                          }`}
                        >
                          <span
                            className={`${
                              isActive(nav.path)
                                ? "menu-item-icon-active"
                                : "menu-item-icon-inactive"
                            }`}
                          >
                            {nav.icon}
                          </span>
                          {(isExpanded || isHovered || isMobileOpen) && (
                            <span className="menu-item-text">{nav.name}</span>
                          )}
                        </Link>
                      )
                    )}
                    {nav.subItems && (isExpanded || isHovered || isMobileOpen) && (
                      <div
                        ref={(el) => {
                          subMenuRefs.current[itemKey] = el;
                        }}
                        className="overflow-hidden transition-all duration-300"
                        style={{
                          height: openSubmenu === itemKey ? "auto" : "0px",
                        }}
                      >
                        <ul className="mt-2 space-y-1 ml-9">
                          {nav.subItems.map((subItem) => (
                            <li key={subItem.name}>
                              {subItem.path && (
                                <Link
                                  href={subItem.path}
                                  className={`menu-dropdown-item ${
                                    isActive(subItem.path)
                                      ? "menu-dropdown-item-active"
                                      : "menu-dropdown-item-inactive"
                                  }`}
                                  scroll={false}
                                  onClick={e => {
                                    e.preventDefault();
                                    if (typeof subItem.path === 'string') {
                                      router.push(subItem.path);
                                    } else {
                                      // fallback: do nothing or handle error
                                    }
                                    fetch(`${API_BASE_URL}/api/slotmachine?machine_status=${encodeURIComponent(subItem.name === 'Live' ? 'Active' : subItem.name === 'Offline' ? 'Inactive' : 'Under_Maintenance')}`)
                                      .then(res => res.json())
                                      .then(data => {
                                        // handle slot machine data here if needed
                                      });
                                  }}
                                >
                                  {subItem.name}
                                </Link>
                              )}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    );
  };

  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const [subMenuHeight, setSubMenuHeight] = useState<Record<string, number>>(
    {}
  );
  const [openSecondLevel, setOpenSecondLevel] = useState<Record<string, boolean>>({});
  const subMenuRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // const isActive = (path: string) => path === pathname;
   const isActive = useCallback((path?: string) => path === pathname, [pathname]);

  useEffect(() => {
    // Check if the current path matches any submenu item
    let submenuMatched = false;
    builtMenuSections.forEach((section, sectionIndex) => {
      section.items.forEach((nav, index) => {
        if (nav.subItems) {
          nav.subItems.forEach((subItem) => {
            if (isActive(subItem.path)) {
              setOpenSubmenu(`${sectionIndex}-${index}`);
              submenuMatched = true;
            }
          });
        }
      });
    });

    // If no submenu item matches, close the open submenu
    if (!submenuMatched) {
      setOpenSubmenu(null);
    }
  }, [pathname, isActive]);

  useEffect(() => {
    // Set the height of the submenu items when the submenu is opened
    if (openSubmenu !== null) {
      const key = openSubmenu;
      if (subMenuRefs.current[key]) {
        setSubMenuHeight((prevHeights) => ({
          ...prevHeights,
          [key]: subMenuRefs.current[key]?.scrollHeight || 0,
        }));
      }
    }
  }, [openSubmenu]);

  const handleSubmenuToggle = (itemKey: string) => {
    setOpenSubmenu((prevOpenSubmenu) => {
      if (prevOpenSubmenu === itemKey) {
        return null;
      }
      return itemKey;
    });
  };

  return (
    <aside
      className={`fixed mt-16 flex flex-col lg:mt-0 top-0 px-5 left-0 bg-white dark:bg-gray-900 dark:border-gray-800 text-gray-900 h-screen transition-all duration-300 ease-in-out z-50 border-r border-gray-200 
        ${
          isExpanded || isMobileOpen
            ? "w-[290px]"
            : isHovered
            ? "w-[290px]"
            : "w-[90px]"
        }
        ${isMobileOpen ? "translate-x-0" : "-translate-x-full"}
        lg:translate-x-0`}
      onMouseEnter={() => !isExpanded && setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`py-8 flex  ${
          !isExpanded && !isHovered ? "lg:justify-center" : "justify-start"
        }`}
      >
        <Link href="/">
          {isExpanded || isHovered || isMobileOpen ? (
            <>
              <Image
                className="dark:hidden"
                src="/images/logo/gamexpro_logo_latest.png"
                alt="Logo"
                width={220}
                height={60}
                
              />
              <Image
                className="hidden dark:block"
                src="/images/logo/logo-dark.svg"
                alt="Logo"
                width={150}
                height={40}
              />
            </>
          ) : (
            <Image
              src="/images/logo/gamexpro_logo_symbol.png"
              alt="Logo"
              width={32}
              height={32}
            />
          )}
        </Link>
      </div>
      <div className="flex flex-col overflow-y-auto duration-300 ease-linear no-scrollbar">
        <nav className="mb-6">
          {renderMenuSections()}
        </nav>
        {/* {isExpanded || isHovered || isMobileOpen ? <SidebarWidget /> : null} */}
      </div>
    </aside>
  );
};

export default AppSidebar;
