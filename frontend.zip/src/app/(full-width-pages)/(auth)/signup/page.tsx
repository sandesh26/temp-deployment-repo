import SignUpForm from "@/components/auth/SignUpForm";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Gamexpro Casino Management System",
  description: "This is Next.js Casino Management Dashboard",
};

export default function SignUp() {
  return <SignUpForm />;
}
