
"use client";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { getUser } from "@/lib/api";
import { API_BASE_URL } from '@/config/api';

// Component to display MAC address (best effort, uses public IP API as browser cannot access MAC directly)
function MacAddressField() {
  const [mac, setMac] = useState("Fetching...");
  useEffect(() => {
    //fetch(`${API_BASE_URL}/api/system-macaddress`)
    fetch('http://localhost:45673/device-info')
      .then(async res => {
        if (!res.ok) {
          setMac("Not available");
          return;
        }
        try {
          const data = await res.json();
          if (data.mac) setMac(data.mac.toUpperCase());
          else if (data.ip) setMac(`IP: ${data.ip}`);
          else setMac("Not available");
        } catch {
          setMac("Not available");
        }
      })
      .catch(() => setMac("Not available"));
  }, []);
  return (
    <div className="sr-only" aria-hidden>
      {/* keep fetching logic available but hidden when using the icon UI */}
      <span>{mac}</span>
    </div>
  );
}

// Icon in the top-right that shows MAC info on click
function MacInfoIcon() {
  const [mac, setMac] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [showDecoded, setShowDecoded] = useState(false);

  useEffect(() => {
    let mounted = true;
    fetch('http://localhost:45673/device-info')
      .then(async res => {
        if (!res.ok) {
          if (!mounted) return;
          setMac('Not available');
          setLoading(false);
          return;
        }
        try {
          const data = await res.json();
          if (!mounted) return;
          if (data.mac) setMac(String(data.mac).toUpperCase());
          else if (data.ip) setMac(`IP: ${data.ip}`);
          else setMac('Not available');
        } catch {
          if (!mounted) return;
          setMac('Not available');
        } finally {
          if (!mounted) return;
          setLoading(false);
        }
      })
      .catch(() => {
        if (!mounted) return;
        setMac('Not available');
        setLoading(false);
      });
    return () => { mounted = false; };
  }, []);

  return (
    <div className="absolute top-4 right-4 z-50">
      <div className="relative">
        <button
          type="button"
          aria-expanded={open}
          aria-controls="mac-info-popover"
          onClick={() => setOpen(v => !v)}
          className="w-8 h-8 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shadow-sm hover:bg-blue-100 focus:outline-none"
          title="Device info"
        >
          <span className="font-semibold">i</span>
        </button>
        {open && (
          <div id="mac-info-popover" role="dialog" aria-label="Device MAC info" className="absolute top-full right-0 mt-2 w-56 bg-white border rounded shadow-lg p-3 text-sm z-50">
            <div className="flex items-start justify-between">
              <div className="text-xs text-gray-500 font-medium">Device</div>
              <button className="text-gray-400 text-xs" onClick={() => setOpen(false)}>Close</button>
            </div>
              <div className="mt-2">
                <div className="text-xs text-gray-500">MAC / Device</div>
                <div
                  className="font-mono text-sm text-gray-800 mt-1 cursor-pointer select-all"
                  title="Triple-click to toggle decoded/encoded value"
                  onClick={(e) => {
                    // Use event.detail to detect triple click (detail === 3)
                    try {
                      if ((e as React.MouseEvent).detail === 5) {
                        setShowDecoded(s => !s);
                      }
                    } catch (err) {
                      // ignore
                    }
                  }}
                  role="button"
                  aria-label="Device MAC encoded value; triple click to toggle decoded"
                >
                  {loading
                    ? 'Fetching...'
                    : (() => {
                        const raw = mac ?? '';
                        let encoded = 'Not available';
                        try {
                          encoded = raw ? btoa(raw) : 'Not available';
                        } catch (e) {
                          encoded = raw ? raw : 'Not available';
                        }
                        if (showDecoded) {
                          return raw || 'Not available';
                        }
                        return encoded || 'Not available';
                      })()
                  }
                </div>
              </div>
            <div className="mt-3">
              <div className="text-xs text-gray-500 font-medium">Downloads</div>
              <ul className="mt-2 space-y-2 text-sm">
                <li>
                  <a href="/device-tools/device-helper-macos" download className="text-blue-600 hover:underline">
                    MacOS Helper
                  </a>
                </li>
                <li>
                  <a href="/device-tools/device-helper-linux" download className="text-blue-600 hover:underline">
                    Linux Helper
                  </a>
                </li>
                <li>
                  <a href="/device-tools/device-helper-win.exe" download className="text-blue-600 hover:underline">
                    Windows Helper
                  </a>
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const DEMO_ROLES = [
  "Admin",
  "Super_Admin",
  "Casino_Manager",
  "Reception_Executive",
  "Reception_Sr_Executive",
  "Reception_Supervisor",
  "Cage_Executive",
  "Cage_Supervisor",
  "Cage_Manager",
  "Slot_Executive",
  "Slot_Supervisor",
  "Slot_Manager",
  "Pit_Supervisor",
  "Inspector",
  "Technical_Executive",
  "Dealer",
];

const DEFAULT_DEMO_USER_MAP: Record<string, string> = {
  Reception_Executive: "9",
  Reception_Sr_Executive: "22",
  Reception_Supervisor: "20",
  Cage_Executive: "7",
  Cage_Supervisor: "2",
  Cage_Manager: "4",
  Slot_Executive: "15",
  Slot_Supervisor: "8",
  Slot_Manager: "25",
  Pit_Supervisor: "21",
  Inspector: "18",
  Casino_Manager: "12",
  Admin: "3",
  Super_Admin: "14",
  Technical_Executive: "5",
  Dealer: "13",
};

// localStorage key to persist editable mappings
const DEMO_ROLE_MAPPINGS_KEY = "demo_role_mappings";

export default function LoginPage() {
  const { loginAs, loading } = useAuth();
  // creative animated background will be rendered below (no external background selector)
  const [operation, setOperation] = useState<'Demo'|'Live'>('Demo');
  const [selectedRole, setSelectedRole] = useState<string>(DEMO_ROLES[0]);
  const [userIdOrEmail, setUserIdOrEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [mappings, setMappings] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem(DEMO_ROLE_MAPPINGS_KEY);
      return raw ? JSON.parse(raw) : DEFAULT_DEMO_USER_MAP;
    } catch (e) {
      return DEFAULT_DEMO_USER_MAP;
    }
  });
  const [editingMappings, setEditingMappings] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const router = useRouter();

  // Helper: fetch device MAC (best-effort) from local device-info service
  // Polls the device-info endpoint until a value is available or timeout is reached.
  // By default it polls every 1s and times out after 30s to avoid hanging the login flow.
  const getDeviceMac = async (opts?: { retryIntervalMs?: number; timeoutMs?: number }): Promise<string | null> => {
    const retryIntervalMs = opts?.retryIntervalMs ?? 1000;
    const timeoutMs = opts?.timeoutMs ?? 30000;
    const start = Date.now();

    const tryOnce = async (): Promise<string | null> => {
      try {
        const res = await fetch('http://localhost:45673/device-info');
        if (!res.ok) return null;
        const data = await res.json();
        if (!data) return null;
        if (data.mac) return String(data.mac).toUpperCase();
        if (data.ip) return String(data.ip);
        return null;
      } catch (e) {
        return null;
      }
    };

    // Poll until we get a value or timeout
    while (true) {
      const val = await tryOnce();
      if (val) return val;
      if (timeoutMs && Date.now() - start > timeoutMs) return null;
      // wait before retrying
      await new Promise((r) => setTimeout(r, retryIntervalMs));
    }
  };

  // Helper: call backend cage lookup by macaddress and normalize response
  const fetchCagesByMac = async (mac: string): Promise<any[] | null> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/cage?macaddress=${mac}`);
      if (response.ok) {
        const cages = await response.json();
        return Array.isArray(cages) ? cages : [cages];
      } else {
        console.error('Failed', response.status, await response.text());
        return null;
      }
    } catch (e) {
      return null;
    }
  };

  // If the user is a Cage_Executive, attempt to resolve device MAC -> cage, and redirect.
  // Returns true if a redirect was performed.
  const redirectIfCageExecutive = async (role: string | null): Promise<boolean> => {
    if (!role) return false;
    if (role !== 'Cage_Executive') return false;
    const mac = await getDeviceMac();
    if (!mac) return false;
    const cages = await fetchCagesByMac(mac);
    if (!cages || cages.length === 0) return false;
    const first = cages[0];
    const cageId = first?.id ?? first?.cage_id ?? first?.cageId ?? null;
    if (!cageId) return false;
    // redirect to the single cage view for the operator device
    router.replace(`/cage/${cageId}`);
    return true;
  };

  const onSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      if (operation === 'Demo') {
        const mapped = mappings[selectedRole] ?? DEFAULT_DEMO_USER_MAP[selectedRole];
        if (!mapped) {
          setError('No demo user mapping for selected role');
          return;
        }
        // Demo login should not carry a real token
        await loginAs(mapped, selectedRole, null);
        // If a cage operator logs in from the designated device, redirect to their cage
        if (!(await redirectIfCageExecutive(selectedRole))) {
          router.replace('/');
        }
        return;
      }

      // Live mode: require user id/email and password
      if (!userIdOrEmail) {
        setError('Please enter User id');
        return;
      }
      if (!password) {
        setError('Please enter password');
        return;
      }

      // Live mode: call the auth login endpoint with username + password
      // Hash the password client-side (SHA-256 hex) before sending to the API.
      const sha256Hex = async (input: string) => {
        try {
          const enc = new TextEncoder();
          const data = enc.encode(input);
          const hashBuffer = await crypto.subtle.digest('SHA-256', data);
          const hashArray = Array.from(new Uint8Array(hashBuffer));
          return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        } catch (err) {
          // fallback to sending plain password if Web Crypto is unavailable
          return input;
        }
      };

      const hashedPassword = await sha256Hex(password);

      const loginRes = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userIdOrEmail, password: hashedPassword }),
      });

      if (!loginRes.ok) {
        const txt = await loginRes.text().catch(() => '');
        throw new Error(`Login failed: ${loginRes.status} ${txt}`);
      }

      const loginData = await loginRes.json();

      // Attempt to extract user id and role from common response shapes
      const extract = (obj: any) => {
        if (!obj) return { id: null, role: null };

        // Example shape handled:
        // { success, token, employee: { employee_id, username, role, access_level, user: { user_id, full_name, ... } }, message }
        if (obj.employee) {
          const emp = obj.employee;
          const userObj = emp.user ?? emp;
          const id = userObj?.user_id ?? userObj?.id ?? userObj?.userId ?? emp?.user_id ?? emp?.id ?? null;
          const role = emp?.role ?? userObj?.role ?? obj?.role ?? obj?.role_name ?? null;
          return { id, role };
        }

        const maybeUser = obj.user ?? obj.data ?? obj;
        const id = maybeUser?.id ?? maybeUser?.user_id ?? maybeUser?.userId ?? obj?.id ?? obj?.user_id ?? obj?.userId ?? null;
        const role = maybeUser?.role ?? obj?.role ?? obj?.role_name ?? maybeUser?.role_name ?? null;
        return { id, role };
      };

      const { id: returnedId, role: returnedRole } = extract(loginData);

      if (returnedId && returnedRole) {
        // pass through token from login response so AuthProvider can persist and use it
        await loginAs(String(returnedId), returnedRole, loginData?.token ?? null);
        if (!(await redirectIfCageExecutive(returnedRole))) {
          router.replace('/');
        }
        return;
      }

      // Fallback: fetch user details by identifier (id or email) and continue
      const user = await getUser(userIdOrEmail);
      const roleFromUser = user?.role || user?.role_name || user?.roleName;
      if (!roleFromUser) {
        setError('User role not available from user details');
        return;
      }
  await loginAs(String(user.id ?? userIdOrEmail), roleFromUser, null);
      if (!(await redirectIfCageExecutive(roleFromUser))) {
        router.replace('/');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative bg-gradient-to-b from-[#050816] via-[#071030] to-[#0b1220] overflow-hidden">
      {/* Decorative animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -left-40 -top-40 w-[520px] h-[520px] rounded-full bg-gradient-to-br from-[#7c3aed]/20 to-[#06b6d4]/10 blur-3xl animate-blob" />
        <div className="absolute -right-28 -bottom-28 w-[420px] h-[420px] rounded-full bg-gradient-to-br from-[#ef4444]/10 to-[#f59e0b]/10 blur-2xl animate-blob animation-delay-2000" />
      </div>
      <div className="w-full max-w-md">
        <MacInfoIcon />
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl p-8">
          <div className="flex flex-col items-center gap-4">
            <img src="/images/logo/gamexpro_logo_latest.png" alt="logo" className="w-90 h-20" />
            <h1 className="text-2xl font-bold">Login</h1>
            <p className="text-sm text-gray-500">Sign in to continue</p>
            {/* Mac info moved to top-right info icon */}
          </div>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            {/* Decorative background selection removed - using animated background */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Operation Type</label>
              <select
                value={operation}
                onChange={(e) => setOperation(e.target.value as 'Demo'|'Live')}
                className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
              >
                <option value="Demo">Demo</option>
                <option value="Live">Live</option>
              </select>
            </div>

            {operation === 'Demo' ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Role (Demo)</label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                >
                  {DEMO_ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-gray-400">Demo user id mapped: <span className="font-medium">{mappings[selectedRole] ?? DEFAULT_DEMO_USER_MAP[selectedRole]}</span></p>

                {/* Editable mappings UI */}
                <div className="mt-3">
                  <button
                    type="button"
                    onClick={() => { setEditingMappings((s) => !s); setSaveMessage(null); }}
                    className="text-xs text-amber-500 hover:underline"
                  >
                    {editingMappings ? 'Close mapping editor' : 'Edit demo role mappings'}
                  </button>
                  {editingMappings && (
                    <div className="mt-3 bg-gray-50 dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-500 mb-2">Update the user id that will be used for each demo role. Saved to your browser (localStorage).</p>
                      <div className="space-y-2 max-h-40 overflow-auto pr-2">
                        {DEMO_ROLES.map((role) => (
                          <div key={role} className="flex items-center gap-2">
                            <label className="text-xs w-40 truncate">{role.replace(/_/g, ' ')}</label>
                            <input
                              className="flex-1 px-2 py-1 text-sm rounded border bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700"
                              value={mappings[role] ?? DEFAULT_DEMO_USER_MAP[role] ?? ''}
                              onChange={(e) => setMappings((m) => ({ ...m, [role]: e.target.value }))}
                            />
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              localStorage.setItem(DEMO_ROLE_MAPPINGS_KEY, JSON.stringify(mappings));
                              setSaveMessage('Mappings saved');
                            } catch (e: any) {
                              setSaveMessage('Failed to save mappings');
                            }
                          }}
                          className="px-3 py-1 bg-amber-500 text-white rounded text-sm"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setMappings(DEFAULT_DEMO_USER_MAP);
                            try {
                              localStorage.removeItem(DEMO_ROLE_MAPPINGS_KEY);
                              setSaveMessage('Reset to defaults');
                            } catch (e) {
                              setSaveMessage('Reset locally');
                            }
                          }}
                          className="px-3 py-1 bg-gray-200 dark:bg-gray-700 text-sm rounded"
                        >
                          Reset
                        </button>
                        {saveMessage && <div className="text-xs text-green-500 ml-2">{saveMessage}</div>}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">User ID</label>
                  <input
                    value={userIdOrEmail}
                    onChange={(e) => setUserIdOrEmail(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    placeholder="Enter User ID"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    placeholder="Enter Password"
                  />
                  <p className="mt-2 text-xs text-gray-400">(Password is currently unused for demo — will be enabled when auth endpoint is available | Default Password : <b>casino@123</b>)</p>
                </div>
              </>
            )}

            {error && <div className="text-red-600 text-sm">{error}</div>}

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading || isSubmitting}
                className="w-full inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-md shadow disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {(loading || isSubmitting) ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    Signing in...
                  </>
                ) : (
                  'Login'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
