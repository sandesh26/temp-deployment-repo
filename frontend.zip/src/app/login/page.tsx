
"use client";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { getUser } from "@/lib/api";
import { API_BASE_URL } from '@/config/api';

// Component to display MAC address (best effort, uses public IP API as browser cannot access MAC directly)
function MacAddressField() {
  const [mac, setMac] = useState("Fetching...");
  useEffect(() => {
    fetch(`${API_BASE_URL}/api/system-macaddress`)
      .then(async res => {
        if (!res.ok) {
          setMac("Not available");
          return;
        }
        try {
          const data = await res.json();
          if (data.mac) setMac(data.mac.toUpperCase());
          else if (data.ip) setMac(`IP: ${data.ip}`);
          else setMac("Not available");
        } catch {
          setMac("Not available");
        }
      })
      .catch(() => setMac("Not available"));
  }, []);
  return (
    <div className="flex items-center gap-2 mt-2 px-3 py-2 rounded-lg bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 shadow-sm">
      <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <rect x="3" y="7" width="18" height="10" rx="2" stroke="currentColor" strokeWidth="2" fill="none" />
        <circle cx="7" cy="12" r="1.5" fill="currentColor" />
        <circle cx="17" cy="12" r="1.5" fill="currentColor" />
      </svg>
      <span className="text-xs text-blue-700 font-semibold tracking-wider">Machine MAC:</span>
      <span className="font-mono text-xs text-blue-900 bg-blue-100 px-2 py-0.5 rounded select-all">{mac}</span>
    </div>
  );
}

const DEMO_ROLES = [
  "Admin",
  "Super_Admin",
  "Casino_Manager",
  "Reception_Executive",
  "Reception_Sr_Executive",
  "Reception_Supervisor",
  "Cage_Executive",
  "Cage_Supervisor",
  "Cage_Manager",
  "Slot_Executive",
  "Slot_Supervisor",
  "Slot_Manager",
  "Pit_Supervisor",
  "Inspector",
  "Technical_Executive",
  "Dealer",
];

const DEFAULT_DEMO_USER_MAP: Record<string, string> = {
  Reception_Executive: "9",
  Reception_Sr_Executive: "22",
  Reception_Supervisor: "20",
  Cage_Executive: "7",
  Cage_Supervisor: "2",
  Cage_Manager: "4",
  Slot_Executive: "15",
  Slot_Supervisor: "8",
  Slot_Manager: "25",
  Pit_Supervisor: "21",
  Inspector: "18",
  Casino_Manager: "12",
  Admin: "3",
  Super_Admin: "14",
  Technical_Executive: "5",
  Dealer: "13",
};

// localStorage key to persist editable mappings
const DEMO_ROLE_MAPPINGS_KEY = "demo_role_mappings";

export default function LoginPage() {
  const { loginAs, loading } = useAuth();
  // creative animated background will be rendered below (no external background selector)
  const [operation, setOperation] = useState<'Demo'|'Live'>('Demo');
  const [selectedRole, setSelectedRole] = useState<string>(DEMO_ROLES[0]);
  const [userIdOrEmail, setUserIdOrEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [mappings, setMappings] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem(DEMO_ROLE_MAPPINGS_KEY);
      return raw ? JSON.parse(raw) : DEFAULT_DEMO_USER_MAP;
    } catch (e) {
      return DEFAULT_DEMO_USER_MAP;
    }
  });
  const [editingMappings, setEditingMappings] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const router = useRouter();

  const onSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      if (operation === 'Demo') {
        const mapped = mappings[selectedRole] ?? DEFAULT_DEMO_USER_MAP[selectedRole];
        if (!mapped) {
          setError('No demo user mapping for selected role');
          return;
        }
        // Demo login should not carry a real token
        await loginAs(mapped, selectedRole, null);
        router.replace('/');
        return;
      }

      // Live mode: require user id/email and password
      if (!userIdOrEmail) {
        setError('Please enter User id or Email');
        return;
      }
      if (!password) {
        setError('Please enter password');
        return;
      }

      // Live mode: call the auth login endpoint with username + password
      const loginRes = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userIdOrEmail, password }),
      });

      if (!loginRes.ok) {
        const txt = await loginRes.text().catch(() => '');
        throw new Error(`Login failed: ${loginRes.status} ${txt}`);
      }

      const loginData = await loginRes.json();

      // Attempt to extract user id and role from common response shapes
      const extract = (obj: any) => {
        if (!obj) return { id: null, role: null };

        // Example shape handled:
        // { success, token, employee: { employee_id, username, role, access_level, user: { user_id, full_name, ... } }, message }
        if (obj.employee) {
          const emp = obj.employee;
          const userObj = emp.user ?? emp;
          const id = userObj?.user_id ?? userObj?.id ?? userObj?.userId ?? emp?.user_id ?? emp?.id ?? null;
          const role = emp?.role ?? userObj?.role ?? obj?.role ?? obj?.role_name ?? null;
          return { id, role };
        }

        const maybeUser = obj.user ?? obj.data ?? obj;
        const id = maybeUser?.id ?? maybeUser?.user_id ?? maybeUser?.userId ?? obj?.id ?? obj?.user_id ?? obj?.userId ?? null;
        const role = maybeUser?.role ?? obj?.role ?? obj?.role_name ?? maybeUser?.role_name ?? null;
        return { id, role };
      };

      const { id: returnedId, role: returnedRole } = extract(loginData);

      if (returnedId && returnedRole) {
        // pass through token from login response so AuthProvider can persist and use it
        await loginAs(String(returnedId), returnedRole, loginData?.token ?? null);
        router.replace('/');
        return;
      }

      // Fallback: fetch user details by identifier (id or email) and continue
      const user = await getUser(userIdOrEmail);
      const roleFromUser = user?.role || user?.role_name || user?.roleName;
      if (!roleFromUser) {
        setError('User role not available from user details');
        return;
      }
  await loginAs(String(user.id ?? userIdOrEmail), roleFromUser, null);
      router.replace('/');
    } catch (err: any) {
      setError(err?.message || 'Login failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative bg-gradient-to-b from-[#050816] via-[#071030] to-[#0b1220] overflow-hidden">
      {/* Decorative animated background elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -left-40 -top-40 w-[520px] h-[520px] rounded-full bg-gradient-to-br from-[#7c3aed]/20 to-[#06b6d4]/10 blur-3xl animate-blob" />
        <div className="absolute -right-28 -bottom-28 w-[420px] h-[420px] rounded-full bg-gradient-to-br from-[#ef4444]/10 to-[#f59e0b]/10 blur-2xl animate-blob animation-delay-2000" />
      </div>
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl p-8">
          <div className="flex flex-col items-center gap-4">
            <img src="/images/logo/gamexpro_logo_latest.png" alt="logo" className="w-90 h-20" />
            <h1 className="text-2xl font-bold">Login</h1>
            <p className="text-sm text-gray-500">Sign in to continue</p>
            <MacAddressField />
          </div>

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            {/* Decorative background selection removed - using animated background */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Operation Type</label>
              <select
                value={operation}
                onChange={(e) => setOperation(e.target.value as 'Demo'|'Live')}
                className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
              >
                <option value="Demo">Demo</option>
                <option value="Live">Live</option>
              </select>
            </div>

            {operation === 'Demo' ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Role (Demo)</label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                >
                  {DEMO_ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <p className="mt-2 text-xs text-gray-400">Demo user id mapped: <span className="font-medium">{mappings[selectedRole] ?? DEFAULT_DEMO_USER_MAP[selectedRole]}</span></p>

                {/* Editable mappings UI */}
                <div className="mt-3">
                  <button
                    type="button"
                    onClick={() => { setEditingMappings((s) => !s); setSaveMessage(null); }}
                    className="text-xs text-amber-500 hover:underline"
                  >
                    {editingMappings ? 'Close mapping editor' : 'Edit demo role mappings'}
                  </button>
                  {editingMappings && (
                    <div className="mt-3 bg-gray-50 dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-500 mb-2">Update the user id that will be used for each demo role. Saved to your browser (localStorage).</p>
                      <div className="space-y-2 max-h-40 overflow-auto pr-2">
                        {DEMO_ROLES.map((role) => (
                          <div key={role} className="flex items-center gap-2">
                            <label className="text-xs w-40 truncate">{role.replace(/_/g, ' ')}</label>
                            <input
                              className="flex-1 px-2 py-1 text-sm rounded border bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-700"
                              value={mappings[role] ?? DEFAULT_DEMO_USER_MAP[role] ?? ''}
                              onChange={(e) => setMappings((m) => ({ ...m, [role]: e.target.value }))}
                            />
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              localStorage.setItem(DEMO_ROLE_MAPPINGS_KEY, JSON.stringify(mappings));
                              setSaveMessage('Mappings saved');
                            } catch (e: any) {
                              setSaveMessage('Failed to save mappings');
                            }
                          }}
                          className="px-3 py-1 bg-amber-500 text-white rounded text-sm"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setMappings(DEFAULT_DEMO_USER_MAP);
                            try {
                              localStorage.removeItem(DEMO_ROLE_MAPPINGS_KEY);
                              setSaveMessage('Reset to defaults');
                            } catch (e) {
                              setSaveMessage('Reset locally');
                            }
                          }}
                          className="px-3 py-1 bg-gray-200 dark:bg-gray-700 text-sm rounded"
                        >
                          Reset
                        </button>
                        {saveMessage && <div className="text-xs text-green-500 ml-2">{saveMessage}</div>}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">User ID or Email</label>
                  <input
                    value={userIdOrEmail}
                    onChange={(e) => setUserIdOrEmail(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    placeholder="Enter user id or email"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    placeholder="Enter password"
                  />
                  <p className="mt-2 text-xs text-gray-400">(Password is currently unused for demo — will be enabled when auth endpoint is available | Default Password : <b>casino@123</b>)</p>
                </div>
              </>
            )}

            {error && <div className="text-red-600 text-sm">{error}</div>}

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading || isSubmitting}
                className="w-full inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-md shadow disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {(loading || isSubmitting) ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    Signing in...
                  </>
                ) : (
                  'Login'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
