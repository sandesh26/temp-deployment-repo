"use client";
import React, { Suspense } from "react";
import SlotMachineDetails from "@/components/common/SlotMachineDetails";
import BackButton from '@/components/common/BackButton';
import PageBreadcrumb from "@/components/common/PageBreadCrumb";

export default function SlotMachine() {
  return (
    <div className="grid grid-cols-12 gap-4 md:gap-4">
      <BackButton />
      <div className="col-span-12">
        <Suspense fallback={<div>Loading...</div>}>
          <SlotMachineDetails />
        </Suspense>
      </div>
    </div>
  );
}