"use client";
import React from "react";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import Vault from "@/components/common/Vault";

export default function VaultPage() {
  return (
    <div>
      <PageBreadcrumb pageTitle="Vault" />
      <div className="space-y-6">
          <Vault />
      </div>
    </div>
  );
}