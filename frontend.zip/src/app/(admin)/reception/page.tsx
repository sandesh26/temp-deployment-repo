"use client";
import React from "react";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import Reception from "@/components/common/Reception";

export default function SlotMachines() {
  return (
    <div>
      <PageBreadcrumb pageTitle="Reception" />
      <div className="space-y-6">
          <Reception />
      </div>
    </div>
  );
}