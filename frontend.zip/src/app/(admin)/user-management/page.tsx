"use client";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import UserManagement from "@/components/common/UserManagement";

import { useSearchParams } from "next/navigation";

export default function BasicTables() {
  const searchParams = useSearchParams();
  const department = searchParams.get("department") || "";
  return (
    <>
      <div>
        <PageBreadcrumb pageTitle="User Management" />
        <div className="space-y-6">
            <UserManagement department={department} />
        </div>
      </div>
    </>
  );
}
