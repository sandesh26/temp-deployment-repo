import type { Metadata } from "next";
import { DashboardMetrics } from "@/components/ecommerce/DashboardMetrics";
import React from "react";
import MonthlyTarget from "@/components/ecommerce/MonthlyTarget";
import MonthlySalesChart from "@/components/ecommerce/MonthlySalesChart";
import StatisticsChart from "@/components/ecommerce/StatisticsChart";
import SlotMachineStatistics from "@/components/ecommerce/SlotMachineStatistics";
// import DemographicCard from "@/components/ecommerce/DemographicCard";

export const metadata: Metadata = {
  title: "Gamexpro Casino Management System",
  description: "This is Next.js Casino Management Dashboard",
};

export default function Ecommerce() {
  return (
    <div className="grid grid-cols-12 gap-4 md:gap-6">
      <div className="col-span-12 space-y-6 xl:col-span-12">
        <DashboardMetrics />
      </div>
      <div className="col-span-12 xl:col-span-6">
        <SlotMachineStatistics />
      </div>
      <div className="col-span-12 space-y-6 xl:col-span-12">
        <MonthlySalesChart />
      </div>

      {/* <div className="col-span-12 xl:col-span-5">
        <MonthlyTarget />
      </div> */}

      {/* <div className="col-span-12 xl:col-span-7">
        <RecentOrders />
      </div> */}

      <div className="col-span-12">
        <StatisticsChart />
      </div>


      {/* <div className="col-span-12 xl:col-span-5">
        <DemographicCard />
      </div> */}
    </div>
  );
}
