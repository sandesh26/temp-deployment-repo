//import ComponentCard from "@/components/common/ComponentCard";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import EmployeeTable from "@/components/tables/EmployeeTable";
import { Metadata } from "next";
import React from "react";

export const metadata: Metadata = {
  title: "Gamexpro Casino Management System",
  description: "This is Next.js Casino Management Dashboard",
};

export default function BasicTables() {
  return (
    <div>
      <PageBreadcrumb pageTitle="Employee List" />
      <div className="space-y-6">
          <EmployeeTable />
      </div>
    </div>
  );
}
