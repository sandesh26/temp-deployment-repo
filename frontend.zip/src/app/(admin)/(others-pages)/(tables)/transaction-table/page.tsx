"use client";

import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import TransactionTable from "@/components/tables/TransactionTable";
import React, { useState } from "react";

export default function BasicTables() {
  const [resourceType, setResourceType] = useState<'CAGE' | 'TABLE' | 'VAULT' | 'GAMES'>('CAGE');
  return (
    <div>
      <div className="flex items-start justify-between">
        <h2
          className="text-xl font-semibold text-gray-800 dark:text-white/90"
          x-text="pageName"
        >
          Transactions List
        </h2>
        <div className="ml-4">
          <label className="text-sm text-gray-500 mr-2">Source:</label>
          <select
            value={resourceType}
            onChange={(e) => setResourceType(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-lg bg-white text-sm"
          >
            <option value="CAGE">CAGE</option>
            <option value="TABLE">TABLE (UD)</option>
            {/* <option value="VAULT">VAULT</option> */}
            <option value="GAMES">GAMES (UD)</option>
          </select>
        </div>
      </div>

      <div className="space-y-6 mt-4">
        {/* <ComponentCard title="Basic Table 1"> */}
          <TransactionTable resourceType={resourceType} />
        {/* </ComponentCard> */}
      </div>
    </div>
  );
}
