"use client";
import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import CageDetails from "@/components/common/CageDetails";

function CagePageContent() {
  const searchParams = useSearchParams();
  const floor = searchParams.get("floor");

  return (
    <div className="grid grid-cols-12 gap-4 md:gap-6">
      <div className="col-span-12">
        <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">
          Cage Details
        </h1>
        <CageDetails floor={floor ?? undefined} />
      </div>
    </div>
  );
}

export default function CagePage() {
  return (
    <Suspense>
      <CagePageContent />
    </Suspense>
  );
}