import CageDetails from "@/components/common/CageDetails";

export default async function CageDetailsPage(props: any) {
  // props.params may be a Promise-like value in Next.js dynamic routes; await it before accessing properties
  const { id, floor } = await props.params;
  return (
    <div className="grid grid-cols-12 gap-4 md:gap-6">
      <div className="col-span-12">
        <CageDetails cageId={id} floor={floor} />
      </div>
    </div>
  );
}