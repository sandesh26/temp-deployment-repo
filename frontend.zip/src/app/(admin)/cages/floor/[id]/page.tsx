"use client";
import React from "react";
import { useParams } from "next/navigation";
import { API_BASE_URL } from "@/config/api";
import CageCards from "@/components/common/CageCards";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";

export default function Cages() {
  const params  = useParams();
  const floorId = params.id;

  return (
    <>
      <PageBreadcrumb pageTitle={`Floor ${floorId} Cages`} />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12">
          {/* <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">
            Floor {floorId} Cages
          </h1> */}
          <CageCards apiUrl={`${API_BASE_URL}/api/cage?floor=${floorId}`} />
        </div>
      </div>
    </>
  );
}