"use client";
import React from "react";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import ChipsManagement from "@/components/common/ChipsManagement";

export default function ChipsManagementPage() {
  return (
    <div>
      <PageBreadcrumb pageTitle="Vault Chips Management" />
      <div className="space-y-6">
          <ChipsManagement />
      </div>
    </div>
  );
}