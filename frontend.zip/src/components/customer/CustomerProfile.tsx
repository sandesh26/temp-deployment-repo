import React from "react";

const mockData = {
  hotPlayers: [
    {
      name: "John Fast",
      avatar: "/avatars/john.png",
      position: 1,
      winLoss: -1683,
      bet: 10687,
      expWinLoss: -552,
      games: 512,
      betPerGame: 20.87,
      currentPoints: 5429,
      points: 2659,
    },
    {
      name: "Carrie-Anne Caine",
      avatar: "/avatars/carrie.png",
      position: 2,
      winLoss: 12676,
      bet: 7780,
      expWinLoss: -402,
      games: 92,
      betPerGame: 84.57,
      currentPoints: 45390,
      points: 1945,
    },
    // ...more players
  ],
  hotLosers: [
    // ...same structure as above
  ],
  hotWinners: [
    // ...same structure as above
  ],
};

const Section = ({
  title,
  color,
  data,
}: {
  title: string;
  color: "red" | "green" | "orange";
  data: typeof mockData.hotPlayers;
}) => {
  const colorMap = {
    red: "bg-red-600",
    green: "bg-green-600",
    orange: "bg-orange-400",
  };
  return (
    <div className="mb-6 bg-white rounded shadow border">
      <div className={`flex items-center px-4 py-2 text-white font-semibold rounded-t ${colorMap[color]}`}>
        <span className="flex-1">{title}</span>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-gray-50">
              <th className="py-2 px-3 text-left font-semibold"> </th>
              <th className="py-2 px-3 text-left font-semibold">Hot Players</th>
              <th className="py-2 px-3 text-left font-semibold">Position</th>
              <th className="py-2 px-3 text-left font-semibold">Win/Loss</th>
              <th className="py-2 px-3 text-left font-semibold">Bet</th>
              <th className="py-2 px-3 text-left font-semibold">Exp. Win/Loss</th>
              <th className="py-2 px-3 text-left font-semibold">Games</th>
              <th className="py-2 px-3 text-left font-semibold">Bet/Game</th>
              <th className="py-2 px-3 text-left font-semibold">Current Points</th>
              <th className="py-2 px-3 text-left font-semibold">Points</th>
              <th className="py-2 px-3 text-left font-semibold"></th>
            </tr>
          </thead>
          <tbody>
            {data.map((player, idx) => (
              <tr key={player.name} className="border-b last:border-b-0">
                <td className="py-2 px-3">
                  <img
                    src={player.avatar}
                    alt={player.name}
                    className="w-8 h-8 rounded-full border-2 border-yellow-400 object-cover"
                  />
                </td>
                <td className="py-2 px-3 font-medium">{player.name}</td>
                <td className="py-2 px-3">{player.position}</td>
                <td className={`py-2 px-3 font-semibold ${player.winLoss < 0 ? "text-red-600" : "text-green-600"}`}>
                  € {player.winLoss.toLocaleString()}
                </td>
                <td className="py-2 px-3">€ {player.bet.toLocaleString()}</td>
                <td className={`py-2 px-3 font-semibold ${player.expWinLoss < 0 ? "text-red-600" : "text-green-600"}`}>
                  € {player.expWinLoss.toLocaleString()}
                </td>
                <td className="py-2 px-3">{player.games}</td>
                <td className="py-2 px-3">€ {player.betPerGame}</td>
                <td className="py-2 px-3">{player.currentPoints.toLocaleString()}</td>
                <td className="py-2 px-3">{player.points.toLocaleString()}</td>
                <td className="py-2 px-3 text-right">
                  <button className="text-gray-400 hover:text-red-600 text-lg font-bold">–</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const CustomerProfile: React.FC = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <Section title="Hot Players" color="orange" data={mockData.hotPlayers} />
        <Section title="Hot Losers" color="red" data={mockData.hotLosers} />
        <Section title="Hot Winners" color="green" data={mockData.hotWinners} />
      </div>
    </div>
  );
};

export default CustomerProfile;