"use client";
import React, { useState, useEffect, useRef } from "react";
import Modal from "../ui/modal/Modal";
import { API_BASE_URL } from "@/config/api";

type Props = {
  open: boolean;
  onClose: () => void;
  onAuthorized: (user: any | null) => void;
};

const Authorization: React.FC<Props> = ({ open, onClose, onAuthorized }) => {
  const [method, setMethod] = useState<'card' | 'credentials'>('card');
  const [rfid, setRfid] = useState('');
  const [userid, setUserid] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const rfidRef = useRef<HTMLInputElement | null>(null);
  const useridRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!open) return;
    // focus the relevant input when modal opens or method changes
    setTimeout(() => {
      if (method === 'card') rfidRef.current?.focus();
      else useridRef.current?.focus();
    }, 50);
  }, [open, method]);

  const reset = () => {
    setMethod('card');
    setRfid('');
    setUserid('');
    setPassword('');
    setLoading(false);
    setError(null);
    setSuccess(null);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleAuthorizeByCard = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!rfid || rfid.trim().length === 0) {
        setError('Please provide RFID input');
        setLoading(false);
        return;
      }
      // Use auth RFID endpoint: POST /api/auth/rfid { rfid }
      const res = await fetch(`${API_BASE_URL}/api/auth/rfid`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rfid: rfid.trim() }),
      });

      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        throw new Error(`RFID validation failed: ${res.status} ${txt}`);
      }

      const data = await res.json();
      // Expecting { "Validation": "True" } or { "Validation": "False" }
      const valid = data && (data.Validation === true || String(data.Validation).toLowerCase() === 'true');
      if (!valid) {
        setError('Authorization failed: card not valid or inactive');
        setLoading(false);
        return;
      }

      // success: show a small confirmation then notify parent
      setError(null);
      setSuccess('Authorized');
      // determine authorized entity: prefer employee object when returned by RFID endpoint
      const authorizedEntity = data?.employee ?? data?.user ?? data ?? null;
      // notify parent after a short delay so user sees the success message
      setTimeout(() => {
        onAuthorized(authorizedEntity ?? null);
        reset();
        onClose();
      }, 600);
    } catch (err: any) {
      setError(err?.message ?? 'Authorization failed');
    } finally {
      setLoading(false);
    }
  };

  const handleAuthorizeByCredentials = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!userid || userid.trim().length === 0) {
        setError('Please provide user id');
        setLoading(false);
        return;
      }
      if (!password || password.length === 0) {
        setError('Please provide password');
        setLoading(false);
        return;
      }

      // Try authentication endpoint - common pattern /api/auth/login
      const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userid, password }),
      });

      if (!res.ok) {
        const txt = await res.text().catch(() => '');
        // if auth endpoint not available, fall back to user lookup
        if (res.status === 404) {
          // fallback: try user lookup by id and naive password match (not ideal)
          const fallback = await fetch(`${API_BASE_URL}/api/user?id=${encodeURIComponent(userid)}`);
          if (!fallback.ok) throw new Error('Authentication failed');
          const d = await fallback.json();
          const u = Array.isArray(d) ? d[0] : d;
          if (!u) throw new Error('User not found');
          onAuthorized(u);
          reset();
          onClose();
          return;
        }
        throw new Error(`Auth failed: ${res.status} ${txt}`);
      }

      const data = await res.json();
      // Expect token + user object or user object
      const user = data?.user ?? data;
      if (!user) {
        setError('Authentication did not return a user');
        setLoading(false);
        return;
      }

      onAuthorized(user);
      reset();
      onClose();
    } catch (err: any) {
      setError(err?.message ?? 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <Modal onClose={handleClose} width="max-w-md">
      <div className="p-6">
        <h3 className="text-lg font-semibold mb-3">Authorize</h3>
        {/* Tabs for selecting authorization method */}
        <div className="mb-4 border-b border-gray-200">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setMethod('card')}
              className={`px-4 py-2 -mb-px border-b-2 ${method === 'card' ? 'border-blue-600 text-blue-600 font-semibold' : 'border-transparent text-gray-600'}`}
            >
              Authorize using Card (RFID)
            </button>
            <button
              type="button"
              onClick={() => setMethod('credentials')}
              className={`px-4 py-2 -mb-px border-b-2 ${method === 'credentials' ? 'border-blue-600 text-blue-600 font-semibold' : 'border-transparent text-gray-600'}`}
            >
              Authorize using Credentials
            </button>
          </div>
        </div>

        {method === 'card' ? (
          <div className="space-y-2">
            <label className="text-sm font-medium">RFID Input</label>
            <input ref={rfidRef} type="password" value={rfid} onChange={(e) => setRfid(e.target.value)} className="w-full border rounded p-2" placeholder="Scan RFID Card" />
            <div className="text-xs text-gray-500">Scan the card into this field; user will be looked up by RFID.</div>
          </div>
        ) : (
          <div className="space-y-2">
            <label className="text-sm font-medium">User ID</label>
            <input ref={useridRef} type="text" value={userid} onChange={(e) => setUserid(e.target.value)} className="w-full border rounded p-2" placeholder="Enter User ID" />
            <label className="text-sm font-medium">Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border rounded p-2" placeholder="Enter Password" />
          </div>
        )}

  {error && <div className="mt-3 text-sm text-red-600">{error}</div>}
  {success && <div className="mt-3 text-sm text-green-600">{success}</div>}

        <div className="flex justify-end gap-2 mt-6">
          <button type="button" className="px-4 py-2 rounded border" onClick={handleClose} disabled={loading}>Cancel</button>
          {method === 'card' ? (
            <button type="button" className="px-4 py-2 rounded bg-green-600 text-white" onClick={handleAuthorizeByCard} disabled={loading}>{loading ? 'Checking...' : 'Authorize'}</button>
          ) : (
            <button type="button" className="px-4 py-2 rounded bg-green-600 text-white" onClick={handleAuthorizeByCredentials} disabled={loading}>{loading ? 'Authenticating...' : 'Authorize'}</button>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default Authorization;
