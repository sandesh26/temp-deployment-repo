import React from "react";

interface ChipRingProps {
  colorClass: string; // e.g. "bg-blue-500"
  text: string;
}

const ChipRing: React.FC<ChipRingProps> = ({ colorClass, text }) => (
  <div className="relative flex items-center justify-center w-24 h-24">
    {/* Outer ring with dotted border */}
    <div
      className={`absolute inset-0 rounded-full border-4 ${colorClass}`}
      style={{
        borderStyle: "dotted",
        borderWidth: "8px",
        boxSizing: "border-box",
      }}
    />
    {/* White inner circle */}
    <div className="relative w-20 h-20 bg-white rounded-full flex items-center justify-center shadow">
      <span className="text-2xl font-bold text-gray-800">{text}</span>
    </div>
  </div>
);

export default ChipRing;