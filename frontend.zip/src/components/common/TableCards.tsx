"use client";
import { API_BASE_URL } from "@/config/api";
import React, { useEffect, useState } from 'react';
import Link from "next/link";
import Modal from "@/components/ui/modal/Modal";
import './TableCards.css';

export type Balance = {
  label: string;
  value: string;
  warning?: boolean;
};

export type CardData = {
  name: string;
  table_id: string;
  status: 'open' | 'closed';
  gaming_day: string;
  type: string;
  last_change: string;
  changed_by: string;
  chip_balance: string;
  total: string;
  terminal: string;
  opening_chip_balance: string;
};

type StatusBadgeProps = {
  status: 'open' | 'closed';
};

type CardProps = {
  data: CardData;
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => (
  <span className={`status ${status}`}>{status.toUpperCase()}</span>
);

const Card: React.FC<CardProps> = ({ data }) => (
  //<Link href={`/table/${data.table_id}`} className="no-underline block">
    <div className="card">
      <div className="card-header">
        <div className="title">{data.name.toUpperCase()} <span className="code">(TBL - {data.table_id})</span></div>
        <StatusBadge status={data.status} />
      </div>
      <div className="details">
        <div><span>Gaming Day</span>{data.gaming_day?.split(" ")[0] || '—'}</div>
        <div><span>Table Type</span>{data.type || '—'}</div>
        <div><span>Last Change</span>{data.last_change || '—'}</div>
        <div><span>Changed By</span>{data.changed_by || '—'}</div>
      </div>
      <div className="total">
          <span>Table Float</span><span>&#8377; {data.opening_chip_balance}</span>
      </div>
      <div className="balances">
        <div key={data.chip_balance} className="balance-row">
          <span>Chips</span>
            <span>&#8377; {data.chip_balance}</span>
          </div>
      </div>
      <div className="total">
        <span>Total</span>
        {(() => {
          if (data.status === 'closed') {
            return (
              <span style={{ color: 'black', fontWeight: 600 }}>
                &#8377; {data.total}
              </span>
            );
          }
          const ocb = parseFloat(data.opening_chip_balance || '0');
          const total = parseFloat(data.total || '0');
          const isPositive = total >= ocb;
          return (
            <span style={{ color: isPositive ? 'green' : 'red', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '0.25em' }}>
              {isPositive ? (
                <svg width="16" height="16" viewBox="0 0 20 20" fill="green" xmlns="http://www.w3.org/2000/svg" style={{marginRight: 4}}>
                  <path d="M10 4l6 8H4l6-8z" fill="green"/>
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 20 20" fill="red" xmlns="http://www.w3.org/2000/svg" style={{marginRight: 4}}>
                  <path d="M10 16l-6-8h12l-6 8z" fill="red"/>
                </svg>
              )}
              &#8377; {data.total}
            </span>
          );
        })()}
      </div>
    </div>
  //</Link>
);


const TableCards: React.FC<{ apiUrl: string }> = ({ apiUrl }) => {
  const [cardData, setCardData] = useState<CardData[]>([]);

  // Function to fetch table data
  const fetchTableData = () => {
    fetch(apiUrl)
      .then(res => res.json())
      .then((data) => {
        // Map API response to CardData[]
        const mapped = data.map((item: any) => {
          // Convert balance object to array
          const balanceArr = Object.entries(item.balance || {}).map(([label, value]) => ({
            label: label.charAt(0).toUpperCase() + label.slice(1), // Capitalize
            value: String(value),
          }));

          // Calculate total (sum all balances, fallback to 0 if not possible)
          const total = balanceArr.reduce((sum, b) => sum + (parseFloat(b.value) || 0), 0);

          return {
            name: item.name,
            table_id: String(item.table_id),
            status: item.status?.toLowerCase() as 'open' | 'closed' || 'closed',
            gaming_day: item.gaming_day || '',
            type: item.type || '',
            last_change: item.last_change || '',
            changed_by: item.changed_by || '',
            chip_balance: item.chip_balance || '0',
            total: item.chip_balance || '0', 
            terminal: item.terminal || '',
            opening_chip_balance: item.opening_chip_balance || '0',
          };
        });
        setCardData(mapped);
      });
  };

  useEffect(() => {
    fetchTableData();
  }, [apiUrl]);


  // Add Table Modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [floorOptions, setFloorOptions] = useState<{floor_id: number, name: string}[]>([]);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  // Auto-close toast after 3 seconds
  React.useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Fetch floor options from API once on component mount
  React.useEffect(() => {
    fetch(`${API_BASE_URL}/api/floor`)
      .then(res => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setFloorOptions(data); 
        } else {
          setFloorOptions([]);
        }
      })
      .catch(() => {
        setFloorOptions([]);
      });
  }, []);

  // Remove useEffect for resetting modal fields

  // Simple Add Table Modal - conditionally rendered but with stable state
  const AddTableModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    // Local state inside modal - completely isolated
    const [localTableName, setLocalTableName] = useState("");
    const [localFloorId, setLocalFloorId] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleClose = () => {
      onClose();
    };

    const handleAddTable = async () => {
      if (!localTableName || !localFloorId) return;

      setIsSubmitting(true);
      try {
        const response = await fetch(`${API_BASE_URL}/api/table`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: localTableName,
            floor_id: parseInt(localFloorId),
          })
        });

        if (response.ok) {
          // Success - close modal, show success message, and refresh data
          handleClose();
          setToast({message: 'Table added successfully!', type: 'success'});
          fetchTableData(); // Refresh the table list
        } else {
          // Handle error
          setToast({message: 'Something went wrong. Please try again.', type: 'error'});
        }
      } catch (error) {
        console.error('Error creating table:', error);
        setToast({message: 'Something went wrong. Please try again.', type: 'error'});
      } finally {
        setIsSubmitting(false);
      }
    };

    return (
      <Modal onClose={handleClose} width="max-w-3xl">
        <div className="p-8">
          <h2 className="text-xl font-bold mb-4">Add New Table</h2>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">
              Table Name <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              className="border rounded px-3 py-2 w-full"
              placeholder="Enter Table Name"
              value={localTableName}
              onChange={e => setLocalTableName(e.target.value)}
              autoComplete="off"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">
              Floor <span className="text-red-600">*</span>
            </label>
            <select
              className="border rounded px-3 py-2 w-full"
              value={localFloorId}
              onChange={e => setLocalFloorId(e.target.value)}
              disabled={floorOptions.length === 0}
            >
              <option value="" disabled>Select Floor</option>
              {floorOptions.length === 0 ? (
                <option value="" disabled>Loading...</option>
              ) : (
                floorOptions.map((floor) => (
                  <option key={floor.floor_id} value={floor.floor_id}>{floor.name}</option>
                ))
              )}
            </select>
          </div>
          <div className="flex justify-end gap-2 mt-8">
            <button
              className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-bold hover:bg-red-600 hover:text-white A transition-colors"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              className={`px-4 py-2 rounded font-bold  disabled:cursor-not-allowed ${!localTableName || localFloorId === "" || isSubmitting ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-green-700 hover:bg-green-800 text-white'}`}
              onClick={handleAddTable}
              disabled={!localTableName || localFloorId === "" || isSubmitting}
            >
              {isSubmitting ? 'Adding...' : 'Add Table'}
            </button>
          </div>
        </div>
      </Modal>
    );
  };

  return (
    <>
      {/* Toast Notification */}
      {toast && (
        <div 
          className={`fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg text-white font-medium ${
            toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
          }`}
          style={{
            animation: 'slideInRight 0.3s ease-out'
          }}
        >
          {toast.message}
        </div>
      )}
      
      <div className="flex justify-end mb-8">
        <button
          className="flex items-center gap-2 bg-green-700 text-white px-6 py-3 rounded-lg font-bold shadow hover:bg-green-700 transition-colors"
          onClick={() => setShowAddModal(true)}
        >
          ADD TABLE
        </button>
      </div>
      <div className="card-container">
        {cardData.map((card, i) => <Card key={i} data={card} />)}
      </div>
      {showAddModal && <AddTableModal key="add-table-modal" onClose={() => setShowAddModal(false)} />}
      
      {/* Add some basic animation styles */}
      <style jsx>{`
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
    </>
  );
};

export default TableCards;
