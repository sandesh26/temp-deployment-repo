"use client"
import { API_BASE_URL } from "@/config/api";
import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import ExportToExcel from './ExportToExcel';
import { useAuth } from '@/context/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import Button from "@/components/ui/button/Button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { History, Play, Square, AlertTriangle, CheckCircle } from 'lucide-react';
import Modal from "@/components/ui/modal/Modal";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import BackButton from '@/components/common/BackButton';
import { useRouter } from "next/navigation";
import ChipDenominationSelector from './ChipDenominationSelector';
import { performCageTopUp, ChipEntry } from '@/lib/cage';
import { RefreshIcon } from "../../icons/index";

interface ActionIconProps {
  label: string;
  icon: string;
  shortcut?: string;
  className?: string;
  onClick?: () => void;
}

// Removed duplicate ActionIcon definition
async function handleTransactionModalSubmit(
  selectedAction: string | null,
  selectedPlayer: number | string | null,
  amount: string,
  notes: string,
  chipQuantities: { [key: string]: number; },
  availableDenominations: { id: number; chip_denomination: string; }[],
  cageId: number,
  gaming_day_id: number | undefined,
  transaction_time: string,
  paymentMethod: string,
  setRefreshKey: React.Dispatch<React.SetStateAction<number>>,
  // optional actor ids (derived from session in component scope)
  performedBy?: number | null,
  authorizedBy?: number | null,
) {
  let cash_total = parseFloat(amount) || 0;
  // prefer explicit values passed from caller (component) so this top-level helper stays pure
  const performed_by = Number(performedBy ?? 0) || 0;
  const authorized_by = Number(authorizedBy ?? performed_by) || performed_by || 0;
  let cageLatestCashBalance = 0;
  let cageLatestChipsBalance = 0;
  let cageLatestOnlineBalance = 0;
  let cageLatestTitoBalance = 0;
  let cageLatestTotalIn = 0;
  let cageLatestTotalOut = 0;
  let cageDenominationLatest = null;
  const chip_total = Object.entries(chipQuantities).reduce((sum, [denomKey, qty]) => {
    // Find the denomination object where chip_denomination matches the key
    const denomObj = availableDenominations.find(
      (denom) => String(denom.chip_denomination) === denomKey
    );
    if (denomObj) {
      return sum + (Number(denomObj.chip_denomination) * Number(qty));
    }
    return sum;
  }, 0);

  await fetch(`${API_BASE_URL}/api/cage/${cageId}`)
    .then(res => res.json())
    .then((data) => {
      const b = data.balance as any;
      cageLatestCashBalance = Number(b?.cash ?? data.balance ?? 0) || 0;
      cageLatestChipsBalance = Number(b?.chips ?? data.chip_balance ?? 0) || 0;
      cageLatestOnlineBalance = Number(b?.online ?? data.online_balance ?? 0) || 0;
      cageLatestTitoBalance = Number(b?.tito ?? data.tito_balance ?? 0) || 0;
      // capture existing totals so we can increment them client-side
      cageLatestTotalIn = Number(data.total_in) || 0;
      cageLatestTotalOut = Number(data.total_out) || 0;
    });

  await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cageId}&gaming_day_id=${gaming_day_id}`)
    .then(res => res.json())
    .then(inventoryData => {
      cageDenominationLatest = inventoryData;
      console.log("Cage Denomination:", cageDenominationLatest);
    });


  // console.log("Cage Cash Balance:", cageLatestCashBalance);
  // console.log("Cage Chips Balance:", cageLatestChipsBalance);
  // console.log("Cage Denomination:", cageDenominationLatest);
  // console.log("Cash Total:", cash_total);
  // console.log("Chip Total:", chip_total);
  // console.log("Selected Action:", selectedAction);
  // console.log("Selected Player:", selectedPlayer);
  // console.log("Notes:", notes);
  // console.log("Chip Quantities:", chipQuantities);
  // console.log("Available Denominations:", availableDenominations);
  // console.log("Cage ID:", cageId);
  // console.log("Gaming Day ID:", gaming_day_id);
  // console.log("Timestamp:", transaction_time);
  // console.log("Payment Method:", paymentMethod);

  switch (selectedAction) {
    case 'BUY_CHIPS':
      // BUY_CHIPS: increment Total In by chip_total and update the cage balance field based on payment method
      const buyChipsNewTotalIn = (cageLatestTotalIn || 0) + Number(chip_total || 0);
      // normalize payment method
      const buyChipsPM = (paymentMethod || 'Cash').toString().trim().toUpperCase();
      let newCashBalance = cageLatestCashBalance;
      let newChipsBalance = cageLatestChipsBalance;
      let newOnlineBalance = cageLatestOnlineBalance;
      let newTitoBalance = cageLatestTitoBalance;

      if (buyChipsPM === 'CASH') {
        newCashBalance = cageLatestCashBalance + Number(chip_total || 0);
      } else if (buyChipsPM === 'CHIPS') {
        // when payment is chips, cage chip balance likely decreases (chips leave cage)
        newChipsBalance = cageLatestChipsBalance - Number(chip_total || 0);
      } else if (buyChipsPM === 'TITO') {
        newTitoBalance = cageLatestTitoBalance + Number(chip_total || 0);
      } else if (buyChipsPM.includes('UPI') || buyChipsPM.includes('CARD') || buyChipsPM.includes('CREDIT') || buyChipsPM.includes('DEBIT') || buyChipsPM.includes('ONLINE')) {
        newOnlineBalance = cageLatestOnlineBalance + Number(chip_total || 0);
      } else {
        // default: treat as cash
        newCashBalance = cageLatestCashBalance + Number(chip_total || 0);
      }

      newChipsBalance = newChipsBalance - Number(chip_total || 0);

      await updateCageDetails(cageId, newCashBalance, newChipsBalance, transaction_time, gaming_day_id, performed_by, buyChipsNewTotalIn, undefined, newOnlineBalance, newTitoBalance);

      await updateCageChipDenominationDetails(cageId, gaming_day_id, cageDenominationLatest, chipQuantities, "DEDUCT");

      await updateCageTransactionTable({ cage_id: cageId, gaming_day_id: gaming_day_id ?? 0, player_id: (typeof selectedPlayer === 'number' ? selectedPlayer : 0), transaction_type: "CHIP_PURCHASE", performed_by, amount: chip_total, payment_method: paymentMethod || "Cash", notes: `Player ${selectedPlayer} bought Chips worth ${chip_total}`, timestamp: transaction_time, isCageOpenRecord: false });
      break;
    case 'REDEEM_CHIPS':
      // REDEEM_CHIPS: increment Total Out by chip_total and update balances accordingly
      const redeemChipsNewTotalOut = (cageLatestTotalOut || 0) + Number(chip_total || 0);
      // when redeeming chips, cage receives chips (chip balance increases) and cash may decrease if cash was given
      // Here we preserve previous behaviour: decrease cash, increase chips
      await updateCageDetails(cageId, (cageLatestCashBalance - Number(chip_total || 0)), (cageLatestChipsBalance + Number(chip_total || 0)), transaction_time, gaming_day_id, performed_by, undefined, redeemChipsNewTotalOut, cageLatestOnlineBalance, cageLatestTitoBalance);

      await updateCageChipDenominationDetails(cageId, gaming_day_id, cageDenominationLatest, chipQuantities, "ADD");

      await updateCageTransactionTable({ cage_id: cageId, gaming_day_id: gaming_day_id ?? 0, player_id: (typeof selectedPlayer === 'number' ? selectedPlayer : 0), transaction_type: "CHIP_REDEEM", performed_by, amount: chip_total, payment_method: "Chips", notes: `Player ${selectedPlayer} redeemed Chips worth ${chip_total}`, timestamp: transaction_time, isCageOpenRecord: false });

      break;
    case 'REDEEM_TITO':
      // REDEEM_TITO: increment Total Out by cash_total and update tito balance
      const redeemTitoNewTotalOut = (cageLatestTotalOut || 0) + Number(cash_total || 0);
      // Player redeems TITO -> cage gives cash (cash decreases) and tito_balance should decrease
      const newCashAfterRedeemTito = cageLatestCashBalance - Number(cash_total || 0);
      const newTitoAfterRedeem = cageLatestTitoBalance + Number(cash_total || 0);
      await updateCageDetails(cageId, newCashAfterRedeemTito, cageLatestChipsBalance, transaction_time, gaming_day_id, performed_by, undefined, redeemTitoNewTotalOut, cageLatestOnlineBalance, newTitoAfterRedeem);

      // For TITO redemption, selectedPlayer may be a barcode (string) or a player id (number).
      const playerIdForTxn = typeof selectedPlayer === 'number' ? selectedPlayer : 0;
      const barcodeValue = typeof selectedPlayer === 'string' ? selectedPlayer : undefined;
      const notesPrefix = barcodeValue ? `Barcode: ${barcodeValue} - ` : '';
      // ensure player_id is numeric (0 when unknown); include barcode in notes when provided
      await updateCageTransactionTable({
        cage_id: cageId,
        gaming_day_id: gaming_day_id ?? 0,
        player_id: playerIdForTxn,
        transaction_type: "TITO_REDEEM",
        performed_by,
        amount: cash_total,
        payment_method: "TITO",
        notes: `${notesPrefix}TITO redeemed worth ${cash_total}`,
        timestamp: transaction_time,
        isCageOpenRecord: false,
      });
      break;

    case 'BUY_TITO':
      // BUY_TITO: increment Total In by cash_total and update balance based on payment method
      const buyTitoNewTotalIn = (cageLatestTotalIn || 0) + Number(cash_total || 0);
      const buyTitoPM = (paymentMethod || 'Cash').toString().trim().toUpperCase();
      let newCashForBuyTito = cageLatestCashBalance;
      let newChipsForBuyTito = cageLatestChipsBalance;
      let newOnlineForBuyTito = cageLatestOnlineBalance;
      let newTitoForBuyTito = cageLatestTitoBalance;

      if (buyTitoPM === 'CASH') {
        newCashForBuyTito = cageLatestCashBalance + Number(cash_total || 0);
      } else if (buyTitoPM === 'CHIPS') {
        newChipsForBuyTito = cageLatestChipsBalance - Number(cash_total || 0);
      } else if (buyTitoPM === 'TITO') {
        newTitoForBuyTito = cageLatestTitoBalance + Number(cash_total || 0);
      } else if (buyTitoPM.includes('UPI') || buyTitoPM.includes('CARD') || buyTitoPM.includes('CREDIT') || buyTitoPM.includes('DEBIT') || buyTitoPM.includes('ONLINE')) {
        newOnlineForBuyTito = cageLatestOnlineBalance + Number(cash_total || 0);
      } else {
        newCashForBuyTito = cageLatestCashBalance + Number(cash_total || 0);
      }

      await updateCageDetails(cageId, newCashForBuyTito, newChipsForBuyTito, transaction_time, gaming_day_id, performed_by, buyTitoNewTotalIn, undefined, newOnlineForBuyTito, newTitoForBuyTito);

      // Create new TITO and store barcode
      let NEW_TITO_BARCODE = null;
      try {
        const titoRes = await fetch(`${API_BASE_URL}/api/tito`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amount: Number(cash_total),
            issued_location: `Cage ${cageId}`
          })
        });
        if (titoRes.ok) {
          const titoData = await titoRes.json();
          NEW_TITO_BARCODE = titoData.barcode;
        }
      } catch (e) {
        // Optionally handle error
        NEW_TITO_BARCODE = null;
      }

      await updateCageTransactionTable({ cage_id: cageId, gaming_day_id: gaming_day_id ?? 0, player_id: (typeof selectedPlayer === 'number' ? selectedPlayer : 0), transaction_type: "TITO_PURCHASE", performed_by, amount: cash_total, payment_method: paymentMethod || "Cash", notes: `Player ${selectedPlayer} bought TITO worth ${cash_total}`, timestamp: transaction_time, isCageOpenRecord: false });
      break;

    case 'LOAD_CARD':
      // LOAD_CARD: increment Total In by cash_total and update balance based on payment method
      const loadCardNewTotalIn = (cageLatestTotalIn || 0) + Number(cash_total || 0);
      const loadCardPM = (paymentMethod || 'Cash').toString().trim().toUpperCase();
      let newCashForLoad = cageLatestCashBalance;
      let newChipsForLoad = cageLatestChipsBalance;
      let newOnlineForLoad = cageLatestOnlineBalance;
      let newTitoForLoad = cageLatestTitoBalance;

      if (loadCardPM === 'CASH') {
        newCashForLoad = cageLatestCashBalance + Number(cash_total || 0);
      } else if (loadCardPM === 'CHIPS') {
        newChipsForLoad = cageLatestChipsBalance - Number(cash_total || 0);
      } else if (loadCardPM === 'TITO') {
        newTitoForLoad = cageLatestTitoBalance + Number(cash_total || 0);
      } else if (loadCardPM.includes('UPI') || loadCardPM.includes('CARD') || loadCardPM.includes('CREDIT') || loadCardPM.includes('DEBIT') || loadCardPM.includes('ONLINE')) {
        newOnlineForLoad = cageLatestOnlineBalance + Number(cash_total || 0);
      } else {
        newCashForLoad = cageLatestCashBalance + Number(cash_total || 0);
      }

      await updateCageDetails(cageId, newCashForLoad, newChipsForLoad, transaction_time, gaming_day_id, performed_by, loadCardNewTotalIn, undefined, newOnlineForLoad, newTitoForLoad);

      if (typeof selectedPlayer === 'number') {
        await updatePlayerCard(selectedPlayer, cash_total);
      }

      await updateCageTransactionTable({ cage_id: cageId, gaming_day_id: gaming_day_id ?? 0, player_id: (typeof selectedPlayer === 'number' ? selectedPlayer : 0), transaction_type: "MONEY_CREDIT", performed_by, amount: cash_total, payment_method: paymentMethod || "Cash", notes: `Player ${selectedPlayer} loaded card with INR ${cash_total}`, timestamp: transaction_time, isCageOpenRecord: false });
      break;

    default:

      break;
  }
  setRefreshKey(k => k + 1);
}
const ActionIcon: React.FC<ActionIconProps> = ({ label, icon, shortcut, className, onClick }) => {
  return (
    <button
      className={`flex flex-col items-center justify-center hover:bg-gray-100 rounded-lg transition-colors border-[2px] border-gray-300 shadow-sm aspect-square w-full flex-1 ${className || ''}`}
      onClick={onClick}
    >
      <div className="w-14 h-14 mb-2 flex items-center justify-center">
        <img src={`/images/icons/${icon}.svg`} alt={label} className="w-10 h-10" />
      </div>
      <span className="text-sm font-medium text-center text-gray-700">{label}</span>
      {shortcut && <span className="text-xs text-gray-500 mt-1">{shortcut}</span>}
    </button>
  );
}


interface InventoryItem {
  id: number;
  cage_id: number;
  gaming_day_id: number;
  chip_denomination: string;
  chip_color: string;
  quantity: number;
  total_value: string;
  recorded_at: string;
  cage: string;
  gamingDay: {
    start_time: string;
    end_time: string;
  };
  gaming_day_start: string;
  gaming_day_end: string;
  type: 'CHIP' | 'Voucher' | 'CASH' | 'ONLINE' | 'TITO TICKETS';
}

interface CageApiResponse {
  cage_id: string;
  name: string;
  type: string;
  status: 'open' | 'closed';
  terminal: string;
  balance: string;
  changed_by: string;
  last_change: string;
  gaming_day: string;
  inventory?: InventoryItem[];
  total?: string;
  gaming_day_id?: number;
  total_in: string;
  total_out: string;
  online_balance: string;
  tito_balance: string;
}

type StatusBadgeProps = {
  status: 'open' | 'closed';
};

interface CageCardProps {
  cageId?: string;
  floor?: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => (
  <span className={`status ${status.toLocaleLowerCase()}`}>{status.toUpperCase()}</span>
);

const InitialCageSetupModal: React.FC<{
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onSave: (cash: number, chips: { id: number; denomination: string; color: string; quantity: number }[]) => void;
  cageId: string | number; // <-- add this
}> = ({ open, onClose, onSave, cageId, onSuccess }) => {
  const [activeTab, setActiveTab] = useState<"cash" | "chips" | "summary" | "progress">("cash");
  const [cash, setCash] = useState<string>("");
  const [chipList, setChipList] = useState<any[]>([]);
  const [chipQuantities, setChipQuantities] = useState<{ [id: number]: number }>({});
  const [loading, setLoading] = useState(false);

  // New state for modals
  const [showSuccess, setShowSuccess] = useState(false);
  const [showFailure, setShowFailure] = useState(false);

  const router = useRouter(); // For page refresh
  const { session } = useAuth();
  // Mirror the user-id extraction used in AppHeader for display/fallbacks
  const _user = (session?.user as any) ?? {};
  const userIdDisplay = _user.id ?? _user.user_id ?? _user._id ?? _user.userId ?? _user.email ?? "—";
  // Synchronously read stored session user id (helps when `session` hasn't hydrated yet)
  const storedSessionUserId = (() => {
    try {
      if (typeof window === 'undefined') return null;
      const raw = localStorage.getItem('casino_session_v1');
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return (parsed?.user?.user_id ?? parsed?.user?.id) ?? null;
    } catch (e) {
      return null;
    }
  })();
  // numeric actor ids used for API payloads (best-effort from session or stored session)
  const numericSessionUserId = Number((session?.user as any)?.id ?? (session?.user as any)?.user_id) || Number(storedSessionUserId) || 0;
  // (no-op) modal-level local session reader removed — we'll compute storedSessionUserId in CageCard instead

  useEffect(() => {
    if (open && activeTab === "chips") {
      setLoading(true);
      fetch(`${API_BASE_URL}/api/vault-chip-denomination`)
        .then(res => res.json())
        .then((data: any[]) => {
          setChipList(data);
          setChipQuantities(prev => {
            if (Object.keys(prev).length === 0) {
              const initialQuantities: { [id: number]: number } = {};
              data.forEach((chip) => {
                initialQuantities[chip.id] = 0;
              });
              return initialQuantities;
            }
            return prev;
          });
        })
        .finally(() => setLoading(false));
    }
    if (!open) {
      setActiveTab("cash");
      setCash("");
      setChipList([]);
      setChipQuantities({});
      setLoading(false);
    }
  }, [open, activeTab]);

  const handleChipQtyChange = (id: number, qty: string) => {
    setChipQuantities((prev) => ({
      ...prev,
      [id]: Number(qty.replace(/[^0-9]/g, "")) || 0,
    }));
  };

  const chipsSelected = chipList.filter((chip) => (chipQuantities[chip.id] || 0) > 0);
  const chipsTotal = chipsSelected.reduce(
    (sum, chip) =>
      sum +
      (chipQuantities[chip.id] || 0) * (parseFloat(chip.chip_denomination) || 0),
    0
  );
  const cashTotal = Number(cash) || 0;
  const overallTotal = cashTotal + chipsTotal;

  const handleNext = () => setActiveTab("chips");
  const handleBack = () => setActiveTab("cash");
  const handleSummary = () => setActiveTab("summary");
  const handleFinish = async () => {
    setActiveTab("progress");
    setLoading(true);
    let success = true;
    try {
      // --- All your API logic here ---
      const cage_id = Number(cageId);
      const now = new Date().toISOString();
      const authorized_by = numericSessionUserId || 0;
      const performed_by = numericSessionUserId || 0;
      let gaming_day_id = null;
      try {
        const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
        const data = await resp.json();
        if (data && data.gaming_day_id) {
          gaming_day_id = data.gaming_day_id;
        }
      } catch { }

      await saveCageChipDenomination({ cage_id, gaming_day_id, chips: chipList, chipQuantities });
      // Calculate chip total
      const chip_total = chipsSelected.reduce(
        (sum, chip) => sum + (Number(chip.chip_denomination) * (chipQuantities[chip.id] || 0)),
        0
      );
      const cash_total = cashTotal;

      // Update Cage table
      await updateCageTable({ cage_id, cash_total, chip_total, gaming_day_id, performed_by });

      // Update vault balance
      await updateVaultBalance({ cash_total, chip_total });

      // Update Vault Chip Denominations
      await updateVaultChipDenomination({ chips: chipList, chipQuantities });

      // Prepare vault transaction entries
      const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const destination = `Cage ${cage_id}`;
      const transaction_time = now;

      // Cash transaction entry (if any)
      const vaultTransactions = [];
      if (cash_total > 0) {
        vaultTransactions.push({
          vault_id: 1,
          transaction_type: "TRANSFER",
          asset_type: "CASH",
          denomination: 0,
          quantity: 0,
          total_value: cash_total,
          currency_code: "INR",
          source: "Vault",
          destination,
          reference_id,
          authorized_by,
          performed_by,
          transaction_time,
          cage_id: cage_id,
          notes: `Cash of INR ${cash_total} added to Cage ${cage_id}`,
          gaming_day_id,
        });
      }

      // Chip transaction entries (if any)
      chipsSelected.forEach(chip => {
        vaultTransactions.push({
          vault_id: 1,
          transaction_type: "TRANSFER",
          asset_type: "CHIP",
          denomination: Number(chip.chip_denomination),
          quantity: chipQuantities[chip.id] || 0,
          total_value: Number(chip.chip_denomination) * (chipQuantities[chip.id] || 0),
          currency_code: "INR",
          source: "Vault",
          destination,
          reference_id,
          authorized_by,
          performed_by,
          transaction_time,
          cage_id: cage_id,
          notes: `${chipQuantities[chip.id] || 0} Quantity of ${chip.chip_denomination} Denomination added to Cage ${cage_id}`,
          gaming_day_id,
        });
      });

      // POST to vault-transaction/bulk
      if (vaultTransactions.length > 0) {
        await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(vaultTransactions),
        });
      }


      // Insert Cage Session Start Entry
      await updateCageSessionTable({ cage_id, gaming_day_id, performed_by, transaction_time, status: "OPEN", total_amount: cash_total + chip_total });

      // Insert Cage Transaction Table - Cash Entry
      await updateCageTransactionTable({ cage_id, gaming_day_id, player_id: 0, transaction_type: "CAGE_OPEN", performed_by, amount: cash_total, payment_method: "VAULT_TRANSFER", notes: `Cage Opening Balance - Cash Entry`, timestamp: transaction_time, isCageOpenRecord: true });

      // Insert Cage Transaction Table - Chip Entry
      await updateCageTransactionTable({ cage_id, gaming_day_id, player_id: 0, transaction_type: "CAGE_OPEN", performed_by, amount: chip_total, payment_method: "VAULT_TRANSFER", notes: `Cage Opening Balance - Chips Entry`, timestamp: transaction_time, isCageOpenRecord: true });

      // --- End API logic ---
    } catch (err) {
      success = false;
    }

    setLoading(false);
    setActiveTab("cash"); // Remove progress tab

    if (success) {
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        onClose();
        onSuccess();
        router.refresh(); // Refresh the page
      }, 2000);
    } else {
      setShowFailure(true);
    }
  };

  return open ? (
    <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
      <Modal onClose={onClose}>
        <div className="p-6 w-full-[200px] max-w-5xl h-[500px] flex flex-col">
          <h2 className="text-xl font-bold mb-4">Open CAGE</h2>
          {/* Tabs */}
          {(activeTab === "cash" || activeTab === "chips") && (
            <div className="flex mb-2">
              <button
                className={`px-4 py-2 font-bold uppercase text-sm ${activeTab === "cash"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-gray-500"
                  }`}
                onClick={() => setActiveTab("cash")}
                disabled={activeTab === "cash"}
              >
                CASH
              </button>
              <button
                className={`px-4 py-2 font-bold uppercase text-sm ${activeTab === "chips"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-gray-500"
                  }`}
                onClick={() => setActiveTab("chips")}
                disabled={activeTab === "chips"}
              >
                CHIPS
              </button>
            </div>
          )}

          {/* CASH TAB */}
          {activeTab === "cash" && (
            <div className="flex flex-col h-full justify-between">
              <div>
                <div className="mb-6">
                  <label className="block text-gray-700 font-semibold mb-3 mt-3">
                    Enter Initial Cash Balance (INR)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={cash}
                    onChange={(e) => setCash(e.target.value)}
                    className="w-full border rounded px-3 py-2 text-lg font-bold"
                    placeholder="Enter cash amount"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={onClose}>
                  CANCEL
                </Button>
                <Button
                  variant="primary"
                  onClick={handleNext}
                  disabled={!cash || Number(cash) <= 0}
                >
                  NEXT
                </Button>
              </div>
            </div>
          )}

          {/* CHIPS TAB */}
          {activeTab === "chips" && (
            <div className="flex flex-col h-full justify-between">
              {loading ? (
                <div className="py-8 text-center text-gray-500 flex-1 flex items-center justify-center">
                  Loading chip denominations...
                </div>
              ) : (
                <>
                  <div className="max-h-[200px] overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-600">
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Denomination</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Quantity</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {chipList.map((chip) => (
                          <TableRow key={chip.id}>
                            <TableCell className="text-center text-sm py-3">
                              {chip.chip_denomination}
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">
                              <input
                                type="number"
                                min={0}
                                value={chipQuantities[chip.id] || ""}
                                onChange={(e) =>
                                  handleChipQtyChange(chip.id, e.target.value)
                                }
                                className="w-24 border rounded px-2 py-1 text-right"
                              />
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">
                              {((chipQuantities[chip.id] || 0) *
                                (parseFloat(chip.chip_denomination) || 0)
                              ).toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-end mt-4 pt-4 border-t border-gray-200">
                    <div className="text-right">
                      <div className="text-lg text-gray-500 mb-1 font-bold uppercase">
                        TOTAL :{" "}
                        <span className="text-lg font-bold text-gray-800">
                          {chipsTotal.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between mt-6">
                    <Button variant="outline" onClick={handleBack}>
                      BACK
                    </Button>
                    <Button
                      variant="primary"
                      onClick={handleSummary}
                      disabled={chipList.length === 0}
                    >
                      NEXT
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* SUMMARY TAB */}
          {activeTab === "summary" && (
            <div className="flex flex-col h-full justify-between">
              <div className="overflow-y-auto max-h-[340px] pr-2">
                <div className="font-bold text-lg mb-2">Summary</div>
                {/* Diagnostic: show who will be used as performed_by / authorized_by for investigation
                <div className="bg-white p-3 mb-3 border rounded">
                  <div className="text-xs text-gray-500">Performed By (numeric)</div>
                  <div className="text-sm font-medium">{numericSessionUserId}</div>
                  <div className="text-xs text-gray-500 mt-2">Authorized By (numeric)</div>
                  <div className="text-sm font-medium">{numericSessionUserId}</div>
                  <div className="text-xs text-gray-500 mt-2">Session user (display)</div>
                  <div className="text-sm font-medium">{userIdDisplay}</div>
                </div> */}
                {/* Gaming Day */}
                <div className="bg-gray-100 p-4 mb-2 flex justify-between items-center">
                  <span className="text-xs text-gray-500 font-bold uppercase">GAMING DAY</span>
                  <span className="text-lg font-bold">{new Date().toLocaleDateString()}</span>
                </div>
                {/* Cash */}
                <div className="bg-gray-100 border-b p-4 flex justify-between items-center">
                  <span className="text-xs text-gray-500 font-bold uppercase">CASH</span>
                  <span className="text-lg font-bold">
                    INR {cashTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                {/* Chips */}
                {chipsSelected.length > 0 && (
                  <div className="bg-white border-b p-4">
                    <div className="text-xs text-gray-500 font-bold uppercase mb-1">CHIP</div>
                    {chipsSelected.map((chip) => (
                      <div key={chip.id} className="flex justify-between text-base">
                        <span>
                          {chip.chip_denomination} x {chipQuantities[chip.id]}
                        </span>
                        <span>
                          INR {(chipQuantities[chip.id] * parseFloat(chip.chip_denomination)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    ))}
                    <div className="bg-gray-100 p-4 text-xs text-gray-500 flex justify-between font-bold mt-2 items-center left-0">
                      <span className="text-xs text-gray-500 font-bold uppercase">CHIPS TOTAL</span>
                      <span className="text-lg font-bold !text-black">INR {chipsTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                )}
                {/* Total */}
                <div className="bg-white border-b p-4 flex justify-between items-center">
                  <span className="font-bold uppercase">CAGE TOTAL</span>
                  <span className="text-lg font-bold">
                    INR {overallTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
              <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={() => setActiveTab("chips")}>
                  BACK
                </Button>
                <Button variant="primary" onClick={handleFinish}>
                  FINISH
                </Button>
              </div>
            </div>
          )}

          {/* PROGRESS TAB */}
          {activeTab === "progress" && (
            <div className="flex flex-col h-full justify-center items-center">
              <div className="text-lg mb-6">Opening cage in progress...</div>
              <div className="flex justify-center">
                <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
                </svg>
              </div>
            </div>
          )}

          {/* SUCCESS MODAL */}
          {showSuccess && (
            <Modal onClose={() => setShowSuccess(false)}>
              <div className="flex flex-col items-center p-6">
                <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
                <h2 className="text-lg font-bold mb-2 text-center">Cage opened successfully!</h2>
              </div>
            </Modal>
          )}

          {/* FAILURE MODAL */}
          {showFailure && (
            <Modal onClose={() => setShowFailure(false)}>
              <div className="flex flex-col items-center p-6">
                <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
                <h2 className="text-lg font-bold mb-2 text-center">Something went wrong, Please Try Again Later</h2>
                <Button className="mt-4" onClick={() => setShowFailure(false)}>OK</Button>
              </div>
            </Modal>
          )}
        </div>
      </Modal>
    </div>
  ) : null;
};

const CageCard: React.FC<CageCardProps> = ({ cageId, floor }) => {
  const [transactions, setTransactions] = useState<any[]>([]);
  // --- Transactions Modal: Add state and filter logic ---
  const [transactionDateFilter, setTransactionDateFilter] = useState('TODAY');


  // Now safe to use in hooks
  const filterTransactionsByDate = useCallback((txns: any[], filter: string) => {
    const now = new Date();
    if (filter === 'ALL') return txns;
    return txns.filter(txn => {
      const txnDate = new Date(txn.timestamp);
      if (filter === 'TODAY') {
        return txnDate.toDateString() === now.toDateString();
      } else if (filter === 'THIS_WEEK') {
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - now.getDay());
        startOfWeek.setHours(0, 0, 0, 0);
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 7);
        return txnDate >= startOfWeek && txnDate < endOfWeek;
      } else if (filter === 'THIS_MONTH') {
        return txnDate.getFullYear() === now.getFullYear() && txnDate.getMonth() === now.getMonth();
      }
      return true;
    });
  }, []);
  const filteredTransactions = useMemo(() => filterTransactionsByDate(transactions, transactionDateFilter), [transactions, transactionDateFilter, filterTransactionsByDate]);
  const [inventoryData, setInventoryData] = useState<InventoryItem[]>([]);
  const [cageDetails, setCageDetails] = useState<CageApiResponse | null>(null);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [historyData, setHistoryData] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const { session } = useAuth();
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [showTransactions, setShowTransactions] = useState(false);
  // (already declared above, do not redeclare)
  // transactionDateFilter is already declared above, do not redeclare
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const [showStopSessionModal, setShowStopSessionModal] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY' | 'THIS_MONTH' | 'CUSTOM'>('ALL');
  const [customRange, setCustomRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
  const [paymentMethod, setPaymentMethod] = useState<string>("");

  // New state for player transaction modal
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [showPlayerSearch, setShowPlayerSearch] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<any>(null);
  const [titoBarcode, setTitoBarcode] = useState<string>("");
  const [titoLoading, setTitoLoading] = useState<boolean>(false);
  const [titoError, setTitoError] = useState<string | null>(null);
  const [titoValid, setTitoValid] = useState<boolean>(false);
  const [titoId, setTitoId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [amount, setAmount] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [chipDenomination, setChipDenomination] = useState<string>("");
  const [chipQuantities, setChipQuantities] = useState<{ [key: string]: number }>({});
  const [availableDenominations, setAvailableDenominations] = useState<Array<{ id: number, chip_denomination: string }>>([]);
  const [transactionStep, setTransactionStep] = useState<'select-action' | 'search-player' | 'transaction-details' | 'summary' | 'fill-up'>('select-action');

  // current gaming day id fetched from server to compare with cage's gaming_day_id
  const [currentGamingDayId, setCurrentGamingDayId] = useState<number | null>(null);

  useEffect(() => {
    let mounted = true;
    const fetchCurrentGamingDay = async () => {
      try {
        const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
        const data = await resp.json();
        if (!mounted) return;
        setCurrentGamingDayId(data?.gaming_day_id ?? null);
      } catch (err) {
        if (!mounted) return;
        setCurrentGamingDayId(null);
      }
    };
    fetchCurrentGamingDay();
    return () => { mounted = false; };
  }, [cageId, refreshKey]);

  const showCloseBadge = currentGamingDayId != null && cageDetails?.gaming_day_id != null && Number(cageDetails.gaming_day_id) !== Number(currentGamingDayId) && cageDetails.status.toLocaleLowerCase() === 'open';
  console.log("currentGamingDayId : " + currentGamingDayId);
  console.log("cageDetails.gaming_day_id : " + cageDetails?.gaming_day_id);
  console.log("cageDetails.status : " + cageDetails?.status);
  console.log("showCloseBadge : " + showCloseBadge);
  // Fill Up modal state
  const [showFillUpModal, setShowFillUpModal] = useState<boolean>(false);
  const [fillCashAmount, setFillCashAmount] = useState<string>('');
  const [fillChipQuantities, setFillChipQuantities] = useState<{ [denomination: string]: number }>({});
  const [fillSubmitting, setFillSubmitting] = useState<boolean>(false);
  const [fillRequestId, setFillRequestId] = useState<number | null>(null);
  const [fillRequestStatus, setFillRequestStatus] = useState<string | null>(null);
  const [showRequestResult, setShowRequestResult] = useState<{ ok: boolean; message?: string } | null>(null);
  // Credit Out modal state (withdraw from cage to vault)
  const [showCreditOut, setShowCreditOut] = useState<boolean>(false);
  const [creditCashAmount, setCreditCashAmount] = useState<string>('');
  const [creditChipQuantities, setCreditChipQuantities] = useState<{ [denomination: string]: number }>({});
  const [creditSubmitting, setCreditSubmitting] = useState<boolean>(false);
  const [creditRequestId, setCreditRequestId] = useState<number | null>(null);
  const [creditRequestStatus, setCreditRequestStatus] = useState<string | null>(null);
  const [showCreditRequestResult, setShowCreditRequestResult] = useState<{ ok: boolean; message?: string } | null>(null);
  // Local state to show Requests modal (button added to nav)
  const [showRequests, setShowRequests] = useState<boolean>(false);
  const [requests, setRequests] = useState<any[]>([]);
  const [requestsLoading, setRequestsLoading] = useState<boolean>(false);
  const [hasOpenRequests, setHasOpenRequests] = useState<boolean>(false);
  const [actionProcessingId, setActionProcessingId] = useState<number | null>(null);
  const [actionErrorMap, setActionErrorMap] = useState<Record<number | string, string>>({});
  // Pending request action (for confirmation modal)
  const [pendingRequestAction, setPendingRequestAction] = useState<{
    id: number | string;
    type: 'accept' | 'reject' | 'revoke';
    request?: any;
    defaultRemarks?: string;
  } | null>(null);
  const [confirmRemarks, setConfirmRemarks] = useState<string>('');

  // Auto-close the request result modal after 4 seconds and reset the fill flow state.
  useEffect(() => {
    if (!showRequestResult) return;
    const timer = setTimeout(() => {
      setShowRequestResult(null);
      // mirror OK button: close the fill flow and reset fields
      try {
        setSelectedAction(null);
        setFillCashAmount('');
        setFillChipQuantities({});
        setTransactionStep('select-action');
      } catch (e) {
        // defensive: if any setter isn't defined in this scope, ignore
        // (they should be defined, but keep this safe)
      }
    }, 4000);
    return () => clearTimeout(timer);
  }, [showRequestResult]);
  // UI step for Fill Up slider: 'cash' -> enter cash, 'chips' -> enter chip quantities, 'confirm' -> summary before sending
  const [fillStep, setFillStep] = useState<'cash' | 'chips' | 'confirm'>('cash');
  // UI step for Credit Out slider
  const [creditStep, setCreditStep] = useState<'cash' | 'chips' | 'confirm'>('cash');
  // Player search state
  const [playerResults, setPlayerResults] = useState<any[]>([]);
  const [playerSearchLoading, setPlayerSearchLoading] = useState(false);
  const [playerSearchError, setPlayerSearchError] = useState<string>("");

  // Debounced player search
  useEffect(() => {
    if (!showPlayerSearch || searchQuery.trim() === "") {
      setPlayerResults([]);
      setPlayerSearchLoading(false);
      setPlayerSearchError("");
      return;
    }
    const controller = new AbortController();
    setPlayerSearchLoading(true);
    setPlayerSearchError("");
    const handler = setTimeout(() => {
      fetch(`${API_BASE_URL}/api/user?search=${encodeURIComponent(searchQuery)}&role=Player`, { signal: controller.signal })
        .then(res => {
          if (!res.ok) throw new Error("Failed to fetch players");
          return res.json();
        })
        .then(async data => {
          const players = Array.isArray(data) ? data : data.results || [];
          // Fetch balances for each player
          const playersWithBalance = await Promise.all(players.map(async (player: any) => {
            try {
              const balanceRes = await fetch(`${API_BASE_URL}/api/playercard/${player.user_id}`);
              if (!balanceRes.ok) throw new Error("Balance fetch failed");
              const balanceData = await balanceRes.json();
              return { ...player, balance: balanceData.balance };
            } catch {
              return { ...player, balance: null };
            }
          }));
          setPlayerResults(playersWithBalance);
          setPlayerSearchLoading(false);
        })
        .catch(err => {
          if (err.name !== "AbortError") {
            setPlayerSearchError(`Error fetching players: ${err.message}`);
            setPlayerResults([]);
            setPlayerSearchLoading(false);
          }
        });
    }, 300);
    return () => {
      controller.abort();
      clearTimeout(handler);
    };
  }, [searchQuery, showPlayerSearch]);

  const filteredPlayers = searchQuery.trim() === "" ? [] : playerResults;


  // Prevent outer scroll when any modal is open
  useEffect(() => {
    const anyModalOpen = showTransactionModal || showSetupModal || showHistory || showTransactions || showStopSessionModal;
    if (anyModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showTransactionModal, showSetupModal, showHistory, showTransactions, showStopSessionModal]);

  // Reset modal state on open and fetch denominations
  useEffect(() => {
    if (showTransactionModal) {
      setSelectedAction(null);
      setShowPlayerSearch(false);
      setSelectedPlayer(null);
      setSearchQuery("");
      setChipQuantities({});
      setAmount("");
      setNotes("");

      // Fetch available denominations
      fetch(`${API_BASE_URL}/api/vault-chip-denomination`)
        .then(res => res.json())
        .then(data => {
          setAvailableDenominations(data);
        })
        .catch(error => {
          console.error('Error fetching denominations:', error);
        });
    }
  }, [showTransactionModal]);

  // Reset fill-up fields when user leaves the fill-in flow or closes the transaction modal
  useEffect(() => {
    if (selectedAction !== 'FILL_IN' || !showTransactionModal) {
      // clear fill fields and status
      setFillCashAmount('');
      setFillChipQuantities({});
      setFillSubmitting(false);
      setFillRequestId(null);
      setFillRequestStatus(null);
      setFillStep('cash');
    }
  }, [selectedAction, showTransactionModal]);

  // Reset credit-out fields when user leaves the credit-out flow or closes the transaction modal
  useEffect(() => {
    if (selectedAction !== 'CREDIT_OUT' || !showTransactionModal) {
      // clear credit fields and status
      setCreditCashAmount('');
      setCreditChipQuantities({});
      setCreditSubmitting(false);
      setCreditRequestId(null);
      setCreditRequestStatus(null);
      setCreditStep('cash');
      setShowCreditOut(false);
    }
  }, [selectedAction, showTransactionModal]);

  // Reset values when switching actions
  useEffect(() => {
    setChipQuantities({});
    setAmount("");
    setNotes("");
  }, [selectedAction]);

  // Handler to open modal and fetch history
  const handleOpenHistory = () => {
    setShowHistory(true);
    setHistoryLoading(true);
    fetch(`${API_BASE_URL}/api/cage-session`)// /cage?cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => setHistoryData(data))
      .catch(() => setHistoryData([]))
      .finally(() => setHistoryLoading(false));
  };

  // Fetch TITO details by barcode and populate amount if valid
  const fetchTitoDetails = async (barcode: string) => {
    if (!barcode) return;
    setTitoLoading(true);
    setTitoError(null);
    setTitoValid(false);
    try {
      const res = await fetch(`${API_BASE_URL}/api/tito?barcode=${encodeURIComponent(barcode)}`);
      if (!res.ok) {
        setTitoError('Failed to fetch TITO');
        return;
      }
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) {
        setTitoError('TITO not found');
        return;
      }
      const tito = data[0] as any;
      const status = (tito.status || '').toString().toUpperCase();
      // If already redeemed, show redeemed time & location
      if (status === 'REDEEMED') {
        const redeemedAtRaw = tito.redeemed_at ?? tito.redeemedAt ?? null;
        const redeemedLocation = tito.redeemed_location ?? tito.redeemedLocation ?? '';
        const redeemedAt = redeemedAtRaw ? new Date(redeemedAtRaw) : null;
        const redeemedAtStr = redeemedAt && isFinite(redeemedAt.getTime()) ? redeemedAt.toLocaleString() : 'unknown time';
        setTitoError(`TITO Already redeemed on ${redeemedAtStr}${redeemedLocation ? ` at ${redeemedLocation}` : ''}`);
        return;
      }

      // If status explicitly marked expired, show expiry date if available
      if (status === 'EXPIRED') {
        const validUptoRaw = tito.valid_upto ?? tito.validUpto ?? null;
        if (!validUptoRaw) {
          setTitoError('TITO is Expired');
          return;
        }
        const validUpto = new Date(validUptoRaw);
        const validUptoStr = isFinite(validUpto.getTime()) ? validUpto.toLocaleString() : 'unknown date';
        setTitoError(`TITO Ticket expired on ${validUptoStr}`);
        return;
      }

      // Fallback: if the valid_upto is in the past, treat as expired
      if (tito.valid_upto) {
        const validUpto = new Date(tito.valid_upto);
        if (isFinite(validUpto.getTime()) && validUpto < new Date()) {
          const validUptoStr = validUpto.toLocaleString();
          setTitoError(`TITO Ticket expired on ${validUptoStr}`);
          return;
        }
      }

      if (status !== 'GENERATED') {
        setTitoError(`Invalid TITO status: ${tito.status}`);
        return;
      }
      // ok: populate amount (string) into amount state
      setAmount(String(tito.amount ?? ''));
      setTitoValid(true);
      // store tito id if available for later update
      const foundId = Number(tito.tito_id ?? tito.id ?? tito.TITO_ID ?? null) || null;
      setTitoId(foundId);
      // mark this barcode as successfully fetched to avoid duplicate auto-fetches
      try {
        // lastFetchedBarcodeRef is defined below; safe to set at runtime
        (lastFetchedBarcodeRef as any).current = barcode;
      } catch (e) {
        // ignore if ref not ready
      }
    } catch (err) {
      setTitoError('Network error while fetching TITO');
    } finally {
      setTitoLoading(false);
    }
  };

  // Auto-trigger validation when barcode input stops changing (debounced)
  const lastFetchedBarcodeRef = useRef<string | null>(null);
  const debounceTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const trimmed = titoBarcode ? titoBarcode.trim() : '';
    // clear any existing timer
    if (debounceTimerRef.current) {
      window.clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }

    if (!trimmed) {
      // reset validation states when barcode cleared
      setTitoValid(false);
      setTitoError(null);
      lastFetchedBarcodeRef.current = null;
      setTitoId(null);
      return;
    }

    // If we've already successfully fetched this barcode, don't auto-fetch again
    if (lastFetchedBarcodeRef.current === trimmed) {
      return;
    }

    // debounce auto-check to allow typing to finish
    debounceTimerRef.current = window.setTimeout(() => {
      if (!titoValid && !titoLoading) {
        fetchTitoDetails(trimmed);
      }
    }, 600) as unknown as number;

    return () => {
      if (debounceTimerRef.current) {
        window.clearTimeout(debounceTimerRef.current);
        debounceTimerRef.current = null;
      }
    };
  }, [titoBarcode]);

  // Manual refresh handler: bump the refresh key so the cage data useEffect refires
  const handleManualRefresh = () => {
    setRefreshKey(k => k + 1);
  };

  // Auto-refresh cage details every 60 seconds
  useEffect(() => {
    if (!cageId && cageDetails?.status.toLowerCase() == "open") return;
    const interval = setInterval(() => {
      setRefreshKey(k => k + 1);
    }, 60 * 1000); // 60s
    return () => clearInterval(interval);
  }, [cageId]);

  // Manual refresh is supported via handleManualRefresh which increments refreshKey

  // Handler to open transactions modal and fetch data
  const handleOpenTransactions = () => {
    if (!cageDetails?.gaming_day || !cageId) return;
    setShowTransactions(true);
    setTransactionsLoading(true);
    fetch(`${API_BASE_URL}/api/cage-transaction?gaming_day_id=${cageDetails.gaming_day_id}&cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => setTransactions(data))
      .catch(() => setTransactions([]))
      .finally(() => setTransactionsLoading(false));
  };

  // Handler to open requests modal (placeholder for Requests UI)
  const handleOpenRequests = () => {
    // Refresh requests before showing
    if (!cageId) {
      setRequests([]);
      setShowRequests(true);
      return;
    }
    setRequestsLoading(true);
    fetch(`${API_BASE_URL}/api/cage-vault-requests/open?cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setRequests(data);
        else if (data && Array.isArray(data.data)) setRequests(data.data);
        else setRequests([]);
        // track whether we have any open requests so the nav button can be shown
        try {
          const count = Array.isArray(data) ? data.length : (data && Array.isArray(data.data) ? data.data.length : 0);
          setHasOpenRequests(count > 0);
        } catch (e) {
          setHasOpenRequests(false);
        }
      })
      .catch(() => setRequests([]))
      .finally(() => {
        setRequestsLoading(false);
        setShowRequests(true);
      });
  };

  // Helper to get current user id (session or stored session)
  const getCurrentUserId = (): number | null => {
    try {
      const sid = (session?.user as any)?.user_id ?? (session?.user as any)?.id;
      if (sid) return Number(sid);
      if (typeof window !== 'undefined') {
        const raw = localStorage.getItem('casino_session_v1');
        if (raw) {
          const p = JSON.parse(raw);
          return Number(p?.user?.user_id ?? p?.user?.id ?? null);
        }
      }
      return cageDetails?.changed_by ? Number(cageDetails.changed_by) : null;
    } catch (e) {
      return null;
    }
  };

  // Perform action on a request: accept, reject or revoke
  const performRequestAction = async (
    requestId: number | string,
    type: 'accept' | 'reject' | 'revoke',
    requestObj?: any,
    overrideRemarks?: string
  ): Promise<{ ok: boolean; partial?: boolean; message?: string }> => {
    const id = requestId;
    setActionProcessingId(Number(id));
    setActionErrorMap(prev => ({ ...prev, [id]: '' }));

    const operatorId = getCurrentUserId();
    let status = '';
    let remarks = '';

    // Ensure we have the request object (either passed or fetched)
    let r = requestObj;
    if (!r) {
      try {
        const rres = await fetch(`${API_BASE_URL}/api/cage-vault-requests/${id}`);
        r = await rres.json();
      } catch (e) {
        setActionErrorMap(prev => ({ ...prev, [id]: 'Failed to fetch request details' }));
        setActionProcessingId(null);
        return { ok: false, message: 'Failed to fetch request details' };
      }
    }

    const reqTypeLabel = (r?.request_type || r?.requestType || 'request').toString().toLowerCase() === 'fill' ? 'Fill' : (r?.request_type || r?.requestType || 'Withdraw');

    if (type === 'accept') {
      status = 'CLOSED_CONFIRMED';
      remarks = `Cage Operator/Manager accepted the ${reqTypeLabel} Request`;
    } else if (type === 'reject') {
      status = 'CLOSED_REJECTED';
      remarks = `Cage Operator/Manager rejected the ${reqTypeLabel} Request`;
    } else {
      // revoke
      status = 'CLOSED_REJECTED';
      remarks = `Cage Operator/Manager revoked the ${reqTypeLabel} Request`;
    }

    // allow caller to override the remarks (confirmation modal)
    if (overrideRemarks && overrideRemarks.trim().length > 0) {
      remarks = overrideRemarks.trim();
    }

    try {
      const patchBody: any = { status, remarks };
      // user requested payload key: confirmedBy for the patch
      if (operatorId) patchBody.confirmed_by = operatorId;
      patchBody.confirmed_at = new Date().toISOString();

      const resp = await fetch(`${API_BASE_URL}/api/cage-vault-requests/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patchBody),
      });

      if (!resp.ok) {
        let msg = 'Failed to perform action';
        try {
          const body = await resp.json();
          msg = body?.message || body?.error || JSON.stringify(body) || msg;
        } catch (e) {
          try {
            const text = await resp.text();
            msg = text || msg;
          } catch { }
        }
        setActionErrorMap(prev => ({ ...prev, [id]: String(msg) }));
        setActionProcessingId(null);
        return { ok: false, message: String(msg) };
      }

      // If accepted, apply vault/cage updates (re-use helper functions defined below)
      if (type === 'accept') {
        try {
          const cash_total = Number(r?.cash_amount) || 0;
          let chip_amount = Number(r?.chip_amount) || 0;
          const chipDenoms: Record<string, number> = r?.chip_denominations || r?.chip_denominations_map || {};

          // If chip_amount isn't provided by the request payload, compute it from the denominations map
          if ((!chip_amount || chip_amount === 0) && chipDenoms && Object.keys(chipDenoms).length > 0) {
            try {
              chip_amount = Object.entries(chipDenoms).reduce((sum, [denomStr, qty]) => {
                const denom = Number(denomStr);
                const q = Number(qty) || 0;
                if (!isNaN(denom) && denom > 0) {
                  return sum + denom * q;
                }
                return sum;
              }, 0);
            } catch (_) {
              // fallback to 0 if computation fails
              chip_amount = 0;
            }
          }

          // Fetch vault chips to map denominations to vault ids
          const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
          const vaultChips = await vaultChipRes.json();

          // Build two maps:
          // 1) chipQuantitiesByDenom: denom string -> qty (used to merge into cage chip denominations)
          // 2) chipQuantitiesByVaultId: vault chip id -> qty (used for vault updates / post transactions)
          const chipQuantitiesByVaultId: { [id: number]: number } = {};
          const chipQuantitiesByDenom: { [denom: string]: number } = {};
          Object.entries(chipDenoms || {}).forEach(([denomStr, qty]) => {
            const qtyNum = Number(qty) || 0;
            // denom key for cage merging
            chipQuantitiesByDenom[String(denomStr)] = qtyNum;
            // also map to vault id when possible for vault updates
            const match = vaultChips.find((vc: any) => String(vc.chip_denomination) === String(denomStr));
            if (match) {
              chipQuantitiesByVaultId[match.id] = qtyNum;
            }
          });

          const cage_id_num = Number(cageId);
          const gaming_day_id = cageDetails?.gaming_day_id ?? 0;

          // Determine request type and perform appropriate post-accept updates
          const reqType = (r?.request_type || r?.requestType || '').toString().toLowerCase();

          if (reqType === 'fill' || reqType === 'f') {
            // FILL_IN flow: Vault -> Cage (ADD)
            try {
              const denRes = await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cage_id_num}&gaming_day_id=${gaming_day_id}`);
              const existingCageChipDenoms = await denRes.json();
              // Pass denomination-keyed quantities so existing cage denominations (matched by chip_denomination) are updated
              await updateCageChipDenominationDetails(cage_id_num, gaming_day_id, existingCageChipDenoms, chipQuantitiesByDenom, "ADD");
            } catch (e) {
              // fallback: if fetch fails, create new cage chip denomination entries
              await saveCageChipDenomination({ cage_id: cage_id_num, gaming_day_id, chips: vaultChips, chipQuantities: chipQuantitiesByVaultId });
            }

            // Update cage table balances by adding the incoming amounts to existing balances
            await updateCageTable({ cage_id: cage_id_num, cash_total: cash_total, chip_total: chip_amount, gaming_day_id, performed_by: operatorId ?? 0 });

            // Update vault balance (subtract since vault gave assets)
            await updateVaultBalance({ cash_total, chip_total: chip_amount });

            // Update vault chip denominations (use vault id keyed map)
            await updateVaultChipDenomination({ chips: vaultChips, chipQuantities: chipQuantitiesByVaultId });

            // Post vault transactions (Vault -> Cage)
            await postVaultTransactions({ cage_id: cage_id_num, cash_total, chips: vaultChips, chipQuantities: chipQuantitiesByVaultId, gaming_day_id, performed_by: getCurrentUserId(), authorized_by: getCurrentUserId() });
          } else if (reqType === 'withdraw' || reqType === 'credit_out' || reqType === 'w' || reqType === 'cash_out') {
            // WITHDRAW / CREDIT_OUT flow: Cage -> Vault (DEDUCT from cage, ADD to vault)
            try {
              const denRes = await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cage_id_num}&gaming_day_id=${gaming_day_id}`);
              const existingCageChipDenoms = await denRes.json();
              // Deduct quantities from cage denominations
              await updateCageChipDenominationDetails(cage_id_num, gaming_day_id, existingCageChipDenoms, chipQuantitiesByDenom, "DEDUCT");
            } catch (e) {
              // If fetch fails, we cannot safely deduct cage denominations; surface error
              throw new Error('Failed to fetch existing cage chip denominations for deduction');
            }

            // Subtract amounts from cage by passing negative totals to the additive updater
            await updateCageTable({ cage_id: cage_id_num, cash_total: -cash_total, chip_total: -chip_amount, gaming_day_id, performed_by: operatorId ?? 0 });

            // Add amounts to vault by negating the sign passed to the vault updater (which subtracts by default)
            await updateVaultBalance({ cash_total: -cash_total, chip_total: -chip_amount });

            // For vault denominations, the updater subtracts params.chipQuantities from the vault record.
            // To ADD quantities to the vault (Cage -> Vault), pass negated quantities so the subtraction becomes an addition.
            const vaultChipQuantitiesForUpdate: { [id: number]: number } = {};
            Object.entries(chipQuantitiesByVaultId).forEach(([vid, q]) => {
              vaultChipQuantitiesForUpdate[Number(vid)] = -Number(q);
            });

            await updateVaultChipDenomination({ chips: vaultChips, chipQuantities: vaultChipQuantitiesForUpdate });

            // Post vault transactions (Cage -> Vault) — keep the original positive quantities for human-readable transaction records
            await postVaultTransactions({ cage_id: cage_id_num, cash_total, chips: vaultChips, chipQuantities: chipQuantitiesByVaultId, gaming_day_id, direction: 'CAGE_TO_VAULT', performed_by: getCurrentUserId(), authorized_by: getCurrentUserId() });
          } else {
            // Unknown request type — default to FILL behavior for safety
            try {
              const denRes = await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cage_id_num}&gaming_day_id=${gaming_day_id}`);
              const existingCageChipDenoms = await denRes.json();
              await updateCageChipDenominationDetails(cage_id_num, gaming_day_id, existingCageChipDenoms, chipQuantitiesByDenom, "ADD");
            } catch (e) {
              await saveCageChipDenomination({ cage_id: cage_id_num, gaming_day_id, chips: vaultChips, chipQuantities: chipQuantitiesByVaultId });
            }
            await updateCageTable({ cage_id: cage_id_num, cash_total: cash_total, chip_total: chip_amount, gaming_day_id, performed_by: operatorId ?? 0 });
            await updateVaultBalance({ cash_total, chip_total: chip_amount });
            await updateVaultChipDenomination({ chips: vaultChips, chipQuantities: chipQuantitiesByVaultId });
            await postVaultTransactions({ cage_id: cage_id_num, cash_total, chips: vaultChips, chipQuantities: chipQuantitiesByVaultId, gaming_day_id, performed_by: getCurrentUserId(), authorized_by: getCurrentUserId() });
          }
        } catch (e: any) {
          // If any of the downstream updates fail, attempt to mark the request as partially processed
          const errMsg = String(e?.message ?? e);
          setActionErrorMap(prev => ({ ...prev, [id]: `Action accepted but post-confirm updates failed: ${errMsg}` }));

          // Try to PATCH the request to indicate partial processing (best-effort)
          try {
            const partialRemarks = `${remarks} — PARTIALLY_PROCESSED: ${errMsg}`;
            await fetch(`${API_BASE_URL}/api/cage-vault-requests/${id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              // Backend RequestStatus enum doesn't include a 'CLOSED_PARTIALLY_PROCESSED' value.
              // Use an existing valid closed status (CLOSED_CONFIRMED) and include the
              // PARTIALLY_PROCESSED note in the remarks so the backend records the
              // acceptance while we surface the partial processing detail.
              body: JSON.stringify({ status: 'CLOSED_CONFIRMED', remarks: partialRemarks, confirmedBy: operatorId }),
            });
            // refresh list below
            return { ok: true, partial: true, message: errMsg };
          } catch (patchErr) {
            // Could not mark as partial; surface both errors
            const patchErrMsg = String((patchErr as any)?.message ?? patchErr);
            setActionErrorMap(prev => ({ ...prev, [id]: `Post-confirm updates failed: ${errMsg}; additionally failed to mark request partial: ${patchErrMsg}` }));
            return { ok: false, partial: true, message: `${errMsg}; patchFailed:${patchErrMsg}` };
          }
        }
      }

      // Success — refresh requests
      setActionErrorMap(prev => ({ ...prev, [id]: '' }));
      // re-fetch list (use the same `/open` endpoint as the watcher/handler)
      setRequestsLoading(true);
      fetch(`${API_BASE_URL}/api/cage-vault-requests/open?cage_id=${cageId}`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) setRequests(data);
          else if (data && Array.isArray(data.data)) setRequests(data.data);
          else setRequests([]);
        })
        .catch(() => setRequests([]))
        .finally(() => setRequestsLoading(false));
    } catch (err: any) {
      setActionErrorMap(prev => ({ ...prev, [id]: String(err?.message ?? 'Network error') }));
      setActionProcessingId(null);
      return { ok: false, message: String(err?.message ?? 'Network error') };
    } finally {
      setActionProcessingId(null);
    }

    return { ok: true };
  };

  // Keep a lightweight watcher to determine whether to show the button (fetch silently)
  useEffect(() => {
    if (!cageId) return;
    setRequestsLoading(true);
    fetch(`${API_BASE_URL}/api/cage-vault-requests/open?cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setRequests(data);
        else if (data && Array.isArray(data.data)) setRequests(data.data);
        else setRequests([]);
        // update nav visibility flag
        try {
          const count = Array.isArray(data) ? data.length : (data && Array.isArray(data.data) ? data.data.length : 0);
          setHasOpenRequests(count > 0);
        } catch (e) {
          setHasOpenRequests(false);
        }
      })
      .catch(() => setRequests([]))
      .finally(() => setRequestsLoading(false));
  }, [cageId, refreshKey]);

  useEffect(() => {
    if (!cageId) return;
    setLoading(true);
    fetch(`${API_BASE_URL}/api/cage/${cageId}`)
      .then(res => res.json())
      .then((data) => {
        setCageDetails(data);
        setTotal(data.total || (data.balance as any)?.cash || 'INR 0.00');
        if (data.status.toLocaleLowerCase() === 'closed') {
          setInventoryData([]);
          setTotal(0);
        } else {
          fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cageId}&gaming_day_id=${data.gaming_day_id}`)
            .then(res => res.json())
            .then(inventoryData => {
              let chipArr = Array.isArray(inventoryData)
                ? inventoryData
                  .map((item: any) => ({
                    ...item,
                    type: item.type || 'CHIP',
                  }))
                  .sort((a, b) => Number(b.chip_denomination) - Number(a.chip_denomination)) // Sort descending by chip_denomination
                : [];
              // After you have the final inventory array (chipArr + cashEntry)
              const allItems = [...chipArr];
              if ((data.balance as any)?.cash) {
                const cashEntry: InventoryItem = {
                  id: -1,
                  cage_id: data.cage_id,
                  gaming_day_id: data.gaming_day_id,
                  chip_denomination: "",
                  chip_color: "",
                  quantity: 1,
                  total_value: (data.balance as any).cash,
                  recorded_at: data.last_change || "",
                  cage: data.name || "",
                  gamingDay: data.gamingDay || {},
                  gaming_day_start: data.gaming_day_start || "",
                  gaming_day_end: data.gaming_day_end || "",
                  type: "CASH",
                };
                allItems.push(cashEntry);
              }
              if ((data.balance as any).online > 0) {
                const onlineEntry: InventoryItem = {
                  id: -1,
                  cage_id: data.cage_id,
                  gaming_day_id: data.gaming_day_id,
                  chip_denomination: "",
                  chip_color: "",
                  quantity: 1,
                  total_value: (data.balance as any).online,
                  recorded_at: data.last_change || "",
                  cage: data.name || "",
                  gamingDay: data.gamingDay || {},
                  gaming_day_start: data.gaming_day_start || "",
                  gaming_day_end: data.gaming_day_end || "",
                  type: "ONLINE",
                };
                allItems.push(onlineEntry);
              }
              if ((data.balance as any).tito > 0) {
                const titoEntry: InventoryItem = {
                  id: -1,
                  cage_id: data.cage_id,
                  gaming_day_id: data.gaming_day_id,
                  chip_denomination: "",
                  chip_color: "",
                  quantity: 1,
                  total_value: (data.balance as any).tito,
                  recorded_at: data.last_change || "",
                  cage: data.name || "",
                  gamingDay: data.gamingDay || {},
                  gaming_day_start: data.gaming_day_start || "",
                  gaming_day_end: data.gaming_day_end || "",
                  type: "TITO TICKETS",
                };
                allItems.push(titoEntry);
              }
              setInventoryData(allItems);

              // Calculate total as integer (sum of all total_value fields)
              const totalSum = allItems.reduce(
                (sum, item) => sum + (parseFloat(item.total_value) || 0),
                0
              );
              setTotal(Math.round(totalSum));
            })
            .catch(() => {
              setInventoryData([]);
              setTotal(data.total || data.balance || 'INR 0.00');
            });
        }
      })
      .catch(() => {
        setCageDetails(null);
        setInventoryData([]);
        setTotal(0);
      })
      .finally(() => setLoading(false));
  }, [cageId, refreshKey]);

  if (!cageId) {
    return (
      <div className="w-full max-w-7xl mx-auto p-4 space-y-4">
        <div className="text-center text-gray-500">No cage selected.</div>
      </div>
    );
  }

  // Determine session button properties based on status
  const isOpen = cageDetails?.status.toLocaleLowerCase() === "open";
  const sessionButton = isOpen
    ? {
      text: "STOP SESSION",
      icon: <Square className="w-4 h-4 mr-2" />,
      className: "bg-red-500 text-white hover:bg-red-600",
    }
    : {
      text: "START SESSION",
      icon: <Play className="w-4 h-4 mr-2" />,
      className: "bg-green-600 text-white hover:bg-green-800",
    };

  // Handler for confirming stop session
  const handleConfirmStopSession = async () => {
    // Close modal immediately
    setShowStopSessionModal(false);

    if (!cageId || !cageDetails) return;
    const cage_id_num = Number(cageId);
    const operatorId = getCurrentUserId() ?? 0;
    const gaming_day_id = cageDetails?.gaming_day_id;
    const now = new Date().toISOString();

    try {
      // 1) Fetch vault chip definitions and existing cage chip denominations
      const [vaultChipRes, cageDenRes] = await Promise.all([
        fetch(`${API_BASE_URL}/api/vault-chip-denomination`),
        fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cage_id_num}&gaming_day_id=${gaming_day_id}`),
      ]);
      const vaultChips = await vaultChipRes.json();
      const cageChipDenoms = await cageDenRes.json();

      // Build mappings and totals
      const chipQuantitiesByVaultIdForUpdate: { [id: number]: number } = {}; // negative values to add to vault via updater
      const chipQuantitiesByVaultIdForTx: { [id: number]: number } = {}; // positive values for transaction records
      const chipQuantitiesByDenom: { [denom: string]: number } = {}; // denom -> qty for deducting cage
      let chip_total_value = 0;

      (cageChipDenoms || []).forEach((row: any) => {
        const qty = Number(row.quantity) || 0;
        const denom = Number(row.chip_denomination) || 0;
        if (qty <= 0) return;
        // find matching vault chip id by denomination
        const match = (vaultChips || []).find((vc: any) => String(vc.chip_denomination) === String(row.chip_denomination) || Number(vc.id) === Number(row.chip_id));
        if (match) {
          chipQuantitiesByVaultIdForUpdate[match.id] = -(qty); // negative so vault updater will add
          chipQuantitiesByVaultIdForTx[match.id] = qty; // positive for tx
        }
        chipQuantitiesByDenom[String(row.chip_denomination)] = qty;
        chip_total_value += denom * qty;
      });

      // 2) Update vault chip denominations (add quantities moved from cage)
      if (Object.keys(chipQuantitiesByVaultIdForUpdate).length > 0) {
        await updateVaultChipDenomination({ chips: vaultChips, chipQuantities: chipQuantitiesByVaultIdForUpdate });
      }

      // 3) Update vault balances: add cage balances to vault (vault updater subtracts provided values,
      // so pass negative values to cause an addition)
      const cageCash = Number(typeof (cageDetails?.balance as any) === 'object' ? ((cageDetails?.balance as any)?.cash ?? 0) : (cageDetails?.balance ?? 0)) || 0;
      const cageOnline = Number(cageDetails?.online_balance ?? ((cageDetails?.balance as any)?.online ?? 0)) || 0;
      const cageTito = Number(cageDetails?.tito_balance ?? ((cageDetails?.balance as any)?.tito ?? 0)) || 0;
      const cageChipTotal = chip_total_value;

      // Add balances to vault by passing negatives
      await updateVaultBalance({ cash_total: -cageCash, chip_total: -cageChipTotal, online_total: -cageOnline, tito_total: -cageTito });

      // 4) Update cage chip denominations to deduct all quantities (set to zero)
      if (Object.keys(chipQuantitiesByDenom).length > 0) {
        // fetch latest cage denom rows to supply to helper
        const latestCageDenRes = await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cage_id_num}&gaming_day_id=${gaming_day_id}`);
        const latestCageDenoms = await latestCageDenRes.json();
        await updateCageChipDenominationDetails(cage_id_num, gaming_day_id, latestCageDenoms, chipQuantitiesByDenom, 'DEDUCT');
      }

      // 5) Create cage transaction record for stop session
      const totalMoved = cageCash + cageChipTotal + cageOnline + cageTito;
      await updateCageTransactionTable({
        cage_id: cage_id_num,
        gaming_day_id: gaming_day_id ?? 0,
        player_id: operatorId,
        transaction_type: 'VAULT_MONEY_CREDIT',
        performed_by: operatorId,
        amount: totalMoved,
        payment_method: 'VAULT_TRANSFER',
        notes: `Stop session: moved Cash ${cageCash}, Chips ${cageChipTotal}, Online ${cageOnline}, TITO ${cageTito}`,
        timestamp: now,
        isCageOpenRecord: true,
      });

      // 6) Post vault transactions (Cage -> Vault)
      await postVaultTransactions({ cage_id: cage_id_num, cash_total: cageCash, chips: vaultChips, chipQuantities: chipQuantitiesByVaultIdForTx, gaming_day_id, direction: 'CAGE_TO_VAULT', performed_by: getCurrentUserId(), authorized_by: getCurrentUserId() });

      // 7) Update cage table: set balances to zero and status to CLOSED
      await fetch(`${API_BASE_URL}/api/cage/${cage_id_num}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'CLOSED',
          balance: 0,
          chip_balance: 0,
          online_balance: 0,
          tito_balance: 0,
          opening_balance: 0,
          opening_chip_balance: 0,
          last_change: now,
          gaming_day_id,
          changed_by: operatorId,
          total_in: 0,
          total_out: 0
        }),
      });

      // 8) Optionally update cage session end info if endpoint exists (best-effort)
      try {
        await fetch(`${API_BASE_URL}/api/cage-session`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cage_id: cage_id_num, ended_at: now, closed_by: operatorId }),
        });
      } catch (e) {
        // ignore
      }

      // Refresh UI
      setRefreshKey(k => k + 1);
    } catch (err) {
      console.error('Error stopping session:', err);
      // still refresh to reflect any partial changes
      setRefreshKey(k => k + 1);
    }
  };

  function isDateInRange(dateStr: string, start: Date, end: Date) {
    if (!dateStr) return false;
    const date = new Date(dateStr.replace(" ", "T"));
    return date >= start && date <= end;
  }

  function filterHistoryRows(rows: any[]) {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (historyFilter === 'ALL') return rows;

    switch (historyFilter) {
      case 'TODAY':
        return rows.filter(row =>
          isDateInRange(row.started_at, new Date(today.toDateString()), new Date(today.toDateString() + " 23:59:59")) ||
          isDateInRange(row.ended_at, new Date(today.toDateString()), new Date(today.toDateString() + " 23:59:59"))
        );
      case 'YESTERDAY':
        return rows.filter(row =>
          isDateInRange(row.started_at, new Date(yesterday.toDateString()), new Date(yesterday.toDateString() + " 23:59:59")) ||
          isDateInRange(row.ended_at, new Date(yesterday.toDateString()), new Date(yesterday.toDateString() + " 23:59:59"))
        );
      case 'THIS_MONTH':
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59);
        return rows.filter(row =>
          isDateInRange(row.started_at, monthStart, monthEnd) ||
          isDateInRange(row.ended_at, monthStart, monthEnd)
        );
      case 'CUSTOM':
        if (!customRange.start || !customRange.end) return rows;
        const customStart = new Date(customRange.start + "T00:00:00");
        const customEnd = new Date(customRange.end + "T23:59:59");
        return rows.filter(row =>
          isDateInRange(row.started_at, customStart, customEnd) ||
          isDateInRange(row.ended_at, customStart, customEnd)
        );
      default:
        return rows;
    }
  }

  return (
    <>
      <BackButton />
      <PageBreadcrumb pageTitle="Cage Details" />
      <div className="w-full mx-auto p-1 space-y-4">
        {/* Header Section */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <span className="text-xl font-bold text-gray-800">{cageDetails?.name.toUpperCase()}</span>
              <span className="text-sm text-gray-500 font-medium">(CG - {cageId})</span>
              {cageDetails?.status && <StatusBadge status={cageDetails.status} />}
            </div>
            <div className="flex space-x-2">
              {/* <Button
                size="sm"
                className="bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 text-xs font-bold"
                onClick={handleOpenHistory}
              >
                <History className="w-4 h-4 mr-2" />
                HISTORY
              </Button> */}
              {showCloseBadge && (
                <div className="flex items-center mr-2">
                  <span role="status" aria-live="polite" className="inline-block bg-red-600 text-white text-xs font-bold px-2.5 py-2.5 rounded-full shadow-lg drop-shadow-lg animate-heartbeat">CLOSE CAGE</span>
                </div>
              )}
              <div className="relative inline-block group">
                <button
                  type="button"
                  onClick={handleManualRefresh}
                  className={`inline-flex items-center justify-center w-10 h-10 rounded-full border border-gray-200 bg-white hover:bg-gray-50 shadow-sm transition-shadow focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-blue-300`}
                  aria-label="Refresh"
                >
                  {loading ? (
                    <svg className="w-5 h-5 text-gray-600 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                      <path d="M21 9a9 8 0 10-1.95 7.15" />
                      <path d="M21 2.7v6h-6" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5 text-gray-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                      <path d="M21 9a9 8 0 10-1.95 7.15" />
                      <path d="M21 2.7v6h-6" />
                    </svg>
                  )}
                </button>
                <div className="pointer-events-none absolute -top-8 left-1 transform -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-75 w-32">
                  Refresh Cage Details
                </div>
              </div>
              {!isOpen ? (
                <Button
                  size="sm"
                  className="bg-green-600 text-white hover:bg-green-800 px-4 py-2 text-xs font-bold"
                  onClick={() => setShowSetupModal(true)}
                >
                  <Play className="w-4 h-4 mr-2" />
                  START SESSION
                </Button>
              ) : (
                <Button
                  size="sm"
                  className={`${sessionButton.className} px-4 py-2 text-xs font-bold`}
                  onClick={() => setShowStopSessionModal(true)}
                >
                  {sessionButton.icon}
                  {sessionButton.text}
                </Button>
              )}
            </div>
          </div>

          {/* Info Grid */}
          <div className="bg-gray-100">
            <div className="grid grid-cols-4 gap-1 bg-gray-100 text-xs mb-4">
              {/* <div className="h-full flex flex-col py-4 px-1">
                  <div className="text-gray-500 mb-1 font-medium uppercase text-center">TERMINAL</div>
                  <div className="font-bold text-gray-800 text-center font-large">{cageDetails?.terminal?.replace('-', ' ') || "—"}</div>
                </div> */}
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">GAMING DAY</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.gaming_day?.split(" ")[0] || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">LAST CHANGE</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.last_change || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">CHANGED BY</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.changed_by || "—"}</div>
              </div>
              {/* <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">OWNER</div>
                 <div className="font-bold text-gray-800 text-center">{cageDetails?.owner || "—"}</div> 
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">NO. OF TRANS</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.no_of_trans || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">ACTIVE TIME</div>
                 <div className="font-bold text-gray-800 text-center">{cageDetails?.active_time || "—"}</div> 
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">TRANS/HOUR</div>
                 <div className="font-bold text-gray-800 text-center">{cageDetails?.trans_per_hour || "—"}</div> 
              </div> */}
            </div>
            {/* Navigation Buttons Section */}
            <div className="flex items-center gap-4 bg-gray-100 px-6 py-4 mb-4">
              <Button
                className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
                onClick={handleOpenTransactions}
              >
                TRANSACTIONS
              </Button>
              {/* <Button
                className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
              >
                REPORT
              </Button> */}
              {isOpen && (
                <Button
                  className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
                  onClick={() => {
                    setShowTransactionModal(true);
                    setSelectedAction(null);
                    setShowPlayerSearch(false);
                    setSelectedPlayer(null);
                    setSearchQuery("");
                    setChipQuantities({});
                    setAmount("");
                    setNotes("");
                    setTransactionStep('select-action');
                    setPaymentMethod("");
                  }}
                >
                  PERFORM TRANSACTION
                </Button>
              )}

              {/* Show pending requests button only when there are open requests for this cage */}
              {!requestsLoading && (hasOpenRequests || requests.length > 0) && (
                <Button
                  className="relative !bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
                  onClick={handleOpenRequests}
                >
                  <span className="inline-flex items-center">
                    <span className="pl-1">PENDING REQUESTS</span>
                    <span className="ml-2 w-2 h-2 bg-red-600 rounded-full animate-pulse ring-2 ring-white" aria-hidden="true"></span>
                  </span>
                </Button>
              )}
            </div>
          </div>

          {/* Transaction Modal */}
          {showTransactionModal && (
            <div className="fixed inset-0 z-[1000000] flex items-center justify-center">
              <div className="fixed inset-0 bg-black/30" onClick={() => {
                setShowTransactionModal(false);
                setSelectedAction(null);
                setShowPlayerSearch(false);
                setSelectedPlayer(null);
                setSearchQuery("");
                setChipQuantities({});
                setAmount("");
                setNotes("");
                setTransactionStep('select-action');
                setPaymentMethod("");
              }}></div>
              <div className="bg-white shadow-lg w-[1200px] overflow-hidden relative rounded-lg z-10">
                {/* Main Content Layout */}
                <div className="relative h-[500px] w-full overflow-hidden">
                  {/* Sliding sections */}
                  <div
                    className={`absolute top-0 left-0 h-full w-full flex transition-all duration-500`}
                    style={{ transform: selectedAction ? 'translateX(-33.33333333333333%)' : 'translateX(0)' }}
                  >
                    {/* TOTAL IN (hidden after action) */}
                    <div className={`w-1/3 bg-[#00a100] flex flex-col text-white h-full ${selectedAction ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-all duration-500`}>
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="text-center">
                          <span className="text-md font-medium mb-4 block">TOTAL IN</span>
                          <div className="flex items-baseline justify-center space-x-2 mt-4">
                            <span className="text-2xl font-bold">INR </span>
                            <span className="text-2xl">{cageDetails?.total_in || "0.00"}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* ActionIcons (becomes left after action) */}
                    <div className={`w-1/3 bg-gray-100 relative flex flex-col h-full transition-all duration-500 ${selectedAction ? 'border-r border-gray-300' : ''}`}>
                      <div className="bg-slate-600 h-20 w-full flex flex-col text-white justify-center">
                        <div className="text-center align-middle text-2xl">
                          <span className="text-md font-medium mb-4 block text-center">Select Your Operation</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2 h-[calc(100%-5rem)] items-center justify-center p-4">
                        {['BUY_CHIPS', 'REDEEM_CHIPS', 'BUY_TITO', 'REDEEM_TITO', 'LOAD_CARD', 'CREDIT_OUT', 'FILL_IN'].map((action, idx) => (
                          <ActionIcon
                            key={action}
                            label={action.replace(/_/g, ' ')}
                            icon={
                              action === 'REDEEM_CHIPS' ? 'redeem-chips' :
                                action === 'REDEEM_TITO' ? 'ticket' :
                                  action === 'BUY_TITO' ? 'ticket-buy' :
                                    action === 'LOAD_CARD' ? 'load-card' :
                                      action === 'BUY_CHIPS' ? 'buy-chip' :
                                        action === 'CREDIT_OUT' ? 'cash-out' :
                                          action === 'FILL_IN' ? 'fill' :
                                            ''
                            }
                            className={selectedAction === action ? 'border-green-500 bg-green-100 text-green-700' : ''}
                            onClick={() => {
                              if (action === 'FILL_IN') {
                                setSelectedAction(action);
                                setShowPlayerSearch(false);
                                setTransactionStep('fill-up');
                                setShowCreditOut(false);
                              } else if (action === 'CREDIT_OUT') {
                                setSelectedAction(action);
                                setShowPlayerSearch(false);
                                setTransactionStep('fill-up');
                                setShowCreditOut(true);
                              } else if (action === 'BUY_TITO') {
                                setSelectedAction(action);
                                setShowPlayerSearch(false);
                                setTransactionStep('transaction-details');
                                setShowCreditOut(false);
                              } else if (action === 'REDEEM_TITO') {
                                // For REDEEM_TITO we don't want player selection — show barcode input instead
                                setSelectedAction(action);
                                setShowPlayerSearch(false);
                                setSelectedPlayer(null);
                                setTitoBarcode("");
                                setTitoId(null);
                                setTransactionStep('transaction-details');
                                setShowCreditOut(false);
                              } else {
                                setSelectedAction(action);
                                setShowPlayerSearch(true);
                                setTransactionStep('search-player');
                                setShowCreditOut(false);
                              }
                            }}
                          />
                        ))}
                        <div className="w-full aspect-square" />
                        <div className="w-full aspect-square" />
                      </div>
                    </div>
                    {/* TOTAL OUT (hidden after action) */}
                    <div className={`w-1/3 bg-[#0066ff] flex flex-col text-white h-full ${selectedAction ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-all duration-500`}>
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="text-center">
                          <span className="text-md font-medium mb-4 block">TOTAL OUT</span>
                          <div className="flex items-baseline justify-center space-x-2 mt-4">
                            <span className="text-2xl font-bold">INR </span>
                            <span className="text-2xl">{cageDetails?.total_out || "0.00"}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* Combined section for player search and transaction details */}
                  {selectedAction && showPlayerSearch && (
                    <div className="absolute top-0 left-1/3 h-full w-2/3 bg-white flex flex-col animate-slide-in">
                      {transactionStep === 'search-player' ? (
                        <>
                          <div className="bg-slate-600 h-20 w-full flex items-center justify-between px-4">
                            <button
                              onClick={() => {
                                setSelectedAction(null);
                                setShowPlayerSearch(false);
                                setSelectedPlayer(null);
                                setSearchQuery("");
                              }}
                              className="flex text-white hover:text-gray-200 transition-colors"
                            >
                              <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                              </svg>
                              Back
                            </button>
                            <span className="text-white text-lg font-medium align-middle">Search Player</span>
                            <button
                              onClick={() => {
                                setShowTransactionModal(false);
                                setSelectedAction(null);
                                setShowPlayerSearch(false);
                                setSelectedPlayer(null);
                                setSearchQuery("");
                              }}
                              className="text-white hover:text-gray-200 transition-colors"
                            >
                              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            </button>
                          </div>
                          <div className="p-4">
                            <input
                              type="text"
                              value={searchQuery}
                              onChange={e => {
                                setSearchQuery(e.target.value);
                                setSelectedPlayer(null);
                              }}
                              placeholder="Search player by name or ID..."
                              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                            />
                            <div className="space-y-2 max-h-[250px] overflow-y-auto">
                              {searchQuery.trim() === "" ? (
                                <div className="text-center text-gray-400 py-8">Type to search for a player...</div>
                              ) : playerSearchLoading ? (
                                <div className="text-center text-gray-400 py-8">Searching...</div>
                              ) : playerSearchError ? (
                                <div className="text-center text-red-400 py-8">{playerSearchError}</div>
                              ) : filteredPlayers.length === 0 ? (
                                <div className="text-center text-gray-400 py-8">No players found.</div>
                              ) : (
                                filteredPlayers.map(player => (
                                  <div
                                    key={player.user_id}
                                    className={`p-4 border rounded-md cursor-pointer transition-colors ${selectedPlayer?.user_id === player.user_id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}`}
                                    onClick={() => setSelectedPlayer(player)}
                                  >
                                    <div className="flex justify-between items-center">
                                      <div>
                                        <h3 className="font-medium text-gray-900">Name : {player.full_name}</h3>
                                        <p className="text-sm text-gray-500">Player Id: {player.user_id}</p>
                                      </div>
                                      <div className="text-right">
                                        <p className="text-sm text-gray-500">Balance</p>
                                        <p className="font-medium text-gray-900">INR {player.balance?.toLocaleString?.() ?? player.balance}</p>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                            {(
                              <div className="mt-1 rounded-lg pr-4">
                                <div className="flex justify-end mt-8">
                                  <Button
                                    className="bg-blue-600 text-white hover:bg-blue-700 px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                                    onClick={() => {
                                      setTransactionStep('transaction-details');
                                    }}
                                    disabled={!selectedPlayer || !searchQuery}
                                  >
                                    NEXT
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </>
                      ) : null}
                    </div>
                  )}

                  {/* Fill Up Slider Section (moved from top-level modal) */}
                  {selectedAction === 'FILL_IN' && transactionStep === 'fill-up' ? (
                    <div className="absolute top-0 left-1/3 h-full w-2/3 bg-white flex flex-col animate-slide-in">
                      <div className="bg-slate-600 h-24 w-full flex items-center justify-between px-4">
                        <button
                          onClick={() => {
                            // go back to action selection
                            setSelectedAction(null);
                            setTransactionStep('select-action');
                          }}
                          className="flex text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          Back
                        </button>
                        <span className="text-white text-lg font-medium align-middle">Request Fill In</span>
                        <button
                          onClick={() => {
                            setShowTransactionModal(false);
                            setSelectedAction(null);
                            setTransactionStep('select-action');
                          }}
                          className="text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>

                      <div className="p-5 flex flex-col h-full">
                        {fillStep === 'cash' ? (
                          <>
                            <div className="flex-1 overflow-y-auto">
                              <div className="mb-2">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Cash Amount (INR)</label>
                                <input
                                  type="number"
                                  min={1}
                                  value={fillCashAmount}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    // allow only digits and optional decimal point, disallow negative
                                    const cleaned = e.target.value.replace(/[^0-9.]/g, "");
                                    setFillCashAmount(cleaned);
                                  }}
                                  className="w-full px-4 py-2 border border-gray-300 rounded-md"
                                  placeholder="Enter cash amount to request"
                                />
                              </div>
                            </div>
                            <div className="mt-1 rounded-lg pr-4">
                              <div className="flex justify-end mt-8">
                                <Button
                                  className="bg-blue-600 text-white hover:bg-blue-700 px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                                  onClick={() => setFillStep('chips')}
                                  // Cash is optional for Fill In — allow proceeding to chips even when cash is zero
                                  disabled={false}
                                >
                                  NEXT
                                </Button>
                              </div>
                            </div>
                          </>
                        ) : fillStep === 'chips' ? (
                          <>
                            <div className="flex-1 overflow-y-auto">
                              <div className="mb-0">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Chips (optional)</label>
                                <ChipDenominationSelector
                                  availableDenominations={availableDenominations}
                                  chipQuantities={fillChipQuantities}
                                  onQuantityChange={(denom, qty) => setFillChipQuantities(prev => ({ ...prev, [denom]: qty }))}
                                />
                              </div>
                            </div>
                            <div className="mt-4 flex justify-end">
                              <button className="bg-gray-200 text-gray-800 px-4 py-2 rounded mr-2" onClick={() => setFillStep('cash')}>Back</button>
                              <button
                                className="bg-green-700 text-white px-4 py-2 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                                onClick={() => setFillStep('confirm')}
                                disabled={!(Number(fillCashAmount) > 0 || Object.values(fillChipQuantities || {}).some(q => Number(q) > 0))}
                              >
                                Review
                              </button>
                            </div>
                          </>
                        ) : (
                          // confirm
                          <>
                            <div className="flex-1 overflow-y-auto max-h-80">
                              <h2 className="text-xl font-bold mb-2">Confirm Fill Up Request</h2>
                              <div className="bg-gray-100 p-4 rounded mb-4">
                                <div className="flex justify-between items-center mb-2">
                                  <span className="font-bold text-sm text-gray-500 uppercase">Cash Requested</span>
                                  <span className="font-bold">INR {Number(fillCashAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                                <div className="mb-2">
                                  <div className="font-bold text-sm text-gray-500 uppercase mb-2">Chips Requested</div>
                                  {availableDenominations.filter((denom: any) => (fillChipQuantities[String(denom.chip_denomination)] || 0) > 0).length === 0 ? (
                                    <div className="text-gray-500">No chips requested</div>
                                  ) : (
                                    availableDenominations.filter((denom: any) => (fillChipQuantities[String(denom.chip_denomination)] || 0) > 0).map((denom: any) => (
                                      <div key={denom.id} className="flex justify-between items-center mb-1">
                                        <span>{denom.chip_denomination} x {fillChipQuantities[String(denom.chip_denomination)]}</span>
                                        <span className="font-bold">INR {(Number(denom.chip_denomination) * (fillChipQuantities[String(denom.chip_denomination)] || 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                      </div>
                                    ))
                                  )}
                                </div>
                                <div className="pt-2 border-t mt-2 flex justify-between items-center">
                                  <span className="font-bold text-sm text-gray-500 uppercase">Chips Total</span>
                                  <span className="font-bold">INR {availableDenominations.reduce((sum: number, denom: any) => sum + (Number(denom.chip_denomination) * (fillChipQuantities[String(denom.chip_denomination)] || 0)), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                                <div className="pt-2 border-t mt-2 flex justify-between items-center">
                                  <span className="font-bold text-lg uppercase">Request Total</span>
                                  <span className="font-bold text-lg">INR {(Number(fillCashAmount || 0) + availableDenominations.reduce((sum: number, denom: any) => sum + (Number(denom.chip_denomination) * (fillChipQuantities[String(denom.chip_denomination)] || 0)), 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                              </div>
                            </div>
                            {/* DEBUG <div className="mb-3 p-3 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-900">
                              <div className="font-semibold mb-1">Debug — session user</div>
                              <div>session.user.id: {String(session?.user?.id ?? 'null')}</div>
                              <div>session.user.user_id: {String(((session?.user as any)?.user_id) ?? 'null')}</div>
                              <div>storedSessionUserId: {(() => {
                                try {
                                  if (typeof window === 'undefined') return 'null';
                                  const raw = localStorage.getItem('casino_session_v1');
                                  if (!raw) return 'null';
                                  const p = JSON.parse(raw);
                                  return String(p?.user?.user_id ?? p?.user?.id ?? 'null');
                                } catch (e) {
                                  return 'null';
                                }
                              })()}</div>
                            </div> */}
                            <div className="mt-4 flex justify-end">
                              <button className="bg-gray-200 text-gray-800 px-4 py-2 rounded mr-2" onClick={() => setFillStep('chips')}>Back</button>
                              <button
                                className="bg-green-700 text-white px-4 py-2 rounded"
                                onClick={async () => {
                                  // build chip_denominations object and totals
                                  const chipDenominationsObj: Record<string, number> = {};
                                  let chipAmount = 0;
                                  Object.entries(fillChipQuantities || {}).forEach(([denom, qty]) => {
                                    const q = Number(qty) || 0;
                                    if (q > 0) {
                                      chipDenominationsObj[denom] = q;
                                    }
                                  });
                                  // compute chip amount using availableDenominations mapping (safe fallback)
                                  chipAmount = availableDenominations.reduce((sum: number, d: any) => {
                                    const qty = Number(fillChipQuantities[String(d.chip_denomination)] || 0);
                                    return sum + (Number(d.chip_denomination) * qty);
                                  }, 0);

                                  const cashAmount = Number(fillCashAmount) || 0;
                                  const requestTotal = cashAmount + chipAmount;
                                  // who initiated the request: prefer session.user.user_id, then session.user.id, then stored session, then cageDetails.changed_by
                                  let _storedId: any = null;
                                  try {
                                    if (typeof window !== 'undefined') {
                                      const _raw = localStorage.getItem('casino_session_v1');
                                      if (_raw) {
                                        const _p = JSON.parse(_raw);
                                        _storedId = _p?.user?.user_id ?? _p?.user?.id ?? null;
                                      }
                                    }
                                  } catch (e) {
                                    _storedId = null;
                                  }
                                  const initiatedBy = Number(((session?.user as any)?.user_id ?? session?.user?.id) ?? _storedId ?? cageDetails?.changed_by ?? 0);

                                  const payload = {
                                    request_type: 'FILL',
                                    cage_id: Number(cageId),
                                    vault_id: 1,
                                    amount: requestTotal,
                                    cash_amount: cashAmount,
                                    chip_amount: chipAmount,
                                    chip_denominations: chipDenominationsObj,
                                    initiated_by: initiatedBy,
                                    remarks: 'Fill In Request',
                                    priority: 1,
                                  };

                                  try {
                                    setFillSubmitting(true);
                                    const resp = await fetch(`${API_BASE_URL}/api/cage-vault-requests`, {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify(payload),
                                    });
                                    const data = await resp.json();
                                    const requestId = data?.id || data?.request_id || data?.cage_vault_request_id;
                                    setFillRequestId(requestId || null);
                                    // mark submitted locally
                                    setFillRequestStatus('SUBMITTED');
                                    if (resp.ok) {
                                      setShowRequestResult({ ok: true, message: 'Fill request submitted to vault' });
                                    } else {
                                      const errMsg = data?.message || data?.error || 'Failed to submit request';
                                      setShowRequestResult({ ok: false, message: String(errMsg) });
                                    }
                                  } catch (err) {
                                    console.error('Failed to create cage vault request', err);
                                    setShowRequestResult({ ok: false, message: 'Network error while submitting request' });
                                  } finally {
                                    setFillSubmitting(false);
                                  }
                                }}
                                disabled={fillSubmitting}
                              >
                                {fillSubmitting ? 'Requesting...' : 'Send Request'}
                              </button>
                            </div>
                          </>
                        )}

                        {/* Status / actions after a decision */}
                        {/* Previously we polled for vault decision. That is no longer required; show a transient popup on submit result instead. */}
                        {showRequestResult && (
                          <Modal onClose={() => setShowRequestResult(null)} width="max-w-xl">
                            <div className="p-6 flex flex-col items-center">
                              {showRequestResult.ok ? (
                                <>
                                  <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
                                  <h3 className="text-lg font-bold mb-5 text-center">Request submitted</h3>
                                  <Button onClick={() => {
                                    setShowRequestResult(null);
                                    // close the fill flow
                                    setSelectedAction(null);
                                    setFillCashAmount('');
                                    setFillChipQuantities({});
                                    setTransactionStep('select-action');
                                  }}>OK</Button>
                                </>
                              ) : (
                                <>
                                  <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
                                  <h3 className="text-lg font-bold mb-2 text-center">Request failed</h3>
                                  <p className="text-sm text-gray-600 text-center mb-4">{showRequestResult.message}</p>
                                  <Button onClick={() => setShowRequestResult(null)}>OK</Button>
                                </>
                              )}
                            </div>
                          </Modal>
                        )}
                      </div>
                    </div>

                  ) : null}

                  {/* Credit Out Slider Section (mirror of Fill In but withdraw from cage to vault) */}
                  {selectedAction === 'CREDIT_OUT' && transactionStep === 'fill-up' ? (
                    <div className="absolute top-0 left-1/3 h-full w-2/3 bg-white flex flex-col animate-slide-in">
                      <div className="bg-slate-600 h-24 w-full flex items-center justify-between px-4">
                        <button
                          onClick={() => {
                            // go back to action selection
                            setSelectedAction(null);
                            setTransactionStep('select-action');
                            setShowCreditOut(false);
                          }}
                          className="flex text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          Back
                        </button>
                        <span className="text-white text-lg font-medium align-middle">Request Credit Out</span>
                        <button
                          onClick={() => {
                            setShowTransactionModal(false);
                            setSelectedAction(null);
                            setTransactionStep('select-action');
                            setShowCreditOut(false);
                          }}
                          className="text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>

                      <div className="p-5 flex flex-col h-full">
                        {creditStep === 'cash' ? (
                          <>
                            <div className="flex-1 overflow-y-auto">
                              <div className="mb-2">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Cash Amount (INR) — max available: INR {Number(typeof (cageDetails?.balance as any) === 'object' ? ((cageDetails?.balance as any)?.cash ?? 0) : (cageDetails?.balance ?? 0)).toLocaleString()}</label>
                                <input
                                  type="number"
                                  min={0}
                                  value={creditCashAmount}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    const cleaned = e.target.value.replace(/[^0-9.]/g, "");
                                    // enforce max
                                    const max = Number(typeof (cageDetails?.balance as any) === 'object' ? ((cageDetails?.balance as any)?.cash ?? 0) : (cageDetails?.balance ?? 0)) || 0;
                                    let val = cleaned === '' ? '' : String(Number(cleaned));
                                    if (val !== '' && Number(val) > max) val = String(max);
                                    setCreditCashAmount(val);
                                  }}
                                  className="w-full px-4 py-2 border border-gray-300 rounded-md"
                                  placeholder="Enter cash amount to withdraw (optional)"
                                />
                              </div>
                            </div>
                            <div className="mt-1 rounded-lg pr-4">
                              <div className="flex justify-end mt-8">
                                <Button
                                  className="bg-blue-600 text-white hover:bg-blue-700 px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                                  onClick={() => setCreditStep('chips')}
                                // allow zero cash (optional) but allow proceeding to chips
                                >
                                  NEXT
                                </Button>
                              </div>
                            </div>
                          </>
                        ) : creditStep === 'chips' ? (
                          <>
                            <div className="flex-1 overflow-y-auto">
                              <div className="mb-0">
                                <label className="block text-sm font-medium text-gray-700 mb-1">Chips (optional) — max per denom shown</label>
                                <ChipDenominationSelector
                                  // build denominations from cage inventory (only chip items) and include current quantity as maxQuantity
                                  availableDenominations={inventoryData
                                    .filter(i => i.type === 'CHIP' && Number(i.quantity) > 0)
                                    .map((it: any) => ({ id: it.chip_id ?? it.id, chip_denomination: it.chip_denomination, maxQuantity: Number(it.quantity) || 0 }))}
                                  chipQuantities={creditChipQuantities}
                                  onQuantityChange={(denom, qty) => setCreditChipQuantities(prev => ({ ...prev, [denom]: qty }))}
                                />
                              </div>
                            </div>
                            <div className="mt-4 flex justify-end">
                              <button className="bg-gray-200 text-gray-800 px-4 py-2 rounded mr-2" onClick={() => setCreditStep('cash')}>Back</button>
                              <button
                                className="bg-green-700 text-white px-4 py-2 rounded disabled:opacity-50 disabled:cursor-not-allowed"
                                onClick={() => setCreditStep('confirm')}
                                disabled={!(Number(creditCashAmount) > 0 || Object.values(creditChipQuantities || {}).some(q => Number(q) > 0))}
                              >
                                Review
                              </button>
                            </div>
                          </>
                        ) : (
                          // confirm
                          <>
                            <div className="flex-1 overflow-y-auto max-h-80">
                              <h2 className="text-xl font-bold mb-2">Confirm Credit Out Request</h2>
                              <div className="bg-gray-100 p-4 rounded mb-4">
                                <div className="flex justify-between items-center mb-2">
                                  <span className="font-bold text-sm text-gray-500 uppercase">Cash To Withdraw</span>
                                  <span className="font-bold">INR {Number(creditCashAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                                <div className="mb-2">
                                  <div className="font-bold text-sm text-gray-500 uppercase mb-2">Chips To Withdraw</div>
                                  {inventoryData.filter((denom: any) => (creditChipQuantities[String(Number(denom.chip_denomination))] || 0) > 0).length === 0 ? (
                                    <div className="text-gray-500">No chips selected</div>
                                  ) : (
                                    inventoryData.filter((denom: any) => (creditChipQuantities[String(Number(denom.chip_denomination))] || 0) > 0).map((denom: any) => (
                                      <div key={denom.id} className="flex justify-between items-center mb-1">
                                        <span>{denom.chip_denomination} x {creditChipQuantities[String(Number(denom.chip_denomination))]}</span>
                                        <span className="font-bold">INR {(Number(denom.chip_denomination) * (creditChipQuantities[String(Number(denom.chip_denomination))] || 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                      </div>
                                    ))
                                  )}
                                </div>
                                <div className="pt-2 border-t mt-2 flex justify-between items-center">
                                  <span className="font-bold text-sm text-gray-500 uppercase">Chips Total</span>
                                  <span className="font-bold">INR {inventoryData.reduce((sum: number, d: any) => sum + (Number(d.chip_denomination) * (creditChipQuantities[String(Number(d.chip_denomination))] || 0)), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                                <div className="pt-2 border-t mt-2 flex justify-between items-center">
                                  <span className="font-bold text-lg uppercase">Request Total</span>
                                  <span className="font-bold text-lg">INR {(Number(creditCashAmount || 0) + inventoryData.reduce((sum: number, d: any) => sum + (Number(d.chip_denomination) * (creditChipQuantities[String(Number(d.chip_denomination))] || 0)), 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                </div>
                              </div>
                            </div>
                            <div className="mt-4 flex justify-end">
                              <button className="bg-gray-200 text-gray-800 px-4 py-2 rounded mr-2" onClick={() => setCreditStep('chips')}>Back</button>
                              <button
                                className="bg-green-700 text-white px-4 py-2 rounded"
                                onClick={async () => {
                                  // build chip_denominations object and totals
                                  const chipDenominationsObj: Record<string, number> = {};
                                  let chipAmount = 0;
                                  Object.entries(creditChipQuantities || {}).forEach(([denom, qty]) => {
                                    const q = Number(qty) || 0;
                                    if (q > 0) {
                                      chipDenominationsObj[denom] = q;
                                    }
                                  });
                                  // compute chip amount using inventoryData mapping
                                  chipAmount = inventoryData.reduce((sum: number, d: any) => {
                                    const qty = Number(creditChipQuantities[String(d.chip_denomination)] || 0);
                                    return sum + (Number(d.chip_denomination) * qty);
                                  }, 0);

                                  const cashAmount = Number(creditCashAmount) || 0;
                                  const requestTotal = cashAmount + chipAmount;

                                  // initiated by logic
                                  let _storedId: any = null;
                                  try {
                                    if (typeof window !== 'undefined') {
                                      const _raw = localStorage.getItem('casino_session_v1');
                                      if (_raw) {
                                        const _p = JSON.parse(_raw);
                                        _storedId = _p?.user?.user_id ?? _p?.user?.id ?? null;
                                      }
                                    }
                                  } catch (e) {
                                    _storedId = null;
                                  }
                                  const initiatedBy = Number(((session?.user as any)?.user_id ?? session?.user?.id) ?? _storedId ?? cageDetails?.changed_by ?? 0);

                                  const payload = {
                                    request_type: 'CASH_OUT',
                                    cage_id: Number(cageId),
                                    vault_id: 1,
                                    amount: requestTotal,
                                    cash_amount: cashAmount,
                                    chip_amount: chipAmount,
                                    chip_denominations: chipDenominationsObj,
                                    initiated_by: initiatedBy,
                                    remarks: 'Credit Out Request',
                                    priority: 1,
                                  };

                                  try {
                                    setCreditSubmitting(true);
                                    const resp = await fetch(`${API_BASE_URL}/api/cage-vault-requests`, {
                                      method: 'POST',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify(payload),
                                    });
                                    const data = await resp.json();
                                    const requestId = data?.id || data?.request_id || data?.cage_vault_request_id;
                                    setCreditRequestId(requestId || null);
                                    setCreditRequestStatus('SUBMITTED');
                                    if (resp.ok) {
                                      setShowCreditRequestResult({ ok: true, message: 'Withdraw request submitted to vault' });
                                    } else {
                                      const errMsg = data?.message || data?.error || 'Failed to submit request';
                                      setShowCreditRequestResult({ ok: false, message: String(errMsg) });
                                    }
                                  } catch (err) {
                                    console.error('Failed to create cage vault withdraw request', err);
                                    setShowCreditRequestResult({ ok: false, message: 'Network error while submitting request' });
                                  } finally {
                                    setCreditSubmitting(false);
                                  }
                                }}
                                disabled={creditSubmitting}
                              >
                                {creditSubmitting ? 'Requesting...' : 'Send Request'}
                              </button>
                            </div>
                          </>
                        )}

                        {/* Show credit request result modal */}
                        {showCreditRequestResult && (
                          <Modal onClose={() => setShowCreditRequestResult(null)} width="max-w-xl">
                            <div className="p-6 flex flex-col items-center">
                              {showCreditRequestResult.ok ? (
                                <>
                                  <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
                                  <h3 className="text-lg font-bold mb-5 text-center">Request submitted</h3>
                                  <Button onClick={() => {
                                    setShowCreditRequestResult(null);
                                    setSelectedAction(null);
                                    setCreditCashAmount('');
                                    setCreditChipQuantities({});
                                    setTransactionStep('select-action');
                                    setShowCreditOut(false);
                                  }}>OK</Button>
                                </>
                              ) : (
                                <>
                                  <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
                                  <h3 className="text-lg font-bold mb-2 text-center">Request failed</h3>
                                  <p className="text-sm text-gray-600 text-center mb-4">{showCreditRequestResult.message}</p>
                                  <Button onClick={() => setShowCreditRequestResult(null)}>OK</Button>
                                </>
                              )}
                            </div>
                          </Modal>
                        )}
                      </div>
                    </div>
                  ) : null}

                  {/* Transaction Details Section */}
                  {transactionStep === 'transaction-details' && (
                    <div style={{ height: "500px" }} className="absolute top-0 left-1/3 h-full w-2/3 bg-white flex flex-col animate-slide-in">
                      <div className="bg-gray-600 h-20 w-full flex items-center justify-between px-4">
                        <button
                          onClick={() => {
                            // If REDEEM_TITO was selected we skip player search flow — go back to action selection
                            if (selectedAction === 'REDEEM_TITO') {
                              setSelectedAction(null);
                              setShowPlayerSearch(false);
                              setSelectedPlayer(null);
                              setTitoBarcode("");
                              setTitoId(null);
                              setAmount("");
                              setTransactionStep('select-action');
                            } else {
                              setTransactionStep('search-player');
                            }
                          }}
                          className="flex items-center text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          Back
                        </button>
                        <span className="text-white text-lg font-medium">Transaction Details</span>
                        <button
                          onClick={() => {
                            setShowTransactionModal(false);
                            setSelectedAction(null);
                            setShowPlayerSearch(false);
                            setSelectedPlayer(null);
                            setSearchQuery("");
                            setTransactionStep('select-action');
                          }}
                          className="text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>

                      <div className="p-6">
                        <div className="space-y-4">
                          {(selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') ? (
                            <ChipDenominationSelector
                              availableDenominations={availableDenominations}
                              chipQuantities={chipQuantities}
                              onQuantityChange={(denomination, quantity) => {
                                setChipQuantities(prev => ({
                                  ...prev,
                                  [denomination]: quantity
                                }));
                              }}
                            />
                          ) : selectedAction === 'REDEEM_TITO' ? (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Enter TITO Barcode
                              </label>
                              <div className="flex items-center gap-2">
                                <input
                                  type="text"
                                  value={titoBarcode}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                    setTitoBarcode(e.target.value);
                                    setTitoError(null);
                                    setTitoValid(false);
                                  }}
                                  onBlur={() => {
                                    if (titoBarcode && titoBarcode.trim().length > 0) fetchTitoDetails(titoBarcode.trim());
                                  }}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' && titoBarcode && titoBarcode.trim().length > 0) {
                                      e.preventDefault();
                                      fetchTitoDetails(titoBarcode.trim());
                                    }
                                  }}
                                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  placeholder="Scan or enter barcode"
                                />
                                <button
                                  type="button"
                                  className="px-3 py-2 h-10 bg-blue-600 text-white rounded flex items-center justify-center"
                                  onClick={() => { if (titoBarcode && titoBarcode.trim().length > 0) fetchTitoDetails(titoBarcode.trim()); }}
                                >
                                  Check
                                </button>
                              </div>

                              <div className="mt-2">
                                {titoLoading && <div className="text-sm text-gray-500">Checking barcode...</div>}
                                {titoError && <div className="text-sm text-red-500 mt-1">{titoError}</div>}
                                {titoValid && !titoLoading && <div className="text-sm text-green-600 mt-1">TITO valid — amount loaded</div>}
                              </div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Amount
                              </label>
                              <input
                                type="number"
                                value={amount}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter amount"
                              />
                            </div>
                          ) : (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Amount
                              </label>
                              <input
                                type="number"
                                value={amount}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter amount"
                              />
                            </div>
                          )}
                        </div>

                        <div className="flex justify-end mt-4 space-x-4">
                          {/* <Button
                            variant="outline"
                            onClick={() => setTransactionStep('search-player')}
                          >
                            Back
                          </Button> */}
                          <Button
                            className="bg-green-600 text-white hover:bg-green-700"
                            onClick={() => setTransactionStep('summary')}
                            disabled={
                              selectedAction === 'REDEEM_TITO'
                                ? (!titoValid || !(Number(amount) > 0))
                                : (selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS')
                                  ? Object.values(chipQuantities).every(qty => !qty || qty <= 0)
                                  : (selectedAction === 'CREDIT_OUT' || selectedAction === 'FILL_IN')
                                    ? !(Number(amount) > 0)
                                    : !(Number(amount) > 0)
                            }
                          >
                            Confirm Transaction
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                  {/* Transaction Summary Section */}
                  {transactionStep === 'summary' && (
                    <div style={{ height: "500px" }} className="absolute top-0 left-1/3 h-full w-2/3 bg-white flex flex-col animate-slide-in">
                      <div className="bg-white w-full flex items-center justify-between px-6 pt-6 pb-2">
                        <span className="text-2xl font-bold tracking-[2px]">Summary</span>
                        <button className="text-gray-400 hover:text-gray-600" onClick={() => setShowTransactionModal(false)}>
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                      <div className="p-6 flex flex-col gap-4 overflow-y-auto">
                        {/* DEBUG: Show availableDenominations and chipQuantities */}
                        {/* <div className="mb-4 p-4 bg-yellow-50 border border-yellow-300 rounded">
                          <div className="font-bold mb-2 text-yellow-800">Debug Info</div>
                          <div className="text-xs text-yellow-900">
                            <div><strong>availableDenominations:</strong></div>
                            <pre>{JSON.stringify(availableDenominations, null, 2)}</pre>
                            <div><strong>chipQuantities:</strong></div>
                            <pre>{JSON.stringify(chipQuantities, null, 2)}</pre>
                          </div>
                        </div> */}
                        {/* GAMING DAY */}
                        <div className="bg-gray-100 rounded mb-2">
                          <div className="flex flex-col px-2 py-4 gap-2">
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Player Name</span>
                              <span className="font-bold text-xl">{selectedPlayer ? selectedPlayer.full_name : <span className="text-gray-400">No player selected</span>}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Transaction Type</span>
                              <span className="font-bold text-xl">{selectedAction ? selectedAction.replace(/_/g, ' ') : <span className="text-gray-400">No action selected</span>}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Current Card Balance</span>
                              <span className="font-bold text-xl">{selectedPlayer && typeof selectedPlayer.balance !== 'undefined' ? `INR ${Number(selectedPlayer.balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : <span className="text-gray-400">N/A</span>}</span>
                            </div>
                          </div>
                        </div>
                        {/* CASH (for cash actions) */}
                        {(selectedAction !== 'BUY_CHIPS' && selectedAction !== 'REDEEM_CHIPS') && (
                          <div className="bg-gray-100 rounded mb-2">
                            <div className="flex justify-between items-center px-2 py-4">
                              <span className="font-bold text-base text-gray-500 uppercase">Cash</span>
                              <span className="font-bold text-xl">INR {Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                          </div>
                        )}
                        {/* CHIP (for chip actions) */}
                        {(selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') && (
                          <>
                            <div className="bg-gray-100 mb-2 px-2">
                              <span className="font-bold text-base text-gray-500 uppercase">Chip</span>
                              <div className="mt-2">
                                {availableDenominations.filter((denom: { id: number, chip_denomination: string }) => (chipQuantities[String(denom.chip_denomination)] || 0) > 0).length === 0 ? (
                                  <span className="text-gray-500">No chips selected</span>
                                ) : (
                                  availableDenominations.filter((denom: { id: number, chip_denomination: string }) => (chipQuantities[String(denom.chip_denomination)] || 0) > 0).map((denom: { id: number, chip_denomination: string }) => (
                                    <div key={denom.id} className="flex justify-between items-center mb-1">
                                      <span className="text-lg">{denom.chip_denomination} x {chipQuantities[String(denom.chip_denomination)]}</span>
                                      <span className="font-bold text-lg">INR {(Number(chipQuantities[String(denom.chip_denomination)]) * Number(denom.chip_denomination)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>
                            {/* <div className="bg-gray-100 rounded mb-2">
                              <div className="flex justify-between items-center px-6 py-4">
                                <span className="font-bold text-base text-gray-500 uppercase">Chips Total</span>
                                <span className="font-bold text-xl">INR {availableDenominations.filter((denom: {id: number, chip_denomination: string}) => (chipQuantities[denom.id] || 0) > 0)
                                  .reduce((sum: number, denom: {id: number, chip_denomination: string}) => sum + (Number(chipQuantities[String(denom.chip_denomination)]) * Number(denom.chip_denomination)), 0)
                                  .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div> */}
                          </>
                        )}
                        {/* CAGE TOTAL */}
                        <div className="mt-4 border-t pt-4">
                          <div className="flex justify-between items-center px-2">
                            <span className="font-bold text-xl uppercase">Total</span>
                            <span className="font-bold text-xl">INR {(() => {
                              if (selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') {
                                return availableDenominations.reduce((sum, denom) => sum + (Number(denom.chip_denomination) * (chipQuantities[String(denom.chip_denomination)] || 0)), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                              } else {
                                return Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                              }
                            })()}</span>
                          </div>
                        </div>

                        {/* Payment Method Dropdown - hidden for redeem actions */}
                        {!(selectedAction === 'REDEEM_CHIPS' || selectedAction === 'REDEEM_TITO') && (
                          <div className="mt-4">
                            <label className="block text-sm font-medium text-gray-600 mb-1">
                              Payment Method
                            </label>
                            <select
                              className="w-full border rounded px-3 py-2 text-lg font-bold text-gray-500"
                              value={paymentMethod}
                              onChange={e => setPaymentMethod(e.target.value)}
                            >
                              <option value="">Select Payment Method</option>
                              <option value="Cash">Cash</option>
                              {/* <option value="Chips">Chips</option> */}
                              <option value="UPI">UPI</option>
                              <option value="Credit_Debit_Card">Credit/Debit Card</option>
                              {/* <option value="TITO">TITO Ticket</option> */}
                            </select>
                          </div>
                        )}
                        <div className="flex justify-end mt-8 gap-4">
                          <Button variant="outline" onClick={() => setTransactionStep('transaction-details')}>BACK</Button>
                          <Button
                            variant="primary"
                            onClick={async () => {
                              try {
                                await handleTransactionModalSubmit(
                                  selectedAction,
                                  selectedAction === 'BUY_TITO' ? 0 : (selectedAction === 'REDEEM_TITO' ? (titoBarcode || null) : (selectedPlayer ? selectedPlayer.user_id : 0)),
                                  amount,
                                  notes,
                                  chipQuantities,
                                  availableDenominations,
                                  parseInt(cageId, 10),
                                  cageDetails?.gaming_day_id,
                                  new Date().toISOString(),
                                  paymentMethod,
                                  setRefreshKey,
                                  getCurrentUserId(),
                                  getCurrentUserId()
                                );

                                // After performing the existing transaction updates, if this was a TITO redeem
                                // attempt to mark the TITO as Redeemed via API.
                                if (selectedAction === 'REDEEM_TITO') {
                                  try {
                                    let idToUpdate: number | null = titoId;
                                    // fallback: fetch by barcode to obtain id
                                    if (!idToUpdate && titoBarcode) {
                                      const resp = await fetch(`${API_BASE_URL}/api/tito?barcode=${encodeURIComponent(titoBarcode)}`);
                                      if (resp.ok) {
                                        const arr = await resp.json();
                                        if (Array.isArray(arr) && arr.length > 0) {
                                          idToUpdate = Number(arr[0].tito_id ?? arr[0].id ?? null) || null;
                                        }
                                      }
                                    }

                                    if (idToUpdate) {
                                      await fetch(`${API_BASE_URL}/api/tito/${idToUpdate}`, {
                                        method: 'PUT',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ status: 'Redeemed', redeemed_location: `Cage ${parseInt(cageId, 10)}`, redeemed_at: new Date().toISOString() })
                                      });
                                    } else {
                                      console.warn('TITO id not found; skipping TITO status update');
                                    }
                                  } catch (e) {
                                    console.error('Failed to update TITO status', e);
                                  }
                                }
                              } finally {
                                // close modal in all cases
                                setShowTransactionModal(false);
                              }
                            }}
                            disabled={
                              selectedAction === 'REDEEM_TITO'
                                ? (!titoValid || !(Number(amount) > 0))
                                : (selectedAction === 'REDEEM_CHIPS' ? false : (paymentMethod == ""))
                            }
                          >
                            SUBMIT
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}



          {/* Cage Inventory Table */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl font-bold text-gray-800">Cage Inventory</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {loading ? (
                <div className="py-8 text-center text-gray-500">Loading...</div>
              ) : (
                <>
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-600">
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Type</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Denomination</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Quantity</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Amount</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Base Currency</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inventoryData.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-gray-400 py-6">
                            No inventory data available
                          </TableCell>
                        </TableRow>
                      ) : (
                        inventoryData
                          .filter((item) => {
                            // If quantity is a numeric value and equals 0, omit the row.
                            // Keep the row when quantity is missing or non-numeric.
                            const q = Number(item?.quantity);
                            if (Number.isFinite(q)) {
                              return q !== 0;
                            }
                            return true;
                          })
                          .map((item, index) => (
                            <TableRow key={index} className="hover:bg-gray-50 border-b border-gray-200">
                              <TableCell className="text-center font-medium text-sm py-3">
                                {item.type}
                              </TableCell>
                              <TableCell className="text-center text-sm py-3">
                                {item.type == "CHIP" ? item.chip_denomination
                                  ? parseInt(item.chip_denomination, 10)
                                  : "" : "-"}
                              </TableCell>
                              <TableCell className="text-center text-sm py-3">{item.type == "CHIP" ? item.quantity : "-"}</TableCell>
                              <TableCell className="text-center font-medium text-sm py-3">
                                {/* Show amount with 2 decimals */}
                                {item.total_value
                                  ? Number(item.total_value).toLocaleString(undefined, {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2,
                                  })
                                  : ""}
                              </TableCell>
                              <TableCell className="text-center text-sm py-3">INR</TableCell>
                            </TableRow>
                          ))
                      )}
                    </TableBody>
                  </Table>
                  <div className="flex justify-end mt-4 pt-4 border-t border-gray-200">
                    <div className="text-right">
                      <div className="text-lg text-gray-500 mb-1 font-bold uppercase">
                        TOTAL : <span className="text-lg font-bold text-gray-800">
                          INR {total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* History Modal */}
          {showHistory && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => setShowHistory(false)}>
                <div className="p-6 w-full h-[600px]">
                  <h2 className="text-xl font-bold mb-4">Cage Session History</h2>
                  <div className="flex items-center mb-4">
                    <span className="text-lg font-bold mr-2">{cageDetails?.name?.toUpperCase()}</span>
                    {cageDetails?.status && <StatusBadge status={cageDetails.status} />}
                    <span className="ml-2">{cageDetails?.terminal}</span>
                  </div>
                  <div className="flex gap-2 mb-4">
                    {(['ALL', 'TODAY', 'YESTERDAY', 'THIS_MONTH', 'CUSTOM'] as const).map((filter) => (
                      <Button
                        key={filter}
                        size="sm"
                        className={`rounded-full px-1 py-1 font-semibold transition-all duration-150 ${historyFilter === filter
                          ? "bg-blue-600 text-white shadow"
                          : "bg-gray-200 text-gray-700 hover:bg-blue-100"
                          }`}
                        onClick={() => setHistoryFilter(filter)}
                      >
                        {filter.replace("_", " ")}
                      </Button>
                    ))}
                    {historyFilter === 'CUSTOM' && (
                      <div className="flex items-center gap-2 ml-4">
                        <input
                          type="date"
                          value={customRange.start}
                          onChange={e => setCustomRange(r => ({ ...r, start: e.target.value }))}
                          className="border rounded px-2 py-1 text-sm"
                        />
                        <span className="text-gray-500">to</span>
                        <input
                          type="date"
                          value={customRange.end}
                          onChange={e => setCustomRange(r => ({ ...r, end: e.target.value }))}
                          className="border rounded px-2 py-1 text-sm"
                        />
                      </div>
                    )}
                  </div>
                  <div className="overflow-auto max-h-85">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-600 sticky top-0 z-10">
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Opening Time</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Owner</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">No of Transactions</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Transaction Amount</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Close Time</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Closed By</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {historyLoading ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                          </TableRow>
                        ) : filterHistoryRows(historyData).length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center">No history found</TableCell>
                          </TableRow>
                        ) : (
                          filterHistoryRows(historyData).map((row, idx) => (
                            <TableRow key={idx}>
                              <TableCell className="text-center">{row.started_at}</TableCell>
                              <TableCell className="text-center">{row.opened_by}</TableCell>
                              <TableCell className="text-center">{row.transaction_count}</TableCell>
                              <TableCell className="text-center">INR {row.total_amount}</TableCell>
                              <TableCell className="text-center">{row.ended_at}</TableCell>
                              <TableCell className="text-center">{row.closed_by}</TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-end gap-2 mt-6">
                    <Button variant="outline" onClick={() => setShowHistory(false)}>CANCEL</Button>
                    {/* <Button variant="primary" onClick={() => setShowHistory(false)}>SELECT</Button> */}
                  </div>
                </div>
              </Modal>
            </div>
          )}

          {/* Confirmation modal for request actions */}
          {pendingRequestAction && (
            <div className="fixed inset-0 z-200000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => { setPendingRequestAction(null); setConfirmRemarks(''); }} width="max-w-lg">
                <div className="p-6 w-full">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Confirm {pendingRequestAction.type.toUpperCase()}</h2>
                  </div>
                  <div className="mb-3 text-sm text-gray-700">
                    <div className="mb-2">Request ID : {String(pendingRequestAction.id)}</div>
                    <div className="mb-2">Type: {pendingRequestAction.request?.request_type ?? '-'}</div>
                    <div className="mb-2">Amount: {pendingRequestAction.request?.amount ?? pendingRequestAction.request?.request_total ?? '-'}</div>
                    <div className="mb-2">Initiator: {(pendingRequestAction.request?.initiatedBy?.user?.full_name ?? pendingRequestAction.request?.initiated_by?.user?.full_name ?? pendingRequestAction.request?.initiated_by ?? '-')}</div>
                  </div>

                  <label className="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
                  <textarea
                    className="w-full border rounded p-2 min-h-[80px] text-sm"
                    value={confirmRemarks}
                    onChange={e => setConfirmRemarks(e.target.value)}
                  />

                  <div className="flex justify-end gap-3 mt-4">
                    <Button variant="outline" onClick={() => { setPendingRequestAction(null); setConfirmRemarks(''); }}>Cancel</Button>
                    <Button
                      className="bg-green-600 text-white px-4 py-2"
                      onClick={async () => {
                        if (!pendingRequestAction) return;
                        const { id, type, request } = pendingRequestAction;
                        // Call performRequestAction with override remarks
                        const res = await performRequestAction(id, type, request, confirmRemarks);
                        if (res.ok) {
                          // if partial, message already set in actionErrorMap; close modal
                          setPendingRequestAction(null);
                          setConfirmRemarks('');
                        } else {
                          // keep modal open and show inline message
                          setActionErrorMap(prev => ({ ...prev, [id]: res.message || 'Action failed' }));
                        }
                      }}
                      disabled={actionProcessingId !== null}
                    >
                      {actionProcessingId !== null ? 'Processing...' : 'Confirm'}
                    </Button>
                  </div>
                </div>
              </Modal>
            </div>
          )}

          {/* Initial Setup Modal */}
          <InitialCageSetupModal
            open={showSetupModal}
            onClose={() => setShowSetupModal(false)}
            cageId={cageId}
            onSuccess={() => setRefreshKey(k => k + 1)}
            onSave={async (cash, chips) => {
              const cage_id = Number(cageId);
              const now = new Date().toISOString();
              const changed_by = 1;
              let gaming_day_id = 6;
              try {
                const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
                const data = await resp.json();
                if (data && data.gaming_day_id) {
                  gaming_day_id = data.gaming_day_id;
                }
              } catch { }

              // Save chip denominations
              console.log("Saving chips:", chips);
              const chipEntries = chips
                .filter(chip => chip.quantity > 0)
                .map(chip => ({
                  cage_id,
                  chip_id: chip.id,
                  gaming_day_id,
                  chip_denomination: chip.denomination,
                  chip_color: chip.color,
                  quantity: chip.quantity,
                  total_value: Number(chip.denomination) * Number(chip.quantity),
                  recorded_at: now,
                }));

              await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(chipEntries),
              });

              // Calculate chip total
              const chip_total = chips.reduce(
                (sum, chip) => sum + (Number(chip.denomination) * Number(chip.quantity)),
                0
              );
              const cash_total = Number(cash) || 0;

              // Update Cage table
              await fetch(`${API_BASE_URL}/api/cage/${cage_id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  status: "OPEN",
                  balance: cash_total,
                  chip_balance: chip_total,
                  opening_balance: cash_total,
                  opening_chip_balance: chip_total,
                  total_in: 0,
                  total_out: 0,
                  online_balance: 0,
                  tito_balance: 0,
                  last_change: now,
                  gaming_day_id,
                  changed_by,
                }),
              });

              // Fetch current vault balance
              const vaultResp = await fetch(`${API_BASE_URL}/api/vault-balance/1`);
              const vault = await vaultResp.json();

              // Calculate new vault balances
              const new_total_cash = Number(vault.total_cash) - cash_total;
              const new_total_chips = Number(vault.total_chips) - chip_total;
              const new_total_assets = Number(vault.total_assets) - (cash_total + chip_total);

              // Update vault balance
              await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  total_cash: new_total_cash,
                  total_chips: new_total_chips,
                  total_assets: new_total_assets,
                  last_updated: now,
                }),
              });

              // Fetch Vault Chip Denominations Inventory
              const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
              const vaultChips = await vaultChipRes.json();

              // Prepare the update array
              const vaultChipUpdates = chips.map(chip => {
                const vaultChip = vaultChips.find((vc: any) => vc.id === chip.id);
                const prevQuantity = Number(vaultChip?.actual_quantity) || 0;
                const prevTotalValue = Number(vaultChip?.total_value) || 0;
                const denomination = Number(chip.denomination);

                return {
                  id: chip.id,
                  actual_quantity: prevQuantity - chip.quantity,
                  total_value: prevTotalValue - (chip.quantity * denomination),
                };
              });

              // PUT update to bulk endpoint
              await fetch(`${API_BASE_URL}/api/vault-chip-denomination/bulk`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(vaultChipUpdates),
              });

              // Prepare vault transaction entries
              const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
              // derive actor ids from session (fallback to 0 when unavailable)
              const authorized_by = getCurrentUserId() ?? 0;
              const performed_by = getCurrentUserId() ?? 0;
              const destination = `Cage ${cage_id}`;
              const transaction_time = new Date().toISOString();

              // Cash transaction entry (if any)
              const vaultTransactions = [];
              if (cash_total > 0) {
                vaultTransactions.push({
                  vault_id: 1,
                  transaction_type: "TRANSFER",
                  asset_type: "CASH",
                  denomination: 0,
                  quantity: 0,
                  total_value: cash_total,
                  currency_code: "INR",
                  source: "Vault",
                  destination,
                  reference_id,
                  authorized_by,
                  performed_by,
                  transaction_time,
                  cage_id: cage_id,
                  notes: `Cash of INR ${cash_total} added to Cage ${cage_id}`,
                  gaming_day_id,
                });
              }

              // Chip transaction entries (if any)
              chips
                .filter(chip => chip.quantity > 0)
                .forEach(chip => {
                  vaultTransactions.push({
                    vault_id: 1,
                    transaction_type: "TRANSFER",
                    asset_type: "CHIP",
                    denomination: Number(chip.denomination),
                    quantity: chip.quantity,
                    total_value: Number(chip.denomination) * Number(chip.quantity),
                    currency_code: "INR",
                    source: "Vault",
                    destination,
                    reference_id,
                    authorized_by,
                    performed_by,
                    transaction_time,
                    cage_id: cage_id,
                    notes: `${chip.quantity} Quantity of ${chip.denomination} Denomination added to Cage ${cage_id}`,
                    gaming_day_id,
                  });
                });

              // POST to vault-transaction/bulk
              if (vaultTransactions.length > 0) {
                await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(vaultTransactions),
                });
              }

            }}
          />

          {/* Transactions Modal */}
          {showTransactions && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40 max-w-5xl!">
              <Modal onClose={() => setShowTransactions(false)} height="max-h-7xl">
                <div className="p-6 w-full">
                  <h2 className="text-xl font-bold mb-4">Transactions</h2>
                  {/* Date Filter and Export Row */}
                  <div className="flex flex-wrap items-center justify-between mb-4 gap-2">
                    <div className="flex items-center gap-2">
                      <label htmlFor="txn-date-filter" className="text-sm font-medium">Filter:</label>
                      {(() => {
                        const allowedRoles = [
                          "Cage_Manager",
                          "Casino_Manager",
                          "Casino_Asst_Manager",
                          "Admin",
                          "SuperAdmin",
                          "Super_Admin"
                        ];
                        const userRole = session?.role;
                        const canSeeAllFilters = userRole && allowedRoles.map(r => r.toLowerCase()).includes(userRole.toLowerCase());
                        return (
                          <select
                            id="txn-date-filter"
                            className="border rounded px-2 py-1 text-sm"
                            value={transactionDateFilter}
                            onChange={e => setTransactionDateFilter(e.target.value)}
                          >
                            <option value="TODAY">Today</option>
                            {canSeeAllFilters && <option value="THIS_WEEK">This Week</option>}
                            {canSeeAllFilters && <option value="THIS_MONTH">This Month</option>}
                            {canSeeAllFilters && <option value="ALL">All</option>}
                          </select>
                        );
                      })()}
                    </div>
                    <div className="flex-1 flex justify-end">
                      <div className={filteredTransactions.length === 0 ? 'pointer-events-none opacity-50' : ''}>
                        <ExportToExcel
                          rows={filteredTransactions}
                          columns={[
                            { key: 'transaction_id', label: 'TX ID' },
                            { key: 'payment_method', label: 'Type' },
                            { key: 'player', label: 'Player Name' },
                            { key: 'amount', label: 'Amount' },
                            { key: 'timestamp', label: 'Time' },
                          ]}
                          fileName={`CAGE${cageId}_${(() => {
                            const pad = (n: number) => n.toString().padStart(2, '0');
                            const today = new Date();
                            if (transactionDateFilter === 'TODAY') {
                              return `TODAY_${pad(today.getDate())}${pad(today.getMonth() + 1)}${today.getFullYear()}`;
                            } else if (transactionDateFilter === 'THIS_WEEK') {
                              const start = new Date(today);
                              start.setDate(today.getDate() - today.getDay());
                              const end = new Date(start);
                              end.setDate(start.getDate() + 6);
                              return `THISWEEK_${pad(start.getDate())}${pad(start.getMonth() + 1)}${start.getFullYear()}-${pad(end.getDate())}${pad(end.getMonth() + 1)}${end.getFullYear()}`;
                            } else if (transactionDateFilter === 'THIS_MONTH') {
                              return `THISMONTH_${pad(today.getMonth() + 1)}${today.getFullYear()}`;
                            } else if (transactionDateFilter === 'ALL') {
                              return 'ALL';
                            } else {
                              return transactionDateFilter;
                            }
                          })()}_TRANSACTIONS.CSV`}
                          buttonText="EXPORT TRANSACTIONS"
                          showButton={true}
                          className="px-4 py-2 mt-2 bg-green-600 text-white rounded"
                        />
                      </div>
                    </div>
                  </div>
                  {transactionsLoading ? (
                    <div className="py-8 text-center text-gray-500">Loading...</div>
                  ) : filteredTransactions.length === 0 ? (
                    <div className="py-8 text-center text-gray-500">No transactions found.</div>
                  ) : (
                    <div className="overflow-auto max-h-96">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-600">
                            <TableHead className="font-bold text-white text-xs uppercase text-center">TX ID</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Type</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Player Name</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-right">Amount</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Time</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredTransactions.map((txn, idx) => (
                            <TableRow key={idx}>
                              <TableCell className="text-center">{txn.transaction_id}</TableCell>
                              <TableCell className="text-center">{txn.payment_method}</TableCell>
                              <TableCell className="text-center">{txn.player}</TableCell>
                              <TableCell className="text-right">
                                INR {Number(txn.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </TableCell>
                              <TableCell className="text-center">
                                {new Date(txn.timestamp).toLocaleString("en-GB", {
                                  year: "numeric",
                                  month: "2-digit",
                                  day: "2-digit",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                  second: "2-digit",
                                  hour12: false,
                                  timeZone: "Asia/Kolkata",
                                }).replace(",", "")} IST
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              </Modal>
            </div>
          )}

          {/* Requests Modal (placeholder) */}
          {showRequests && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => setShowRequests(false)} width="max-w-6xl">
                <div className="p-6 w-full">
                  <div className="flex items-center justify-between mb-5">
                    <h2 className="text-xl font-bold">Pending Requests<span className="text-lg font-bold text-gray-500"> ( {requests.length} ) </span></h2>
                  </div>

                  {requestsLoading ? (
                    <div className="py-8 text-center text-gray-500">Loading...</div>
                  ) : requests.length === 0 ? (
                    <div className="py-8 text-center text-gray-500">No open requests for this cage.</div>
                  ) : (
                    <div className="overflow-auto max-h-[60vh] border rounded">
                      <table className="min-w-full text-sm">
                        <thead>
                          <tr className="bg-gray-100">
                            <th className="px-3 py-2 text-left">Request ID</th>
                            <th className="px-3 py-2 text-left">Type</th>
                            <th className="px-3 py-2 text-left">Amount</th>
                            <th className="px-3 py-2 text-left">Cash</th>
                            <th className="px-3 py-2 text-left">Chips</th>
                            <th className="px-3 py-2 text-left">Status</th>
                            <th className="px-3 py-2 text-left">Initiator</th>
                            <th className="px-3 py-2 text-left">Initiated On</th>
                            <th className="px-3 py-2 text-left">Remarks</th>
                            <th className="px-3 py-2 text-left">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {requests.map((r: any) => {
                            const id = r.id ?? r.request_id;
                            return (
                              <tr key={id} className="border-t">
                                <td className="px-3 py-2">{id}</td>
                                <td className="px-3 py-2">{r.request_type}</td>
                                <td className="px-3 py-2">{r.amount ?? r.request_total ?? '-'}</td>
                                <td className="px-3 py-2">{r.cash_amount ?? '-'}</td>
                                <td className="px-3 py-2">{r.chip_amount ?? '-'}</td>
                                <td className="px-3 py-2">{r.status}</td>
                                <td className="px-3 py-2">
                                  {(() => {
                                    try {
                                      // Prefer API's `initiatedBy.user.full_name`, fall back to older shapes
                                      const name = r?.initiatedBy?.user?.full_name
                                        ?? r?.initiated_by?.user?.full_name
                                        ?? r?.initiated_by
                                        ?? r?.initiated_by_id
                                        ?? r?.initiatedBy?.employee_id;
                                      return (name ?? '-') as any;
                                    } catch (e) {
                                      return '-';
                                    }
                                  })()}
                                </td>
                                <td className="px-3 py-2">
                                  {r.requested_at ? (
                                    (() => {
                                      try {
                                        return new Date(r.requested_at).toLocaleString("en-GB", {
                                          year: "numeric",
                                          month: "2-digit",
                                          day: "2-digit",
                                          hour: "2-digit",
                                          minute: "2-digit",
                                          second: "2-digit",
                                          hour12: false,
                                          timeZone: "Asia/Kolkata",
                                        }).replace(",", "") + " IST";
                                      } catch (e) {
                                        return r.requested_at;
                                      }
                                    })()
                                  ) : (
                                    '-'
                                  )}
                                </td>
                                <td className="px-3 py-2">{r.remarks ?? '-'}</td>
                                <td className="px-3 py-2">
                                  {actionErrorMap[id] && (
                                    <div className="text-xs text-red-600 mb-2">{actionErrorMap[id]}</div>
                                  )}
                                  {r.status === 'AWAITING_CAGE_CONFIRMATION' ? (
                                    <div className="flex gap-2">
                                      <Button
                                        className="bg-green-600 text-white px-3 py-1 text-xs hover:bg-green-700"
                                        onClick={() => {
                                          const defaultRemarks = `Cage Operator/Manager accepted the ${((r?.request_type || r?.requestType || 'request').toString().toLowerCase() === 'fill' ? 'Fill' : 'Withdraw')} Request`;
                                          setPendingRequestAction({ id, type: 'accept', request: r, defaultRemarks });
                                          setConfirmRemarks(defaultRemarks);
                                        }}
                                        disabled={actionProcessingId !== null}
                                      >
                                        {actionProcessingId === Number(id) ? 'Processing...' : 'ACCEPT'}
                                      </Button>
                                      <Button
                                        className="bg-red-600 text-white px-3 py-1 text-xs hover:bg-red-700"
                                        onClick={() => {
                                          const defaultRemarks = `Cage Operator/Manager rejected the ${((r?.request_type || r?.requestType || 'request').toString().toLowerCase() === 'fill' ? 'Fill' : 'Withdraw')} Request`;
                                          setPendingRequestAction({ id, type: 'reject', request: r, defaultRemarks });
                                          setConfirmRemarks(defaultRemarks);
                                        }}
                                        disabled={actionProcessingId !== null}
                                      >
                                        {actionProcessingId === Number(id) ? 'Processing...' : 'REJECT'}
                                      </Button>
                                    </div>
                                  ) : (
                                    <div>
                                      <Button
                                        className="bg-yellow-600 text-white px-3 py-1 text-xs hover:bg-yellow-700"
                                        onClick={() => {
                                          const defaultRemarks = `Cage Operator/Manager revoked the ${((r?.request_type || r?.requestType || 'request').toString().toLowerCase() === 'fill' ? 'Fill' : 'Withdraw')} Request`;
                                          setPendingRequestAction({ id, type: 'revoke', request: r, defaultRemarks });
                                          setConfirmRemarks(defaultRemarks);
                                        }}
                                        disabled={actionProcessingId !== null}
                                      >
                                        {actionProcessingId === Number(id) ? 'Processing...' : 'REVOKE REQUEST'}
                                      </Button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <div className="flex justify-end gap-2 mt-6">
                    <Button variant="outline" onClick={() => setShowRequests(false)}>CLOSE</Button>
                  </div>
                </div>
              </Modal>
            </div>
          )}

          {/* Stop Session Confirmation Modal */}
          {showStopSessionModal && (
            <div className="fixed inset-0 z-3000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => setShowStopSessionModal(false)} width="max-w-2xl">
                <div className="p-6 flex flex-col items-center ">
                  <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4" />
                  <h2 className="text-lg font-bold mb-2 text-center">Are you sure you want to Stop the Cage Session?</h2>
                  {/* Inventory Summary Section */}
                  <div className="w-full bg-gray-50 rounded-lg p-4 my-4 border">
                    <div className="mb-2 text-base font-semibold text-gray-700">Cage Inventory Summary</div>
                    <div className="grid grid-cols-2 gap-4 mb-2">
                      <div>
                        <div className="text-xs text-gray-500">Cash Balance</div>
                        <div className="font-bold text-lg text-gray-800">INR {(() => {
                          if (typeof cageDetails?.balance === 'object' && cageDetails?.balance !== null && 'cash' in cageDetails.balance) {
                            return Number((cageDetails.balance as any).cash).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else if (typeof cageDetails?.balance === 'number' || typeof cageDetails?.balance === 'string') {
                            return Number(cageDetails.balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else {
                            return '0.00';
                          }
                        })()}</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">TITO Balance</div>
                        <div className="font-bold text-lg text-gray-800">INR {(() => {
                          if (typeof cageDetails?.balance === 'object' && cageDetails?.balance !== null && 'tito' in cageDetails.balance) {
                            return Number((cageDetails.balance as any).tito).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else if (typeof cageDetails?.tito_balance === 'number' || typeof cageDetails?.tito_balance === 'string') {
                            return Number(cageDetails.tito_balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else {
                            return '0.00';
                          }
                        })()}</div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">Online Balance</div>
                        <div className="font-bold text-lg text-gray-800">INR {(() => {
                          if (typeof cageDetails?.balance === 'object' && cageDetails?.balance !== null && 'online' in cageDetails.balance) {
                            return Number((cageDetails.balance as any).online).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else if (typeof cageDetails?.online_balance === 'number' || typeof cageDetails?.online_balance === 'string') {
                            return Number(cageDetails.online_balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                          } else {
                            return '0.00';
                          }
                        })()}</div>
                      </div>
                    </div>
                    {inventoryData.some(item => item.type === 'CHIP') && (
                      <div className="mb-2">
                        <div className="text-xs text-gray-500 mb-1">Chips by Denomination</div>
                        <div className="overflow-x-auto">
                          <table className="min-w-full text-xs border">
                            <thead>
                              <tr className="bg-gray-100">
                                <th className="px-2 py-1 text-left">Denomination</th>
                                <th className="px-2 py-1 text-left">Quantity</th>
                                <th className="px-2 py-1 text-left">Amount</th>
                              </tr>
                            </thead>
                            <tbody>
                              {inventoryData.filter(item => item.type === 'CHIP').map((item, idx) => (
                                <tr key={idx}>
                                  <td className="px-2 py-1">{item.chip_denomination}</td>
                                  <td className="px-2 py-1">{item.quantity}</td>
                                  <td className="px-2 py-1">INR {Number(item.total_value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                    <div className="flex justify-end mt-2">
                      <div className="text-right">
                        <div className="text-base text-gray-500 mb-1 font-bold uppercase">
                          TOTAL : <span className="text-lg font-bold text-gray-800">
                            INR {(() => {
                              let cash = 0, tito = 0, online = 0;
                              if (typeof cageDetails?.balance === 'object' && cageDetails?.balance !== null) {
                                cash = 'cash' in cageDetails.balance ? Number((cageDetails.balance as any).cash) : 0;
                                tito = 'tito' in cageDetails.balance ? Number((cageDetails.balance as any).tito) : 0;
                                online = 'online' in cageDetails.balance ? Number((cageDetails.balance as any).online) : 0;
                              } else {
                                cash = typeof cageDetails?.balance === 'number' || typeof cageDetails?.balance === 'string' ? Number(cageDetails.balance) : 0;
                                tito = typeof cageDetails?.tito_balance === 'number' || typeof cageDetails?.tito_balance === 'string' ? Number(cageDetails.tito_balance) : 0;
                                online = typeof cageDetails?.online_balance === 'number' || typeof cageDetails?.online_balance === 'string' ? Number(cageDetails.online_balance) : 0;
                              }
                              const chips = inventoryData.filter(i => i.type === 'CHIP').reduce((sum, i) => sum + Number(i.total_value || 0), 0);
                              return (cash + chips + tito + online).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                            })()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-4 mt-6">
                    <Button
                      variant="outline"
                      onClick={() => setShowStopSessionModal(false)}
                      className="flex items-center gap-2"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                      Cancel
                    </Button>
                    <Button
                      variant="primary"
                      onClick={handleConfirmStopSession}
                      className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Confirm
                    </Button>
                  </div>
                </div>
              </Modal>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CageCard;

type SaveCageChipDenominationParams = {
  cage_id: number;
  gaming_day_id: number;
  chips: any[];
  chipQuantities: { [id: number]: number };
};

async function saveCageChipDenomination({
  cage_id,
  gaming_day_id,
  chips,
  chipQuantities,
}: SaveCageChipDenominationParams) {
  const now = new Date().toISOString();
  const chipEntries = chips
    .filter(chip => chipQuantities[chip.id] > 0)
    .map(chip => ({
      cage_id,
      chip_id: chip.id,
      gaming_day_id,
      chip_denomination: chip.chip_denomination,
      chip_color: chip.chip_color,
      quantity: chipQuantities[chip.id],
      total_value: Number(chip.chip_denomination) * chipQuantities[chip.id],
      recorded_at: now,
    }));
  if (chipEntries.length === 0) return;
  const res = await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(chipEntries),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => null);
    throw new Error(`Failed to save cage chip denominations: ${res.status} ${txt || ''}`);
  }
}

async function updateCageTable(params: UpdateCageTableParams) {
  const now = new Date().toISOString();

  // Fetch current cage to compute new balances by adding incoming totals
  let existingCash = 0;
  let existingChips = 0;
  let existingOnline = 0;
  let existingTito = 0;
  // Track whether we successfully computed the chip total from denomination rows
  // (kept in outer scope so it's available below when computing newChips).
  let denomSumUsed = false;
  try {
    const resp = await fetch(`${API_BASE_URL}/api/cage/${params.cage_id}`);
    const data = await resp.json();
    const _b = data.balance as any;
    existingCash = Number(_b?.cash ?? data.balance ?? 0) || 0;
    // Prefer authoritative chip total from cage_chip_denomination records when available
    existingChips = Number(_b?.chips ?? data.chip_balance ?? 0) || 0;
    try {
      const denRes = await fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${params.cage_id}&gaming_day_id=${params.gaming_day_id}`);
      const denData = await denRes.json();
      if (Array.isArray(denData) && denData.length > 0) {
        const denomSum = denData.reduce((sum: number, d: any) => sum + (Number(d.total_value) || (Number(d.chip_denomination) * (Number(d.quantity) || 0)) || 0), 0);
        // Use denomSum if it's a valid number (fallback otherwise)
        if (!isNaN(denomSum)) {
          existingChips = denomSum;
          denomSumUsed = true;
        }
      }
    } catch (e) {
      // ignore denom fetch errors and fall back to existingChips from cage payload
    }
    existingOnline = Number(_b?.online ?? data.online_balance ?? 0) || 0;
    existingTito = Number(_b?.tito ?? data.tito_balance ?? 0) || 0;
  } catch (e) {
    // if fetch fails, treat existing as zero and continue
  }

  const newCash = existingCash + (Number(params.cash_total) || 0);
  // If we were able to compute the chip total from denomination rows (denomSumUsed),
  // that value already reflects any recent denomination updates applied prior to calling
  // updateCageTable. In that case we should set the chip balance to that denom sum
  // instead of adding params.chip_total (which would double-count).
  const newChips = denomSumUsed ? existingChips : (existingChips + (Number(params.chip_total) || 0));

  const body: any = {
    status: "OPEN",
    balance: newCash,
    chip_balance: newChips,
    last_change: now,
    gaming_day_id: params.gaming_day_id,
    changed_by: params.performed_by,
  };

  // Preserve existing online/tito balances by including them if present on the cage
  if (existingOnline !== 0) body.online_balance = existingOnline;
  if (existingTito !== 0) body.tito_balance = existingTito;

  // optionally include total_in / total_out when provided (client computed new totals)
  if (typeof params.total_in !== 'undefined') body.total_in = params.total_in;
  if (typeof params.total_out !== 'undefined') body.total_out = params.total_out;

  const updateResp = await fetch(`${API_BASE_URL}/api/cage/${params.cage_id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!updateResp.ok) {
    const txt = await updateResp.text().catch(() => null);
    throw new Error(`Failed to update cage table: ${updateResp.status} ${txt || ''}`);
  }
}

async function updateCageSessionTable(params: UpdateCageSessionTableParams) {
  const body: any = {
    cage_id: params.cage_id,
    gaming_day_id: params.gaming_day_id,
  };

  if (params.total_amount > 0) {
    body.total_amount = params.total_amount;
  }

  if (params.status == "OPEN") {
    body.started_at = params.transaction_time;
    body.opened_by = params.performed_by;

    const sessionResp = await fetch(`${API_BASE_URL}/api/cage-session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!sessionResp.ok) {
      const txt = await sessionResp.text().catch(() => null);
      throw new Error(`Failed to create cage session: ${sessionResp.status} ${txt || ''}`);
    }
  } else if (params.status === "CLOSE") {
    // body.ended_at = params.transaction_time;
    // body.closed_by = params.performed_by;
  }
}

async function updateCageTransactionTable(params: UpdateCageTransactionTableParams) {
  const body: any = {
    cage_id: params.cage_id,
    gaming_day_id: params.gaming_day_id,
    performed_by: params.performed_by,
    timestamp: params.timestamp,
    amount: params.amount,
    payment_method: params.payment_method,
    transaction_type: params.transaction_type,
    notes: params.notes,
  };

  if (!params.isCageOpenRecord) {
    body.player_id = params.player_id;
  }

  const txnResp = await fetch(`${API_BASE_URL}/api/cage-transaction`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!txnResp.ok) {
    const txt = await txnResp.text().catch(() => null);
    throw new Error(`Failed to insert cage transaction: ${txnResp.status} ${txt || ''}`);
  }
}

async function updateCageDetails(
  cageId: number,
  cageCashBalance: number,
  cageChipsBalance: number,
  transaction_time: string,
  gaming_day_id: number | undefined,
  performed_by: number,
  total_in?: number,
  total_out?: number,
  cageOnlineBalance?: number,
  cageTitoBalance?: number,
) {
  // Build request body
  const body: any = {
    status: "OPEN",
    balance: cageCashBalance,
    chip_balance: cageChipsBalance,
    last_change: transaction_time,
    gaming_day_id,
    changed_by: performed_by,
  };

  if (typeof total_in !== 'undefined') body.total_in = total_in;
  if (typeof total_out !== 'undefined') body.total_out = total_out;
  if (typeof cageOnlineBalance !== 'undefined') body.online_balance = cageOnlineBalance;
  if (typeof cageTitoBalance !== 'undefined') body.tito_balance = cageTitoBalance;

  // Update Cage table
  const resp = await fetch(`${API_BASE_URL}/api/cage/${cageId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    const txt = await resp.text().catch(() => null);
    throw new Error(`Failed to update cage details: ${resp.status} ${txt || ''}`);
  }
}

async function updateCageChipDenominationDetails(cageId: number, gaming_day_id: number | undefined, cageChipDenominationLatest: any, chipQuantities: Record<number, number>, operation: string) {
  const now = new Date().toISOString();
  let requestMethod = 'PUT';
  const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
  const vaultChips = await vaultChipRes.json();
  console.log("Vault Chips:", vaultChips);
  console.log("Chip Quantities:", chipQuantities);
  console.log("Operation:", operation);
  console.log("CageChipDenominationLatest:", cageChipDenominationLatest);

  const chipUpdates = Object.entries(chipQuantities)
    .map(([denomKey, quantity]) => {
      // Robust denomination matching: try exact string, numeric-normalized match,
      // match via existing cage row chip_id, and finally treat denomKey as possible id.
      const normalize = (v: any) => {
        if (v === null || typeof v === 'undefined') return NaN;
        const s = String(v).replace(/[\s,]/g, '');
        const n = parseFloat(s);
        return Number.isFinite(n) ? n : NaN;
      };

      let vaultChip = (vaultChips || []).find((chip: any) => String(chip.chip_denomination) === denomKey);
      if (!vaultChip) {
        // numeric match (handles 10000 vs 10000.00, commas, etc.)
        const targetNum = normalize(denomKey);
        if (!Number.isNaN(targetNum)) {
          vaultChip = (vaultChips || []).find((chip: any) => normalize(chip.chip_denomination) === targetNum);
        }
      }

      if (!vaultChip) {
        // Try to find a cage row that has the denomination, then match by that row's chip_id
        const cageRowMatch = (cageChipDenominationLatest || []).find((r: any) => normalize(r.chip_denomination) === normalize(denomKey));
        if (cageRowMatch) {
          vaultChip = (vaultChips || []).find((vc: any) => Number(vc.id) === Number(cageRowMatch.chip_id));
        }
      }

      if (!vaultChip) {
        // As a last resort, denomKey might actually be an id string
        if (!Number.isNaN(Number(denomKey))) {
          vaultChip = (vaultChips || []).find((vc: any) => Number(vc.id) === Number(denomKey));
        }
      }

      // If we still don't have a vaultChip, log diagnostics and throw a helpful error.
      if (!vaultChip) {
        const msg = `Missing vault chip denomination definition for denom "${denomKey}". Cannot proceed with operation=${operation} for cage ${cageId}.`;
        console.error(msg, { denomKey, chipQuantities, vaultChips, cageChipDenominationLatest });
        throw new Error(msg);
      }

      const cageChip = cageChipDenominationLatest.find(
        (chip: { chip_id: number }) => Number(chip.chip_id) === Number(vaultChip.id)
      );
      console.log("cageChip:", cageChip);
      if (cageChip && quantity > 0) {
        // Conditional logic based on operation
        let finalQuantity = Number(quantity);
        console.log("VaultChip:", vaultChip);
        if (operation === "ADD") {
          finalQuantity = (Number(cageChip.quantity) || 0) + Number(quantity);
        } else if (operation === "DEDUCT") {
          finalQuantity = (Number(cageChip.quantity) || 0) - Number(quantity);
        }
        console.log("finalQuantity:", finalQuantity);
        return {
          id: cageChip.id,
          chip_id: Number(cageChip.chip_id),
          quantity: finalQuantity,
          recorded_at: now,
          total_value: finalQuantity * Number(cageChip.chip_denomination),
        };
      } else if (cageChip == undefined) {
        // If there's no existing cage chip row
        // - For ADD operations we should create a new row
        // - For DEDUCT operations this is an error: you can't deduct a denom that doesn't exist in the cage
        if (operation === "DEDUCT") {
          throw new Error(`Cannot deduct denomination ${denomKey} from cage ${cageId} — missing inventory row`);
        }
        requestMethod = 'POST';
        return {
          cage_id: cageId,
          gaming_day_id: gaming_day_id,
          chip_id: Number(vaultChip.id),
          chip_denomination: Number(vaultChip.chip_denomination),
          chip_color: vaultChip.chip_color,
          quantity: quantity,
          recorded_at: now,
          total_value: quantity * Number(vaultChip.chip_denomination),
        };
      }
      return null;
    })
    .filter(Boolean);

  console.log("Chip Updates:", chipUpdates);
  console.log("Request Method (derived):", requestMethod);

  // Split updates (existing records with id) and creates (new records without id)
  const updates = chipUpdates.filter((u: any) => !!u.id);
  const creates = chipUpdates.filter((u: any) => !u.id);

  // Send updates (PUT) for existing cage denomination records
  if (updates.length > 0) {
    const upResp = await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    if (!upResp.ok) {
      const txt = await upResp.text().catch(() => null);
      throw new Error(`Failed to update cage chip denominations: ${upResp.status} ${txt || ''}`);
    }
  }

  // Send creates (POST) for new cage denomination records
  if (creates.length > 0) {
    const createResp = await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(creates),
    });
    if (!createResp.ok) {
      const txt = await createResp.text().catch(() => null);
      throw new Error(`Failed to create cage chip denominations: ${createResp.status} ${txt || ''}`);
    }
  }
}

async function updatePlayerCard(playerId: number, cashAmount: number) {
  let playerCashBalance = 0;
  await fetch(`${API_BASE_URL}/api/playercard?user_id=${playerId}`)
    .then(res => res.json())
    .then(data => {
      playerCashBalance = Number(data.balance);
    });
  await fetch(`${API_BASE_URL}/api/playercard?user_id=${playerId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: playerId,
      balance: (playerCashBalance + cashAmount),
    }),
  });
}

async function updateVaultBalance(params: UpdateVaultBalanceParams) {
  const now = new Date().toISOString();
  const vaultResp = await fetch(`${API_BASE_URL}/api/vault-balance/1`);
  const vault = await vaultResp.json();
  // Parse numeric fields robustly (in case API returns formatted strings)
  const parseNum = (v: any) => {
    if (v === null || typeof v === 'undefined') return 0;
    if (typeof v === 'number') return v;
    const s = String(v).replace(/[,\s]/g, '');
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : 0;
  };
  const vault_total_cash = parseNum(vault.total_cash);
  const vault_total_chips = parseNum(vault.total_chips);
  const vault_total_assets = parseNum(vault.total_assets);
  const vault_total_online = parseNum(vault.total_online);
  const vault_total_tito = parseNum(vault.total_tito);

  const new_total_cash = vault_total_cash - params.cash_total;
  const new_total_chips = vault_total_chips - params.chip_total;
  const new_total_assets = vault_total_assets - (params.cash_total + params.chip_total);
  const new_total_online = vault_total_online - (params.online_total ?? 0);
  const new_total_tito = vault_total_tito - (params.tito_total ?? 0);
  const vaultPut = await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      total_cash: new_total_cash,
      total_chips: new_total_chips,
      total_assets: new_total_assets,
      total_online: new_total_online,
      total_tito: new_total_tito,
      last_updated: now,
    }),
  });
  if (!vaultPut.ok) {
    const txt = await vaultPut.text().catch(() => null);
    throw new Error(`Failed to update vault balance: ${vaultPut.status} ${txt || ''}`);
  }
}

async function updateVaultChipDenomination(params: UpdateVaultChipDenominationParams) {
  const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
  const vaultChips = await vaultChipRes.json();
  const vaultChipUpdates = params.chips
    .filter(chip => Math.abs(params.chipQuantities[chip.id] || 0) > 0)
    .map(chip => {
      const vaultChip = vaultChips.find((vc: any) => vc.id === chip.id);
      const prevQuantity = Number(vaultChip?.actual_quantity) || 0;
      const prevTotalValue = Number(vaultChip?.total_value) || 0;
      const denomination = Number(chip.chip_denomination);
      // params.chipQuantities[chip.id] may be negative to indicate addition to vault
      return {
        id: chip.id,
        actual_quantity: prevQuantity - (params.chipQuantities[chip.id] || 0),
        total_value: prevTotalValue - ((params.chipQuantities[chip.id] || 0) * denomination),
      };
    });
  if (vaultChipUpdates.length === 0) return;
  const vresp = await fetch(`${API_BASE_URL}/api/vault-chip-denomination/bulk`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(vaultChipUpdates),
  });
  if (!vresp.ok) {
    const txt = await vresp.text().catch(() => null);
    throw new Error(`Failed to update vault chip denominations: ${vresp.status} ${txt || ''}`);
  }
}

async function postVaultTransactions(
  params: PostVaultTransactionsParams & { direction?: 'VAULT_TO_CAGE' | 'CAGE_TO_VAULT'; performed_by?: number | null; authorized_by?: number | null }
) {
  const now = new Date().toISOString();
  const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
  // prefer explicit values passed from caller, otherwise fall back to 0
  const authorized_by = Number(params.authorized_by ?? 0) || 0;
  const performed_by = Number(params.performed_by ?? 0) || 0;
  const direction = params.direction || 'VAULT_TO_CAGE';
  const vaultTransactions: any[] = [];

  // Determine source/destination and note templates based on direction
  const vaultSource = direction === 'VAULT_TO_CAGE' ? 'Vault' : `Cage ${params.cage_id}`;
  const vaultDestination = direction === 'VAULT_TO_CAGE' ? `Cage ${params.cage_id}` : 'Vault';

  if (params.cash_total > 0) {
    const cashNote = direction === 'VAULT_TO_CAGE'
      ? `Cash of INR ${params.cash_total} added to Cage ${params.cage_id}`
      : `Cash of INR ${params.cash_total} moved from Cage ${params.cage_id} to Vault`;
    vaultTransactions.push({
      vault_id: 1,
      transaction_type: "TRANSFER",
      asset_type: "CASH",
      denomination: 0,
      quantity: 0,
      total_value: params.cash_total,
      currency_code: "INR",
      source: vaultSource,
      destination: vaultDestination,
      reference_id,
      authorized_by,
      performed_by,
      transaction_time: now,
      cage_id: params.cage_id,
      notes: cashNote,
      gaming_day_id: params.gaming_day_id,
    });
  }

  params.chips
    .filter(chip => Math.abs(params.chipQuantities[chip.id] || 0) > 0)
    .forEach(chip => {
      const qty = params.chipQuantities[chip.id];
      const chipNote = direction === 'VAULT_TO_CAGE'
        ? `${qty} Quantity of ${chip.chip_denomination} Denomination added to Cage ${params.cage_id}`
        : `${qty} Quantity of ${chip.chip_denomination} Denomination moved from Cage ${params.cage_id} to Vault`;
      vaultTransactions.push({
        vault_id: 1,
        transaction_type: "TRANSFER",
        asset_type: "CHIP",
        denomination: Number(chip.chip_denomination),
        quantity: Math.abs(qty),
        total_value: Number(chip.chip_denomination) * Math.abs(qty),
        currency_code: "INR",
        source: vaultSource,
        destination: vaultDestination,
        reference_id,
        authorized_by,
        performed_by,
        transaction_time: now,
        cage_id: params.cage_id,
        notes: chipNote,
        gaming_day_id: params.gaming_day_id,
      });
    });
  if (vaultTransactions.length === 0) return;
  const bulkResp = await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(vaultTransactions),
  });
  if (!bulkResp.ok) {
    const txt = await bulkResp.text().catch(() => null);
    throw new Error(`Failed to post vault transactions: ${bulkResp.status} ${txt || ''}`);
  }
}

type UpdateCageTableParams = {
  cage_id: number;
  cash_total: number;
  chip_total: number;
  gaming_day_id?: number;
  performed_by: number;
  total_in?: number;
  total_out?: number;
};

type UpdateCageSessionTableParams = {
  cage_id: number;
  gaming_day_id?: number;
  performed_by: number;
  transaction_time: string;
  status: string;
  total_amount: number;
};

type UpdateCageTransactionTableParams = {
  cage_id: number;
  gaming_day_id?: number;
  player_id: number;
  transaction_type: string;
  performed_by: number;
  amount: number;
  payment_method: string;
  notes: string;
  timestamp: string;
  isCageOpenRecord: boolean
};

type UpdateVaultBalanceParams = {
  cash_total: number;
  chip_total: number;
  online_total?: number;
  tito_total?: number;
};

type UpdateVaultChipDenominationParams = {
  chips: any[];
  chipQuantities: { [id: number]: number };
};

type PostVaultTransactionsParams = {
  cage_id: number;
  cash_total: number;
  chips: any[];
  chipQuantities: { [id: number]: number };
  gaming_day_id?: number;
};