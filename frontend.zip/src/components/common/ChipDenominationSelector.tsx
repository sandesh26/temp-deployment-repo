import React from 'react';

interface ChipDenominationSelectorProps {
  // chip_denomination may be a string or number; include optional maxQuantity (current available qty)
  availableDenominations: Array<{ id: number; chip_denomination: string; maxQuantity?: number }>;
  chipQuantities: { [key: string]: number };
  onQuantityChange: (denomination: number, quantity: number) => void;
}

const ChipDenominationSelector: React.FC<ChipDenominationSelectorProps> = ({
  availableDenominations,
  chipQuantities,
  onQuantityChange,
}) => {
  const total = Object.entries(chipQuantities).reduce(
    (sum, [denom, qty]) => sum + (parseInt(denom) * (qty || 0)),
    0
  );

  return (
    <div className="space-y-4">
      <div>
        <div className="rounded-lg border border-gray-200">
          {/* Fixed Header */}
          <div className="sticky top-0 z-10 bg-slate-600 shadow-sm">
            <div className="grid grid-cols-3">
              <div className="py-1 text-center text-white text-base font-semibold uppercase tracking-wider">Denomination</div>
              <div className="py-1 text-center text-white text-base font-semibold uppercase tracking-wider">Quantity</div>
              <div className="py-1 text-center text-white text-base font-semibold uppercase tracking-wider">Amount</div>
            </div>
          </div>

          {/* Scrollable Content */}
          <div style={{ maxHeight: "230px" }} className="overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
            <div className="divide-y divide-gray-200">
              {availableDenominations.map((item) => (
                <div key={item.id} className="grid grid-cols-3 hover:bg-gray-50 border-0">
                  <div className="py-1 text-center">
                    <span className="font-medium text-gray-900">{parseFloat(item.chip_denomination).toLocaleString()}</span>
                  </div>
                  <div className="py-1 flex justify-center">
                    <input
                      type="number"
                      min={0}
                      max={typeof item.maxQuantity !== 'undefined' ? item.maxQuantity : undefined}
                      value={chipQuantities[parseFloat(item.chip_denomination)] || ''}
                      onChange={(e) => {
                        const raw = parseInt(e.target.value || '0') || 0;
                        const max = typeof item.maxQuantity === 'number' ? Number(item.maxQuantity) : Infinity;
                        const qty = Math.max(0, Math.min(max, raw));
                        onQuantityChange(parseFloat(item.chip_denomination), qty);
                      }}
                      className="w-32 py-1 px-3 border border-gray-300 rounded-md text-right focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0"
                    />
                  </div>
                  <div className="py-1 text-right pr-8">
                    <span className="font-medium text-gray-900">
                      {((chipQuantities[parseFloat(item.chip_denomination)] || 0) * parseFloat(item.chip_denomination)).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Total Section */}
        <div className="flex justify-end mt-2">
          <div className="text-right pr-8">
            <div className="flex items-baseline space-x-4">
              <span className="text-base font-semibold text-gray-600 uppercase">Total:</span>
              <span className="text-xl font-bold text-gray-900">
                INR {total.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChipDenominationSelector;
