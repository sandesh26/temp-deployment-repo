"use client";
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import Button from '@/components/ui/button/Button';
import Badge from '@/components/ui/badge/Badge';

const PlayerStats = () => {
  const playerData = {
    accountNo: '0000032',
    name: 'Dom Richard Hawthorne',
    memberSince: '01/05/2012',
    membershipExpiration: 'Never',
    lastEntry: '08/13/2015',
    secondEntry: '07/13/2015',
    address: 'United States, CASINO ROAD 125, NEW YORK',
    distance: '0 km',
    time: '0h 00m',
    credits: '€ 8.070',
    points: '2.739',
    gameTypes: ['104 - Vega Vision (EGT)', '106 - AFRICAN DUSK (ARI)'],
    platinum: 'PLATINUM 07.2015'
  };

  const todayStats = {
    winLoss: '€ 1.154',
    trueWin: '€ 1.126',
    expWin: '€ -6',
    bet: '€ 61',
    promo: '€ 61',
    avgBet: '€ 2.66',
    points: '0',
    playTime: '0h 17m',
    activeTime: '0h 04m',
    cashBack: '€ 0',
    otherCosts: '€ 350',
    netValue: '€ -1.504'
  };

  const historicalData = [
    { period: 'Previous Visit', winLoss: '€ -101', trueWinLoss: '€ -101', expWinLoss: '€ -8', bet: '€ 160', promo: '€ 0', avgBet: '€ 10.00', points: '40', playersCosts: '€ 40', netValue: '€ 61', avgPlaytime: '0h 07m', avgActivePlaytime: '0h 02m' },
    { period: 'This Month', winLoss: '€ -7.342', trueWinLoss: '€ -3.967', expWinLoss: '€ -395', bet: '€ 10.919', promo: '€ 3.375', avgBet: '€ 89.50', points: '1.896', playersCosts: '€ 600', netValue: '€ 6.742', avgPlaytime: '1h 11m', avgActivePlaytime: '0h 02m' },
    { period: 'Previous Month', winLoss: '€ 3.993', trueWinLoss: '€ 5.608', expWinLoss: '€ -5.514', bet: '€ 104.107', promo: '€ 1.615', avgBet: '€ 75.55', points: '67.270', playersCosts: '€ 9.810', netValue: '€ -13.802', avgPlaytime: '1h 43m', avgActivePlaytime: '0h 13m' },
    { period: 'Last 30 days', winLoss: '€ -7.576', trueWinLoss: '€ -3.471', expWinLoss: '€ -461', bet: '€ 11.648', promo: '€ 4.104', avgBet: '€ 43.46', points: '1.886', playersCosts: '€ 2.340', netValue: '€ 5.236', avgPlaytime: '1h 08m', avgActivePlaytime: '0h 04m' },
    { period: 'This year', winLoss: '€ -144.588', trueWinLoss: '€ -133.626', expWinLoss: '€ -80.699', bet: '€ 1.530.792', promo: '€ 10.962', avgBet: '€ 62.30', points: '530.653', playersCosts: '€ 17.636', netValue: '€ 126.952', avgPlaytime: '2h 17m', avgActivePlaytime: '0h 22m' },
    { period: 'Lifetime', winLoss: '€ -222.167', trueWinLoss: '€ -184.904', expWinLoss: '€ -319.137', bet: '€ 2.770.544', promo: '€ 37.263', avgBet: '€ 31.59', points: '1.359.394', playersCosts: '€ 36.674', netValue: '€ 185.493', avgPlaytime: '0h 18m', avgActivePlaytime: '0h 18m' }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto p-4 space-y-4 bg-gray-50">
      {/* Header with Player Info */}
      <Card className="bg-white">
        <CardContent className="p-6">
          <div className="flex items-start space-x-6">
            {/* Player Photo */}
            <div className="relative">
              <div className="w-32 h-40 bg-gray-300 rounded overflow-hidden">
                <img 
                  src="/lovable-uploads/12415086-08d1-450f-bfc6-3df704454870.png" 
                  alt="Player Photo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 text-white text-xs text-center py-1">
                {playerData.platinum}
              </div>
            </div>

            {/* Player Details */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="text-sm text-gray-500 mb-1">Account No: {playerData.accountNo}</div>
                  <div className="flex items-center space-x-2 mb-2">
                    <h1 className="text-xl font-bold">{playerData.name}</h1>
                    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">!</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 mb-3">
                    {[1,2,3,4,5].map((star, index) => (
                      <span key={index} className={`text-lg ${index === 0 ? 'text-yellow-400' : 'text-gray-300'}`}>★</span>
                    ))}
                  </div>
                  <div className="text-sm text-gray-600 mb-4">{playerData.address}</div>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span>🚗 {playerData.distance}</span>
                    <span>⏱️ {playerData.time}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="text-green-600 border-green-600">📱</Button>
                  <Button variant="outline" size="sm" className="text-green-600 border-green-600">@</Button>
                  <Button variant="outline" size="sm" className="text-green-600 border-green-600">✉️</Button>
                  <Button variant="outline" size="sm" className="text-gray-600">📄</Button>
                  <Button variant="outline" size="sm" className="text-gray-600">💬</Button>
                </div>
              </div>

              {/* Membership Info */}
              <div className="grid grid-cols-4 gap-4 text-sm mb-4">
                <div>
                  <div className="text-gray-500">Member Since</div>
                  <div className="font-medium">{playerData.memberSince}</div>
                </div>
                <div>
                  <div className="text-gray-500">Membership Expiration</div>
                  <div className="font-medium">{playerData.membershipExpiration}</div>
                </div>
                <div>
                  <div className="text-gray-500">Last Entry</div>
                  <div className="font-medium">{playerData.lastEntry}</div>
                </div>
                <div>
                  <div className="text-gray-500">Second Entry</div>
                  <div className="font-medium">{playerData.secondEntry}</div>
                </div>
              </div>
            </div>

            {/* Current Stats */}
            <div className="bg-gray-100 p-4 rounded">
              <div className="text-center text-sm text-gray-500 mb-2">Current</div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-gray-500">Credits</div>
                  <div className="font-bold">{playerData.credits}</div>
                </div>
                <div>
                  <div className="text-gray-500">Points</div>
                  <div className="font-bold">{playerData.points}</div>
                </div>
              </div>
              <div className="mt-4 text-xs">
                {playerData.gameTypes.map((game, index) => (
                  <div key={index} className="text-gray-600">{game}</div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts Section */}
      <div className="grid grid-cols-6 gap-4">
        {/* Charts placeholders */}
        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Bets</div>
            <div className="h-20 bg-blue-100 rounded flex items-end justify-center space-x-1">
              {[40, 60, 30, 70, 50].map((height, i) => (
                <div key={i} className="w-2 bg-blue-500" style={{height: `${height}%`}}></div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Visits</div>
            <div className="h-20 bg-green-100 rounded flex items-end justify-center space-x-1">
              {[60, 80, 70, 90, 85].map((height, i) => (
                <div key={i} className="w-2 bg-green-500" style={{height: `${height}%`}}></div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Recency</div>
            <div className="h-20 bg-teal-100 rounded flex items-center justify-center">
              <div className="text-2xl font-bold text-white bg-teal-500 px-3 py-1 rounded">
                0<div className="text-xs">AVG 1.8</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Win/Loss</div>
            <div className="h-20 bg-gray-100 rounded flex items-end justify-center space-x-1">
              {[30, 40, 60, 35, 50].map((height, i) => (
                <div key={i} className="w-2 bg-gray-400" style={{height: `${height}%`}}></div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Exp. Loss Deviation</div>
            <div className="h-20 bg-gray-100 rounded flex items-end justify-center space-x-1">
              {[50, 30, 40, 60, 45].map((height, i) => (
                <div key={i} className="w-2 bg-gray-500" style={{height: `${height}%`}}></div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardContent className="p-4">
            <div className="text-xs text-center mb-2">Game Type</div>
            <div className="h-20 flex items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-red-500 relative">
                <div className="absolute inset-4 bg-white rounded-full"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Statistics */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-12 gap-4 items-center text-sm">
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">Win/Loss</div>
              <div className="font-bold text-green-600">{todayStats.winLoss}</div>
              <div className="text-xs text-gray-400">True Win: {todayStats.trueWin}</div>
              <div className="text-xs text-gray-400">Exp Win: {todayStats.expWin}</div>
            </div>
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">Bet</div>
              <div className="font-bold">{todayStats.bet}</div>
              <div className="text-xs text-gray-400">Promo: {todayStats.promo}</div>
              <div className="text-xs text-gray-400">Avg. Bet: {todayStats.avgBet}</div>
            </div>
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">Points</div>
              <div className="font-bold">{todayStats.points}</div>
            </div>
            <div className="col-span-2">
              <Badge
                size="sm"
                color="success"
              >
                TODAY
              </Badge>
              <div className="text-gray-500 mb-1">PlayTime</div>
              <div className="font-bold">{todayStats.playTime}</div>
              <div className="text-xs text-gray-400">Active: {todayStats.activeTime}</div>
            </div>
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">CashBack</div>
              <div className="font-bold">{todayStats.cashBack}</div>
            </div>
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">Other Costs</div>
              <div className="font-bold">{todayStats.otherCosts}</div>
            </div>
            <div className="col-span-1">
              <div className="text-gray-500 mb-1">Net Value</div>
              <div className="font-bold text-red-600">{todayStats.netValue}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Historical Data Table */}
      <Card>
        <CardContent className="p-6">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2"></th>
                  <th className="text-left py-2">Previous Visit</th>
                  <th className="text-left py-2">This Month</th>
                  <th className="text-left py-2">Previous Month</th>
                  <th className="text-left py-2">Last 30 days</th>
                  <th className="text-left py-2">This year</th>
                  <th className="text-left py-2">Lifetime</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 font-medium">Win/Loss</td>
                  <td className="py-2 text-red-600">€ -101</td>
                  <td className="py-2 text-red-600">€ -7.342</td>
                  <td className="py-2 text-green-600">€ 3.993</td>
                  <td className="py-2 text-red-600">€ -7.576</td>
                  <td className="py-2 text-red-600">€ -144.588</td>
                  <td className="py-2 text-red-600">€ -222.167</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">True Win/Loss</td>
                  <td className="py-2">€ -101</td>
                  <td className="py-2">€ -3.967</td>
                  <td className="py-2">€ 5.608</td>
                  <td className="py-2">€ -3.471</td>
                  <td className="py-2">€ -133.626</td>
                  <td className="py-2">€ -184.904</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Exp. Win/Loss</td>
                  <td className="py-2">€ -8</td>
                  <td className="py-2">€ -395</td>
                  <td className="py-2">€ -5.514</td>
                  <td className="py-2">€ -461</td>
                  <td className="py-2">€ -80.699</td>
                  <td className="py-2">€ -319.137</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Bet</td>
                  <td className="py-2">€ 160</td>
                  <td className="py-2">€ 10.919</td>
                  <td className="py-2">€ 104.107</td>
                  <td className="py-2">€ 11.648</td>
                  <td className="py-2">€ 1.530.792</td>
                  <td className="py-2">€ 2.770.544</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">- Promo</td>
                  <td className="py-2">€ 0</td>
                  <td className="py-2">€ 3.375</td>
                  <td className="py-2">€ 1.615</td>
                  <td className="py-2">€ 4.104</td>
                  <td className="py-2">€ 10.962</td>
                  <td className="py-2">€ 37.263</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Avg. Bet</td>
                  <td className="py-2">€ 10.00</td>
                  <td className="py-2">€ 89.50</td>
                  <td className="py-2">€ 75.55</td>
                  <td className="py-2">€ 43.46</td>
                  <td className="py-2">€ 62.30</td>
                  <td className="py-2">€ 31.59</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Points</td>
                  <td className="py-2">40</td>
                  <td className="py-2">1.896</td>
                  <td className="py-2">67.270</td>
                  <td className="py-2">1.886</td>
                  <td className="py-2">530.653</td>
                  <td className="py-2">1.359.394</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Player's Costs</td>
                  <td className="py-2">€ 40</td>
                  <td className="py-2">€ 600</td>
                  <td className="py-2">€ 9.810</td>
                  <td className="py-2">€ 2.340</td>
                  <td className="py-2">€ 17.636</td>
                  <td className="py-2">€ 36.674</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Net Value</td>
                  <td className="py-2 text-green-600">€ 61</td>
                  <td className="py-2 text-green-600">€ 6.742</td>
                  <td className="py-2 text-red-600">€ -13.802</td>
                  <td className="py-2 text-green-600">€ 5.236</td>
                  <td className="py-2 text-green-600">€ 126.952</td>
                  <td className="py-2 text-green-600">€ 185.493</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Avg. Playtime</td>
                  <td className="py-2">0h 07m</td>
                  <td className="py-2">1h 11m</td>
                  <td className="py-2">1h 43m</td>
                  <td className="py-2">1h 08m</td>
                  <td className="py-2">2h 17m</td>
                  <td className="py-2">0h 18m</td>
                </tr>
                <tr>
                  <td className="py-2 font-medium">Avg. Active Playtime</td>
                  <td className="py-2">0h 02m</td>
                  <td className="py-2">0h 02m</td>
                  <td className="py-2">0h 13m</td>
                  <td className="py-2">0h 04m</td>
                  <td className="py-2">0h 22m</td>
                  <td className="py-2">0h 18m</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlayerStats;
