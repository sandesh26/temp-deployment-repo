"use client";
import React, { useEffect, useState } from 'react';
import { API_BASE_URL } from '@/config/api';
import Button from '@/components/ui/button/Button';

export type RfidPinVerifierProps = {
  // initialRfid can be a string (rfid) or a player-like object
  initialRfid?: any;
  onCancel?: () => void;
  onVerified?: (rfid: string, pin: string, response?: any) => void;
  onFailed?: (rfid: string, pin: string, response?: any) => void;
  // optional amount to check against card balance. If provided, verification will only pass when card balance >= requiredAmount
  requiredAmount?: number | string;
  className?: string;
};

const RfidPinVerifier: React.FC<RfidPinVerifierProps> = ({ initialRfid = null, onCancel, onVerified, onFailed, requiredAmount, className }) => {
  const extractRfid = (val: any) => {
    if (val == null) return '';
    if (typeof val === 'string' || typeof val === 'number') return String(val);
    if (typeof val === 'object') {
      // common direct keys
      const direct = val.rfid ?? val.card_rfid ?? val.rfid_tag ?? val.rfid_code ?? val.rfidNumber ?? val.id ?? val.code ?? null;
      if (direct) return String(direct);
      // nested card object
      if (val.card && (val.card.rfid || val.card.card_rfid)) return String(val.card.rfid ?? val.card.card_rfid);
      // search shallow keys for anything containing 'rfid'
      for (const k of Object.keys(val)) {
        if (/rfid/i.test(k) && val[k]) return String(val[k]);
      }
      // fallback to any string-like property that looks useful
      for (const k of Object.keys(val)) {
        if (typeof val[k] === 'string' && val[k].length > 0) return String(val[k]);
      }
      return '';
    }
    return '';
  };

  const [rfid, setRfid] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [verifying, setVerifying] = useState<boolean>(false);
  const [statusOk, setStatusOk] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [cardInfo, setCardInfo] = useState<any | null>(null);
  const [cardLoading, setCardLoading] = useState<boolean>(false);

  useEffect(() => {
    // Avoid treating a numeric 0 (or string '0') as a valid prefilled RFID — treat it as empty
    if (initialRfid === null || typeof initialRfid === 'undefined' || initialRfid === 0 || initialRfid === '0') {
      setRfid('');
    } else {
      setRfid(extractRfid(initialRfid));
    }
    // Reset verification when RFID changes
    setStatusOk(false);
    setError(null);
  }, [initialRfid]);

  // Fetch card info proactively when RFID input changes so balance is visible before PIN entry
  useEffect(() => {
    let mounted = true;
    const controller = new AbortController();
    const fetchCard = async () => {
      if (!rfid) {
        setCardInfo(null);
        setCardLoading(false);
        return;
      }
      setCardLoading(true);
      try {
        const cardResp = await fetch(`${API_BASE_URL}/api/playercard?rfid_number=${encodeURIComponent(String(rfid))}`, { signal: controller.signal });
        const cardData = await cardResp.json().catch(() => null);
        let card = null;
        if (Array.isArray(cardData) && cardData.length > 0) card = cardData[0];
        else if (cardData && typeof cardData === 'object') {
          if (Array.isArray((cardData as any).data) && (cardData as any).data.length > 0) card = (cardData as any).data[0];
          else if (Array.isArray((cardData as any).results) && (cardData as any).results.length > 0) card = (cardData as any).results[0];
          else if ((cardData as any).card_id || (cardData as any).balance) card = cardData;
          else {
            const arrKey = Object.keys(cardData).find(k => Array.isArray((cardData as any)[k]) && (cardData as any)[k].length > 0);
            if (arrKey) card = (cardData as any)[arrKey][0];
          }
        }
        if (!mounted) return;
        setCardInfo(card);
      } catch (e) {
        if (!mounted) return;
        setCardInfo(null);
      } finally {
        if (!mounted) return;
        setCardLoading(false);
      }
    };
    fetchCard();
    return () => { mounted = false; controller.abort(); };
  }, [rfid]);

  const verify = async () => {
    setVerifying(true);
    setError(null);
    setStatusOk(false);
    try {
      if (!rfid) {
        setError('RFID required');
        setVerifying(false);
        if (onFailed) onFailed(rfid, pin, { status: 'FAIL', message: 'RFID required' });
        return;
      }
      if (!pin) {
        setError('PIN required');
        setVerifying(false);
        if (onFailed) onFailed(rfid, pin, { status: 'FAIL', message: 'PIN required' });
        return;
      }

      const resp = await fetch(`${API_BASE_URL}/api/playercard/verify-pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rfid: String(rfid), pin: String(pin) })
      });
      const data = await resp.json().catch(() => ({}));
      const status = (data?.status || '').toString().toUpperCase();
      if (status === 'OK') {
        // PIN verified. If requiredAmount is provided, fetch card info and validate balance.
          let card = cardInfo ?? null;
          // If we already fetched card info from the input-change effect, reuse it
          if (!card) {
            try {
              const cardResp = await fetch(`${API_BASE_URL}/api/playercard?rfid_number=${encodeURIComponent(String(rfid))}`);
              const cardData = await cardResp.json().catch(() => null);
              if (Array.isArray(cardData) && cardData.length > 0) card = cardData[0];
              else if (cardData && typeof cardData === 'object') {
                if (Array.isArray((cardData as any).data) && (cardData as any).data.length > 0) card = (cardData as any).data[0];
                else if (Array.isArray((cardData as any).results) && (cardData as any).results.length > 0) card = (cardData as any).results[0];
                else if ((cardData as any).card_id || (cardData as any).balance) card = cardData;
                else {
                  const arrKey = Object.keys(cardData).find(k => Array.isArray((cardData as any)[k]) && (cardData as any)[k].length > 0);
                  if (arrKey) card = (cardData as any)[arrKey][0];
                }
              }
            } catch (e) {
              card = null;
            }
            setCardInfo(card);
          }

        const reqAmt = typeof requiredAmount !== 'undefined' && requiredAmount !== null ? Number(String(requiredAmount)) : NaN;
        const cardBalance = card ? Number(String((card?.balance ?? card?.amount ?? 0)).replace(/[^0-9.-]/g, '')) : NaN;

        if (!isNaN(reqAmt)) {
          if (isNaN(cardBalance)) {
            setStatusOk(false);
            const msg = 'Unable to read card balance for amount validation';
            setError(msg);
            if (onFailed) onFailed(rfid, pin, { verifyResponse: data, card });
            setVerifying(false);
            return;
          }
          if (cardBalance < reqAmt) {
            setStatusOk(false);
            const msg = `Insufficient card balance (INR ${cardBalance.toLocaleString()}) for transaction amount INR ${reqAmt}`;
            setError(msg);
            if (onFailed) onFailed(rfid, pin, { verifyResponse: data, card });
            setVerifying(false);
            return;
          }
        }

        // All checks passed
        setStatusOk(true);
        setError(null);
        if (onVerified) onVerified(rfid, pin, { verifyResponse: data, card });
      } else {
        const msg = data?.message || data?.error || 'Invalid PIN';
        setStatusOk(false);
        setError(String(msg));
        if (onFailed) onFailed(rfid, pin, data);
      }
    } catch (e) {
      setError('Network error while verifying PIN');
      setStatusOk(false);
      if (onFailed) onFailed(rfid, pin, { status: 'FAIL', message: 'Network error' });
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className={className}>
      {/* Title centered at top */}
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-center">VERIFY CARD</h3>
      </div>

      {/* RFID on its own line */}
      <div className="mb-3">
        <input
          type="text"
          value={rfid}
          onChange={(e) => { setRfid(e.target.value); }}
          placeholder="RFID"
          className="w-full px-4 h-12 text-lg placeholder-gray-400 bg-white border border-gray-200 rounded-lg shadow-sm"
        />
      </div>

      {/* PIN on its own line */}
      <div className="mb-4">
        <input
          type="password"
          value={pin}
          onChange={(e) => { setPin(e.target.value); }}
          placeholder="PIN"
          className="w-full px-4 h-12 text-lg placeholder-gray-400 border border-gray-200 rounded-lg shadow-sm"
        />
      </div>

      {/* Validate button on next line */}
      <div className="flex justify-center gap-4">
        <button
          type="button"
          onClick={() => { if (typeof onCancel === 'function') onCancel(); }}
          className="h-12 px-6 rounded-lg bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
        >
          CANCEL
        </button>

        <Button
          onClick={verify}
          disabled={
            verifying || !rfid || !pin || (
              // disable if card balance is known and insufficient for requiredAmount
              (typeof requiredAmount !== 'undefined' && requiredAmount !== null) && (!isNaN(Number(requiredAmount)) && !isNaN(Number(String(cardInfo?.balance ?? cardInfo?.amount ?? NaN))) && (Number(String(cardInfo?.balance ?? cardInfo?.amount ?? 0)) < Number(requiredAmount)))
            )
          }
          className={`h-12 px-6 rounded-lg ${verifying || !rfid || !pin ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700'}`}>
          {verifying ? 'Verifying...' : (statusOk ? 'Verified' : 'VALIDATE')}
        </Button>
        {cardInfo && (
          <div className="text-sm text-gray-700 mt-2">Card balance: INR {Number(String(cardInfo?.balance ?? cardInfo?.amount ?? 0)).toLocaleString()}</div>
        )}
      </div>
    </div>
  );
};

export default RfidPinVerifier;
