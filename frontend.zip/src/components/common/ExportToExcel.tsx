import React, { forwardRef, useImperativeHandle } from 'react';

type Column = { key: string; label: string };

interface ExportProps {
  rows: any[];
  columns: Column[];
  visibleColumns?: string[];
  getCellValue?: (row: any, key: string) => any;
  fileName?: string;
  className?: string;
  buttonText?: string;
  showButton?: boolean;
}

export interface ExportRef {
  exportCsv: (rowsArg?: any[]) => void;
}

const ExportToExcel = forwardRef<ExportRef, ExportProps>(({
  rows,
  columns,
  visibleColumns,
  getCellValue,
  fileName = 'export.csv',
  className,
  buttonText = 'Export CSV',
  showButton = true,
}, ref) => {
  const buildCsv = (useRows: any[]) => {
    const cols = columns.filter(c => !visibleColumns || visibleColumns.includes(c.key));
    const headers = cols.map(c => c.label);

    const escapeCell = (value: any) => {
      let s = value == null ? '' : String(value);
      if (s.includes('"')) s = s.replace(/"/g, '""');
      if (s.includes(',') || s.includes('\n') || s.includes('\r') || s.includes('"')) return `"${s}"`;
      return s;
    };

    const rowsData = useRows.map(row => cols.map(col => {
      const raw = getCellValue ? getCellValue(row, col.key) : row[col.key];
      return escapeCell(raw);
    }).join(','));

    const csv = [headers.map(escapeCell).join(','), ...rowsData].join('\n');
    return '\uFEFF' + csv;
  };

  const doExport = (rowsArg?: any[]) => {
    try {
      const csv = buildCsv(rowsArg ?? rows);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('Export failed', err);
    }
  };

  useImperativeHandle(ref, () => ({
    exportCsv: (rowsArg?: any[]) => doExport(rowsArg),
  }));

  if (!showButton) return null;

  return (
    <button type="button" onClick={() => doExport()} className={className || 'px-3 py-2 bg-green-600 text-white rounded'}>
      {buttonText}
    </button>
  );
});

export default ExportToExcel;
