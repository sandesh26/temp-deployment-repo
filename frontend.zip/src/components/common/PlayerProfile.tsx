"use client";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import { API_BASE_URL } from "@/config/api";

import React, { useEffect, useState, useRef } from 'react';
import Modal from '@/components/ui/modal/Modal';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

const PlayerProfile = ({ playerId }: { playerId: string }) => {
  const [sessionSearch, setSessionSearch] = useState("");
  // State for paginated sessions
  const [sessions, setSessions] = useState<any[]>([]);
  const [sessionPage, setSessionPage] = useState(1);
  const [sessionTotalPages, setSessionTotalPages] = useState(1);
  const [sessionLoading, setSessionLoading] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<{ type: 'success' | 'error', text: string }|null>(null);
  // Auto-close update message after 2.5s
  React.useEffect(() => {
    if (updateMessage) {
      const timer = setTimeout(() => setUpdateMessage(null), 2500);
      return () => clearTimeout(timer);
    }
  }, [updateMessage]);
  // Fetch paginated sessions
  useEffect(() => {
    if (!playerId) return;
    setSessionLoading(true);
    // Add search param if present
    const searchParam = sessionSearch ? `&game=${encodeURIComponent(sessionSearch)}` : "";
    fetch(`${API_BASE_URL}/api/gametransaction?playerId=${playerId}&page=${sessionPage}&pageSize=10${searchParam}`)
      .then(res => res.json())
      .then(data => {
        setSessions(Array.isArray(data.data) ? data.data : []);
        setSessionTotalPages(data.totalPages || 1);
      })
      .catch(() => {
        setSessions([]);
        setSessionTotalPages(1);
      })
      .finally(() => setSessionLoading(false));
  }, [playerId, sessionPage, sessionSearch]);
  const [playerData, setPlayerData] = useState<any>(null);
  // Modal state
  // UI feedback state
  

  // Auto-close update message after 2.5s
  useEffect(() => {
    if (updateMessage) {
      const timer = setTimeout(() => setUpdateMessage(null), 2500);
      return () => clearTimeout(timer);
    }
  }, [updateMessage]);
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState<any>(null);
  const [originalForm, setOriginalForm] = useState<any>(null); // for change detection
  const [editPhoto, setEditPhoto] = useState<File|null>(null);
  const [editPhotoPreview, setEditPhotoPreview] = useState<string|null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [updateLoading, setUpdateLoading] = useState(false);
  // Profile Tier state
  const [editTier, setEditTier] = useState<string>("");
  const [originalTier, setOriginalTier] = useState<string>("");
  // Validation state
  const [validation, setValidation] = useState({
    name: true,
    email: true,
    phone: true,
    dob: true
  });

  // Open modal and populate form
  const handleEditOpen = () => {
    if (!playerData) return;
    const formObj = {
      full_name: playerData.full_name || '',
      address: playerData.address || '',
      date_of_birth: playerData.date_of_birth ? playerData.date_of_birth.slice(0,10) : '',
      govt_id_number: playerData.govt_id_number || '',
      govt_id_type: playerData.govt_id_type || 'PAN',
      photo_url: playerData.photoUrl || null,
      email: playerData.email || '',
      phone: playerData.phone || '',
      status: playerData.status === 'Inactive' ? 'Inactive' : 'Active',
    };
    setEditForm(formObj);
    setOriginalForm(formObj);
    setEditPhoto(null);
    setEditPhotoPreview(playerData.photoUrl || null);
    setValidation({ name: true, email: true, phone: true, dob: true });
    // Tier
    const tier = cardData?.tier || "Silver";
    setEditTier(tier);
    setOriginalTier(tier);
    setEditOpen(true);
  };

  // Handle form field change with validation
  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement|HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let newValue: any = value;
    let valid = true;
    if (type === 'checkbox') {
      newValue = (e.target as HTMLInputElement).checked ? 'Active' : 'Inactive';
    }
    // Validation logic
    if (name === 'phone') {
      valid = /^\d{0,10}$/.test(newValue) && (newValue.length === 0 || newValue.length === 10);
    } else if (name === 'email') {
      valid = /^\S+@\S+\.\S+$/.test(newValue);
    } else if (name === 'date_of_birth') {
      valid = /^\d{4}-\d{2}-\d{2}$/.test(newValue);
    } else if (name === 'full_name') {
      valid = /^[A-Za-z ]+$/.test(newValue);
    }
    setEditForm((prev: any) => ({
      ...prev,
      [name]: newValue
    }));
    setValidation((prev) => ({
      ...prev,
      ...(name === 'phone' ? { phone: valid } : {}),
      ...(name === 'email' ? { email: valid } : {}),
      ...(name === 'date_of_birth' ? { dob: valid } : {}),
      ...(name === 'full_name' ? { name: valid } : {})
    }));
  };

  // Handle file upload
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      setEditPhoto(file);
      setEditPhotoPreview(URL.createObjectURL(file));
    }
  };

  // Handle update
  const handleUpdate = async () => {
    if (!editForm) return;
    setUpdateLoading(true);
    setUpdateMessage(null);
    try {
      // Determine what changed
      // Only compare profile fields, not tier
      const { full_name, address, date_of_birth, govt_id_number, govt_id_type, photo_url, email, phone, status } = editForm || {};
      const { full_name: o_full_name, address: o_address, date_of_birth: o_date_of_birth, govt_id_number: o_govt_id_number, govt_id_type: o_govt_id_type, photo_url: o_photo_url, email: o_email, phone: o_phone, status: o_status } = originalForm || {};
      const profileChanged =
        full_name !== o_full_name ||
        address !== o_address ||
        date_of_birth !== o_date_of_birth ||
        govt_id_number !== o_govt_id_number ||
        govt_id_type !== o_govt_id_type ||
        email !== o_email ||
        phone !== o_phone ||
        status !== o_status;
      const photoChanged = !!editPhoto;
      const tierChanged = editTier !== originalTier;

      // If nothing changed, do nothing
      if (!profileChanged && !photoChanged && !tierChanged) {
        setUpdateLoading(false);
        setEditOpen(false);
        return;
      }

      let photoUrl = editForm.photo_url;
      // If photo changed, upload and get new url
      if (photoChanged) {
        const formData = new FormData();
        formData.append("file", editPhoto);
        formData.append("folder", "user-documents");
        const uploadRes = await fetch(`${API_BASE_URL}/api/upload`, {
          method: "POST",
          body: formData,
        });
        const uploadData = await uploadRes.json();
        photoUrl = uploadData.url;
      } else if (!editForm.photo_url && playerData?.photo_url) {
        // If no new photo and no photo_url in form, but playerData has photo_url, use it
        photoUrl = playerData.photo_url;
      }

      // Only call user profile update API if profile fields or photo changed (not tier alone)
      if (profileChanged || photoChanged) {
        let dobIso = editForm.date_of_birth;
        if (dobIso && /^\d{4}-\d{2}-\d{2}$/.test(dobIso)) {
          dobIso = new Date(dobIso + 'T00:00:00.000Z').toISOString();
        }
        const payload = {
          ...editForm,
          date_of_birth: dobIso,
          photo_url: photoUrl,
          status: editForm.status,
        };
        const updateRes = await fetch(`${API_BASE_URL}/api/user/${playerId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (!updateRes.ok) throw new Error('Update failed');
        // Re-fetch profile from API for latest data
        const res = await fetch(`${API_BASE_URL}/api/user/${playerId}?role=Player`);
        const freshData = await res.json();
        setPlayerData(freshData);
        // Reset form to latest data
        const formObj = {
          full_name: freshData.full_name || '',
          address: freshData.address || '',
          date_of_birth: freshData.date_of_birth ? freshData.date_of_birth.slice(0,10) : '',
          govt_id_number: freshData.govt_id_number || '',
          govt_id_type: freshData.govt_id_type || 'PAN',
          photo_url: freshData.photoUrl || null,
          email: freshData.email || '',
          phone: freshData.phone || '',
          status: freshData.status === 'Inactive' ? 'Inactive' : 'Active',
        };
        setEditForm(formObj);
        setOriginalForm(formObj);
        setEditPhoto(null);
        setEditPhotoPreview(freshData.photoUrl || null);
      }

      // If tier changed, update tier and re-fetch cardData
      if (tierChanged) {
        const tierRes = await fetch(`${API_BASE_URL}/api/playercard/${playerId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tier: editTier })
        });
        if (!tierRes.ok) throw new Error('Tier update failed');
        // Re-fetch cardData
        if (playerData?.user_id) {
          const cardRes = await fetch(`${API_BASE_URL}/api/playercard?user_id=${playerData.user_id}`);
          const card = await cardRes.json();
          setCardData(card);
        }
        setEditTier(editTier);
        setOriginalTier(editTier);
      }

      setEditOpen(false);
      setUpdateMessage({ type: 'success', text: 'Profile updated successfully!' });
    } catch {
      setUpdateMessage({ type: 'error', text: 'Failed to update profile. Please try again.' });
    }
    setUpdateLoading(false);
  };
  const [cardData, setCardData] = useState<any>(null);
  const [issuing, setIssuing] = useState(false);
  const [gameSummary, setGameSummary] = useState<any>(null);
  const [graphData, setGraphData] = useState<any[]>([]);
  // Dummy data for session, stats, etc. (to be replaced later)
  const todayStats = {
    winLoss: 'INR 1.154',
    trueWin: 'INR 1.126',
    expWin: 'INR -6',
    bet: 'INR 61',
    promo: 'INR 61',
    avgBet: 'INR 2.66',
    points: '0',
    playTime: '0h 17m',
    activeTime: '0h 04m',
    cashBack: 'INR 0',
    otherCosts: 'INR 350',
    netValue: 'INR -1.504'
  };
  const historicalData = [];

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/user/${playerId}?role=Player`)
      .then(res => res.json())
      .then(data => {
        setPlayerData(data);
        if (data?.user_id) {
          fetch(`${API_BASE_URL}/api/playercard?user_id=${data.user_id}`)
            .then(res => res.json())
            .then(card => setCardData(card))
            .catch(() => setCardData(null));
        }
      })
      .catch(() => setPlayerData(null));

    // Fetch game transaction summary
    const now = new Date();
    const month = now.getMonth() + 1; // JS months are 0-based
    const year = now.getFullYear();
    fetch(`${API_BASE_URL}/api/gametransaction/summary?playerId=${playerId}`)
      .then(res => res.json())
      .then(summary => setGameSummary(summary))
      .catch(() => setGameSummary(null));

    // Fetch graph summary for win/loss chart
    fetch(`${API_BASE_URL}/api/gametransaction/graph-summary?playerId=${playerId}`)
      .then(res => res.json())
      .then(data => {
        if (data && Array.isArray(data.summary)) {
          // Map to chart format: { month: 'Apr', winnings: ..., losses: ... }
          const monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          const chartData = data.summary.slice(-6).map((item: any) => ({
            month: monthNames[item.month],
            winnings: item.totalProfit,
            losses: item.totalLoss
          }));
          setGraphData(chartData);
        } else {
          setGraphData([]);
        }
      })
      .catch(() => setGraphData([]));
  }, []);

  const handleIssueCard = async () => {
    if (!playerData?.user_id) return;
    setIssuing(true);
    try {
      // Assuming POST creates a new card, adjust method/body as needed
      const res = await fetch(`${API_BASE_URL}/api/playercard?user_id=${playerData.user_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          user_id: playerData.user_id })
      });
      const newCard = await res.json();
      setCardData(newCard);
    } catch {
      // handle error (optional)
    }
    setIssuing(false);
  };

  // Disable background scroll when modal is open
  useEffect(() => {
    if (editOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [editOpen]);

  return (
    <div className="w-full max-w-6xl mx-auto py-1 px-2">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">{playerData?.full_name} - Profile</h1>
        <button
          className="bg-green-700 hover:bg-green-800 text-white text-sm font-semibold px-5 py-2 rounded shadow transition-colors duration-150 flex items-center gap-2"
          type="button"
          onClick={handleEditOpen}
        >
          <svg width="18" height="18" fill="none" viewBox="0 0 24 24" className="inline-block align-middle"><path d="M15.232 5.232a3 3 0 1 1 4.243 4.243L7.5 21H3v-4.5L15.232 5.232Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M14 7l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Edit Profile
        </button>
      {/* Edit Profile Modal */}
      {editOpen && (
        <Modal onClose={() => {
          // Reset form to latest API data on close
          if (playerData) {
            const formObj = {
              full_name: playerData.full_name || '',
              address: playerData.address || '',
              date_of_birth: playerData.date_of_birth ? playerData.date_of_birth.slice(0,10) : '',
              govt_id_number: playerData.govt_id_number || '',
              govt_id_type: playerData.govt_id_type || 'PAN',
              photo_url: playerData.photoUrl || null,
              email: playerData.email || '',
              phone: playerData.phone || '',
              status: playerData.status === 'Inactive' ? 'Inactive' : 'Active',
            };
            setEditForm(formObj);
            setOriginalForm(formObj);
            setEditPhoto(null);
            setEditPhotoPreview(playerData.photoUrl || null);
          }
          setEditOpen(false);
        }} width="max-w-3xl" height="max-h-2xl">
          {/* Spinner overlay while updating */}
          {updateLoading && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-30">
              <div className="flex flex-col items-center">
                <span className="inline-block animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-green-600 mb-4"></span>
                <span className="text-lg font-semibold text-white drop-shadow">Updating profile...</span>
              </div>
            </div>
          )}
          <div className="p-6 max-h-[90vh] overflow-y-auto">
      {/* Success/Error message popup */}
      {updateMessage && (
        <div className={`fixed top-6 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded shadow-lg text-white font-semibold transition-all ${updateMessage.type === 'success' ? 'bg-green-600' : 'bg-red-600'}`}
          onClick={() => setUpdateMessage(null)}
        >
          {updateMessage.text}
        </div>
      )}
            <h2 className="text-xl font-bold mb-4">Edit Profile</h2>
            <form className="space-y-4" onSubmit={e => { e.preventDefault(); handleUpdate(); }}>
              {/* Photo upload */}
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-gray-200 bg-gray-100 flex items-center justify-center">
                  {editPhotoPreview ? (
                    <img src={editPhotoPreview} alt="Preview" className="w-full h-full object-cover" />
                  ) : playerData?.photo_url ? (
                    <img src={`${API_BASE_URL}${playerData.photo_url}`} alt="Original" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-gray-400 text-2xl">?</span>
                  )}
                </div>
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handlePhotoChange}
                  />
                  <button
                    type="button"
                    className="px-3 py-1 bg-gray-200 rounded text-sm font-medium hover:bg-gray-300"
                    onClick={() => fileInputRef.current?.click()}
                  >Upload Photo</button>
                </div>
              </div>
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold mb-1">Full Name</label>
                <input type="text" name="full_name" value={editForm.full_name} onChange={handleEditChange} className={`w-full border rounded px-3 py-2 text-sm ${validation.name ? '' : 'border-red-500'}`} required pattern="[A-Za-z ]+" />
                {!validation.name && <span className="text-xs text-red-500">Name must contain only alphabets and spaces.</span>}
              </div>
              {/* Address */}
              <div>
                <label className="block text-xs font-semibold mb-1">Address</label>
                <input type="text" name="address" value={editForm.address} onChange={handleEditChange} className="w-full border rounded px-3 py-2 text-sm" />
              </div>
              {/* Date of Birth */}
              <div>
                <label className="block text-xs font-semibold mb-1">Date of Birth</label>
                <input type="date" name="date_of_birth" value={editForm.date_of_birth} onChange={handleEditChange} className={`w-full border rounded px-3 py-2 text-sm ${validation.dob ? '' : 'border-red-500'}`} required />
                {!validation.dob && <span className="text-xs text-red-500">Enter a valid date.</span>}
              </div>
              {/* Govt ID Type and Number */}
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-xs font-semibold mb-1">Govt ID Type</label>
                  <select name="govt_id_type" value={editForm.govt_id_type} onChange={handleEditChange} className="w-full border rounded px-3 py-2 text-sm">
                    <option value="Aadhaar">Aadhaar</option>
                    <option value="PAN">PAN</option>
                    <option value="Passport">Passport</option>
                    <option value="Driving_License">Driving License</option>
                  </select>
                </div>
                <div className="flex-1">
                  <label className="block text-xs font-semibold mb-1">Govt ID Number</label>
                  <input type="text" name="govt_id_number" value={editForm.govt_id_number} onChange={handleEditChange} className="w-full border rounded px-3 py-2 text-sm" />
                </div>
              </div>
              {/* Email */}
              <div>
                <label className="block text-xs font-semibold mb-1">Email</label>
                <input type="email" name="email" value={editForm.email} onChange={handleEditChange} className={`w-full border rounded px-3 py-2 text-sm ${validation.email ? '' : 'border-red-500'}`} required />
                {!validation.email && <span className="text-xs text-red-500">Enter a valid email address.</span>}
              </div>
              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold mb-1">Phone</label>
                <input type="text" name="phone" value={editForm.phone} onChange={handleEditChange} className={`w-full border rounded px-3 py-2 text-sm ${validation.phone ? '' : 'border-red-500'}`} maxLength={10} required pattern="\d{10}" />
                {!validation.phone && <span className="text-xs text-red-500">Phone must be 10 digits.</span>}
              </div>
              {/* Profile Tier */}
              <div>
                <label className="block text-xs font-semibold mb-1">Profile Tier</label>
                <select
                  name="profile_tier"
                  value={editTier}
                  onChange={e => setEditTier(e.target.value)}
                  className="w-full border rounded px-3 py-2 text-sm"
                >
                  <option value="VIP">VIP</option>
                  <option value="VVIP">VVIP</option>
                  <option value="Premium">Premium</option>
                  <option value="Gold">Gold</option>
                  <option value="Silver">Silver</option>
                </select>
              </div>
              {/* Status Toggle */}
              <div className="flex items-center gap-3">
                <label className="block text-xs font-semibold">Profile Status</label>
                <label className="inline-flex items-center cursor-pointer select-none">
                  <input type="checkbox" name="status" checked={editForm.status === 'Active'} onChange={handleEditChange} className="sr-only peer" />
                  <div className="w-11 h-6 flex items-center bg-gray-200 rounded-full transition-colors duration-200 peer-checked:bg-green-500 relative">
                    <span
                      className={
                        `inline-block w-4 h-4 bg-white rounded-full shadow-md transform transition-transform duration-200`
                        + (editForm.status === 'Active' ? ' translate-x-5' : ' translate-x-0')
                      }
                      style={{ position: 'absolute', left: '4px', top: '4px' }}
                    ></span>
                  </div>
                  <span className={"ml-3 text-sm font-medium transition-colors duration-200 " + (editForm.status === 'Active' ? 'text-green-700' : 'text-gray-500')}>{editForm.status === 'Active' ? 'Active' : 'Inactive'}</span>
                </label>
              </div>
              {/* Buttons */}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
              className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-bold hover:bg-red-600 hover:text-white A transition-colors"
                  onClick={() => setEditOpen(false)}
                  disabled={updateLoading}
                >Cancel</button>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded  font-bold ${
                    updateLoading ||
                    !editForm ||
                    !originalForm ||
                    (JSON.stringify(editForm) === JSON.stringify(originalForm) && !editPhoto && editTier === originalTier) ||
                    !validation.name ||
                    !validation.email ||
                    !validation.phone ||
                    !validation.dob
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-green-700 hover:bg-green-800 text-white'
                  }`}
                  disabled={
                    updateLoading ||
                    !editForm ||
                    !originalForm ||
                    (JSON.stringify(editForm) === JSON.stringify(originalForm) && !editPhoto && editTier === originalTier) ||
                    !validation.name ||
                    !validation.email ||
                    !validation.phone ||
                    !validation.dob
                  }
                >{updateLoading ? 'Updating...' : 'Update'}</button>
              </div>
            </form>
          </div>
        </Modal>
      )}
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 flex flex-row gap-6 items-center mb-6">
        {/* Photo */}
        <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-white shadow-md">
          <img src={`${API_BASE_URL}${playerData?.photo_url}`} alt="Player" className="w-full h-full object-cover" />
        </div>
        {/* Info */}
        <div className="flex-1 flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span className="text-xl font-semibold text-gray-900">{playerData?.full_name || "-"}</span>
            <span className="text-xs text-gray-500 font-mono">ID: {playerData?.user_id || "-"}</span>
            {(() => {
              let tier = cardData?.tier || "Silver";
              let color = "bg-yellow-400";
              if (tier === "VVIP") color = "bg-purple-600";
              else if (tier === "Premium") color = "bg-blue-500";
              else if (tier === "Gold") color = "bg-amber-400";
              else if (tier === "Silver") color = "bg-gray-400";
              else if (tier === "VIP") color = "bg-yellow-400";
              return (
                <span className={`${color} text-xs font-semibold px-2 py-0.5 rounded text-white shadow`}>
                  {tier}
                </span>
              );
            })()}
          </div>
          {/* First line: Member Since, Email, Phone */}
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm text-gray-600 mt-1">
            <span className="flex items-center gap-1">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><path d="M8 7V3h8v4" stroke="#888" strokeWidth="1.5"/><rect x="4" y="7" width="16" height="14" rx="2" stroke="#888" strokeWidth="1.5"/></svg>
              Member Since : {playerData?.created_at ? new Date(playerData.created_at).toLocaleDateString() : "-"}
            </span>
            <span className="flex items-center gap-1">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><path d="M4 4h16v16H4V4z" stroke="#888" strokeWidth="1.5"/><path d="M4 4l8 8 8-8" stroke="#888" strokeWidth="1.5"/></svg>
              Email : {playerData?.email || "-"}
            </span>
            <span className="flex items-center gap-1">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="2" stroke="#888" strokeWidth="1.5"/><circle cx="12" cy="18" r="1" fill="#888"/></svg>
              Contact : {playerData?.phone || "-"}
            </span>
          </div>
          {/* Second line: DOB, Address */}
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm text-gray-600 mt-1">
            <span className="flex items-center gap-1">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#888" strokeWidth="1.5"/><path d="M12 6v6l4 2" stroke="#888" strokeWidth="1.5"/></svg>
              Date of Birth : {playerData?.date_of_birth ? new Date(playerData.date_of_birth).toLocaleDateString() : "-"}
            </span>
            <span className="flex items-center gap-1">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z" stroke="#888" strokeWidth="1.5"/></svg>
              Address : {playerData?.address || "-"}
            </span>
          </div>
          {/* Third line: Identity Proof */}
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm text-gray-600 mt-1">
            <span className="flex items-center gap-1 font-medium">
              <svg width="16" height="16" fill="none" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2" stroke="#888" strokeWidth="1.5"/><path d="M8 12h8M8 16h8M8 8h8" stroke="#888" strokeWidth="1.5"/></svg>
              Identity Proof : {playerData?.govt_id_type || "-"} ( {playerData?.govt_id_number || "-"} )
            </span>
          </div>
        </div>
        {/* Card Balance & Points */}
        <div className="flex flex-col items-center justify-center min-w-[140px] bg-gray-50 rounded-lg px-5 py-3 border border-gray-200 text-center">
          {cardData && cardData.card_id ? (
            <>
              <div className="mb-2">
                <span className="block text-xs text-gray-500">Card Balance</span>
                <span className="block text-lg font-bold text-gray-900">INR {cardData.balance || "-"}</span>
              </div>
              <div>
                <span className="block text-xs text-gray-500">Profile Points</span>
                <span className="block text-lg font-bold text-green-600">{cardData.loyalty_points || "-"}</span>
              </div>
              <div className="mt-2 text-xs text-gray-500">Tier: {cardData.tier || '-'}</div>
              {cardData.rfid_number && (
                <div className="mt-2 text-xs text-gray-500">RFID: <span className="font-mono">{cardData.rfid_number}</span></div>
              )}
            </>
          ) : (
            <button
              className="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded transition disabled:opacity-60"
              onClick={handleIssueCard}
              disabled={issuing || !playerData?.user_id}
            >
              {issuing ? 'Issuing...' : 'Issue Card'}
            </button>
          )}
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg border border-gray-200 p-5 flex flex-col gap-2">
          <span className="text-xs text-gray-500">Total Wagered</span>
          <span className="text-2xl font-bold text-gray-900">{gameSummary ? `INR ${gameSummary.totalWagered}` : '-'}</span>
          <span className="text-xs text-gray-400">Lifetime</span>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-5 flex flex-col gap-2">
          {(() => {
            let value = gameSummary ? gameSummary.totalProfit - gameSummary.totalLoss : null;
            let isPositive = value !== null && value >= 0;
            let color = isPositive ? 'text-green-600' : 'text-red-600';
            let arrow = isPositive
              ? (<svg width="16" height="16" fill="none" viewBox="0 0 24 24"><path d="M12 19V5m0 0l-7 7m7-7l7 7" stroke="#22c55e" strokeWidth="2"/></svg>)
              : (<svg width="16" height="16" fill="none" viewBox="0 0 24 24"><path d="M12 5v14m0 0l-7-7m7 7l7-7" stroke="#dc2626" strokeWidth="2"/></svg>);
            return (
              <>
                <span className={`text-xs text-gray-500 flex items-center gap-1`}>Net Win/Loss {arrow}</span>
                <span className={`text-2xl font-bold ${color}`}>{value !== null ? `INR ${value}` : '-'}</span>
              </>
            );
          })()}
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-5 flex flex-col gap-2">
          <span className="text-xs text-gray-500">Favorite Game</span>
          <span className="text-lg font-semibold text-gray-900">{gameSummary ? gameSummary.favouriteGame : '-'}</span>
          <span className="text-xs text-gray-400">Based on session count</span>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-5 flex flex-col gap-2">
          <span className="text-xs text-gray-500">Risk Profile</span>
          {(() => {
            let risk = "Medium";
            let color = "text-yellow-600";
            if (gameSummary && gameSummary.totalWagered > 0) {
              const netWinLoss = Math.abs((gameSummary.totalProfit || 0) - (gameSummary.totalLoss || 0));
              const riskRatio = (netWinLoss / gameSummary.totalWagered) * 100;
              if (riskRatio > 50) {
                risk = "High";
                color = "text-red-600";
              } else if (riskRatio <= 20) {
                risk = "Low";
                color = "text-green-600";
              }
            }
            return <span className={`text-lg font-semibold ${color}`}>{risk}</span>;
          })()}
          <span className="text-xs text-gray-400">AI-generated assessment</span>
        </div>
      </div>

      {/* Chart Section */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold text-gray-900">Monthly Win/Loss History (To be Updated/Development with Slot Meters : Phase 2)</h2>
          <span className="text-xs text-gray-500">Performance over the last 6 months.</span>
        </div>
        {/* Win/Loss Line Chart */}
        <div className="w-full h-56 flex items-center justify-center">
          {graphData && graphData.length > 0 ? (
            (() => {
              // Find max value in winnings/losses to determine Y-axis scale
              const allValues = graphData.flatMap(d => [d.winnings, d.losses]);
              const maxValue = Math.max(...allValues);
              const useK = maxValue >= 1000;
              // Find min/max for nice Y-axis domain
              const minValue = Math.min(...allValues, 0);
              const domain = [Math.min(0, minValue), Math.ceil(maxValue / (useK ? 1000 : 100)) * (useK ? 1000 : 100)];
              // Custom tooltip
              const CustomTooltip = ({ active, payload, label }: any) => {
                if (active && payload && payload.length) {
                  const winnings = payload.find((p: any) => p.dataKey === 'winnings')?.value || 0;
                  const losses = payload.find((p: any) => p.dataKey === 'losses')?.value || 0;
                  return (
                    <div className="bg-white rounded shadow-lg px-4 py-2 border border-gray-200">
                      <div className="font-semibold text-base mb-1">{label}</div>
                      <div className="text-red-600">Losses : ₹{losses}</div>
                      <div className="text-green-600">Winnings : ₹{winnings}</div>
                    </div>
                  );
                }
                return null;
              };
              return (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={graphData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ccc" />
                    <XAxis dataKey="month" tick={{ fill: '#888' }} />
                    <YAxis
                      tick={{ fill: '#888' }}
                      domain={domain}
                      tickFormatter={v => useK ? `₹${(v/1000).toFixed(0)}k` : `₹${v}`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    {/* Legend removed as per design */}
                    <Line type="monotone" dataKey="winnings" name="Winnings" stroke="#22c55e" strokeWidth={2} dot={{ r: 4, stroke: '#22c55e', fill: '#fff', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                    <Line type="monotone" dataKey="losses" name="Losses" stroke="#dc2626" strokeWidth={2} dot={{ r: 4, stroke: '#dc2626', fill: '#fff', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              );
            })()
          ) : (
            <span className="text-gray-400">No data available for chart.</span>
          )}
        </div>
        <div className="flex gap-6 mt-2 text-xs text-gray-500">
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 bg-green-400 inline-block rounded"></span> Winnings</span>
          <span className="flex items-center gap-1"><span className="w-3 h-1.5 bg-red-400 inline-block rounded"></span> Losses</span>
        </div>
      </div>

      {/* Recent Gaming Sessions Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Recent Gaming Sessions (To be Updated/Development with Slot Meters : Phase 2)</h2>
            <span className="text-xs text-gray-500">Details of the player's most recent activity.</span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm table-fixed">
            <colgroup>
              <col style={{ width: '20%' }} />
              <col style={{ width: '20%' }} />
              <col style={{ width: '20%' }} />
              <col style={{ width: '20%' }} />
              <col style={{ width: '20%' }} />
            </colgroup>
            <thead>
              <tr className="border-b text-gray-500">
                <th className="text-left py-2 pl-12">Game Name</th>
                <th className="text-center py-2">Playing Date</th>
                <th className="text-center py-2">Wagered</th>
                <th className="text-center py-2">Game Result</th>
                <th className="text-center py-2">Win/Loss</th>
              </tr>
            </thead>
            <tbody style={{ minHeight: 400, height: 400, display: 'table-row-group' }}>
              {sessionLoading ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center" style={{ height: 400 }}>
                    <span className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gray-400 align-middle"></span>
                  </td>
                </tr>
              ) : sessions.length === 0 ? (
                <tr><td colSpan={5} className="py-12 text-center text-gray-400">No sessions found.</td></tr>
              ) : (
                sessions.map((s, idx) => {
                  const date = s.createdAt ? new Date(s.createdAt) : null;
                  const dateStr = date ? date.toLocaleDateString() : '-';
                  return (
                    <tr key={s.id} className={idx !== sessions.length - 1 ? "border-b" : undefined}>
                      <td className="py-2 truncate text-left pl-12">{s.gameName}</td>
                      <td className="py-2 truncate text-center">{dateStr}</td>
                      <td className="py-2 truncate text-center">INR {s.betAmount}</td>
                      <td className={"py-2 truncate text-center " + (s.outcome === 'WIN' ? 'text-green-600' : 'text-red-600')}>
                        {s.outcome === 'LOSS' ? '- INR ' : '+ INR '}{Math.abs(s.resultAmount-s.betAmount)}
                      </td>
                      <td className={"py-2 truncate text-center font-bold " + (s.outcome === 'WIN' ? 'text-green-600' : 'text-red-600')}>{s.outcome}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-4 text-xs text-gray-500">
          <button
            className={"px-3 py-1 rounded border transition-colors duration-150 " + (sessionPage === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-green-100 hover:border-green-500 hover:text-green-700')}
            onClick={() => setSessionPage(p => Math.max(1, p - 1))}
            disabled={sessionPage === 1}
          >Previous</button>
          <span>Page {sessionPage} of {sessionTotalPages}</span>
          <button
            className={"px-3 py-1 rounded border transition-colors duration-150 " + (sessionPage === sessionTotalPages ? 'opacity-50 cursor-not-allowed' : 'hover:bg-green-100 hover:border-green-500 hover:text-green-700')}
            onClick={() => setSessionPage(p => Math.min(sessionTotalPages, p + 1))}
            disabled={sessionPage === sessionTotalPages}
          >Next</button>
        </div>
      </div>
    </div>
  );
};

export default PlayerProfile;
