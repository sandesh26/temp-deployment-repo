"use client";
import { API_BASE_URL } from "@/config/api";

import React, { useEffect, useState, useRef } from 'react';
import Modal from '@/components/ui/modal/Modal';


const EmployeeProfile = ({ employeeId }: { employeeId: string }) => {
  const [employee, setEmployee] = useState<any>(null);
  const [originalEmployee, setOriginalEmployee] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [updateMessage, setUpdateMessage] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    fetch(`${API_BASE_URL}/api/user/${employeeId}`)
      .then(res => res.json())
      .then(data => {
        setEmployee(data);
        setOriginalEmployee(data);
      })
      .finally(() => setLoading(false));
  }, [employeeId]);

  const hasChanges = JSON.stringify(employee) !== JSON.stringify(originalEmployee);

  const handleFieldChange = (field: string, value: string) => {
    if (field === 'govt_id_type') {
      setEmployee((prev: any) => ({ ...prev, govt_id_type: value, govt_id_number: '' }));
    } else {
      setEmployee((prev: any) => ({ ...prev, [field]: value }));
    }
  };
  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^ -\s@]+\.[^\s@]+$/.test(email);
  };
  const validatePhone = (phone: string) => {
    return /^\+?\d{7,15}$/.test(phone.replace(/\s/g, ''));
  };
  const validateDate = (date: string) => {
    if (!date) return false;
    const d = new Date(date);
    return !isNaN(d.getTime());
  };
  const isFormValid = employee &&
    employee.full_name &&
    employee.email && validateEmail(employee.email) &&
    employee.phone && validatePhone(employee.phone) &&
    employee.role &&
    employee.address &&
    employee.date_of_birth && validateDate(employee.date_of_birth) &&
    employee.status &&
    employee.govt_id_type &&
    employee.govt_id_number;

  const handleSave = async () => {
    setSaving(true);
    setUpdateMessage(null);
    try {
      await fetch(`${API_BASE_URL}/api/user/${employee.user_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(employee)
      });
      setOriginalEmployee(JSON.parse(JSON.stringify(employee)));
      setUpdateMessage('Changes saved successfully!');
    } catch {
      setUpdateMessage('Failed to save changes.');
    }
    setSaving(false);
    setTimeout(() => setUpdateMessage(null), 3000);
  };

  if (loading) return <div className="p-8 text-center">Loading employee...</div>;
  if (!employee) return <div className="p-8 text-center">Employee not found.</div>;

  return (
    <div className="rounded-2xl max-w-4xl mx-auto overflow-hidden">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-center gap-8 px-2 pt-2 pb-6 border-b border-gray-100 bg-white">
        {/* Avatar */}
        <div className="flex-shrink-0 w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center text-2xl font-bold text-brand-700 shadow-theme-md ring-4 ring-brand-200">
          {originalEmployee?.photo_url ? (
            <img src={originalEmployee.photo_url} alt={originalEmployee?.full_name} className="w-28 h-28 rounded-full object-cover" />
          ) : (
            (originalEmployee?.full_name || 'U').split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase()
          )}
        </div>
        <div className="flex-1 min-w-0 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-4 mb-2">
              <h2 className="text-xl font-extrabold text-black tracking-tight">{originalEmployee?.full_name}</h2>
              <span className={`px-3 py-1 rounded-full text-base font-bold shadow-theme-xs ${originalEmployee?.status === 'Active' ? 'bg-green-500 text-white' : originalEmployee?.status === 'Banned' ? 'bg-red-500 text-white' : 'bg-gray-300 text-gray-700'}`}>{originalEmployee?.status}</span>
            </div>
            <div className="text-base text-gray-400 font-normal">EMP ID: {originalEmployee?.user_id}</div>
            <div className="text-base text-gray-400 font-normal mt-1">
              Employee Since: {originalEmployee?.created_at ? new Date(originalEmployee.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }) : '-'}
            </div>
          </div>
          <div className="flex gap-2 md:gap-4">
          </div>
        </div>
      </div>
      {updateMessage && (
        <Modal onClose={() => setUpdateMessage(null)} width="max-w-lg" height="max-h-5xl">
          <div className={`px-6 py-10 rounded text-white font-semibold text-center`} style={{ background: updateMessage.includes('success') ? '#16a34a' : '#dc2626' }}>
            {updateMessage}
          </div>
        </Modal>
      )}
      <form onSubmit={e => { e.preventDefault(); handleSave(); }} className="px-10 pt-8 pb-10 bg-white">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-8">
          <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M6 20v-2a4 4 0 014-4h0a4 4 0 014 4v2" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Full Name</label>
              <input type="text" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.full_name || ''} onChange={e => handleFieldChange('full_name', e.target.value)} />
            </div>
          </div>
          {/* Email */}
          <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect width="20" height="16" x="2" y="4" rx="2" /><path d="M22 6l-10 7L2 6" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Email</label>
              <input type="email" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.email || ''} onChange={e => handleFieldChange('email', e.target.value)} />
              {employee.email && !validateEmail(employee.email) && <div className="text-xs text-red-600 mt-1">Invalid email address</div>}
            </div>
          </div>
          {/* Phone */}
          <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92V19a2 2 0 0 1-2 2A18 18 0 0 1 3 5a2 2 0 0 1 2-2h2.09a2 2 0 0 1 2 1.72c.13.81.28 1.6.47 2.36a2 2 0 0 1-.45 2.11l-.27.27a16 16 0 0 0 6.29 6.29l.27-.27a2 2 0 0 1 2.11-.45c.76.19 1.55.34 2.36.47A2 2 0 0 1 19 16.91z" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Phone</label>
              <input type="text" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.phone || ''} onChange={e => handleFieldChange('phone', e.target.value)} />
              {employee.phone && !validatePhone(employee.phone) && <div className="text-xs text-red-600 mt-1">Invalid phone number</div>}
            </div>
          </div>
          {/* Position/Role */}
          <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M16 3v4M8 3v4" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Role</label>
              <select
                required
                className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 pr-8 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={employee.role || ''}
                onChange={e => handleFieldChange('role', e.target.value)}
              >
                <option value="">Select Role</option>
                <optgroup label="Reception">
                  <option value="Reception_Executive">Reception Executive</option>
                  <option value="Reception_Sr_Executive">Reception Senior Executive</option>
                  <option value="Reception_Supervisor">Reception Supervisor</option>
                </optgroup>
                <optgroup label="Cage">
                  <option value="Cage_Executive">Cage Executive</option>
                  <option value="Cage_Supervisor">Cage Supervisor</option>
                  <option value="Cage_Manager">Cage Manager</option>
                </optgroup>
                <optgroup label="Slot Machine">
                  <option value="Slot_Executive">Slot Executive</option>
                  <option value="Slot_Supervisor">Slot Supervisor</option>
                  <option value="Slot_Manager">Slot Manager</option>
                </optgroup>
                <optgroup label="Gaming">
                  <option value="Pit_Supervisor">Pit Supervisor</option>
                  <option value="Inspector">Inspector</option>
                  <option value="Casino_Manager">Casino Manager</option>
                  <option value="Dealer">Dealer</option>
                </optgroup>
                <optgroup label="Technical">
                  <option value="Technical_Executive">Technical Executive</option>
                </optgroup>
                <optgroup label="Administration">
                  <option value="Admin">Admin</option>
                  <option value="Super_Admin">Super Admin</option>
                </optgroup>
              </select>
            </div>
          </div>
          {/* Address */}
          <div className="flex items-center gap-4 md:col-span-2">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Address</label>
              <input type="text" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.address || ''} onChange={e => handleFieldChange('address', e.target.value)} />
            </div>
          </div>

          {/* Date of Birth */}
          {/* <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Date of Birth</label>
              <input type="date" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.date_of_birth ? employee.date_of_birth.slice(0, 10) : ''} onChange={e => handleFieldChange('date_of_birth', e.target.value)} />
              {employee.date_of_birth && !validateDate(employee.date_of_birth) && <div className="text-xs text-red-600 mt-1">Invalid date</div>}
            </div>
          </div> */}

          {/* Status Dropdown */}
          <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-full w-12 text-2xl text-gray-400">
              <svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" />
                <path d="M9 12l2 2 4-4" />
              </svg>
            </span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Status</label>
              <select
                required
                className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={employee.status || ''}
                onChange={e => handleFieldChange('status', e.target.value)}
              >
                <option value="">Select Status</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Banned">Banned</option>
              </select>
            </div>
          </div>
          {/* Govt ID Type */}
          {/* <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2" /><path d="M8 11h8M8 15h6" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Govt ID Type</label>
              <select
                required
                className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={employee.govt_id_type || ''}
                onChange={e => handleFieldChange('govt_id_type', e.target.value)}
              >
                <option value="">Select Govt ID Type</option>
                <option value="Aadhaar">Aadhaar</option>
                <option value="PAN">PAN</option>
                <option value="Passport">Passport</option>
                <option value="Driving_License">Driving License</option>
              </select>
            </div>
          </div> */}
          {/* Govt ID Number */}
          {/* <div className="flex items-center gap-4">
            <span className="flex items-center justify-center h-12 w-12 text-2xl text-gray-400"><svg width="28" height="28" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2" /><path d="M8 11h8M8 15h6" /></svg></span>
            <div className="w-full">
              <label className="block text-[1rem] font-medium text-gray-600 mb-1">Govt ID Number</label>
              <input type="text" required className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500" value={employee.govt_id_number || ''} onChange={e => handleFieldChange('govt_id_number', e.target.value)} />
            </div>
          </div> */}
        </div>
        <div className="flex justify-end mt-10">
          <button
            type="submit"
            className={`px-10 py-3 rounded-xl font-bold text-white text-lg shadow-theme-md transition-all duration-200 flex items-center gap-3 ${hasChanges && isFormValid && !saving ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-300 cursor-not-allowed'}`}
            disabled={!hasChanges || !isFormValid || saving}
          >
            {saving && <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" /></svg>}
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};
export default EmployeeProfile;
