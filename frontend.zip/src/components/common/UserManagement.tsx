"use client";

import React, { useEffect, useMemo, useState, useRef } from "react";
import { API_BASE_URL } from "@/config/api";
import { DEFAULT_ROLES, MODULES as DEFAULT_MODULES } from '@/data/roles';

type ServerRow = {
  role_name: string;
  module_name: string;
  permission_id?: string | number;
  can_view?: boolean | string;
  can_create?: boolean | string;
  can_edit?: boolean | string;
  can_action?: boolean | string;
  can_delete?: boolean | string;
};

// Mapping of department values to API user roles
export const DEPARTMENT_ROLE_MAP: Record<string, string[]> = {
  Cage: ["Cage_Executive", "Cage_Supervisor", "Cage_Manager"],
  Reception: ["Reception_Executive", "Reception_Sr_Executive", "Reception_Supervisor"],
  Slot: ["Slot_Executive", "Slot_Supervisor", "Slot_Manager"],
  Gaming: ["Pit_Supervisor", "Dealer", "Inspector","Casino_Manager"],
  Admin: ["Admin", "Super_Admin"],
  Technical: ["Technical_Executive"],
};

type Permission = { view: boolean; create: boolean; edit: boolean; action: boolean };

type Role = { id: string; name: string; permissions: Record<string, PermissionWithId> };

const modules = DEFAULT_MODULES;

type PermissionWithId = Permission & { permission_id?: string | number };

const defaultPermissions: PermissionWithId = { view: false, create: false, edit: false, action: false };

const parseBool = (v: boolean | string | undefined) => v === true || v === "true";

const rowsToRoles = (rows: ServerRow[]): Role[] => {
  const map = new Map<string, Role>();
  for (const r of rows) {
    const roleName = r.role_name ?? "Unknown";
    const moduleName = r.module_name ?? "Unknown";
    const perm: PermissionWithId = {
      view: parseBool(r.can_view),
      create: parseBool(r.can_create),
      edit: parseBool(r.can_edit),
      action: parseBool(r.can_action ?? r.can_delete),
      permission_id: (r as any).permission_id ?? (r as any).id ?? undefined,
    };
    if (!map.has(roleName)) {
      map.set(roleName, { id: roleName.replace(/\s+/g, "-").toLowerCase(), name: roleName, permissions: {} });
    }
    const role = map.get(roleName)!;
    role.permissions[moduleName] = perm;
  }

  // ensure all modules exist
  for (const r of map.values()) {
    for (const m of modules) {
      if (!r.permissions[m]) r.permissions[m] = { ...defaultPermissions };
    }
  }

  return Array.from(map.values());
};

// Build roles from DEFAULT_ROLES when API returns nothing
const buildRolesFromDefaults = (): Role[] => {
  return DEFAULT_ROLES.map((name) => ({
    id: name.replace(/\s+/g, "-").toLowerCase(),
    name,
    permissions: Object.fromEntries(modules.map((m) => [m, { ...defaultPermissions }])) as Record<string, PermissionWithId>,
  }));
};

const buildPermissionRowsForRole = (role: Role): ServerRow[] => {
  return modules.map((m) => {
    const p = role.permissions[m] ?? defaultPermissions;
    const row: ServerRow = {
      role_name: role.name,
      module_name: m,
      can_view: String(!!p.view),
      can_create: String(!!p.create),
      can_edit: String(!!p.edit),
      can_action: String(!!p.action),
    };
    if ((p as PermissionWithId).permission_id) row.permission_id = (p as PermissionWithId).permission_id;
    return row;
  });
};




interface UserManagementProps {
  department?: string;
}


const UserManagement: React.FC<UserManagementProps> = ({ department }) => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [originalRoles, setOriginalRoles] = useState<Role[]>([]);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [modal, setModal] = useState<{ open: boolean; message: string; type: 'success' | 'error' }>({ open: false, message: '', type: 'success' });
  // Dropdown state for department selection
  const departmentKeys = Object.keys(DEPARTMENT_ROLE_MAP);
  const initialDepartment = department
    ? departmentKeys.find(k => k.toLowerCase() === department.toLowerCase()) || departmentKeys[0]
    : departmentKeys[0];
  const [selectedDepartment, setSelectedDepartment] = useState<string>(initialDepartment);

  // When department dropdown changes, auto-select first visible role and fetch its permissions
  useEffect(() => {
    if (selectedDepartment && visibleRoles.length > 0) {
      setSelectedRole(visibleRoles[0].name);
      fetchRolePermissions(visibleRoles[0].name);
    }
  }, [selectedDepartment]);

  // If department prop changes, update selectedDepartment
  React.useEffect(() => {
    if (department) {
      const depKey = departmentKeys.find(k => k.toLowerCase() === department.toLowerCase());
      if (depKey && depKey !== selectedDepartment) {
        setSelectedDepartment(depKey);
      }
    }
  }, [department]);

  // Auto-close modal after 5 seconds
  React.useEffect(() => {
    if (modal.open) {
      const timer = setTimeout(() => setModal((m: typeof modal) => ({ ...m, open: false })), 3000);
      return () => clearTimeout(timer);
    }
  }, [modal.open]);

  // Auto-close modal after 5 seconds
  React.useEffect(() => {
    if (modal.open) {
      const timer = setTimeout(() => setModal(m => ({ ...m, open: false })), 5000);
      return () => clearTimeout(timer);
    }
  }, [modal.open]);

  // Helper to fetch and set roles from API
  const fetchAndSetRoles = async (keepSelected = false) => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/user-permissions`);
      if (!res.ok) return;
      const json = await res.json();
      let rows: ServerRow[] = [];
      if (Array.isArray(json)) {
        rows = json;
      } else if (Array.isArray(json?.permissions)) {
        rows = json.permissions;
      }
      if (department) {
        const dep = department.toLowerCase();
        rows = rows.filter(r =>
          (r.role_name && r.role_name.toLowerCase().includes(dep)) ||
          (r.module_name && r.module_name.toLowerCase().includes(dep))
        );
      }
      const apiRoles = rowsToRoles(rows);
      const apiRoleNames = new Set(apiRoles.map(r => r.name));
      const mergedRoles = [
        ...apiRoles,
        ...DEFAULT_ROLES.filter(name => !apiRoleNames.has(name)).map(name => ({
          id: name.replace(/\s+/g, "-").toLowerCase(),
          name,
          permissions: Object.fromEntries(modules.map((m) => [m, { ...defaultPermissions }])) as Record<string, PermissionWithId>,
        }))
      ];
      const roleOrder = DEFAULT_ROLES;
      mergedRoles.sort((a, b) => roleOrder.indexOf(a.name) - roleOrder.indexOf(b.name));
      setRoles(mergedRoles);
      setOriginalRoles(JSON.parse(JSON.stringify(mergedRoles)));
      //if (mergedRoles.length && (!selectedRole || !keepSelected)) setSelectedRole(mergedRoles[0].name);
    } catch (err) {
      console.error("Failed to load permissions", err);
    }
  };

  useEffect(() => {
    fetchAndSetRoles();
  }, []);


  // Fetch permissions for a single role
  const fetchRolePermissions = async (roleName: string) => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/user-permissions?role=${encodeURIComponent(roleName)}`);
      if (!res.ok) return;
      const json = await res.json();
      let rows: ServerRow[] = [];
      if (Array.isArray(json)) {
        rows = json;
      } else if (Array.isArray(json?.permissions)) {
        rows = json.permissions;
      }
      // Only keep rows for this role
      rows = rows.filter(r => r.role_name === roleName);
      const apiRoles = rowsToRoles(rows);
      if (apiRoles.length > 0) {
        setRoles(prev => prev.map(r => r.name === roleName ? apiRoles[0] : r));
      }
    } catch (err) {
      console.error("Failed to fetch role permissions", err);
    }
  };

  const selectedRoleData = useMemo(() => roles.find((r) => r.name === selectedRole), [roles, selectedRole]);

  const toggleAllPermissionsForModule = (moduleName: string, value: boolean) => {
    if (!selectedRole) return;
    setRoles((prev) => prev.map((r) => {
      if (r.name !== selectedRole) return r;
      const newPerms = { ...r.permissions };
      const prev = r.permissions[moduleName] as PermissionWithId | undefined;
      newPerms[moduleName] = { view: value, create: value, edit: value, action: value, permission_id: prev?.permission_id } as PermissionWithId;
      return { ...r, permissions: newPerms };
    }));
  };

  const updatePermission = (moduleName: string, key: keyof Permission, value: boolean) => {
    setRoles((prev) => prev.map((r) => {
      if (r.name !== selectedRole) return r;
      return { ...r, permissions: { ...r.permissions, [moduleName]: { ...r.permissions[moduleName], [key]: value } } };
    }));
  };

  // Compare two roles deeply
  const isRoleDirty = (role: Role, original: Role | undefined) => {
    if (!original) return true;
    for (const m of modules) {
      const p1 = role.permissions[m] || defaultPermissions;
      const p2 = original.permissions[m] || defaultPermissions;
      if (p1.view !== p2.view || p1.create !== p2.create || p1.edit !== p2.edit || p1.action !== p2.action) {
        return true;
      }
    }
    return false;
  };

  // Find all dirty roles
  const dirtyRoles = useMemo(() => {
    return roles.filter(r => {
      const orig = originalRoles.find(o => o.name === r.name);
      return isRoleDirty(r, orig);
    });
  }, [roles, originalRoles]);

  const handleSavePermissions = async () => {
    if (dirtyRoles.length === 0) return;
    setIsSaving(true);
    try {
      // Split dirty roles into existing roles (update) and new roles (create)
      const newRoles = dirtyRoles.filter(r => !originalRoles.some(o => o.name === r.name));
      const updatedRoles = dirtyRoles.filter(r => originalRoles.some(o => o.name === r.name));

      // Helper to send rows for a set of roles with the given HTTP method
      const sendRows = async (method: 'POST' | 'PUT', rolesToSend: Role[]) => {
        if (rolesToSend.length === 0) return null;
        const payload = rolesToSend.flatMap(buildPermissionRowsForRole);
        const res = await fetch(`${API_BASE_URL}/api/user-permissions`, {
          method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error(`${method} failed`);
        return res;
      };

      // First update existing roles (PUT), then create new roles (POST)
      if (updatedRoles.length) {
        await sendRows('PUT', updatedRoles);
      }
      if (newRoles.length) {
        await sendRows('POST', newRoles);
      }

      setModal({ open: true, message: "Permissions Saved Successfully!", type: "success" });
      // Re-fetch permissions after save to update UI and reset dirty state
      await fetchAndSetRoles(true);
    } catch (err) {
      console.error(err);
      setModal({ open: true, message: "Save failed", type: "error" });
    } finally {
      setIsSaving(false);
    }
  };

  const addRole = () => {
    const name = prompt("New role name");
    if (!name) return;
    const newRole: Role = { id: name.replace(/\s+/g, "-").toLowerCase(), name, permissions: Object.fromEntries(modules.map((m) => [m, { ...defaultPermissions }])) };
    setRoles((p) => [...p, newRole]);
    setSelectedRole(newRole.name);
  };

  const visibleRoles = React.useMemo(() => {
    if (selectedDepartment) {
      const allowedRoles = DEPARTMENT_ROLE_MAP[selectedDepartment].map(r => r.toLowerCase());
      return roles.filter(r => allowedRoles.includes(r.name.toLowerCase()));
    }
    return roles.filter((r) => r.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [roles, selectedDepartment, searchTerm]);

  // Auto-select first role in visibleRoles if none selected or if selectedRole is not in visibleRoles
  React.useEffect(() => {
    if (visibleRoles.length === 0) {
      if (selectedRole !== "") setSelectedRole("");
      return;
    }
    // If no role is selected or selectedRole is not in visibleRoles, select the first
    if (!selectedRole || !visibleRoles.some(r => r.name === selectedRole)) {
      setSelectedRole(visibleRoles[0].name);
    }
  }, [visibleRoles, selectedDepartment]);

  const formatRoleDisplay = (name: string) => name.replace(/_/g, ' ');

  return (
    <div className="p-0 min-h-screen bg-gray-50">
      {/* Modal Popup */}
      {modal.open && (
        <div className="fixed inset-0 z-5000000 flex items-center justify-center bg-black/30">
          <div className="bg-white rounded-lg shadow-lg p-8 min-w-[300px] flex flex-col items-center">
            <div className={`text-lg font-semibold mb-4 ${modal.type === 'success' ? 'text-green-600' : 'text-red-600'}`}>{modal.message}</div>
            <button className="mt-2 px-4 py-2 bg-green-600 text-white rounded" onClick={() => setModal({ ...modal, open: false })}>OK</button>
          </div>
        </div>
      )}
      <div className="flex h-[calc(100vh-3rem)] min-h-0 bg-white rounded-xl shadow overflow-hidden">
        <aside className="w-80 border-r border-gray-200 bg-white flex flex-col">
          <div className="px-6 py-4">
            <h3 className="text-lg font-bold">Roles</h3>
            <p className="text-sm text-gray-500">Select a role to edit permissions</p>
          </div>
          <div className="px-6 pb-4">
            <select
              value={selectedDepartment}
              onChange={e => setSelectedDepartment(e.target.value)}
              className="w-full px-3 py-2 border rounded"
            >
              {departmentKeys.map(key => (
                <option key={key} value={key}>{key.charAt(0).toUpperCase() + key.slice(1)}</option>
              ))}
            </select>
          </div>
          <div className="flex-1 overflow-auto p-4 px-8 space-y-2">
            {visibleRoles.map((r) => (
              <label key={r.id} className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="role"
                  value={r.name}
                  checked={selectedRole === r.name}
                  onChange={() => {
                    setSelectedRole(r.name);
                    fetchRolePermissions(r.name);
                  }}
                  className="w-4 h-4 text-green-600"
                />
                <span className={`${selectedRole === r.name ? 'text-green-700 font-semibold' : 'text-gray-700'}`}>{formatRoleDisplay(r.name)}</span>
              </label>
            ))}
            {visibleRoles.length === 0 && (
              <div className="text-center text-sm text-gray-500">No roles found</div>
            )}
          </div>
          {/* <div className="p-4 border-t">
            <button onClick={addRole} className="text-sm text-green-600">+ Add role</button>
          </div> */}
        </aside>

        <main className="flex-1 flex flex-col min-h-0">
          <div className="px-6 py-4 border-b flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold">Permissions for <span className="text-green-600">{selectedRole ? formatRoleDisplay(selectedRole) : ''}</span></h2>
              <p className="text-sm text-gray-500">Toggle permissions per module</p>
            </div>
            <div>
              <button
                onClick={handleSavePermissions}
                disabled={isSaving || dirtyRoles.length === 0}
                className={`px-4 py-2 rounded text-white ${isSaving || dirtyRoles.length === 0 ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600'}`}
              >
                {isSaving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>

          <div className="flex-1 p-0 flex flex-col min-h-0">
            {selectedRoleData ? (
              <div className="flex-1 h-full overflow-y-auto overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 h-full">
                  <thead>
                    <tr>
                      <th className="sticky top-0 bg-white z-20 text-left px-4 py-3">Module</th>
                      <th className="sticky top-0 bg-white z-20 px-4 py-3 text-center">All</th>
                      <th className="sticky top-0 bg-white z-20 px-4 py-3 text-center">View</th>
                      <th className="sticky top-0 bg-white z-20 px-4 py-3 text-center">Create</th>
                      <th className="sticky top-0 bg-white z-20 px-4 py-3 text-center">Edit</th>
                      <th className="sticky top-0 bg-white z-20 px-4 py-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white">
                    {modules.map((m) => {
                      const perm = selectedRoleData.permissions[m] ?? defaultPermissions;
                      const totalChecked = (perm.view ? 1 : 0) + (perm.create ? 1 : 0) + (perm.edit ? 1 : 0) + (perm.action ? 1 : 0);
                      const allChecked = totalChecked === 4;
                      const someChecked = totalChecked > 0 && totalChecked < 4;
                      return (
                        <tr key={m} className="border-t">
                          <td className="px-4 py-3 font-medium">{m}</td>
                          <td className="px-4 py-3 text-center">
                            <input
                              type="checkbox"
                              checked={allChecked}
                              onChange={(e) => toggleAllPermissionsForModule(m, e.target.checked)}
                              ref={(el) => { if (el) el.indeterminate = someChecked; }}
                            />
                          </td>
                          <td className="px-4 py-3 text-center"><input type="checkbox" checked={perm.view} onChange={(e) => updatePermission(m, 'view', e.target.checked)} /></td>
                          <td className="px-4 py-3 text-center"><input type="checkbox" checked={perm.create} onChange={(e) => updatePermission(m, 'create', e.target.checked)} /></td>
                          <td className="px-4 py-3 text-center"><input type="checkbox" checked={perm.edit} onChange={(e) => updatePermission(m, 'edit', e.target.checked)} /></td>
                          <td className="px-4 py-3 text-center"><input type="checkbox" checked={perm.action} onChange={(e) => updatePermission(m, 'action', e.target.checked)} /></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center bg-white">
                <span className="text-gray-500 text-lg">Select a Role to Configure Permissions to the user</span>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default UserManagement;
