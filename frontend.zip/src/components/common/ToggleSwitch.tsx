"use client";
import React from "react";

interface ToggleSwitchProps {
  id: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ id, checked, onChange }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    id={id}
    onClick={() => onChange(!checked)}
    className={`w-12 h-6 rounded-full transition-colors duration-200 flex items-center px-0.5 ${
      checked ? "bg-green-500" : "bg-gray-300"
    }`}
    style={{ minWidth: 48, minHeight: 24 }}
  >
    <span
      className={`w-5 h-5 bg-white rounded-full shadow transition-transform duration-200`}
      style={{
        transform: checked ? "translateX(24px)" : "translateX(0)",
        display: "block",
      }}
    />
  </button>
);

export default ToggleSwitch;