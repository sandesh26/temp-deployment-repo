'use client';
import React, { useState } from 'react';
import {
  FaPowerOff,
  FaSyncAlt,
  FaChartBar,
  FaTools,
  FaMoneyBillWave,
  FaCheckCircle,
} from 'react-icons/fa';

const SlotMachineComponent: React.FC = () => {
  const [activeTab, setActiveTab] = useState('SUMMARY');

  const tabs = ['SUMMARY', 'PERFORMANCE', 'PLAYERS', 'EVENTS', 'TECH DETAILS', 'HISTORY'];

  return (
    <div className="cage-wrapper">
      {/* Top Menu Bar */}
      <div className="top-bar">
        <ul className="menu">
          {tabs.map((tab) => (
            <li
              key={tab}
              className={activeTab === tab ? 'active' : ''}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </li>
          ))}
        </ul>
        <button className="action-button">Action</button>
      </div>

      {/* Content based on tab */}
      {activeTab === 'SUMMARY' && (
        <>
          <div className="main-info">
            <img src="/vega-vision.png" alt="Vega Vision" className="game-img" />
            <div className="info">
              <h2>
                Vega Vision <span className="live-status">Live</span>
              </h2>
              <p>Multigame / UpRight / EGT</p>
              <p>Game Set: EGT665</p>
              <p>Max Bet: 9.999€ | Volatility: 0</p>
              <p>Multidemon: € 0.01, 0.02, 0.05, 0.10</p>
              <p>
                On floor since: <strong>June 22nd 2013</strong> (25 months)
              </p>
              <p>
                Last configuration since: <strong>August 20th 2015</strong> (1 day)
              </p>
            </div>

            <div className="actions">
              <FaPowerOff title="Power Off" />
              <FaSyncAlt title="Restart" />
              <FaChartBar title="Stats" />
              <FaTools title="Settings" />
              <FaMoneyBillWave title="Finance" />
              <FaCheckCircle title="Active" />
            </div>

            <div className="credit-box">
              <p>
                Credits: <strong>€ 0.00</strong>
              </p>
              <p>
                Cash in dropbox: <strong>€ 0.00</strong>
              </p>
            </div>
          </div>

          {/* Table Section */}
          <div className="table-section">
            <table>
              <thead>
                <tr>
                  <th></th>
                  <th>Today</th>
                  <th>This Month</th>
                  <th>Previous Month</th>
                  <th>This Year</th>
                  <th>Lifetime</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Total In</td>
                  <td>€ 550</td>
                  <td>€ 62.118</td>
                  <td>€ 300.760</td>
                  <td>€ 5.942.913</td>
                  <td>€ 11.269.401</td>
                </tr>
                <tr>
                  <td>- of which Promo In</td>
                  <td>€ 108</td>
                  <td>€ 6.991</td>
                  <td>€ 4.101</td>
                  <td>€ 26.058</td>
                  <td>€ 167.344</td>
                </tr>
                <tr>
                  <td>Net Win</td>
                  <td className="green">€ 140</td>
                  <td className="red">€ -6.903</td>
                  <td className="green">€ 21.504</td>
                  <td className="green">€ 234.329</td>
                  <td className="green">€ 618.722</td>
                </tr>
                <tr>
                  <td>True Net Win</td>
                  <td className="green">€ 32</td>
                  <td className="red">€ -13.894</td>
                  <td className="green">€ 17.402</td>
                  <td className="green">€ 208.272</td>
                  <td className="green">€ 451.379</td>
                </tr>
                <tr>
                  <td>Net Win w/o Mystery</td>
                  <td className="green">€ 140</td>
                  <td className="red">€ -1.303</td>
                  <td className="green">€ 28.604</td>
                  <td className="green">€ 256.029</td>
                  <td className="green">€ 640.422</td>
                </tr>
                <tr>
                  <td>Games Played</td>
                  <td>55</td>
                  <td>1.613</td>
                  <td>6.122</td>
                  <td>90.329</td>
                  <td>346.889</td>
                </tr>
                <tr>
                  <td>Average Bet</td>
                  <td>€ 10.00</td>
                  <td>€ 38.51</td>
                  <td>€ 49.13</td>
                  <td>€ 65.79</td>
                  <td>€ 32.49</td>
                </tr>
                <tr>
                  <td>RTP</td>
                  <td>74.55%</td>
                  <td>111.11%</td>
                  <td>92.85%</td>
                  <td>96.06%</td>
                  <td>94.51%</td>
                </tr>
                <tr>
                  <td>RTP w/o Mystery</td>
                  <td>74.55%</td>
                  <td>102.10%</td>
                  <td>90.49%</td>
                  <td>95.69%</td>
                  <td>94.32%</td>
                </tr>
                <tr>
                  <td>Avg. Occupancy</td>
                  <td>0.25%</td>
                  <td>0.36%</td>
                  <td>0.91%</td>
                  <td>2.12%</td>
                  <td>2.17%</td>
                </tr>
                <tr>
                  <td>Profit</td>
                  <td className="green">€ 140</td>
                  <td className="red">€ -6.903</td>
                  <td className="green">€ 21.504</td>
                  <td className="green">€ 234.329</td>
                  <td className="green">€ 618.722</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="footer-note">
            LAST FIVE JACKPOTS SHOWING GREATER THAN € 500,00
          </div>
        </>
      )}

      {/* Placeholder for other tabs */}
      {activeTab !== 'SUMMARY' && (
        <div className="tab-placeholder">
          <h3>{activeTab}</h3>
          {/* <p>Coming soon...</p> */}
        </div>
      )}

      {/* CSS */}
      <style jsx>{`
        .cage-wrapper {
          font-family: Arial, sans-serif;
          background: #fff;
          padding: 20px;
          border-radius: 8px;
        }
        .top-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }
        .menu {
          display: flex;
          list-style: none;
          padding: 0;
        }
        .menu li {
          margin-right: 20px;
          cursor: pointer;
          font-weight: bold;
          color: #666;
        }
        .menu .active {
          color: black;
          border-bottom: 2px solid black;
        }
        .action-button {
          background: #333;
          color: #fff;
          padding: 8px 12px;
          border: none;
          border-radius: 4px;
        }
        .main-info {
          display: flex;
          align-items: flex-start;
          gap: 20px;
          margin-bottom: 30px;
        }
        .game-img {
          width: 200px;
          height: auto;
        }
        .info {
          flex: 2;
        }
        .live-status {
          background: green;
          color: white;
          font-size: 0.8rem;
          padding: 2px 6px;
          margin-left: 10px;
          border-radius: 4px;
        }
        .actions {
          display: flex;
          flex-direction: column;
          gap: 10px;
          font-size: 1.2rem;
        }
        .credit-box {
          margin-top: 10px;
        }
        .table-section table {
          width: 100%;
          border-collapse: collapse;
        }
        .table-section th,
        .table-section td {
          padding: 10px;
          text-align: center;
          // border: 1px solid #ccc;
        }
        .green {
          color: green;
        }
        .red {
          color: red;
        }
        .footer-note {
          margin-top: 20px;
          font-size: 0.9rem;
          color: #888;
        }
        .tab-placeholder {
          padding: 40px;
          text-align: center;
          color: #999;
          border: 1px dashed #ccc;
        }
      `}</style>
    </div>
  );
};

export default SlotMachineComponent;