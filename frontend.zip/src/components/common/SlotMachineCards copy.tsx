"use client";
import React, { useEffect, useState } from 'react';
import Link from "next/link";

export type Balance = {
  label: string;
  value: string;
  warning?: boolean;
};

export type CardData = {
  title: string;
  code: string;
  status: 'IDLE' | 'RUNNING' | 'CLOSED';
  gamingDay: string;
  cageType: string;
  lastPlayed: string;
  playedBy: string;
  balances: Balance[];
  currentBet: string;
};

type StatusBadgeProps = {
  status: 'IDLE' | 'RUNNING' | 'CLOSED';
};

type CardProps = {
  data: CardData;
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => (
  <span className={`status ${status.toLocaleLowerCase()}`}>{status.toUpperCase()}</span>
);

const Card: React.FC<CardProps> = ({ data }) => (
  <Link href={`/slot-machine`} className="no-underline block">
    <div className="card">
      <div className="card-header">
        <div className="title">{data.title} <span className="code">({data.code})</span></div>
        <StatusBadge status={data.status} />
      </div>
      <div className="details">
        <div><span>Gaming Day</span>{data.gamingDay || '—'}</div>
        <div><span>Last Played</span>{data.lastPlayed || '—'}</div>
        <div><span>Player</span>{data.playedBy || '—'}</div>
        <div><span>Current Bet</span>{data.currentBet || '—'}</div>
      </div>
    </div>
  </Link>
);

const SlotMachines: React.FC<{ apiUrl: string }> = ({ apiUrl }) => {
  const [cardData, setCardData] = useState<CardData[]>([]);

  useEffect(() => {
    fetch(apiUrl)
      .then(res => res.json())
      .then((data) => {
        // If your API returns an array, map directly. If it returns an object, adjust accordingly.
        const mapped = data.map((item: any) => ({
          title: `SLOT MACHINE ${item.machine_number || item.machine_id}`,
          code: item.machine_number || `SM${item.machine_id}`,
          status:
            item.machine_status === "Active"
              ? "Active"
              : item.machine_status === "Idle"
              ? "IDLE"
              : "CLOSED",
          gamingDay: item.last_updated ? item.last_updated.split("T")[0] : "",
          cageType: item.location || "",
          lastPlayed: item.last_updated || "",
          playedBy: item.current_player_id ? `Player ${item.current_player_id}` : "—",
          balances: [
            { label: "MONEY", value: item.current_balance }
          ],
          currentBet: item.current_balance
        }));
        setCardData(mapped);
      });
  }, []);

  return (
    <div className="card-container">
      {cardData.map((card, i) => <Card key={i} data={card} />)}
    </div>
  );
};

export default SlotMachines;
