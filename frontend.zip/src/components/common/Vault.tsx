import React, { useEffect, useState, useRef } from 'react';
import { API_BASE_URL } from "@/config/api";
import { CashIcon, ChipsIcon, VaultIcon, OnlinePaymentIcon, TitoTicketIcon } from "@/icons";
import ChipsManagement from './ChipsManagement';
import ExportToExcel, { ExportRef } from './ExportToExcel';
import { useRef as useRef2 } from 'react';

// Small confirm dialog used before saving changes
type ConfirmDialogProps = {
  open: boolean;
  title?: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
  // whether the confirm action is processing (used to disable buttons)
  processing?: boolean;
  // optional error message to display from server
  errorMessage?: string | null;
};

const ConfirmDialog: React.FC<ConfirmDialogProps> = ({ open, title, message, onConfirm, onCancel, processing = false, errorMessage = null }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black opacity-30" onClick={onCancel}></div>
      <div className="bg-white rounded shadow-lg z-60 max-w-md w-full p-4">
        {title && <div className="font-semibold text-lg mb-2">{title}</div>}
        <div className="text-sm text-gray-700 mb-4">{message}</div>
        {errorMessage && (
          <div className="mb-3 text-sm text-red-600 whitespace-pre-wrap">{errorMessage}</div>
        )}
        <div className="flex justify-end gap-2">
          <button className="px-3 py-1 border rounded" onClick={onCancel} disabled={processing}>Cancel</button>
          <button className="px-3 py-1 bg-green-600 text-white rounded" onClick={onConfirm} disabled={processing}>{processing ? 'Processing...' : 'Confirm'}</button>
        </div>
      </div>
    </div>
  );
};

// Small inline component to edit or add cash reserve value
type EditCashControlProps = {
  currentValue: number;
  currency: string;
  mode?: 'edit' | 'add';
  onSave: (value: number) => Promise<{ success: boolean; message?: string }>;
  // if provided, only the control whose id matches activeEditor can enter editing mode
  id?: string;
  activeEditor?: string | null;
  requestStartEdit?: (id: string) => void;
  requestCloseEdit?: (id: string) => void;
};

const EditCashControl: React.FC<EditCashControlProps> = ({ currentValue, currency, mode = 'edit', onSave, id, activeEditor, requestStartEdit, requestCloseEdit }) => {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(mode === 'add' ? '' : String(currentValue));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);

  useEffect(() => setValue(mode === 'add' ? '' : String(currentValue)), [currentValue, mode]);


  function openConfirm() {
    setError(null);
    const num = Number(value);
    if (isNaN(num) || num < 0) {
      setError('Enter a valid non-negative number');
      return;
    }
    setConfirmOpen(true);
  }

  async function doSave() {
    setConfirmOpen(false);
    setLoading(true);
    const num = Number(value);
    const res = await onSave(num);
    setLoading(false);
    if (res.success) {
  setEditing(false);
  setValue(mode === 'add' ? '' : String(num));
  // notify parent to clear active editor if provided
  if (id && requestCloseEdit) requestCloseEdit(id);
    } else {
      setError(res.message || 'Save failed');
    }
  }

    useEffect(() => {
      if (!editing) {
        setValue(mode === 'add' ? '' : String(currentValue));
        setError(null);
      }
    }, [editing, currentValue, mode]);
    // Enable Save only when add amount > 0 or edit amount differs from currentValue
    const numericValue = value === '' ? NaN : Number(value);
    const canSave = mode === 'add'
      ? !isNaN(numericValue) && numericValue > 0
      : !isNaN(numericValue) && numericValue !== currentValue;
  const title = mode === 'add' ? 'Confirm Add Cash' : 'Confirm Update';
  const message = mode === 'add'
    ? `Are you sure you want to add ${currency} ${Number(value || 0).toLocaleString('en-IN')} to the vault balance?`
    : `Are you sure you want to set the vault cash reserve to ${currency} ${Number(value || 0).toLocaleString('en-IN')}?`;

  // control should open edit only when requested/allowed
  useEffect(() => {
    if (typeof activeEditor !== 'undefined' && id) {
      setEditing(activeEditor === id);
    }
  }, [activeEditor, id]);

  return (
    <div className="flex flex-col items-end gap-2">
      {!editing ? (
        <button
          className={`px-4 py-2 ${mode === 'add' ? 'bg-green-700 hover:bg-green-800' : 'bg-yellow-500 hover:bg-yellow-600'} text-white rounded`}
          onClick={() => { if (id && requestStartEdit) requestStartEdit(id); else setEditing(true); }}
        >{mode === 'add' ? 'Add Cash' : 'Edit'}</button>
      ) : (
        <div className="flex items-center gap-2">
          {/* Mode badge to indicate which control is active */}
          <div className="flex items-center">
            <span className="text-xs px-2 py-1 rounded bg-yellow-100 text-yellow-800 mr-2">{mode === 'add' ? 'Adding' : 'Editing'}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-sm text-gray-600">{currency}</span>
            <input
              type="number"
              min={0}
              step="0.01"
              className="w-36 border rounded px-2 py-1 text-sm"
              value={value}
              onChange={e => {
                let v = e.target.value;
                // strip non-numeric except dot
                v = v.replace(/[^0-9.]/g, '');
                // allow only one dot
                const parts = v.split('.');
                if (parts.length > 2) {
                  v = parts[0] + '.' + parts.slice(1).join('');
                }
                // remove leading zeros (but allow '0' and decimals)
                if (/^0[0-9]+/.test(v) && !v.startsWith('0.')) {
                  v = String(Number(v));
                }
                setValue(v);
              }}
              onKeyDown={e => {
                // prevent scientific notation and signs
                if (e.key === 'e' || e.key === 'E' || e.key === '+' || e.key === '-') {
                  e.preventDefault();
                }
              }}
            />
          </div>
          <button
            className={`px-3 py-1 rounded ${canSave && !loading ? 'bg-green-600 text-white' : 'bg-green-200 text-white/60 cursor-not-allowed'}`}
            onClick={openConfirm}
            disabled={loading || !canSave}
          >{loading ? 'Saving...' : 'Save'}</button>
          <button className="px-3 py-1 border rounded" onClick={() => { if (id && requestCloseEdit) requestCloseEdit(id); else { setEditing(false); setValue(mode === 'add' ? '' : String(currentValue)); setError(null); } }}>Cancel</button>
        </div>
      )}
      {error && <div className="text-xs text-red-600">{error}</div>}
      <ConfirmDialog open={confirmOpen} title={title} message={message} onConfirm={doSave} onCancel={() => setConfirmOpen(false)} />
    </div>
  );
};

// Utility to format denomination
function formatDenomination(value: string) {
  const num = Number(value);
  if (num >= 10000000) return `${(num / 10000000).toFixed(num % 10000000 === 0 ? 0 : 1)} Cr`;
  if (num >= 100000) return `${(num / 100000).toFixed(num % 100000 === 0 ? 0 : 1)} L`;
  if (num >= 1000) return `${(num / 1000).toFixed(num % 1000 === 0 ? 0 : 1)} K`;
  return `${num}`;
}

const TRANSACTION_COLUMNS = [
  { key: "transaction_id", label: "Txn ID" },
  { key: "transaction_type", label: "Type" },
  { key: "asset_type", label: "Asset" },
  { key: "denomination", label: "Denomination" },
  { key: "quantity", label: "Qty" },
  { key: "total_value", label: "Amount" },
  { key: "currency_code", label: "Currency" },
  { key: "source", label: "Source" },
  { key: "destination", label: "Destination" },
  { key: "reference_id", label: "Reference" },
  { key: "authorized_by", label: "Authorized By" },
  { key: "performed_by", label: "Performed By" },
  { key: "transaction_time", label: "Time" },
  { key: "notes", label: "Notes" },
];

const REQUEST_COLUMNS = [
  { key: 'request_id', label: 'Req ID' },
  { key: 'request_type', label: 'Type' },
  { key: 'cage', label: 'Cage' },
  { key: 'amount', label: 'Amount' },
  { key: 'cash_amount', label: 'Cash' },
  { key: 'chip_amount', label: 'Chips' },
  { key: 'status', label: 'Status' },
  { key: 'initiatedBy', label: 'Initiated By' },
  { key: 'requested_at', label: 'Requested At' },
  { key: 'remarks', label: 'Remarks' },
  { key: 'actions', label: 'Actions' },
];

const Vault: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"overview" | "transactions" | "chip-management" | "cash-management" | "requests">("overview");
  const [vault, setVault] = useState<null | {
    currency_code: string;
    total_cash: string;
    total_chips: string;
    total_assets: string;
    total_online: string;
    total_tito: string;
    last_updated: string;
  }>(null);

  const [chipData, setChipData] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]); // current page rows from server
  const [requests, setRequests] = useState<any[]>([]);
  const [reqSearch, setReqSearch] = useState("");
  // Default to showing open requests
  const [reqStatus, setReqStatus] = useState<string | null>('PENDING_VAULT_ACTION');
  const [reqType, setReqType] = useState<string | null>(null);
  const [reqPage, setReqPage] = useState(1);
  const [reqPageSize, setReqPageSize] = useState(10);
  const [reqTotalCount, setReqTotalCount] = useState(0);
  const [reqServerTotalPages, setReqServerTotalPages] = useState(0);
  // whether the requests endpoint returned paginated metadata (server-side paging)
  const [reqIsServerPaged, setReqIsServerPaged] = useState(false);
  const [reqVisibleColumns, setReqVisibleColumns] = useState<string[]>(REQUEST_COLUMNS.map(c => c.key));
  const [reqShowColDropdown, setReqShowColDropdown] = useState(false);
  const [reqExportMenuOpen, setReqExportMenuOpen] = useState(false);
  const [reqDateFilterOpen, setReqDateFilterOpen] = useState(false);
  const [reqStartDate, setReqStartDate] = useState<string | null>(null);
  const [reqEndDate, setReqEndDate] = useState<string | null>(null);
  const [reqRefreshKey, setReqRefreshKey] = useState(0);

  const [actionConfirmOpen, setActionConfirmOpen] = useState(false);
  const [actionTargetId, setActionTargetId] = useState<number | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | null>(null);
  const [actionProcessing, setActionProcessing] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [requestModalOpen, setRequestModalOpen] = useState(false);
  const [requestModalData, setRequestModalData] = useState<any | null>(null);
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState("transaction_time");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  // Request table sorting (separate from transactions)
  const [reqSortKey, setReqSortKey] = useState<string>("requested_at");
  const [reqSortDir, setReqSortDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [visibleColumns, setVisibleColumns] = useState<string[]>(TRANSACTION_COLUMNS.map(col => col.key));
  const [showColDropdown, setShowColDropdown] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);
  const [dateFilterOpen, setDateFilterOpen] = useState(false);
  // Small popup notification used for save success/failure
  const [popup, setPopup] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const [showPopup, setShowPopup] = useState(false);
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [serverTotalPages, setServerTotalPages] = useState<number>(0);
  const exportRef = useRef2<ExportRef | null>(null);
  const reqExportRef = useRef2<ExportRef | null>(null);
  const reqColDropdownRef = useRef<HTMLDivElement | null>(null);
  const exportMenuRef = useRef<HTMLDivElement | null>(null);
  const exportButtonRef = useRef<HTMLButtonElement | null>(null);
  const dateFilterRef = useRef<HTMLDivElement | null>(null);
  const dateFilterButtonRef = useRef<HTMLButtonElement | null>(null);

  // Auto-hide popup after a short duration
  useEffect(() => {
    if (!showPopup) return;
    const t = setTimeout(() => setShowPopup(false), 3000);
    return () => clearTimeout(t);
  }, [showPopup]);

  // For closing dropdown on outside click
  const colDropdownRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function handleExportClickOutside(event: MouseEvent) {
      const target = event.target as Node;
      if (exportMenuOpen) {
        if (
          exportMenuRef.current && !exportMenuRef.current.contains(target) &&
          exportButtonRef.current && !exportButtonRef.current.contains(target)
        ) {
          setExportMenuOpen(false);
        }
      }
    }
    if (exportMenuOpen) {
      document.addEventListener('mousedown', handleExportClickOutside);
    } else {
      document.removeEventListener('mousedown', handleExportClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleExportClickOutside);
  }, [exportMenuOpen]);

  // Close date filter popup on outside click
  useEffect(() => {
    function handleDateFilterClickOutside(event: MouseEvent) {
      const target = event.target as Node;
      if (dateFilterOpen) {
        if (
          dateFilterRef.current && !dateFilterRef.current.contains(target) &&
          dateFilterButtonRef.current && !dateFilterButtonRef.current.contains(target)
        ) {
          setDateFilterOpen(false);
        }
      }
    }
    if (dateFilterOpen) {
      document.addEventListener('mousedown', handleDateFilterClickOutside);
    } else {
      document.removeEventListener('mousedown', handleDateFilterClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleDateFilterClickOutside);
  }, [dateFilterOpen]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (colDropdownRef.current && !colDropdownRef.current.contains(event.target as Node)) {
        setShowColDropdown(false);
      }
    }
    if (showColDropdown) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showColDropdown]);

  // close request show-columns dropdown when clicking outside
  useEffect(() => {
    function handleReqColClickOutside(event: MouseEvent) {
      const target = event.target as Node;
      if (reqColDropdownRef.current && !reqColDropdownRef.current.contains(target)) {
        setReqShowColDropdown(false);
      }
    }
    if (reqShowColDropdown) document.addEventListener('mousedown', handleReqColClickOutside);
    else document.removeEventListener('mousedown', handleReqColClickOutside);
    return () => document.removeEventListener('mousedown', handleReqColClickOutside);
  }, [reqShowColDropdown]);

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/vault-balance/1`)
      .then(res => res.json())
      .then(data => setVault(data));
    fetch(`${API_BASE_URL}/api/vault-chip-denomination`)
      .then(res => res.json())
      .then(data => setChipData(data));
  }, []);

  useEffect(() => {
    if (activeTab === "transactions") {
      const controller = new AbortController();
      const q = new URLSearchParams();
      q.set('page', String(page));
      q.set('pageSize', String(pageSize));
      if (startDate) q.set('startDate', startDate);
      if (endDate) q.set('endDate', endDate);
      fetch(`${API_BASE_URL}/api/vault-transaction?${q.toString()}`, { signal: controller.signal })
        .then(res => res.json())
        .then(data => {
          // expected shape: { data: [...], page, pageSize, total, totalPages }
          setTransactions(Array.isArray(data.data) ? data.data : []);
          if (typeof data.total === 'number') setTotalCount(data.total);
          if (typeof data.totalPages === 'number') setServerTotalPages(data.totalPages);
          // keep local page/pageSize in sync if API returns them
          if (typeof data.page === 'number') setPage(data.page);
          if (typeof data.pageSize === 'number') setPageSize(data.pageSize);
        }).catch(err => {
          if (err.name === 'AbortError') return;
          console.error('Failed to fetch transactions', err);
        });
      return () => controller.abort();
    }
  }, [activeTab]);

  // Fetch open requests when requests tab is active or filters/pagination change
  useEffect(() => {
    if (activeTab !== 'requests') return;
    const controller = new AbortController();
    const q = new URLSearchParams();
    q.set('open', 'true');
    if (reqPage) q.set('page', String(reqPage));
    if (reqPageSize) q.set('pageSize', String(reqPageSize));
    if (reqStartDate) q.set('startDate', reqStartDate);
    if (reqEndDate) q.set('endDate', reqEndDate);
    if (reqStatus) q.set('status', reqStatus);
    if (reqType) q.set('request_type', reqType);
    if (reqSearch) q.set('search', reqSearch);
    fetch(`${API_BASE_URL}/api/cage-vault-requests?${q.toString()}`, { signal: controller.signal })
      .then(res => res.json())
      .then(data => {
        // API may return an array OR an object with { data, total, totalPages }
        if (Array.isArray(data)) {
          // Server returned a plain array - fall back to client-side paging
          setReqIsServerPaged(false);
          setRequests(data);
          setReqTotalCount(data.length);
          setReqServerTotalPages(Math.ceil(data.length / reqPageSize));
        } else if (data && Array.isArray(data.data)) {
          // Server returned paginated structure - use server-side paging
          setReqIsServerPaged(true);
          setRequests(data.data);
          if (typeof data.total === 'number') setReqTotalCount(data.total);
          if (typeof data.totalPages === 'number') setReqServerTotalPages(data.totalPages);
          // ensure page stays within server-provided pages
          if (typeof data.page === 'number') setReqPage(data.page);
        } else {
          setReqIsServerPaged(false);
          setRequests([]);
          setReqTotalCount(0);
          setReqServerTotalPages(0);
        }
      }).catch(err => {
        if (err.name === 'AbortError') return;
        console.error('Failed to fetch requests', err);
      });
    return () => controller.abort();
  }, [activeTab, reqPage, reqPageSize, reqStartDate, reqEndDate, reqStatus, reqType, reqSearch, reqRefreshKey]);

  // Client-side filtering & pagination for requests (ensures dropdowns and search always affect displayed rows)
  const filteredRequests = requests.filter(r => {
    // filter by type/status if selected
    if (reqType && String(r.request_type) !== String(reqType)) return false;
    if (reqStatus && String(r.status) !== String(reqStatus)) return false;
    // date range filter (requested_at)
    if (reqStartDate || reqEndDate) {
      const t = r.requested_at ? new Date(r.requested_at) : null;
      if (!t) return false;
      if (reqStartDate) {
        const s = new Date(reqStartDate);
        if (t < s) return false;
      }
      if (reqEndDate) {
        const e = new Date(reqEndDate);
        e.setHours(23, 59, 59, 999);
        if (t > e) return false;
      }
    }
    // text search across relevant fields
    if (reqSearch && reqSearch.trim() !== '') {
      const q = reqSearch.trim().toLowerCase();
      const hay = [
        String(r.request_id ?? ''),
        String(r.request_type ?? ''),
        String(r.cage?.name ?? ''),
        String(r.amount ?? ''),
        String(r.cash_amount ?? ''),
        String(r.chip_amount ?? ''),
        String(r.remarks ?? ''),
        String(r.initiatedBy?.user?.full_name ?? ''),
        String(r.status ?? ''),
      ].join(' ').toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  // When server-side paging is enabled, `requests` already contains the current page
  const reqTotalFiltered = reqIsServerPaged ? (requests.length || 0) : filteredRequests.length;
  const reqTotalPagesDerived = reqIsServerPaged
    ? Math.max(1, reqServerTotalPages || Math.ceil((reqTotalCount || reqTotalFiltered) / reqPageSize || 1))
    : Math.max(1, Math.ceil(reqTotalFiltered / reqPageSize || 1));
  const displayedRequests = reqIsServerPaged ? requests : filteredRequests.slice((reqPage - 1) * reqPageSize, reqPage * reqPageSize);

  // Client-side sorting for displayed requests. When server-side paging is enabled
  // the server may already provide a sort order; we still allow client sorting
  // on the currently-loaded page for convenience.
  function reqAccessor(row: any, key: string) {
    if (!row) return '';
    if (key === 'requested_at') return row.requested_at ? new Date(row.requested_at).getTime() : 0;
    if (key === 'amount' || key === 'cash_amount' || key === 'chip_amount') return Number(row[key] ?? 0);
    if (key === 'initiatedBy') return row.initiatedBy?.user?.full_name ?? row.initiatedBy?.employee_id ?? '';
    // fallback to raw value
    return row[key] ?? '';
  }

  const sortedDisplayedRequests = [...displayedRequests].sort((a, b) => {
    const aVal = reqAccessor(a, reqSortKey);
    const bVal = reqAccessor(b, reqSortKey);
    // numeric/date compare
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      if (aVal < bVal) return reqSortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return reqSortDir === 'asc' ? 1 : -1;
      return 0;
    }
    // string compare
    const sa = String(aVal).toLowerCase();
    const sb = String(bVal).toLowerCase();
    if (sa < sb) return reqSortDir === 'asc' ? -1 : 1;
    if (sa > sb) return reqSortDir === 'asc' ? 1 : -1;
    return 0;
  });

  // Ensure current page is valid when filters change
  useEffect(() => {
    if (reqPage > reqTotalPagesDerived) {
      setReqPage(1);
    }
  }, [reqTotalPagesDerived]);

  function openActionConfirm(id: number, type: 'approve' | 'reject') {
    setActionTargetId(id);
    setActionType(type);
    setActionConfirmOpen(true);
  }

  async function performRequestAction() {
    if (!actionTargetId || !actionType) return;
    // keep the confirm dialog open while processing so we can show server-side errors
    setActionError(null);
    setActionProcessing(true);
    try {
      // Helper to read current logged in user id from localStorage (robust fallback)
      const getCurrentUserId = () => {
        try {
          const raw = localStorage.getItem('casino_session_v1');
          if (!raw) return null;
          const s = JSON.parse(raw);
          if (s?.user?.user_id) return s.user.user_id;
          if (s?.user?.id) return s.user.id;
          if (s?.id) return s.id;
          return null;
        } catch (e) {
          return null;
        }
      };

      const reviewed_by = getCurrentUserId();
      const followStatus = actionType === 'approve' ? 'AWAITING_CAGE_CONFIRMATION' : 'CLOSED_REJECTED';
      const remarks = actionType === 'approve'
        ? 'Verified vault allocation, awaiting cage confirmation'
        : 'Request rejected by reviewer';

      const res = await fetch(`${API_BASE_URL}/api/cage-vault-requests/${actionTargetId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: followStatus, reviewed_by: reviewed_by, remarks }),
      });

      if (!res.ok) {
        // try to extract a useful message from the response
        let serverMsg = `Server responded with status ${res.status}`;
        try {
          const text = await res.text();
          if (text) {
            try {
              const data = JSON.parse(text);
              serverMsg = data?.message || data?.error || JSON.stringify(data);
            } catch (e) {
              serverMsg = text;
            }
          }
        } catch (e) {
          // ignore
        }
        setActionError(serverMsg);
        setActionProcessing(false);
        return;
      }

      // success
      setActionProcessing(false);
      setActionConfirmOpen(false);
      setActionError(null);
      setPopup({ message: `Request ${actionType === 'approve' ? 'approved' : 'rejected'}`, type: 'success' });
      setShowPopup(true);
      // trigger refresh
      setReqRefreshKey(k => k + 1);
    } catch (err) {
      console.error('Failed to perform action', err);
      setActionError(String(err));
      setActionProcessing(false);
    }
  }

  function viewRequestDetails(r: any) {
    // replaced by request details modal (openRequestModal)
  }

  function openRequestModal(req: any) {
    if (!req) return;
    setRequestModalData(req);
    setRequestModalOpen(true);
  }

  // refetch when pagination or date filters change while on transactions tab
  useEffect(() => {
    if (activeTab !== 'transactions') return;
    const controller = new AbortController();
    const q = new URLSearchParams();
    q.set('page', String(page));
    q.set('pageSize', String(pageSize));
    if (startDate) q.set('startDate', startDate);
    if (endDate) q.set('endDate', endDate);
    fetch(`${API_BASE_URL}/api/vault-transaction?${q.toString()}`, { signal: controller.signal })
      .then(res => res.json())
      .then(data => {
        setTransactions(Array.isArray(data.data) ? data.data : []);
        if (typeof data.total === 'number') setTotalCount(data.total);
        if (typeof data.totalPages === 'number') setServerTotalPages(data.totalPages);
        if (typeof data.page === 'number') setPage(data.page);
        if (typeof data.pageSize === 'number') setPageSize(data.pageSize);
      }).catch(err => {
        if (err.name === 'AbortError') return;
        console.error('Failed to fetch transactions', err);
      });
    return () => controller.abort();
  }, [activeTab, page, pageSize, startDate, endDate]);

  // Fallbacks for initial render
  const cashReserve = vault ? Number(vault.total_cash) : 0;
  const totalChipValue = vault ? Number(vault.total_chips) : 0;
  const totalVaultValue = vault ? Number(vault.total_assets) : 0;
  const totalOnlineValue = vault ? Number(vault.total_online) : 0;
  const totalTitoValue = vault ? Number(vault.total_tito) : 0;
  const currency = vault?.currency_code || "INR";
  // track which cash control is currently active (either 'edit' or 'add' or null)
  const [activeCashEditor, setActiveCashEditor] = useState<string | null>(null);

  // Reset cash editor when user navigates away from cash-management tab
  useEffect(() => {
    if (activeTab !== 'cash-management' && activeCashEditor !== null) {
      setActiveCashEditor(null);
    }
  }, [activeTab]);

  function getCellValue(row: any, key: string) {
    if (key === "authorized_by") return row.authorizedBy?.user?.full_name || row.authorized_by || "";
    if (key === "performed_by") return row.performedBy?.user?.full_name || row.performed_by || "";
    if (key === "transaction_time") return row.transaction_time ? new Date(row.transaction_time).toLocaleString() : "";
    if (key === "denomination") return row.denomination && row.denomination !== "0" ? `₹${row.denomination}` : "-";
    if (key === "total_value") return row.total_value ? `₹${Number(row.total_value).toLocaleString("en-IN")}` : "-";
    return row[key] ?? "";
  }

  function getReqCellValue(row: any, key: string) {
    if (key === 'cage') return row.cage?.name || row.cage?.cage_id || '';
    if (key === 'initiatedBy') return row.initiatedBy?.user?.full_name || row.initiatedBy?.employee_id || '';
    if (key === 'requested_at') return row.requested_at ? new Date(row.requested_at).toLocaleString() : '';
    if (key === 'amount' || key === 'cash_amount' || key === 'chip_amount') return row[key] ? `₹${Number(row[key]).toLocaleString('en-IN')}` : '';
    if (key === 'status') return row.status || '';
    if (key === 'request_type') return row.request_type || '';
    return row[key] ?? '';
  }

  const filtered = transactions.filter(row => {
    // Text search across visible columns
    const matchesSearch = TRANSACTION_COLUMNS.some(col =>
      String(getCellValue(row, col.key)).toLowerCase().includes(search.toLowerCase())
    );

    if (!matchesSearch) return false;

    // Date range filter (transaction_time)
    if (startDate || endDate) {
      const t = row.transaction_time ? new Date(row.transaction_time) : null;
      if (!t) return false;
      if (startDate) {
        const s = new Date(startDate);
        if (t < s) return false;
      }
      if (endDate) {
        // include entire end day by setting time to end of day
        const e = new Date(endDate);
        e.setHours(23, 59, 59, 999);
        if (t > e) return false;
      }
    }

    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    const aVal = getCellValue(a, sortKey);
    const bVal = getCellValue(b, sortKey);
    if (aVal < bVal) return sortDir === "asc" ? -1 : 1;
    if (aVal > bVal) return sortDir === "asc" ? 1 : -1;
    return 0;
  });

  const paged = sorted.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.ceil(sorted.length / pageSize);

  const selectAllRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (selectAllRef.current) {
      selectAllRef.current.indeterminate =
        visibleColumns.length > 0 &&
        visibleColumns.length < TRANSACTION_COLUMNS.length;
    }
  }, [visibleColumns]);

  return (
  <div className="min-h-screen bg-gray-50 overflow-x-hidden">
      <div className="mx-auto">
        {/* Tabs */}
        <div className="flex gap-2 mb-4 border-b border-gray-200">
          <button
            className={`px-6 py-2 text-md font-semibold rounded-t-lg transition-all duration-150 ${
              activeTab === "overview"
                ? "bg-white border-b-2 border-yellow-500 text-yellow-700 shadow"
                : "bg-gray-100 text-gray-500 hover:text-yellow-700"
            }`}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </button>
          <button
            className={`px-6 py-2 text-md font-semibold rounded-t-lg transition-all duration-150 ${
              activeTab === "transactions"
                ? "bg-white border-b-2 border-yellow-500 text-yellow-700 shadow"
                : "bg-gray-100 text-gray-500 hover:text-yellow-700"
            }`}
            onClick={() => setActiveTab("transactions")}
          >
            Transactions
          </button>
          <button
            className={`px-6 py-2 text-md font-semibold rounded-t-lg transition-all duration-150 ${
              activeTab === "chip-management"
                ? "bg-white border-b-2 border-yellow-500 text-yellow-700 shadow"
                : "bg-gray-100 text-gray-500 hover:text-yellow-700"
            }`}
            onClick={() => setActiveTab("chip-management")}
          >
            Chips Management
          </button>
          <button
            className={`px-6 py-2 text-md font-semibold rounded-t-lg transition-all duration-150 ${
              activeTab === "cash-management"
                ? "bg-white border-b-2 border-yellow-500 text-yellow-700 shadow"
                : "bg-gray-100 text-gray-500 hover:text-yellow-700"
            }`}
            onClick={() => setActiveTab("cash-management")}
          >
            Cash Management
          </button>
          <button
            className={`px-6 py-2 text-md font-semibold rounded-t-lg transition-all duration-150 ${
              activeTab === "requests"
                ? "bg-white border-b-2 border-yellow-500 text-yellow-700 shadow"
                : "bg-gray-100 text-gray-500 hover:text-yellow-700"
            }`}
            onClick={() => setActiveTab("requests")}
          >
            Transfer Requests
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Left: Cash & Chips */}
              <div className="md:col-span-2 flex flex-col gap-6">
                {/* Cash Reserve */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-green-500">
                        <CashIcon />
                      </span>
                      <span className="font-semibold text-gray-700 text-lg">Cash Reserve</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {currency} {cashReserve.toLocaleString("en-IN")}
                    </div>
                  </div>
                  <div className="text-gray-500 text-sm">Total cash available in the vault</div>
                </div>
                {/* Online Reserve */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-green-500">
                        <OnlinePaymentIcon />
                      </span>
                      <span className="font-semibold text-gray-700 text-lg">Online Reserve</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {currency} {totalOnlineValue.toLocaleString("en-IN")}
                    </div>
                  </div>
                  <div className="text-gray-500 text-sm">Total online reserves available in the vault</div>
                </div>
                {/* Tito Reserve */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-green-500">
                        <TitoTicketIcon />
                      </span>
                      <span className="font-semibold text-gray-700 text-lg">Tito Ticket Reserve</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {currency} {totalTitoValue.toLocaleString("en-IN")}
                    </div>
                  </div>
                  <div className="text-gray-500 text-sm">Total tito ticket reserves available in the vault</div>
                </div>
                {/* Chip Reserves */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-yellow-500">
                      <ChipsIcon />
                    </span>
                    <span className="font-semibold text-gray-700 text-lg">Chip Reserves</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 gap-4">
                    {chipData.length === 0 ? (
                      <div className="col-span-3 text-center text-gray-400">No chip data</div>
                    ) : (
                      chipData.map((chip, idx) => (
                        <div key={chip.id || idx} className="bg-gray-50 rounded-lg p-4 flex flex-col items-center shadow">
                          <div className="flex justify-center mb-6">
                            <div className="w-28 h-28">
                              <img src={`${API_BASE_URL}${chip.chip_image}`} alt="Chip SVG" className="w-full h-full" />
                            </div>
                          </div>
                          <div className="text-gray-700 font-semibold mt-2">INR {formatDenomination(chip.chip_denomination)}</div>
                          <div className="text-xs text-gray-500 mb-1">Original Quantity : {Number(chip.quantity).toLocaleString("en-IN")}</div>
                          <div className="text-xs text-gray-500 mb-1">Actual Quantity : {Number(chip.actual_quantity).toLocaleString("en-IN")}</div>
                          { (chip.actual_quantity < chip.quantity) && (
                            <div className="text-xs text-red-600 font-bold mb-1">
                              Missing Chips : {Number(chip.quantity - chip.actual_quantity).toLocaleString("en-IN")}
                            </div>
                          )}
                          <div className="text-sm text-yellow-700 font-bold">
                            {currency} {Number(chip.total_value).toLocaleString("en-IN")}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
              {/* Right: Totals & AI */}
              <div className="flex flex-col gap-6">
                {/* Vault Totals */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <div className="font-semibold text-gray-700 mb-4 flex items-center gap-2">
                    <span className="text-yellow-500">
                      <VaultIcon />
                    </span>
                    Vault Totals
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Cash Reserves</span>
                    <span className="font-bold text-gray-800">{currency} {cashReserve.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Chip Reserves</span>
                    <span className="font-bold text-gray-800">{currency} {totalChipValue.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between mt-4 p-2 rounded bg-yellow-50">
                    <span className="font-semibold text-yellow-700">Total Reserves</span>
                    <span className="font-bold text-yellow-700 text-lg">{currency} {totalVaultValue.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "transactions" && (
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
            {/* Top controls */}
            <div className="flex flex-col gap-2 px-4 py-4 border border-b-0 border-gray-100 dark:border-white/[0.05] rounded-t-xl sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <span className="text-gray-500 dark:text-gray-400"> Show </span>
                <div className="relative z-20 bg-transparent">
                  <select
                    className="w-full py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                    value={pageSize}
                    onChange={e => {
                      setPage(Number(1));
                      // @ts-ignore
                      setPageSize(Number(e.target.value));
                    }}
                  >
                    <option value="10" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">10</option>
                    <option value="25" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">25</option>
                    <option value="50" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">50</option>
                    <option value="100" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">100</option>
                  </select>
                  <span className="absolute z-30 text-gray-500 -translate-y-1/2 right-2 top-1/2 dark:text-gray-400">
                    <svg className="stroke-current" width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M3.8335 5.9165L8.00016 10.0832L12.1668 5.9165" stroke="" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"></path>
                    </svg>
                  </span>
                </div>
                {/* Export control previously here — moved next to search input */}
                <span className="text-gray-500 dark:text-gray-400"> entries </span>
                {/* Show Columns Dropdown */}
                <div className="relative" ref={colDropdownRef}>
                  <button
                    className="px-3 py-2 border rounded bg-gray-100 text-gray-700 font-medium ml-2"
                    onClick={() => setShowColDropdown(v => !v)}
                    type="button"
                  >
                    Show Columns
                  </button>
                  {showColDropdown && (
                    <div className="absolute right-0 mt-2 w-56 bg-white border rounded shadow z-50 p-2 max-h-72 overflow-y-auto">
                      {/* Select All Option */}
                      <label className="flex items-center gap-2 py-1 cursor-pointer border-b pb-2 mb-2">
                        <input
                          ref={selectAllRef}
                          type="checkbox"
                          checked={visibleColumns.length === TRANSACTION_COLUMNS.length}
                          onChange={e => {
                            if (e.target.checked) {
                              setVisibleColumns(TRANSACTION_COLUMNS.map(col => col.key));
                            } else {
                              // Prevent hiding all columns, keep the first column visible
                              setVisibleColumns([TRANSACTION_COLUMNS[0].key]);
                            }
                          }}
                        />
                        <span className="font-semibold">Select All</span>
                      </label>
                      {TRANSACTION_COLUMNS.map(col => (
                        <label key={col.key} className="flex items-center gap-2 py-1 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={visibleColumns.includes(col.key)}
                            onChange={() => {
                              setVisibleColumns(cols =>
                                cols.includes(col.key)
                                  ? cols.length === 1
                                    ? cols // Prevent hiding all columns
                                    : cols.filter(k => k !== col.key)
                                  : [...cols, col.key]
                              );
                            }}
                          />
                          <span>{col.label}</span>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="relative flex items-center gap-3">
                <button className="absolute text-gray-500 -translate-y-1/2 left-4 top-1/2 dark:text-gray-400">
                  <svg className="fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path fillRule="evenodd" clipRule="evenodd" d="M3.04199 9.37363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z" fill=""></path>
                  </svg>
                </button>
                <input
                  placeholder="Search..."
                  className="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-11 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
                  type="text"
                  value={search}
                  onChange={e => { setSearch(e.target.value); setPage(1); }}
                />

                <div className="flex items-center gap-3">
                  {/* Date filter button + popup */}
                  <div className="relative">
                    <button
                      ref={dateFilterButtonRef}
                      type="button"
                      onClick={() => setDateFilterOpen(v => !v)}
                      className="px-3 py-2 border rounded bg-white text-gray-700 font-medium ml-2 flex items-center gap-2"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M7 10h10M7 14h7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        <rect x="3" y="4" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5" />
                      </svg>
                      <span className="text-sm">Date</span>
                    </button>
                    {dateFilterOpen && (
                      <div ref={dateFilterRef} className="absolute right-0 mt-2 w-72 bg-white border rounded shadow z-50 p-3">
                        <div className="flex flex-col gap-2">
                          <label className="text-xs text-gray-600">Start Date</label>
                          <input type="date" value={startDate ?? ""} onChange={e => { setStartDate(e.target.value || null); setPage(1); }} className="w-full border px-2 py-2 rounded text-sm" />
                          <label className="text-xs text-gray-600">End Date</label>
                          <input type="date" value={endDate ?? ""} onChange={e => { setEndDate(e.target.value || null); setPage(1); }} className="w-full border px-2 py-2 rounded text-sm" />
                          <div className="flex items-center justify-end gap-2 pt-2">
                            <button className="px-3 py-1 text-sm text-gray-600" onClick={() => { setStartDate(null); setEndDate(null); setDateFilterOpen(false); setPage(1); }}>
                              Clear
                            </button>
                            <button className="px-3 py-1 bg-yellow-500 text-white rounded text-sm" onClick={() => { setDateFilterOpen(false); setPage(1); }}>
                              Search
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Export */}
                  <div className="relative">
                    <button
                      ref={exportButtonRef}
                      onClick={() => setExportMenuOpen(v => !v)}
                      className="inline-flex items-center gap-3 bg-green-700 hover:bg-green-800 text-white rounded-md shadow px-6 py-3"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-white">
                        <path d="M12 3v10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M7 9l5 5 5-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M21 21H3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      <span className="font-semibold text-base">Export</span>
                    </button>
                    {exportMenuOpen && (
                      <div ref={exportMenuRef} className="absolute right-0 mt-2 w-48 bg-white border rounded shadow z-50">
                        <button className="w-full text-left px-3 py-2 hover:bg-gray-100" onClick={async () => {
                          // Fetch all records from server respecting date filters
                          try {
                            const q = new URLSearchParams();
                            q.set('page', '1');
                            // request a large pageSize; if API caps it, we may need to iterate.
                            q.set('pageSize', String(Math.max(1000, totalCount || 1000)));
                            if (startDate) q.set('startDate', startDate);
                            if (endDate) q.set('endDate', endDate);
                            const res = await fetch(`${API_BASE_URL}/api/vault-transaction?${q.toString()}`);
                            const data = await res.json();
                            const rows = Array.isArray(data.data) ? data.data : [];
                            exportRef.current?.exportCsv(rows);
                          } catch (err) {
                            console.error('Export all failed', err);
                          } finally {
                            setExportMenuOpen(false);
                          }
                        }}>
                          Export All
                        </button>
                        <button className="w-full text-left px-3 py-2 hover:bg-gray-100" onClick={() => { exportRef.current?.exportCsv(transactions); setExportMenuOpen(false); }}>
                          Export Current Page
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Hidden ExportToExcel instance used only to trigger export via ref */}
                  <ExportToExcel
                    ref={exportRef}
                    rows={[]}
                    columns={TRANSACTION_COLUMNS}
                    visibleColumns={visibleColumns}
                    getCellValue={getCellValue}
                    fileName={`vault-transactions-${new Date().toISOString().slice(0,10)}.csv`}
                    showButton={false}
                  />
                </div>
              </div>
            </div>
            {/* Table */}
            <div className="w-full overflow-x-auto">
              <div className="w-full">
                <table className="w-full text-sm table-auto">
                  <thead>
                    <tr className="bg-gray-100">
                      {TRANSACTION_COLUMNS.filter(col => visibleColumns.includes(col.key)).map(col => {
                        // define which columns are essential on small screens
                        const essentialOnMobile = ["transaction_id", "transaction_type", "denomination", "quantity", "total_value", "transaction_time"];
                        const thClass = `px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 cursor-pointer ${essentialOnMobile.includes(col.key) ? '' : 'hidden sm:table-cell'}`;
                        return (
                          <th
                            key={col.key}
                            className={thClass}
                            onClick={() => {
                              if (sortKey === col.key) setSortDir(d => (d === "asc" ? "desc" : "asc"));
                              else { setSortKey(col.key); setSortDir("asc"); }
                            }}
                          >
                            <div className="flex items-center justify-between w-full">
                              <span>{col.label}</span>
                              <button className="flex flex-col gap-0.5 ml-2">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="8"
                                  height="5"
                                  fill="none"
                                  className={`text-gray-300 dark:text-gray-700 ${sortKey === col.key && sortDir === "asc" ? "text-brand-500" : ""}`}
                                >
                                  <path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
                                </svg>
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="8"
                                  height="5"
                                  fill="none"
                                  className={`text-gray-300 dark:text-gray-700 ${sortKey === col.key && sortDir === "desc" ? "text-brand-500" : ""}`}
                                >
                                  <path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
                                </svg>
                              </button>
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>
                  <tbody>
                    {paged.length === 0 ? (
                      <tr>
                        <td colSpan={visibleColumns.length} className="text-center py-8 text-gray-400">
                          No transactions found.
                        </td>
                      </tr>
                    ) : (
                      paged.map((row, idx) => (
                        <tr key={row.transaction_id || idx} className="border-b hover:bg-yellow-50">
                          {TRANSACTION_COLUMNS.filter(col => visibleColumns.includes(col.key)).map(col => {
                            const essentialOnMobile = ["transaction_id", "transaction_type", "denomination", "quantity", "total_value", "transaction_time"];
                            const tdClass = `px-5 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center align-top ${essentialOnMobile.includes(col.key) ? '' : 'hidden sm:table-cell'}`;
                            return (
                              <td key={col.key} className={tdClass}>
                                <div className="break-words max-w-[24ch] sm:max-w-full">{getCellValue(row, col.key)}</div>
                              </td>
                            );
                          })}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            {/* Pagination */}
            <div className="border border-t-0 rounded-b-xl border-gray-100 py-4 pl-[18px] pr-4 dark:border-white/[0.05]">
              <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between">
                <div className="pb-3 xl:pb-0">
                  <p className="pb-3 text-sm font-medium text-center text-gray-500 border-b border-gray-100 dark:border-gray-800 dark:text-gray-400 xl:border-b-0 xl:pb-0 xl:text-left">
                    Showing {transactions.length === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, totalCount)} of {totalCount} entries
                  </p>
                </div>
                <div className="flex items-center justify-center gap-4 xl:justify-end">
                  <button
                    className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => setPage(page - 1)}
                    disabled={page === 1}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path fillRule="evenodd" clipRule="evenodd" d="M2.58301 9.99868C2.58272 10.1909 2.65588 10.3833 2.80249 10.53L7.79915 15.5301C8.09194 15.8231 8.56682 15.8233 8.85981 15.5305C9.15281 15.2377 9.15297 14.7629 8.86018 14.4699L5.14009 10.7472L16.6675 10.7472C17.0817 10.7472 17.4175 10.4114 17.4175 9.99715C17.4175 9.58294 17.0817 9.24715 16.6675 9.24715L5.14554 9.24715L8.86017 5.53016C9.15297 5.23717 9.15282 4.7623 8.85983 4.4695C8.56684 4.1767 8.09197 4.17685 7.79917 4.46984L2.84167 9.43049C2.68321 9.568 2.58301 9.77087 2.58301 9.99715C2.58301 9.99766 2.58301 9.99817 2.58301 9.99868Z" fill="currentColor"></path>
                    </svg>
                  </button>
                  <ul className="flex items-center gap-1">
                    {Array.from({ length: serverTotalPages || totalPages }, (_, i) => (
                      <li key={i}>
                        <button
                          className={`px-4 py-2 flex w-10 items-center justify-center h-10 rounded-lg text-sm font-medium ${
                            page === i + 1
                              ? "bg-brand-500 text-white"
                              : "text-gray-700 dark:text-gray-400 hover:bg-blue-500/[0.08] hover:text-brand-500 dark:hover:text-brand-500"
                          }`}
                          onClick={() => setPage(i + 1)}
                        >
                          {i + 1}
                        </button>
                      </li>
                    ))}
                  </ul>
                  <button
                    className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => setPage(page + 1)}
                    disabled={page === totalPages || totalPages === 0}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path fillRule="evenodd" clipRule="evenodd" d="M17.4175 9.9986C17.4178 10.1909 17.3446 10.3832 17.198 10.53L12.2013 15.5301C11.9085 15.8231 11.4337 15.8233 11.1407 15.5305C10.8477 15.2377 10.8475 14.7629 11.1403 14.4699L14.8604 10.7472L3.33301 10.7472C2.91879 10.7472 2.58301 10.4114 2.58301 9.99715C2.58301 9.58294 2.91879 9.24715 3.33301 9.24715L14.8549 9.24715L11.1403 5.53016C10.8475 5.23717 10.8477 4.7623 11.1407 4.4695C11.4336 4.1767 11.9085 4.17685 12.2013 4.46984L17.1588 9.43049C17.3173 9.568 17.4175 9.77087 17.4175 9.99715C17.4175 9.99763 17.4175 9.99812 17.4175 9.9986Z" fill="currentColor"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "cash-management" && (
          <div className="p-6 bg-white rounded-xl border border-gray-200">
            <div className="text-lg font-semibold text-gray-700 mb-3">Cash Management</div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <div className="text-sm text-gray-500">Current Cash Reserve</div>
                <div className="text-2xl font-bold text-green-600">{currency} {cashReserve.toLocaleString("en-IN")}</div>
                <div className="text-xs text-gray-400 mt-1">Last updated: {vault?.last_updated ? new Date(vault.last_updated).toLocaleString() : '—'}</div>
              </div>
              <div className="flex items-center gap-3">
                {/* Edit flow */}
                {(activeCashEditor === null || activeCashEditor === 'edit') && (
                <EditCashControl
                  id="edit"
                  activeEditor={activeCashEditor}
                  requestStartEdit={(id) => setActiveCashEditor(id)}
                  requestCloseEdit={(id) => { if (activeCashEditor === id) setActiveCashEditor(null); }}
                  currentValue={cashReserve}
                  currency={currency}
                  mode="edit"
                  onSave={async (newVal: number) => {
                    // direct update: set total_cash to newVal
                    try {
                      const body = { total_cash: String(newVal) };
                      const res = await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                      });
                      if (!res.ok) throw new Error(`Status ${res.status}`);
                      const data = await res.json();
                      if (data) setVault(data);
                      else setVault(v => v ? { ...v, total_cash: String(newVal), last_updated: new Date().toISOString() } : v);
                      setPopup({ message: 'Cash reserve updated', type: 'success' });
                      setShowPopup(true);
                      return { success: true };
                    } catch (err) {
                      console.error('Failed to update cash reserve', err);
                      setPopup({ message: 'Update failed', type: 'error' });
                      setShowPopup(true);
                      return { success: false, message: String(err) };
                    }
                  }}
                />)}

                {/* Add flow: adds entered amount to existing balance */}
                {(activeCashEditor === null || activeCashEditor === 'add') && (
                <EditCashControl
                  id="add"
                  activeEditor={activeCashEditor}
                  requestStartEdit={(id) => setActiveCashEditor(id)}
                  requestCloseEdit={(id) => { if (activeCashEditor === id) setActiveCashEditor(null); }}
                  currentValue={0}
                  currency={currency}
                  mode="add"
                  onSave={async (addAmount: number) => {
                    try {
                      const current = vault ? Number(vault.total_cash) : 0;
                      const newTotal = current + addAmount;
                      const body = { total_cash: String(newTotal) };
                      const res = await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                      });
                      if (!res.ok) throw new Error(`Status ${res.status}`);
                      const data = await res.json();
                      if (data) setVault(data);
                      else setVault(v => v ? { ...v, total_cash: String(newTotal), last_updated: new Date().toISOString() } : v);
                      setPopup({ message: 'Cash added to vault', type: 'success' });
                      setShowPopup(true);
                      return { success: true };
                    } catch (err) {
                      console.error('Failed to add cash', err);
                      setPopup({ message: 'Add cash failed', type: 'error' });
                      setShowPopup(true);
                      return { success: false, message: String(err) };
                    }
                  }}
                />)}
              </div>
            </div>
          </div>
        )}

        {activeTab === "requests" && (
          <div className="overflow-hidden rounded-xl border border-gray-200 bg-white p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-lg font-semibold text-gray-700">Transfer Requests</div>              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <select
                    className="py-2 pl-3 pr-8 text-sm rounded border"
                    value={reqPageSize}
                    onChange={e => { setReqPage(1); setReqPageSize(Number(e.target.value)); }}
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>
                <div className="hidden sm:block">
                  <select
                    className="py-2 pl-3 pr-8 text-sm rounded border"
                    value={reqStatus ?? ''}
                    onChange={e => { setReqPage(1); setReqStatus(e.target.value || null); }}
                  >
                    <option value="">All Status</option>
                    <option value="PENDING_VAULT_ACTION">Open</option>
                    <option value="PENDING_REVIEW">Pending Review</option>
                    <option value="CONFIRMED">Confirmed</option>
                    <option value="REJECTED">Rejected</option>
                  </select>
                </div>
                <div className="hidden sm:block">
                  <select
                    className="py-2 pl-3 pr-8 text-sm rounded border"
                    value={reqType ?? ''}
                    onChange={e => { setReqPage(1); setReqType(e.target.value || null); }}
                  >
                    <option value="">All Types</option>
                    <option value="FILL">Fill</option>
                    <option value="WITHDRAWAL">Withdrawal</option>
                  </select>
                </div>
                <div className="relative">
                  <input
                    placeholder="Search requests..."
                    className="h-10 rounded-lg border px-3 text-sm"
                    type="text"
                    value={reqSearch}
                    onChange={e => { setReqSearch(e.target.value); setReqPage(1); }}
                  />
                </div>
                <div>
                  <div className="relative inline-block">
                    <div className="inline-flex items-center gap-2">
                      {/* <div className="relative" ref={reqColDropdownRef}>
                        <button className="px-3 py-2 border rounded bg-gray-100 text-gray-700 font-medium ml-2" onClick={() => setReqShowColDropdown(v => !v)} type="button">Show Columns</button>
                        {reqShowColDropdown && (
                          <div className="absolute right-0 mt-2 w-56 bg-white border rounded shadow z-50 p-2 max-h-72 overflow-y-auto">
                            <label className="flex items-center gap-2 py-1 cursor-pointer border-b pb-2 mb-2">
                              <input
                                type="checkbox"
                                checked={reqVisibleColumns.length === REQUEST_COLUMNS.length}
                                onChange={e => {
                                  if (e.target.checked) setReqVisibleColumns(REQUEST_COLUMNS.map(c => c.key));
                                  else setReqVisibleColumns([REQUEST_COLUMNS[0].key]);
                                }}
                              />
                              <span className="font-semibold">Select All</span>
                            </label>
                            {REQUEST_COLUMNS.map(col => (
                              <label key={col.key} className="flex items-center gap-2 py-1 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={reqVisibleColumns.includes(col.key)}
                                  onChange={() => {
                                    setReqVisibleColumns(cols =>
                                      cols.includes(col.key)
                                        ? cols.length === 1 ? cols : cols.filter(k => k !== col.key)
                                        : [...cols, col.key]
                                    );
                                  }}
                                />
                                <span>{col.label}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div> */}
                      <button
                        className="inline-flex items-center gap-2 bg-green-700 hover:bg-green-800 text-white rounded-md shadow px-4 py-2 ml-2"
                        onClick={() => { setReqExportMenuOpen(v => !v); }}
                      >
                        Export
                      </button>
                    </div>
                  </div>
                  {reqExportMenuOpen && (
                    <div className="absolute right-4 mt-2 w-48 bg-white border rounded shadow z-50">
                      <button className="w-full text-left px-3 py-2 hover:bg-gray-100" onClick={() => {
                        // Export all currently loaded requests from client-side state (no API call)
                        reqExportRef.current?.exportCsv(requests);
                        setReqExportMenuOpen(false);
                      }}>
                        Export All
                      </button>
                      <button className="w-full text-left px-3 py-2 hover:bg-gray-100" onClick={() => { reqExportRef.current?.exportCsv(displayedRequests); setReqExportMenuOpen(false); }}>
                        Export Current Page
                      </button>
                    </div>
                  )}
                </div>
                {/* Hidden ExportToExcel instance for requests */}
                <ExportToExcel
                  ref={reqExportRef}
                  rows={[]}
                  columns={REQUEST_COLUMNS}
                  visibleColumns={reqVisibleColumns}
                  getCellValue={getReqCellValue}
                  fileName={`vault-requests-${new Date().toISOString().slice(0,10)}.csv`}
                  showButton={false}
                />
              </div>
            </div>

            {/* Date & small filters row */}
            {/* <div className="flex items-center gap-3 mb-3">
              <div className="relative">
                <button className="px-3 py-2 border rounded" onClick={() => setReqDateFilterOpen(v => !v)}>Date</button>
                {reqDateFilterOpen && (
                  <div className="absolute mt-2 w-72 bg-white border rounded shadow z-50 p-3">
                    <div className="flex flex-col gap-2">
                      <label className="text-xs text-gray-600">Start Date</label>
                      <input type="date" value={reqStartDate ?? ''} onChange={e => { setReqStartDate(e.target.value || null); setReqPage(1); }} className="w-full border px-2 py-2 rounded text-sm" />
                      <label className="text-xs text-gray-600">End Date</label>
                      <input type="date" value={reqEndDate ?? ''} onChange={e => { setReqEndDate(e.target.value || null); setReqPage(1); }} className="w-full border px-2 py-2 rounded text-sm" />
                      <div className="flex items-center justify-end gap-2 pt-2">
                        <button className="px-3 py-1 text-sm text-gray-600" onClick={() => { setReqStartDate(null); setReqEndDate(null); setReqDateFilterOpen(false); setReqPage(1); }}>
                          Clear
                        </button>
                        <button className="px-3 py-1 bg-yellow-500 text-white rounded text-sm" onClick={() => { setReqDateFilterOpen(false); setReqPage(1); }}>
                          Apply
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div> */}

            {/* Table */}
            <div className="w-full overflow-x-auto">
              <table className="w-full text-sm table-auto">
                <thead>
                  <tr className="bg-gray-100">
                    {REQUEST_COLUMNS.filter(col => reqVisibleColumns.includes(col.key)).map(col => {
                      const isSorted = reqSortKey === col.key;
                      return (
                        <th key={col.key} className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400">
                          <div className="flex items-center justify-between w-full">
                            <div
                              role="button"
                              tabIndex={0}
                              className="flex items-center gap-2 cursor-pointer"
                              onClick={() => {
                                if (reqSortKey === col.key) setReqSortDir(d => (d === 'asc' ? 'desc' : 'asc'));
                                else { setReqSortKey(col.key); setReqSortDir('asc'); }
                              }}
                              onKeyDown={(e: React.KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (reqSortKey === col.key) setReqSortDir(d => (d === 'asc' ? 'desc' : 'asc')); else { setReqSortKey(col.key); setReqSortDir('asc'); } } }}
                            >
                              <span>{col.label}</span>
                              <div className="flex flex-col gap-0.5 ml-2" aria-hidden>
                                <svg xmlns="http://www.w3.org/2000/svg" width="8" height="5" fill="none" className={`text-gray-300 ${isSorted && reqSortDir === 'asc' ? 'text-brand-500' : ''}`}>
                                  <path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="8" height="5" fill="none" className={`text-gray-300 ${isSorted && reqSortDir === 'desc' ? 'text-brand-500' : ''}`}>
                                  <path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
                                </svg>
                              </div>
                            </div>
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {displayedRequests.length === 0 ? (
                    <tr>
                      <td colSpan={reqVisibleColumns.length} className="text-center py-8 text-gray-400">No Pending Requests Found.</td>
                    </tr>
                  ) : (
                    sortedDisplayedRequests.map((r, idx) => (
                      <tr key={r.request_id || idx} className="border-b hover:bg-yellow-50">
                        {reqVisibleColumns.map(key => {
                          if (key === 'cage') return <td key={key} className="px-5 py-3 text-gray-500">{r.cage?.name || r.cage?.cage_id || '-'}</td>;
                          if (key === 'initiatedBy') return <td key={key} className="px-5 py-3 text-gray-500">{r.initiatedBy?.user?.full_name || r.initiatedBy?.employee_id || '-'}</td>;
                          if (key === 'requested_at') return <td key={key} className="px-5 py-3 text-gray-500">{r.requested_at ? new Date(r.requested_at).toLocaleString() : '-'}</td>;
                          if (key === 'amount' || key === 'cash_amount' || key === 'chip_amount') return <td key={key} className="px-5 py-3 text-gray-500">{r[key] ? `₹${Number(r[key]).toLocaleString('en-IN')}` : '-'}</td>;
                          if (key === 'actions') return (
                              <td key={key} className="px-5 py-3 text-gray-500">
                                {r.status === 'PENDING_VAULT_ACTION' ? (
                                  <div className="flex items-center gap-2 justify-center">
                                    <button className="px-3 py-1 bg-green-600 text-white rounded text-sm" onClick={() => openActionConfirm(r.request_id, 'approve')}>Approve</button>
                                    <button className="px-3 py-1 bg-red-600 text-white rounded text-sm" onClick={() => openActionConfirm(r.request_id, 'reject')}>Reject</button>
                                    <button className="px-3 py-1 border rounded text-sm" onClick={() => openRequestModal(r)}>View</button>
                                  </div>
                                ) : (
                                  <div className="text-center text-gray-400">-</div>
                                )}
                              </td>
                            );
                          return <td key={key} className="px-5 py-3 text-gray-500">{r[key] ?? '-'}</td>;
                        })}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="border border-t-0 rounded-b-xl border-gray-100 py-4 pl-[18px] pr-4 dark:border-white/[0.05]">
              <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between">
                <div className="pb-3 xl:pb-0">
                  {/* compute total entries (prefer server total when paged) */}
                  <p className="pb-3 text-sm font-medium text-center text-gray-500 border-b border-gray-100 dark:border-gray-800 dark:text-gray-400 xl:border-b-0 xl:pb-0 xl:text-left">
                    {(() => {
                      const totalEntries = reqIsServerPaged ? (reqTotalCount || 0) : reqTotalFiltered;
                      const start = totalEntries === 0 ? 0 : (reqPage - 1) * reqPageSize + 1;
                      const end = Math.min(reqPage * reqPageSize, totalEntries);
                      return `Showing ${start} to ${end} of ${totalEntries} entries`;
                    })()}
                  </p>
                </div>
                <div className="flex items-center justify-center gap-4 xl:justify-end">
                  <button
                    className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => setReqPage(p => Math.max(1, p - 1))}
                    disabled={reqPage === 1}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path fillRule="evenodd" clipRule="evenodd" d="M2.58301 9.99868C2.58272 10.1909 2.65588 10.3833 2.80249 10.53L7.79915 15.5301C8.09194 15.8231 8.56682 15.8233 8.85981 15.5305C9.15281 15.2377 9.15297 14.7629 8.86018 14.4699L5.14009 10.7472L16.6675 10.7472C17.0817 10.7472 17.4175 10.4114 17.4175 9.99715C17.4175 9.58294 17.0817 9.24715 16.6675 9.24715L5.14554 9.24715L8.86017 5.53016C9.15297 5.23717 9.15282 4.7623 8.85983 4.4695C8.56684 4.1767 8.09197 4.17685 7.79917 4.46984L2.84167 9.43049C2.68321 9.568 2.58301 9.77087 2.58301 9.99715C2.58301 9.99766 2.58301 9.99817 2.58301 9.99868Z" fill="currentColor"></path>
                    </svg>
                  </button>
                  <ul className="flex items-center gap-1">
                    {Array.from({ length: (reqServerTotalPages || reqTotalPagesDerived) }, (_, i) => (
                      <li key={i}>
                        <button
                          className={`px-4 py-2 flex w-10 items-center justify-center h-10 rounded-lg text-sm font-medium ${
                            reqPage === i + 1
                              ? "bg-brand-500 text-white"
                              : "text-gray-700 dark:text-gray-400 hover:bg-blue-500/[0.08] hover:text-brand-500"
                          }`}
                          onClick={() => setReqPage(i + 1)}
                        >
                          {i + 1}
                        </button>
                      </li>
                    ))}
                  </ul>
                  <button
                    className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={() => setReqPage(p => Math.min((reqServerTotalPages || reqTotalPagesDerived), p + 1))}
                    disabled={reqPage === (reqServerTotalPages || reqTotalPagesDerived) || (reqServerTotalPages || reqTotalPagesDerived) === 0}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path fillRule="evenodd" clipRule="evenodd" d="M17.4175 9.9986C17.4178 10.1909 17.3446 10.3832 17.198 10.53L12.2013 15.5301C11.9085 15.8231 11.4337 15.8233 11.1407 15.5305C10.8477 15.2377 10.8475 14.7629 11.1403 14.4699L14.8604 10.7472L3.33301 10.7472C2.91879 10.7472 2.58301 10.4114 2.58301 9.99715C2.58301 9.58294 2.91879 9.24715 3.33301 9.24715L14.8549 9.24715L11.1403 5.53016C10.8475 5.23717 10.8477 4.7623 11.1407 4.4695C11.4336 4.1767 11.9085 4.17685 12.2013 4.46984L17.1588 9.43049C17.3173 9.568 17.4175 9.77087 17.4175 9.99715C17.4175 9.99763 17.4175 9.99812 17.4175 9.9986Z" fill="currentColor"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* action confirm dialog */}
        <ConfirmDialog
          open={actionConfirmOpen}
          title={actionType === 'approve' ? 'Confirm Approve' : 'Confirm Reject'}
          message={actionTargetId ? `Are you sure you want to ${actionType === 'approve' ? 'APPROVE' : 'REJECT'} request ${actionTargetId}?` : 'Are you sure?'}
          onConfirm={performRequestAction}
          onCancel={() => { setActionConfirmOpen(false); setActionError(null); setActionProcessing(false); }}
          processing={actionProcessing}
          errorMessage={actionError}
        />

        {/* request details modal */}
        {requestModalOpen && requestModalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black opacity-30" onClick={() => setRequestModalOpen(false)}></div>
            <div className="bg-white rounded shadow-lg z-60 max-w-2xl w-full p-4">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="font-semibold text-lg">Request #{requestModalData.request_id} — {requestModalData.request_type}</div>
                  <div className="text-sm text-gray-500">Status: {requestModalData.status}</div>
                </div>
                <button className="text-sm text-gray-600" onClick={() => setRequestModalOpen(false)}>Close</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-gray-700 mb-4">
                <div><span className="font-semibold">Cage:</span> {requestModalData.cage?.name || requestModalData.cage?.cage_id || '-'}</div>
                <div><span className="font-semibold">Initiated By:</span> {requestModalData.initiatedBy?.user?.full_name || requestModalData.initiated_by || '-'}</div>
                <div><span className="font-semibold">Amount:</span> {requestModalData.amount ? `₹${Number(requestModalData.amount).toLocaleString('en-IN')}` : '-'}</div>
                <div><span className="font-semibold">Requested At:</span> {requestModalData.requested_at ? new Date(requestModalData.requested_at).toLocaleString() : '-'}</div>
                <div><span className="font-semibold">Cash Amount:</span> {requestModalData.cash_amount ? `₹${Number(requestModalData.cash_amount).toLocaleString('en-IN')}` : '-'}</div>
                <div><span className="font-semibold">Chip Amount:</span> {requestModalData.chip_amount ? `₹${Number(requestModalData.chip_amount).toLocaleString('en-IN')}` : '-'}</div>
                <div className="md:col-span-2"><span className="font-semibold">Remarks:</span> {requestModalData.remarks ?? '-'}</div>
              </div>

              <div>
                <div className="font-semibold mb-2">Chip Denominations</div>
                {requestModalData.chip_denominations && Object.keys(requestModalData.chip_denominations).length > 0 ? (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left">
                        <th className="py-1">Denomination</th>
                        <th className="py-1">Quantity</th>
                        <th className="py-1">Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(requestModalData.chip_denominations).map(([denom, qty]) => (
                        <tr key={denom} className="border-t">
                          <td className="py-2">₹{Number(denom).toLocaleString('en-IN')}</td>
                          <td className="py-2">{Number(qty).toLocaleString('en-IN')}</td>
                          <td className="py-2">₹{(Number(denom) * Number(qty)).toLocaleString('en-IN')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="text-sm text-gray-500">No chip denomination breakdown available.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* popup notification */}
        {showPopup && popup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20">
            <div className={`pointer-events-auto min-w-[260px] max-w-[90vw] w-[420px] rounded-xl p-6 shadow-2xl ${popup.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
              <div className="flex items-center justify-between gap-3">
                <div className="flex-1 text-center font-semibold text-lg">{popup.message}</div>
                <button className="text-white/90 text-sm" onClick={() => setShowPopup(false)}>Close</button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "chip-management" && (
          <div>
            <ChipsManagement />
          </div>
        )}
      </div>
    </div>
  );
};

export default Vault;