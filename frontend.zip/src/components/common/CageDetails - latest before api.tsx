"use client"
import { API_BASE_URL } from "@/config/api";
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import Button from "@/components/ui/button/Button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { History, Play, Square, AlertTriangle, CheckCircle } from 'lucide-react';
import Modal from "@/components/ui/modal/Modal";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import BackButton from '@/components/common/BackButton';
import { useRouter } from "next/navigation";
import ChipDenominationSelector from './ChipDenominationSelector';
import Image from "next/image";

interface ActionIconProps {
  label: string;
  icon: string;
  shortcut?: string;
  className?: string;
  onClick?: () => void;
}

// Removed duplicate ActionIcon definition
const ActionIcon: React.FC<ActionIconProps> = ({ label, icon, shortcut, className, onClick }) => {
  return (
    <button
      className={`flex flex-col items-center justify-center hover:bg-gray-100 rounded-lg transition-colors border-[2px] border-gray-300 shadow-sm aspect-square w-full flex-1 ${className || ''}`}
      onClick={onClick}
    >
      <div className="w-14 h-14 mb-2 flex items-center justify-center">
        <img src={`/images/icons/${icon}.svg`} alt={label} className="w-10 h-10" />
      </div>
      <span className="text-sm font-medium text-center text-gray-700">{label}</span>
      {shortcut && <span className="text-xs text-gray-500 mt-1">{shortcut}</span>}
    </button>
  );
}


interface InventoryItem {
  id: number;
  cage_id: number;
  gaming_day_id: number;
  chip_denomination: string;
  chip_color: string;
  quantity: number;
  total_value: string;
  recorded_at: string;
  cage: string;
  gamingDay: {
    start_time: string;
    end_time: string;
  };
  gaming_day_start: string;
  gaming_day_end: string;
  type: 'CHIP' | 'Voucher' | 'CASH';
}

interface CageApiResponse {
  cage_id: string;
  name: string;
  type: string;
  status: 'open' | 'closed';
  terminal: string;
  balance: string;
  changed_by: string;
  last_change: string;
  gaming_day: string;
  inventory?: InventoryItem[];
  total?: string;
  gaming_day_id?: number;
}

type StatusBadgeProps = {
  status: 'open' | 'closed';
};

interface CageCardProps {
  cageId?: string;
  floor?: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => (
  <span className={`status ${status.toLocaleLowerCase()}`}>{status.toUpperCase()}</span>
);

const InitialCageSetupModal: React.FC<{
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  onSave: (cash: number, chips: { id: number; denomination: string; color: string; quantity: number }[]) => void;
  cageId: string | number; // <-- add this
}> = ({ open, onClose, onSave, cageId, onSuccess }) => {
  const [activeTab, setActiveTab] = useState<"cash" | "chips" | "summary" | "progress">("cash");
  const [cash, setCash] = useState<string>("");
  const [chipList, setChipList] = useState<any[]>([]);
  const [chipQuantities, setChipQuantities] = useState<{ [id: number]: number }>({});
  const [loading, setLoading] = useState(false);

  // New state for modals
  const [showSuccess, setShowSuccess] = useState(false);
  const [showFailure, setShowFailure] = useState(false);

  const router = useRouter(); // For page refresh

  useEffect(() => {
    if (open && activeTab === "chips") {
      setLoading(true);
      fetch(`${API_BASE_URL}/api/vault-chip-denomination`)
        .then(res => res.json())
        .then((data: any[]) => {
          setChipList(data);
          setChipQuantities(prev => {
            if (Object.keys(prev).length === 0) {
              const initialQuantities: { [id: number]: number } = {};
              data.forEach((chip) => {
                initialQuantities[chip.id] = 0;
              });
              return initialQuantities;
            }
            return prev;
          });
        })
        .finally(() => setLoading(false));
    }
    if (!open) {
      setActiveTab("cash");
      setCash("");
      setChipList([]);
      setChipQuantities({});
      setLoading(false);
    }
  }, [open, activeTab]);

  const handleChipQtyChange = (id: number, qty: string) => {
    setChipQuantities((prev) => ({
      ...prev,
      [id]: Number(qty.replace(/[^0-9]/g, "")) || 0,
    }));
  };

  const chipsSelected = chipList.filter((chip) => (chipQuantities[chip.id] || 0) > 0);
  const chipsTotal = chipsSelected.reduce(
    (sum, chip) =>
      sum +
      (chipQuantities[chip.id] || 0) * (parseFloat(chip.chip_denomination) || 0),
    0
  );
  const cashTotal = Number(cash) || 0;
  const overallTotal = cashTotal + chipsTotal;

  const handleNext = () => setActiveTab("chips");
  const handleBack = () => setActiveTab("cash");
  const handleSummary = () => setActiveTab("summary");
  const handleFinish = async () => {
    setActiveTab("progress");
    setLoading(true);
    let success = true;
    try {
      // --- All your API logic here ---
      const cage_id = Number(cageId);
      const now = new Date().toISOString();
      const changed_by = 1;
      let gaming_day_id = 6;
      try {
        const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
        const data = await resp.json();
        if (data && data.gaming_day_id) {
          gaming_day_id = data.gaming_day_id;
        }
      } catch { }

      await saveCageChipDenomination({ cage_id, gaming_day_id, chips: chipList, chipQuantities });
      // Calculate chip total
      const chip_total = chipsSelected.reduce(
        (sum, chip) => sum + (Number(chip.chip_denomination) * (chipQuantities[chip.id] || 0)),
        0
      );
      const cash_total = cashTotal;

      // Update Cage table
      await updateCageTable({ cage_id, cash_total, chip_total, gaming_day_id, changed_by });

      // Update vault balance
      await updateVaultBalance({ cash_total, chip_total });

      // Update Vault Chip Denominations
      await updateVaultChipDenomination({ chips: chipList, chipQuantities });

      // Prepare vault transaction entries
      const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const authorized_by = 2;
      const performed_by = 3;
      const destination = `Cage ${cage_id}`;
      const transaction_time = now;

      // Cash transaction entry (if any)
      const vaultTransactions = [];
      if (cash_total > 0) {
        vaultTransactions.push({
          vault_id: 1,
          transaction_type: "TRANSFER",
          asset_type: "CASH",
          denomination: 0,
          quantity: 0,
          total_value: cash_total,
          currency_code: "INR",
          source: "Vault",
          destination,
          reference_id,
          authorized_by,
          performed_by,
          transaction_time,
          cage_id: cage_id,
          notes: `Cash of INR ${cash_total} added to Cage ${cage_id}`,
          gaming_day_id,
        });
      }

      // Chip transaction entries (if any)
      chipsSelected.forEach(chip => {
        vaultTransactions.push({
          vault_id: 1,
          transaction_type: "TRANSFER",
          asset_type: "CHIP",
          denomination: Number(chip.chip_denomination),
          quantity: chipQuantities[chip.id] || 0,
          total_value: Number(chip.chip_denomination) * (chipQuantities[chip.id] || 0),
          currency_code: "INR",
          source: "Vault",
          destination,
          reference_id,
          authorized_by,
          performed_by,
          transaction_time,
          cage_id: cage_id,
          notes: `${chipQuantities[chip.id] || 0} Quantity of ${chip.chip_denomination} Denomination added to Cage ${cage_id}`,
          gaming_day_id,
        });
      });

      // POST to vault-transaction/bulk
      if (vaultTransactions.length > 0) {
        await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(vaultTransactions),
        });
      }

      // --- End API logic ---
    } catch (err) {
      success = false;
    }

    setLoading(false);
    setActiveTab("cash"); // Remove progress tab

    if (success) {
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        onClose();
        onSuccess();
        router.refresh(); // Refresh the page
      }, 2000);
    } else {
      setShowFailure(true);
    }
  };

  return open ? (
    <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
      <Modal onClose={onClose}>
        <div className="p-6 w-full-[200px] max-w-5xl h-[500px] flex flex-col">
          <h2 className="text-xl font-bold mb-4">Open CAGE</h2>
          {/* Tabs */}
          {(activeTab === "cash" || activeTab === "chips") && (
            <div className="flex mb-2">
              <button
                className={`px-4 py-2 font-bold uppercase text-sm ${activeTab === "cash"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-gray-500"
                  }`}
                onClick={() => setActiveTab("cash")}
                disabled={activeTab === "cash"}
              >
                CASH
              </button>
              <button
                className={`px-4 py-2 font-bold uppercase text-sm ${activeTab === "chips"
                  ? "border-b-2 border-blue-600 text-blue-600"
                  : "text-gray-500"
                  }`}
                onClick={() => setActiveTab("chips")}
                disabled={activeTab === "chips"}
              >
                CHIPS
              </button>
            </div>
          )}

          {/* CASH TAB */}
          {activeTab === "cash" && (
            <div className="flex flex-col h-full justify-between">
              <div>
                <div className="mb-6">
                  <label className="block text-gray-700 font-semibold mb-3 mt-3">
                    Enter Initial Cash Balance (INR)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={cash}
                    onChange={(e) => setCash(e.target.value)}
                    className="w-full border rounded px-3 py-2 text-lg font-bold"
                    placeholder="Enter cash amount"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={onClose}>
                  CANCEL
                </Button>
                <Button
                  variant="primary"
                  onClick={handleNext}
                  disabled={!cash || Number(cash) <= 0}
                >
                  NEXT
                </Button>
              </div>
            </div>
          )}

          {/* CHIPS TAB */}
          {activeTab === "chips" && (
            <div className="flex flex-col h-full justify-between">
              {loading ? (
                <div className="py-8 text-center text-gray-500 flex-1 flex items-center justify-center">
                  Loading chip denominations...
                </div>
              ) : (
                <>
                  <div className="max-h-[200px] overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-600">
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Denomination</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Quantity</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {chipList.map((chip) => (
                          <TableRow key={chip.id}>
                            <TableCell className="text-center text-sm py-3">
                              {chip.chip_denomination}
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">
                              <input
                                type="number"
                                min={0}
                                value={chipQuantities[chip.id] || ""}
                                onChange={(e) =>
                                  handleChipQtyChange(chip.id, e.target.value)
                                }
                                className="w-24 border rounded px-2 py-1 text-right"
                              />
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">
                              {((chipQuantities[chip.id] || 0) *
                                (parseFloat(chip.chip_denomination) || 0)
                              ).toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-end mt-4 pt-4 border-t border-gray-200">
                    <div className="text-right">
                      <div className="text-lg text-gray-500 mb-1 font-bold uppercase">
                        TOTAL :{" "}
                        <span className="text-lg font-bold text-gray-800">
                          {chipsTotal.toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between mt-6">
                    <Button variant="outline" onClick={handleBack}>
                      BACK
                    </Button>
                    <Button
                      variant="primary"
                      onClick={handleSummary}
                      disabled={chipList.length === 0}
                    >
                      NEXT
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* SUMMARY TAB */}
          {activeTab === "summary" && (
            <div className="flex flex-col h-full justify-between">
              <div className="overflow-y-auto max-h-[340px] pr-2">
                <div className="font-bold text-lg mb-2">Summary</div>
                {/* Gaming Day */}
                <div className="bg-gray-100 p-4 mb-2 flex justify-between items-center">
                  <span className="text-xs text-gray-500 font-bold uppercase">GAMING DAY</span>
                  <span className="text-lg font-bold">{new Date().toLocaleDateString()}</span>
                </div>
                {/* Cash */}
                <div className="bg-gray-100 border-b p-4 flex justify-between items-center">
                  <span className="text-xs text-gray-500 font-bold uppercase">CASH</span>
                  <span className="text-lg font-bold">
                    INR {cashTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
                {/* Chips */}
                {chipsSelected.length > 0 && (
                  <div className="bg-white border-b p-4">
                    <div className="text-xs text-gray-500 font-bold uppercase mb-1">CHIP</div>
                    {chipsSelected.map((chip) => (
                      <div key={chip.id} className="flex justify-between text-base">
                        <span>
                          {chip.chip_denomination} x {chipQuantities[chip.id]}
                        </span>
                        <span>
                          INR {(chipQuantities[chip.id] * parseFloat(chip.chip_denomination)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    ))}
                    <div className="bg-gray-100 p-4 -left-5 text-xs text-gray-500 flex justify-between font-bold mt-2 items-center left-0">
                      <span className="text-xs text-gray-500 font-bold uppercase">CHIPS TOTAL</span>
                      <span className="text-lg font-bold !text-black">INR {chipsTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                )}
                {/* Total */}
                <div className="bg-white border-b p-4 flex justify-between items-center">
                  <span className="font-bold uppercase">CAGE TOTAL</span>
                  <span className="text-lg font-bold">
                    INR {overallTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
              <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={() => setActiveTab("chips")}>
                  BACK
                </Button>
                <Button variant="primary" onClick={handleFinish}>
                  FINISH
                </Button>
              </div>
            </div>
          )}

          {/* PROGRESS TAB */}
          {activeTab === "progress" && (
            <div className="flex flex-col h-full justify-center items-center">
              <div className="text-lg mb-6">Opening cage in progress...</div>
              <div className="flex justify-center">
                <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
                </svg>
              </div>
            </div>
          )}

          {/* SUCCESS MODAL */}
          {showSuccess && (
            <Modal onClose={() => setShowSuccess(false)}>
              <div className="flex flex-col items-center p-6">
                <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
                <h2 className="text-lg font-bold mb-2 text-center">Cage opened successfully!</h2>
              </div>
            </Modal>
          )}

          {/* FAILURE MODAL */}
          {showFailure && (
            <Modal onClose={() => setShowFailure(false)}>
              <div className="flex flex-col items-center p-6">
                <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
                <h2 className="text-lg font-bold mb-2 text-center">Something went wrong, Please Try Again Later</h2>
                <Button className="mt-4" onClick={() => setShowFailure(false)}>OK</Button>
              </div>
            </Modal>
          )}
        </div>
      </Modal>
    </div>
  ) : null;
};

const CageCard: React.FC<CageCardProps> = ({ cageId, floor }) => {
  const [inventoryData, setInventoryData] = useState<InventoryItem[]>([]);
  const [cageDetails, setCageDetails] = useState<CageApiResponse | null>(null);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [historyData, setHistoryData] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [showTransactions, setShowTransactions] = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const [showStopSessionModal, setShowStopSessionModal] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'TODAY' | 'YESTERDAY' | 'THIS_MONTH' | 'CUSTOM'>('ALL');
  const [customRange, setCustomRange] = useState<{ start: string; end: string }>({ start: '', end: '' });

  // New state for player transaction modal
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [showPlayerSearch, setShowPlayerSearch] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [amount, setAmount] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [chipDenomination, setChipDenomination] = useState<string>("");
  const [chipQuantities, setChipQuantities] = useState<{ [key: string]: number }>({});
  const [availableDenominations, setAvailableDenominations] = useState<Array<{ id: number, chip_denomination: string }>>([]);
  const [transactionStep, setTransactionStep] = useState<'select-action' | 'search-player' | 'transaction-details' | 'summary'>('select-action');
  const [dummyPlayers] = useState([
    { id: 1, name: "John Doe", playerId: "P123", balance: 5000 },
    { id: 2, name: "Jane Smith", playerId: "P456", balance: 12000 },
    { id: 3, name: "Alice Johnson", playerId: "P789", balance: 8000 },
  ]);
  const filteredPlayers = searchQuery.trim() === ""
    ? []
    : dummyPlayers.filter(
      player =>
        player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        player.playerId.toLowerCase().includes(searchQuery.toLowerCase())
    );


  // Prevent outer scroll when any modal is open
  useEffect(() => {
    const anyModalOpen = showTransactionModal || showSetupModal || showHistory || showTransactions || showStopSessionModal;
    if (anyModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showTransactionModal, showSetupModal, showHistory, showTransactions, showStopSessionModal]);

  // Reset modal state on open and fetch denominations
  useEffect(() => {
    if (showTransactionModal) {
      setSelectedAction(null);
      setShowPlayerSearch(false);
      setSelectedPlayer(null);
      setSearchQuery("");
      setChipQuantities({});
      setAmount("");
      setNotes("");

      // Fetch available denominations
      fetch(`${API_BASE_URL}/api/vault-chip-denomination`)
        .then(res => res.json())
        .then(data => {
          setAvailableDenominations(data);
        })
        .catch(error => {
          console.error('Error fetching denominations:', error);
        });
    }
  }, [showTransactionModal]);

  // Reset values when switching actions
  useEffect(() => {
    setChipQuantities({});
    setAmount("");
    setNotes("");
  }, [selectedAction]);

  // Handler to open modal and fetch history
  const handleOpenHistory = () => {
    setShowHistory(true);
    setHistoryLoading(true);
    fetch(`${API_BASE_URL}/api/cage-session`)// /cage?cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => setHistoryData(data))
      .catch(() => setHistoryData([]))
      .finally(() => setHistoryLoading(false));
  };

  // Handler to open transactions modal and fetch data
  const handleOpenTransactions = () => {
    if (!cageDetails?.gaming_day || !cageId) return;
    setShowTransactions(true);
    setTransactionsLoading(true);
    fetch(`${API_BASE_URL}/api/cage-transaction?gaming_day_id=${cageDetails.gaming_day_id}&cage_id=${cageId}`)
      .then(res => res.json())
      .then(data => setTransactions(data))
      .catch(() => setTransactions([]))
      .finally(() => setTransactionsLoading(false));
  };

  useEffect(() => {
    if (!cageId) return;
    setLoading(true);
    fetch(`${API_BASE_URL}/api/cage/${cageId}`)
      .then(res => res.json())
      .then((data) => {
        setCageDetails(data);
        setTotal(data.total || data.balance.cash || 'INR 0.00');
        if (data.status.toLocaleLowerCase() === 'closed') {
          setInventoryData([]);
          setTotal(0);
        } else {
          fetch(`${API_BASE_URL}/api/cage-chip-denomination?cage_id=${cageId}&gaming_day_id=${data.gaming_day_id}`)
            .then(res => res.json())
            .then(inventoryData => {
              let chipArr = Array.isArray(inventoryData)
                ? inventoryData.map((item: any) => ({
                  ...item,
                  type: item.type || 'CHIP',
                }))
                : [];
              // After you have the final inventory array (chipArr + cashEntry)
              const allItems = [...chipArr];
              if (data.balance.cash) {
                const cashEntry: InventoryItem = {
                  id: -1,
                  cage_id: data.cage_id,
                  gaming_day_id: data.gaming_day_id,
                  chip_denomination: "",
                  chip_color: "",
                  quantity: 1,
                  total_value: data.balance.cash,
                  recorded_at: data.last_change || "",
                  cage: data.name || "",
                  gamingDay: data.gamingDay || {},
                  gaming_day_start: data.gaming_day_start || "",
                  gaming_day_end: data.gaming_day_end || "",
                  type: "CASH",
                };
                allItems.push(cashEntry);
              }
              setInventoryData(allItems);

              // Calculate total as integer (sum of all total_value fields)
              const totalSum = allItems.reduce(
                (sum, item) => sum + (parseFloat(item.total_value) || 0),
                0
              );
              setTotal(Math.round(totalSum));
            })
            .catch(() => {
              setInventoryData([]);
              setTotal(data.total || data.balance || 'INR 0.00');
            });
        }
      })
      .catch(() => {
        setCageDetails(null);
        setInventoryData([]);
        setTotal(0);
      })
      .finally(() => setLoading(false));
  }, [cageId, refreshKey]);

  if (!cageId) {
    return (
      <div className="w-full max-w-7xl mx-auto p-4 space-y-4">
        <div className="text-center text-gray-500">No cage selected.</div>
      </div>
    );
  }

  // Determine session button properties based on status
  const isOpen = cageDetails?.status.toLocaleLowerCase() === "open";
  const sessionButton = isOpen
    ? {
      text: "STOP SESSION",
      icon: <Square className="w-4 h-4 mr-2" />,
      className: "bg-red-500 text-white hover:bg-red-600",
    }
    : {
      text: "START SESSION",
      icon: <Play className="w-4 h-4 mr-2" />,
      className: "bg-green-600 text-white hover:bg-green-800",
    };

  // Handler for confirming stop session (replace with your logic)
  const handleConfirmStopSession = () => {
    setShowStopSessionModal(false);
    // Add your stop session logic here (API call, etc.)
  };

  function isDateInRange(dateStr: string, start: Date, end: Date) {
    if (!dateStr) return false;
    const date = new Date(dateStr.replace(" ", "T"));
    return date >= start && date <= end;
  }

  function filterHistoryRows(rows: any[]) {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (historyFilter === 'ALL') return rows;

    switch (historyFilter) {
      case 'TODAY':
        return rows.filter(row =>
          isDateInRange(row.started_at, new Date(today.toDateString()), new Date(today.toDateString() + " 23:59:59")) ||
          isDateInRange(row.ended_at, new Date(today.toDateString()), new Date(today.toDateString() + " 23:59:59"))
        );
      case 'YESTERDAY':
        return rows.filter(row =>
          isDateInRange(row.started_at, new Date(yesterday.toDateString()), new Date(yesterday.toDateString() + " 23:59:59")) ||
          isDateInRange(row.ended_at, new Date(yesterday.toDateString()), new Date(yesterday.toDateString() + " 23:59:59"))
        );
      case 'THIS_MONTH':
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59);
        return rows.filter(row =>
          isDateInRange(row.started_at, monthStart, monthEnd) ||
          isDateInRange(row.ended_at, monthStart, monthEnd)
        );
      case 'CUSTOM':
        if (!customRange.start || !customRange.end) return rows;
        const customStart = new Date(customRange.start + "T00:00:00");
        const customEnd = new Date(customRange.end + "T23:59:59");
        return rows.filter(row =>
          isDateInRange(row.started_at, customStart, customEnd) ||
          isDateInRange(row.ended_at, customStart, customEnd)
        );
      default:
        return rows;
    }
  }

  return (
    <>
      <BackButton />
      <PageBreadcrumb pageTitle="Cage Details" />
      <div className="w-full max-w-7xl mx-auto p-1 space-y-4">
        {/* Header Section */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <span className="text-xl font-bold text-gray-800">{cageDetails?.name.toUpperCase()}</span>
              <span className="text-sm text-gray-500 font-medium">(CG - {cageId})</span>
              {cageDetails?.status && <StatusBadge status={cageDetails.status} />}
            </div>
            <div className="flex space-x-2">
              <Button
                size="sm"
                className="bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 text-xs font-bold"
                onClick={handleOpenHistory}
              >
                <History className="w-4 h-4 mr-2" />
                HISTORY
              </Button>
              {!isOpen ? (
                <Button
                  size="sm"
                  className="bg-green-600 text-white hover:bg-green-800 px-4 py-2 text-xs font-bold"
                  onClick={() => setShowSetupModal(true)}
                >
                  <Play className="w-4 h-4 mr-2" />
                  START SESSION
                </Button>
              ) : (
                <Button
                  size="sm"
                  className={`${sessionButton.className} px-4 py-2 text-xs font-bold`}
                  onClick={() => setShowStopSessionModal(true)}
                >
                  {sessionButton.icon}
                  {sessionButton.text}
                </Button>
              )}
            </div>
          </div>

          {/* Info Grid */}
          <div className="bg-gray-100">
            <div className="grid grid-cols-8 gap-4 bg-gray-100 text-xs mb-4">
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">TERMINAL</div>
                <div className="font-bold text-gray-800 text-center font-large">{cageDetails?.terminal.replace('-', ' ') || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">GAMING DAY</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.gaming_day.split(" ")[0] || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">LAST CHANGE</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.last_change || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">CHANGED BY</div>
                <div className="font-bold text-gray-800 text-center">{cageDetails?.changed_by || "—"}</div>
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">OWNER</div>
                {/* <div className="font-bold text-gray-800 text-center">{cageDetails?.owner || "—"}</div> */}
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">NO. OF TRANS</div>
                {/* <div className="font-bold text-gray-800 text-center">{cageDetails?.no_of_trans || "—"}</div> */}
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">ACTIVE TIME</div>
                {/* <div className="font-bold text-gray-800 text-center">{cageDetails?.active_time || "—"}</div> */}
              </div>
              <div className="h-full flex flex-col py-4 px-1">
                <div className="text-gray-500 mb-1 font-medium uppercase text-center">TRANS/HOUR</div>
                {/* <div className="font-bold text-gray-800 text-center">{cageDetails?.trans_per_hour || "—"}</div> */}
              </div>
            </div>
            {/* Navigation Buttons Section */}
            <div className="flex items-center gap-4 bg-gray-100 px-6 py-4 mb-4">
              <Button
                className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
                onClick={handleOpenTransactions}
              >
                TRANSACTIONS
              </Button>
              <Button
                className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
              >
                REPORT
              </Button>
              {isOpen && (
                <Button
                  className="!bg-white !text-black !border !border-gray-300 font-bold text-sm uppercase px-6 py-2 shadow-none !rounded-none hover:!bg-gray-200 hover:!text-black"
                  onClick={() => {
                    setShowTransactionModal(true);
                    setSelectedAction(null);
                    setShowPlayerSearch(false);
                    setSelectedPlayer(null);
                    setSearchQuery("");
                    setChipQuantities({});
                    setAmount("");
                    setNotes("");
                    setTransactionStep('select-action');
                  }}
                >
                  PERFORM TRANSACTION
                </Button>
              )}
            </div>
          </div>

          {/* Transaction Modal */}
          {showTransactionModal && (
            <div className="fixed inset-0 z-[1000000] flex items-center justify-center">
              <div className="fixed inset-0 bg-black/30" onClick={() => {
                setShowTransactionModal(false);
                setSelectedAction(null);
                setShowPlayerSearch(false);
                setSelectedPlayer(null);
                setSearchQuery("");
                setChipQuantities({});
                setAmount("");
                setNotes("");
                setTransactionStep('select-action');
              }}></div>
              <div className="bg-white shadow-lg w-[1200px] overflow-hidden relative rounded-lg z-10">
                {/* Main Content Layout */}
                <div className="relative h-[500px] w-full overflow-hidden">
                  {/* Sliding sections */}
                  <div className={`absolute top-0 left-0 h-full w-full flex transition-all duration-500 ${selectedAction ? 'translate-x-[-33.3333%]' : ''}`}>
                    {/* TOTAL IN (hidden after action) */}
                    <div className={`w-1/3 bg-[#00a100] flex flex-col text-white h-full ${selectedAction ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-all duration-500`}>
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="text-center">
                          <span className="text-md font-medium mb-4 block">TOTAL IN</span>
                          <div className="flex items-baseline justify-center space-x-2 mt-4">
                            <span className="text-2xl font-bold">INR </span>
                            <span className="text-2xl">0.00</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* ActionIcons (becomes left after action) */}
                    <div className={`w-1/3 bg-gray-100 relative flex flex-col h-full transition-all duration-500 ${selectedAction ? 'border-r border-gray-300' : ''}`}>
                      <div className="bg-slate-600 h-20 w-full flex flex-col text-white justify-center">
                        <div className="text-center align-middle text-2xl">
                          <span className="text-md font-medium mb-4 block text-center">Select Your Operation</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2 h-[calc(100%-5rem)] items-center justify-center p-4">
                        {['REDEEM_CHIPS', 'REDEEM_TITO', 'BUY_TITO', 'LOAD_CARD', 'BUY_CHIPS'].map((action, idx) => (
                          <ActionIcon
                            key={action}
                            label={action.replace(/_/g, ' ')}
                            icon={
                              action === 'REDEEM_CHIPS' ? 'redeem-chips' :
                                action === 'REDEEM_TITO' ? 'ticket' :
                                  action === 'BUY_TITO' ? 'ticket-buy' :
                                    action === 'LOAD_CARD' ? 'load-card' :
                                      action === 'BUY_CHIPS' ? 'buy-chip' : ''
                            }
                            className={selectedAction === action ? 'border-green-500 bg-green-100 text-green-700' : ''}
                            onClick={() => {
                              setSelectedAction(action);
                              setShowPlayerSearch(true);
                              setTransactionStep('search-player');
                            }}
                          />
                        ))}
                        <div className="w-full aspect-square" />
                        <div className="w-full aspect-square" />
                      </div>
                    </div>
                    {/* TOTAL OUT (hidden after action) */}
                    <div className={`w-1/3 bg-[#0066ff] flex flex-col text-white h-full ${selectedAction ? 'opacity-0 pointer-events-none' : 'opacity-100'} transition-all duration-500`}>
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="text-center">
                          <span className="text-md font-medium mb-4 block">TOTAL OUT</span>
                          <div className="flex items-baseline justify-center space-x-2 mt-4">
                            <span className="text-2xl font-bold">INR </span>
                            <span className="text-2xl">0.00</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* Combined section for player search and transaction details */}
                  {selectedAction && showPlayerSearch && (
                    <div className="absolute top-0 left-1/3 h-full w-2/3 bg-white border-l border-gray-200 flex flex-col animate-slide-in">
                      {transactionStep === 'search-player' ? (
                        <>
                          <div className="bg-slate-600 h-20 w-full flex items-center justify-between px-4">
                            <button
                              onClick={() => {
                                setSelectedAction(null);
                                setShowPlayerSearch(false);
                                setSelectedPlayer(null);
                                setSearchQuery("");
                              }}
                              className="flex text-white hover:text-gray-200 transition-colors"
                            >
                              <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                              </svg>
                              Back
                            </button>
                            <span className="text-white text-lg font-medium align-middle">Search Player</span>
                            <button
                              onClick={() => {
                                setShowTransactionModal(false);
                                setSelectedAction(null);
                                setShowPlayerSearch(false);
                                setSelectedPlayer(null);
                                setSearchQuery("");
                              }}
                              className="text-white hover:text-gray-200 transition-colors"
                            >
                              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            </button>
                          </div>
                          <div className="p-4">
                            <input
                              type="text"
                              value={searchQuery}
                              onChange={e => setSearchQuery(e.target.value)}
                              placeholder="Search player by name or ID..."
                              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                            />
                            <div className="space-y-2 max-h-[350px] overflow-y-auto">
                              {searchQuery.trim() === "" ? (
                                <div className="text-center text-gray-400 py-8">Type to search for a player...</div>
                              ) : filteredPlayers.length === 0 ? (
                                <div className="text-center text-gray-400 py-8">No players found.</div>
                              ) : (
                                filteredPlayers.map(player => (
                                  <div
                                    key={player.id}
                                    className={`p-4 border rounded-md cursor-pointer transition-colors ${selectedPlayer?.id === player.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}`}
                                    onClick={() => setSelectedPlayer(player)}
                                  >
                                    <div className="flex justify-between items-center">
                                      <div>
                                        <h3 className="font-medium text-gray-900">{player.name}</h3>
                                        <p className="text-sm text-gray-500">ID: {player.playerId}</p>
                                      </div>
                                      <div className="text-right">
                                        <p className="text-sm text-gray-500">Balance</p>
                                        <p className="font-medium text-gray-900">INR {player.balance.toLocaleString()}</p>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                            {(
                              <div className="mt-8 rounded-lg p-4">
                                <div className="flex justify-end mt-8">
                                  <Button
                                    className="bg-blue-600 text-white hover:bg-blue-700 px-8 disabled:opacity-50 disabled:cursor-not-allowed"
                                    onClick={() => {
                                      setTransactionStep('transaction-details');
                                    }}
                                    disabled={!selectedPlayer || !searchQuery}
                                  >
                                    NEXT
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </>
                      ) : null}
                    </div>
                  )}

                  {/* Transaction Details Section */}
                  {transactionStep === 'transaction-details' && (
                    <div style={{ height: "500px" }} className="absolute top-0 left-1/3 h-full w-2/3 bg-white border-l border-gray-200 flex flex-col animate-slide-in">
                      <div className="bg-gray-600 h-20 w-full flex items-center justify-between px-4">
                        <button
                          onClick={() => setTransactionStep('search-player')}
                          className="flex items-center text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          Back
                        </button>
                        <span className="text-white text-lg font-medium">Transaction Details</span>
                        <button
                          onClick={() => {
                            setShowTransactionModal(false);
                            setSelectedAction(null);
                            setShowPlayerSearch(false);
                            setSelectedPlayer(null);
                            setSearchQuery("");
                            setTransactionStep('select-action');
                          }}
                          className="text-white hover:text-gray-200 transition-colors"
                        >
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>

                      <div className="p-6">
                        <div className="space-y-4">
                          {(selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') ? (
                            <ChipDenominationSelector
                              availableDenominations={availableDenominations}
                              chipQuantities={chipQuantities}
                              onQuantityChange={(denomination, quantity) => {
                                setChipQuantities(prev => ({
                                  ...prev,
                                  [denomination]: quantity
                                }));
                              }}
                            />
                          ) : (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                Amount
                              </label>
                              <input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter amount"
                              />
                            </div>
                          )}
                        </div>

                        <div className="flex justify-end mt-4 space-x-4">
                          <Button
                            variant="outline"
                            onClick={() => setTransactionStep('search-player')}
                          >
                            Back
                          </Button>
                          <Button
                            className="bg-green-600 text-white hover:bg-green-700"
                            onClick={() => setTransactionStep('summary')}
                            disabled={
                              (selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS')
                                ? Object.values(chipQuantities).every(qty => !qty || qty <= 0)
                                : !(Number(amount) > 0)
                            }
                          >
                            Confirm Transaction
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                  {/* Transaction Summary Section */}
                  {transactionStep === 'summary' && (
                    <div style={{ height: "500px" }} className="absolute top-0 left-1/3 h-full w-2/3 bg-white border-l border-gray-200 flex flex-col animate-slide-in">
                      <div className="bg-white w-full flex items-center justify-between px-6 pt-6 pb-2">
                        <span className="text-2xl font-bold">Summary</span>
                        <button className="text-gray-400 hover:text-gray-600" onClick={() => setShowTransactionModal(false)}>
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                      <div className="p-6 flex flex-col gap-4 overflow-y-auto">
                        {/* DEBUG: Show availableDenominations and chipQuantities */}
                        {/* <div className="mb-4 p-4 bg-yellow-50 border border-yellow-300 rounded">
                          <div className="font-bold mb-2 text-yellow-800">Debug Info</div>
                          <div className="text-xs text-yellow-900">
                            <div><strong>availableDenominations:</strong></div>
                            <pre>{JSON.stringify(availableDenominations, null, 2)}</pre>
                            <div><strong>chipQuantities:</strong></div>
                            <pre>{JSON.stringify(chipQuantities, null, 2)}</pre>
                          </div>
                        </div> */}
                        {/* GAMING DAY */}
                        <div className="bg-gray-100 rounded mb-2">
                          <div className="flex flex-col px-2 py-4 gap-2">
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Player Name</span>
                              <span className="font-bold text-xl">{selectedPlayer ? selectedPlayer.name : <span className="text-gray-400">No player selected</span>}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Transaction Type</span>
                              <span className="font-bold text-xl">{selectedAction ? selectedAction.replace(/_/g, ' ') : <span className="text-gray-400">No action selected</span>}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-base text-gray-500 uppercase">Current Card Balance</span>
                              <span className="font-bold text-xl">{selectedPlayer && typeof selectedPlayer.balance !== 'undefined' ? `INR ${Number(selectedPlayer.balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : <span className="text-gray-400">N/A</span>}</span>
                            </div>
                          </div>
                        </div>
                        {/* CASH (for cash actions) */}
                        {(selectedAction !== 'BUY_CHIPS' && selectedAction !== 'REDEEM_CHIPS') && (
                          <div className="bg-gray-100 rounded mb-2">
                            <div className="flex justify-between items-center px-2 py-4">
                              <span className="font-bold text-base text-gray-500 uppercase">Cash</span>
                              <span className="font-bold text-xl">INR {Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                            </div>
                          </div>
                        )}
                        {/* CHIP (for chip actions) */}
                        {(selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') && (
                          <>
                            <div className="bg-gray-100 mb-2 px-2">
                              <span className="font-bold text-base text-gray-500 uppercase">Chip</span>
                              <div className="mt-2">
                                {availableDenominations.filter((denom: {id: number, chip_denomination: string}) => (chipQuantities[String(denom.chip_denomination)] || 0) > 0).length === 0 ? (
                                  <span className="text-gray-500">No chips selected</span>
                                ) : (
                                  availableDenominations.filter((denom: {id: number, chip_denomination: string}) => (chipQuantities[String(denom.chip_denomination)] || 0) > 0).map((denom: {id: number, chip_denomination: string}) => (
                                    <div key={denom.id} className="flex justify-between items-center mb-1">
                                      <span className="text-lg">{denom.chip_denomination} x {chipQuantities[String(denom.chip_denomination)]}</span>
                                      <span className="font-bold text-lg">INR {(Number(chipQuantities[String(denom.chip_denomination)]) * Number(denom.chip_denomination)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>
                            {/* <div className="bg-gray-100 rounded mb-2">
                              <div className="flex justify-between items-center px-6 py-4">
                                <span className="font-bold text-base text-gray-500 uppercase">Chips Total</span>
                                <span className="font-bold text-xl">INR {availableDenominations.filter((denom: {id: number, chip_denomination: string}) => (chipQuantities[denom.id] || 0) > 0)
                                  .reduce((sum: number, denom: {id: number, chip_denomination: string}) => sum + (Number(chipQuantities[String(denom.chip_denomination)]) * Number(denom.chip_denomination)), 0)
                                  .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                              </div>
                            </div> */}
                          </>
                        )}
                        {/* CAGE TOTAL */}
                        <div className="mt-4 border-t pt-4">
                          <div className="flex justify-between items-center px-2">
                            <span className="font-bold text-xl uppercase">Total</span>
                            <span className="font-bold text-xl">INR {(() => {
                              if (selectedAction === 'BUY_CHIPS' || selectedAction === 'REDEEM_CHIPS') {
                                return availableDenominations.reduce((sum, denom) => sum + (Number(denom.chip_denomination) * (chipQuantities[String(denom.chip_denomination)] || 0)), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                              } else {
                                return Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                              }
                            })()}</span>
                          </div>
                        </div>
                        <div className="flex justify-end mt-8 gap-4">
                          <Button variant="outline" onClick={() => setTransactionStep('transaction-details')}>BACK</Button>
                          <Button variant="primary" onClick={() => { /* TODO: Submit transaction logic here */ setShowTransactionModal(false); }}>SUBMIT</Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Cage Inventory Table */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-xl font-bold text-gray-800">Cage Inventory</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {loading ? (
                <div className="py-8 text-center text-gray-500">Loading...</div>
              ) : (
                <>
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-600">
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Type</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Denomination</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Quantity</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Amount</TableHead>
                        <TableHead className="font-bold text-white text-xs uppercase text-center">Base Currency</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inventoryData.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-gray-400 py-6">
                            No inventory data available
                          </TableCell>
                        </TableRow>
                      ) : (
                        inventoryData.map((item, index) => (
                          <TableRow key={index} className="hover:bg-gray-50 border-b border-gray-200">
                            <TableCell className="text-center font-medium text-sm py-3">
                              {item.type}
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">
                              {item.type == "CHIP" ? item.chip_denomination
                                ? parseInt(item.chip_denomination, 10)
                                : "" : "-"}
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">{item.type == "CHIP" ? item.quantity : "-"}</TableCell>
                            <TableCell className="text-center font-medium text-sm py-3">
                              {/* Show amount with 2 decimals */}
                              {item.total_value
                                ? Number(item.total_value).toLocaleString(undefined, {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                                })
                                : ""}
                            </TableCell>
                            <TableCell className="text-center text-sm py-3">INR</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                  <div className="flex justify-end mt-4 pt-4 border-t border-gray-200">
                    <div className="text-right">
                      <div className="text-lg text-gray-500 mb-1 font-bold uppercase">
                        TOTAL : <span className="text-lg font-bold text-gray-800">
                          INR {total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* History Modal */}
          {showHistory && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => setShowHistory(false)}>
                <div className="p-6 w-full h-[600px]">
                  <h2 className="text-xl font-bold mb-4">Cage Session History</h2>
                  <div className="flex items-center mb-4">
                    <span className="text-lg font-bold mr-2">{cageDetails?.name?.toUpperCase()}</span>
                    {cageDetails?.status && <StatusBadge status={cageDetails.status} />}
                    <span className="ml-2">{cageDetails?.terminal}</span>
                  </div>
                  <div className="flex gap-2 mb-4">
                    {(['ALL', 'TODAY', 'YESTERDAY', 'THIS_MONTH', 'CUSTOM'] as const).map((filter) => (
                      <Button
                        key={filter}
                        size="sm"
                        className={`rounded-full px-1 py-1 font-semibold transition-all duration-150 ${historyFilter === filter
                          ? "bg-blue-600 text-white shadow"
                          : "bg-gray-200 text-gray-700 hover:bg-blue-100"
                          }`}
                        onClick={() => setHistoryFilter(filter)}
                      >
                        {filter.replace("_", " ")}
                      </Button>
                    ))}
                    {historyFilter === 'CUSTOM' && (
                      <div className="flex items-center gap-2 ml-4">
                        <input
                          type="date"
                          value={customRange.start}
                          onChange={e => setCustomRange(r => ({ ...r, start: e.target.value }))}
                          className="border rounded px-2 py-1 text-sm"
                        />
                        <span className="text-gray-500">to</span>
                        <input
                          type="date"
                          value={customRange.end}
                          onChange={e => setCustomRange(r => ({ ...r, end: e.target.value }))}
                          className="border rounded px-2 py-1 text-sm"
                        />
                      </div>
                    )}
                  </div>
                  <div className="overflow-auto max-h-85">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-600 sticky top-0 z-10">
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Opening Time</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Owner</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">No of Transactions</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Transaction Amount</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Close Time</TableHead>
                          <TableHead className="font-bold text-white text-xs uppercase text-center">Closed By</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {historyLoading ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                          </TableRow>
                        ) : filterHistoryRows(historyData).length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center">No history found</TableCell>
                          </TableRow>
                        ) : (
                          filterHistoryRows(historyData).map((row, idx) => (
                            <TableRow key={idx}>
                              <TableCell className="text-center">{row.started_at}</TableCell>
                              <TableCell className="text-center">{row.opened_by}</TableCell>
                              <TableCell className="text-center">{row.transaction_count}</TableCell>
                              <TableCell className="text-center">INR {row.total_amount}</TableCell>
                              <TableCell className="text-center">{row.ended_at}</TableCell>
                              <TableCell className="text-center">{row.closed_by}</TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex justify-end gap-2 mt-6">
                    <Button variant="outline" onClick={() => setShowHistory(false)}>CANCEL</Button>
                    {/* <Button variant="primary" onClick={() => setShowHistory(false)}>SELECT</Button> */}
                  </div>
                </div>
              </Modal>
            </div>
          )}

          {/* Initial Setup Modal */}
          <InitialCageSetupModal
            open={showSetupModal}
            onClose={() => setShowSetupModal(false)}
            cageId={cageId}
            onSuccess={() => setRefreshKey(k => k + 1)} 
            onSave={async (cash, chips) => {
              const cage_id = Number(cageId);
              const now = new Date().toISOString();
              const changed_by = 1; 
              let gaming_day_id = 6;
              try {
                const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
                const data = await resp.json();
                if (data && data.gaming_day_id) {
                  gaming_day_id = data.gaming_day_id;
                }
              } catch { }

              // Save chip denominations
              console.log("Saving chips:", chips);
              const chipEntries = chips
                .filter(chip => chip.quantity > 0)
                .map(chip => ({
                  cage_id,
                  chip_id: chip.id,
                  gaming_day_id,
                  chip_denomination: chip.denomination,
                  chip_color: chip.color,
                  quantity: chip.quantity,
                  total_value: Number(chip.denomination) * Number(chip.quantity),
                  recorded_at: now,
                }));

              await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(chipEntries),
              });

              // Calculate chip total
              const chip_total = chips.reduce(
                (sum, chip) => sum + (Number(chip.denomination) * Number(chip.quantity)),
                0
              );
              const cash_total = Number(cash) || 0;

              // Update Cage table
              await fetch(`${API_BASE_URL}/api/cage/${cage_id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  status: "OPEN",
                  balance: cash_total,
                  chip_balance: chip_total,
                  last_change: now,
                  gaming_day_id,
                  changed_by,
                }),
              });

              // Fetch current vault balance
              const vaultResp = await fetch(`${API_BASE_URL}/api/vault-balance/1`);
              const vault = await vaultResp.json();

              // Calculate new vault balances
              const new_total_cash = Number(vault.total_cash) - cash_total;
              const new_total_chips = Number(vault.total_chips) - chip_total;
              const new_total_assets = Number(vault.total_assets) - (cash_total + chip_total);

              // Update vault balance
              await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  total_cash: new_total_cash,
                  total_chips: new_total_chips,
                  total_assets: new_total_assets,
                  last_updated: now,
                }),
              });

              // Fetch Vault Chip Denominations Inventory
              const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
              const vaultChips = await vaultChipRes.json();

              // Prepare the update array
              const vaultChipUpdates = chips.map(chip => {
                const vaultChip = vaultChips.find((vc: any) => vc.id === chip.id);
                const prevQuantity = Number(vaultChip?.quantity) || 0;
                const prevTotalValue = Number(vaultChip?.total_value) || 0;
                const denomination = Number(chip.denomination);

                return {
                  id: chip.id,
                  quantity: prevQuantity - chip.quantity,
                  total_value: prevTotalValue - (chip.quantity * denomination),
                };
              });

              // PUT update to bulk endpoint
              await fetch(`${API_BASE_URL}/api/vault-chip-denomination/bulk`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(vaultChipUpdates),
              });

              // Prepare vault transaction entries
              const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
              const authorized_by = 2;
              const performed_by = 3;
              const destination = `Cage ${cage_id}`;
              const transaction_time = new Date().toISOString();

              // Cash transaction entry (if any)
              const vaultTransactions = [];
              if (cash_total > 0) {
                vaultTransactions.push({
                  vault_id: 1,
                  transaction_type: "TRANSFER",
                  asset_type: "CASH",
                  denomination: 0,
                  quantity: 0,
                  total_value: cash_total,
                  currency_code: "INR",
                  source: "Vault",
                  destination,
                  reference_id,
                  authorized_by,
                  performed_by,
                  transaction_time,
                  cage_id: cage_id,
                  notes: `Cash of INR ${cash_total} added to Cage ${cage_id}`,
                  gaming_day_id,
                });
              }

              // Chip transaction entries (if any)
              chips
                .filter(chip => chip.quantity > 0)
                .forEach(chip => {
                  vaultTransactions.push({
                    vault_id: 1,
                    transaction_type: "TRANSFER",
                    asset_type: "CHIP",
                    denomination: Number(chip.denomination),
                    quantity: chip.quantity,
                    total_value: Number(chip.denomination) * Number(chip.quantity),
                    currency_code: "INR",
                    source: "Vault",
                    destination,
                    reference_id,
                    authorized_by,
                    performed_by,
                    transaction_time,
                    cage_id: cage_id,
                    notes: `${chip.quantity} Quantity of ${chip.denomination} Denomination added to Cage ${cage_id}`,
                    gaming_day_id,
                  });
                });

              // POST to vault-transaction/bulk
              if (vaultTransactions.length > 0) {
                await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(vaultTransactions),
                });
              }

            }}
          />

          {/* Transactions Modal */}
          {showTransactions && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40 max-w-5xl!">
              <Modal onClose={() => setShowTransactions(false)} height="max-h-7xl">
                <div className="p-6 w-full">
                  <h2 className="text-xl font-bold mb-4">Transactions</h2>
                  {transactionsLoading ? (
                    <div className="py-8 text-center text-gray-500">Loading...</div>
                  ) : transactions.length === 0 ? (
                    <div className="py-8 text-center text-gray-500">No transactions found.</div>
                  ) : (
                    <div className="overflow-auto max-h-96">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-600">
                            <TableHead className="font-bold text-white text-xs uppercase text-center">TX ID</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Type</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Player Name</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-right">Amount</TableHead>
                            <TableHead className="font-bold text-white text-xs uppercase text-center">Time</TableHead>
                            {/* Add more columns as needed */}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {transactions.map((txn, idx) => (
                            <TableRow key={idx}>
                              <TableCell className="text-center">{txn.transaction_id}</TableCell>
                              <TableCell className="text-center">{txn.payment_method}</TableCell>
                              <TableCell className="text-center">{txn.player}</TableCell>
                              <TableCell className="text-right">
                                INR {Number(txn.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </TableCell>
                              <TableCell className="text-center">
                                {new Date(txn.timestamp).toLocaleString("en-GB", {
                                  year: "numeric",
                                  month: "2-digit",
                                  day: "2-digit",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                  second: "2-digit",
                                  hour12: false,
                                  timeZone: "Asia/Kolkata",
                                }).replace(",", "")} IST
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                  <div className="flex justify-end gap-2 mt-6">
                    <Button variant="outline" onClick={() => setShowTransactions(false)}>CLOSE</Button>
                  </div>
                </div>
              </Modal>
            </div>
          )}

          {/* Stop Session Confirmation Modal */}
          {showStopSessionModal && (
            <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
              <Modal onClose={() => setShowStopSessionModal(false)} width="max-w-2xl">
                <div className="p-6 flex flex-col items-center ">
                  <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4" />
                  <h2 className="text-lg font-bold mb-2 text-center">Are you sure you want to Stop the Cage Session?</h2>
                  <div className="flex justify-end gap-4 mt-6">
                    <Button
                      variant="outline"
                      onClick={() => setShowStopSessionModal(false)}
                      className="flex items-center gap-2"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                      Cancel
                    </Button>
                    <Button
                      variant="primary"
                      onClick={handleConfirmStopSession}
                      className="flex items-center gap-2 bg-red-600 hover:bg-red-700"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Confirm
                    </Button>
                  </div>
                </div>
              </Modal>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CageCard;

type SaveCageChipDenominationParams = {
  cage_id: number;
  gaming_day_id: number;
  chips: any[];
  chipQuantities: { [id: number]: number };
};

async function saveCageChipDenomination({
  cage_id,
  gaming_day_id,
  chips,
  chipQuantities,
}: SaveCageChipDenominationParams) {
  const now = new Date().toISOString();
  const chipEntries = chips
    .filter(chip => chipQuantities[chip.id] > 0)
    .map(chip => ({
      cage_id,
      chip_id: chip.id,
      gaming_day_id,
      chip_denomination: chip.chip_denomination,
      chip_color: chip.chip_color,
      quantity: chipQuantities[chip.id],
      total_value: Number(chip.chip_denomination) * chipQuantities[chip.id],
      recorded_at: now,
    }));
  if (chipEntries.length === 0) return;
  await fetch(`${API_BASE_URL}/api/cage-chip-denomination`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(chipEntries),
  });
}

async function updateCageTable(params: UpdateCageTableParams) {
  const now = new Date().toISOString();
  await fetch(`${API_BASE_URL}/api/cage/${params.cage_id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      status: "OPEN",
      balance: params.cash_total,
      chip_balance: params.chip_total,
      last_change: now,
      gaming_day_id: params.gaming_day_id,
      changed_by: params.changed_by,
    }),
  });
}

async function updateVaultBalance(params: UpdateVaultBalanceParams) {
  const now = new Date().toISOString();
  const vaultResp = await fetch(`${API_BASE_URL}/api/vault-balance/1`);
  const vault = await vaultResp.json();
  const new_total_cash = Number(vault.total_cash) - params.cash_total;
  const new_total_chips = Number(vault.total_chips) - params.chip_total;
  const new_total_assets = Number(vault.total_assets) - (params.cash_total + params.chip_total);
  await fetch(`${API_BASE_URL}/api/vault-balance/1`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      total_cash: new_total_cash,
      total_chips: new_total_chips,
      total_assets: new_total_assets,
      last_updated: now,
    }),
  });
}

async function updateVaultChipDenomination(params: UpdateVaultChipDenominationParams) {
  const vaultChipRes = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
  const vaultChips = await vaultChipRes.json();
  const vaultChipUpdates = params.chips
    .filter(chip => params.chipQuantities[chip.id] > 0)
    .map(chip => {
      const vaultChip = vaultChips.find((vc: any) => vc.id === chip.id);
      const prevQuantity = Number(vaultChip?.quantity) || 0;
      const prevTotalValue = Number(vaultChip?.total_value) || 0;
      const denomination = Number(chip.chip_denomination);
      return {
        id: chip.id,
        quantity: prevQuantity - params.chipQuantities[chip.id],
        total_value: prevTotalValue - (params.chipQuantities[chip.id] * denomination),
      };
    });
  if (vaultChipUpdates.length === 0) return;
  await fetch(`${API_BASE_URL}/api/vault-chip-denomination/bulk`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(vaultChipUpdates),
  });
}

async function postVaultTransactions(params: PostVaultTransactionsParams) {
  const now = new Date().toISOString();
  const reference_id = `${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
  const authorized_by = 2;
  const performed_by = 3;
  const destination = `Cage ${params.cage_id}`;
  const vaultTransactions = [];
  if (params.cash_total > 0) {
    vaultTransactions.push({
      vault_id: 1,
      transaction_type: "TRANSFER",
      asset_type: "CASH",
      denomination: 0,
      quantity: 0,
      total_value: params.cash_total,
      currency_code: "INR",
      source: "Vault",
      destination,
      reference_id,
      authorized_by,
      performed_by,
      transaction_time: now,
      cage_id: params.cage_id,
      notes: `Cash of INR ${params.cash_total} added to Cage ${params.cage_id}`,
      gaming_day_id: params.gaming_day_id,
    });
  }
  params.chips
    .filter(chip => params.chipQuantities[chip.id] > 0)
    .forEach(chip => {
      vaultTransactions.push({
        vault_id: 1,
        transaction_type: "TRANSFER",
        asset_type: "CHIP",
        denomination: Number(chip.chip_denomination),
        quantity: params.chipQuantities[chip.id],
        total_value: Number(chip.chip_denomination) * params.chipQuantities[chip.id],
        currency_code: "INR",
        source: "Vault",
        destination,
        reference_id,
        authorized_by,
        performed_by,
        transaction_time: now,
        cage_id: params.cage_id,
        notes: `${params.chipQuantities[chip.id]} Quantity of ${chip.chip_denomination} Denomination added to Cage ${params.cage_id}`,
        gaming_day_id: params.gaming_day_id,
      });
    });
  if (vaultTransactions.length === 0) return;
  await fetch(`${API_BASE_URL}/api/vault-transaction/bulk`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(vaultTransactions),
  });
}

type UpdateCageTableParams = {
  cage_id: number;
  cash_total: number;
  chip_total: number;
  gaming_day_id: number;
  changed_by: number;
};

type UpdateVaultBalanceParams = {
  cash_total: number;
  chip_total: number;
};

type UpdateVaultChipDenominationParams = {
  chips: any[];
  chipQuantities: { [id: number]: number };
};

type PostVaultTransactionsParams = {
  cage_id: number;
  cash_total: number;
  chips: any[];
  chipQuantities: { [id: number]: number };
  gaming_day_id: number;
};