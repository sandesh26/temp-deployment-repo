"use client";
import React, { useState, useEffect } from "react";
import Modal from "@/components/ui/modal/Modal";
import { API_BASE_URL } from "@/config/api";


export default function CasinoConfiguration() {
	// Tab state
	const [activeTab, setActiveTab] = useState<'gamingday' | 'currency' | 'games' | 'floors'>('gamingday');

	// Gaming Day state
	const [status, setStatus] = useState<'STOPPED' | 'STARTED'>('STOPPED');
	const [startTime, setStartTime] = useState('04:00');
	const [originalStartTime, setOriginalStartTime] = useState('04:00');
	const [settingsId, setSettingsId] = useState<number | null>(null);
	const [popup, setPopup] = useState<{ visible: boolean; title: string; message: string }>({ visible: false, title: '', message: '' });
	const [showStopConfirm, setShowStopConfirm] = useState(false);
	const [gamingDay, setGamingDay] = useState<any>(null);


	// Currency state
	const [currency, setCurrency] = useState('USD');
	const [originalCurrency, setOriginalCurrency] = useState('USD');
	const currencyOptions = [
		{ value: 'USD', label: 'USD ($)' },
		{ value: 'EUR', label: 'EUR (€)' },
		{ value: 'GBP', label: 'GBP (£)' },
		{ value: 'INR', label: 'INR (₹)' },
		{ value: 'JPY', label: 'JPY (¥)' },
		{ value: 'CNY', label: 'CNY (¥)' },
		{ value: 'SGD', label: 'SGD (S$)' },
		{ value: 'AUD', label: 'AUD (A$)' },
		{ value: 'CAD', label: 'CAD (C$)' },
	];
	const LOGGED_IN_USER_ID = 2;

	// Games Catalog state
	const [games, setGames] = useState<any[]>([]);
	const [gamesLoading, setGamesLoading] = useState(false);
	const [gamesError, setGamesError] = useState('');
	const [gamesSearch, setGamesSearch] = useState('');
	const [gamesFilters, setGamesFilters] = useState<{ [key: string]: string }>({ type: '', status: '' });
	const [gamesSortBy, setGamesSortBy] = useState<string>('name');
	const [gamesSortOrder, setGamesSortOrder] = useState<'asc' | 'desc'>('asc');

	// Casino Floors state
	const [floors, setFloors] = useState<any[]>([]);
	const [floorsLoading, setFloorsLoading] = useState(false);
	const [floorsError, setFloorsError] = useState('');
	const [showAddFloorModal, setShowAddFloorModal] = useState(false);
	const [addFloorName, setAddFloorName] = useState('');
	const [addFloorLoading, setAddFloorLoading] = useState(false);
	const [isEditFloorMode, setIsEditFloorMode] = useState(false);
	const [editFloorId, setEditFloorId] = useState<number | null>(null);
	// Add/Edit Floor handler
	const handleAddFloor = async () => {
		if (!addFloorName.trim()) return;
		setAddFloorLoading(true);
		try {
			let resp;
			if (isEditFloorMode && editFloorId) {
				// Edit mode: update floor
				resp = await fetch(`${API_BASE_URL}/api/floor/${editFloorId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: addFloorName.trim() })
				});
			} else {
				// Add mode: create new floor
				resp = await fetch(`${API_BASE_URL}/api/floor`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: addFloorName.trim() })
				});
			}
			if (!resp.ok) {
				setPopup({ visible: true, title: 'Error', message: isEditFloorMode ? 'Failed to update floor.' : 'Failed to add floor.' });
				setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
				setAddFloorLoading(false);
				return;
			}
			setPopup({ visible: true, title: 'Success', message: isEditFloorMode ? 'Floor updated successfully.' : 'Floor added successfully.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
			setShowAddFloorModal(false);
			setAddFloorName('');
			setIsEditFloorMode(false);
			setEditFloorId(null);
			// Refresh floors list
			setFloorsLoading(true);
			fetch(`${API_BASE_URL}/api/floor`)
				.then(res => res.ok ? res.json() : [])
				.then(data => setFloors(Array.isArray(data) ? data : []))
				.catch(() => setFloors([]))
				.finally(() => setFloorsLoading(false));
		} catch {
			setPopup({ visible: true, title: 'Error', message: isEditFloorMode ? 'Failed to update floor.' : 'Failed to add floor.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
		} finally {
			setAddFloorLoading(false);
		}
	};

	// Add/Edit Game Modal state
	// Fetch Casino Floors when tab is active
	useEffect(() => {
		if (activeTab !== 'floors') return;
		setFloorsLoading(true);
		setFloorsError('');
		fetch(`${API_BASE_URL}/api/floor`)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch floors');
				return res.json();
			})
			.then(data => {
				setFloors(Array.isArray(data) ? data : []);
				setFloorsLoading(false);
			})
			.catch(() => {
				setFloors([]);
				setFloorsError('Failed to load casino floors.');
				setFloorsLoading(false);
			});
	}, [activeTab]);
	const [showAddGameModal, setShowAddGameModal] = useState(false);
	const [isEditMode, setIsEditMode] = useState(false);
	const [editGameId, setEditGameId] = useState<number | null>(null);
	// Add/Edit Game form state
	const [addGameForm, setAddGameForm] = useState({
		name: '',
		title: '',
		type: '',
		rtp: '',
		max_bet: '',
		lines: '',
		reels: '',
		denom: '',
		status: ''
	});


	// Disable background scroll when Add Game modal is open
	useEffect(() => {
		if (showAddGameModal) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = '';
		}
		return () => {
			document.body.style.overflow = '';
		};
	}, [showAddGameModal]);

	const GAME_COLUMNS = [
		{ key: 'name', label: 'Game Name' },
		{ key: 'type', label: 'Game Type' },
		{ key: 'rtp', label: 'RTP' },
		{ key: 'max_bet', label: 'Max Bet' },
		{ key: 'lines', label: 'Lines' },
		{ key: 'reels', label: 'Reels' },
		{ key: 'denom', label: 'Denom' },
		{ key: 'status', label: 'Status' },
		{ key: 'created_at', label: 'Created At' },
	];


	useEffect(() => {
		const fetchAll = async () => {
			try {
				// Fetch casino settings
				const settingsResp = await fetch(`${API_BASE_URL}/api/casinosettings`);
				if (settingsResp.ok) {
					const settingsData = await settingsResp.json();
					if (settingsData && settingsData.default_gaming_day_reset_time) {
						setStartTime(settingsData.default_gaming_day_reset_time);
						setOriginalStartTime(settingsData.default_gaming_day_reset_time);
					}
					if (settingsData && settingsData.default_currency) {
						setCurrency(settingsData.default_currency);
						setOriginalCurrency(settingsData.default_currency);
					}
					if (settingsData && settingsData.id) setSettingsId(settingsData.id);
				}
				// Fetch gaming day
				const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
				if (!resp.ok) {
					setGamingDay(null);
					setStatus('STOPPED');
					return;
				}
				const data = await resp.json();
				if (data && data.error === 'No active gaming day') {
					setGamingDay(null);
					setStatus('STOPPED');
					setPopup({ visible: true, title: 'No Active Gaming Day', message: 'There is currently no active gaming day.' });
					setTimeout(() => {
						setPopup((prev) => ({ ...prev, visible: false }));
					}, 2500);
					return;
				}
				setGamingDay(data);
				if (data.status === 'OPEN') {
					setStatus('STARTED');
				} else {
					setStatus('STOPPED');
				}
			} catch { }
		};
		fetchAll();
	}, []);
	// Add/Edit Game submit handler
	const handleAddGameSubmit = async () => {
		const now = new Date().toISOString();
		const payload: any = {
			name: addGameForm.name,
			title: addGameForm.title,
			type: addGameForm.type,
			rtp: addGameForm.rtp ? `${addGameForm.rtp}%` : '',
			max_bet: addGameForm.max_bet ? `${addGameForm.max_bet}cr` : '',
			lines: addGameForm.lines ? Number(addGameForm.lines) : null,
			reels: addGameForm.reels ? Number(addGameForm.reels) : null,
			denom: addGameForm.denom ? `INR ${parseFloat(addGameForm.denom).toFixed(2)}` : '',
			status: addGameForm.status,
			updated_at: now
		};
		if (!isEditMode) {
			payload.created_at = now;
		}
		try {
			let resp;
			if (isEditMode && editGameId) {
				// Update existing game
				resp = await fetch(`${API_BASE_URL}/api/game-catalog/${editGameId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
			} else {
				// Add new game
				resp = await fetch(`${API_BASE_URL}/api/game-catalog`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
			}
			if (!resp.ok) {
				setPopup({ visible: true, title: isEditMode ? 'Error' : 'Error', message: isEditMode ? 'Failed to update game.' : 'Failed to add game.' });
				setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
				return;
			}
			setPopup({ visible: true, title: isEditMode ? 'Success' : 'Success', message: isEditMode ? 'Game updated successfully.' : 'Game added successfully.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
			setShowAddGameModal(false);
			setAddGameForm({
				name: '', title: '', type: '', rtp: '', max_bet: '', lines: '', reels: '', denom: '', status: ''
			});
			setIsEditMode(false);
			setEditGameId(null);
			// Optionally refresh games list
			if (activeTab === 'games') {
				setGamesLoading(true);
				fetch(`${API_BASE_URL}/api/game-catalog`)
					.then(res => res.ok ? res.json() : [])
					.then(data => setGames(Array.isArray(data) ? data : []))
					.catch(() => setGames([]))
					.finally(() => setGamesLoading(false));
			}
		} catch {
			setPopup({ visible: true, title: isEditMode ? 'Error' : 'Error', message: isEditMode ? 'Failed to update game.' : 'Failed to add game.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
		}
	};

	// Fetch Games Catalog when tab is active
	useEffect(() => {
		if (activeTab !== 'games') return;
		setGamesLoading(true);
		setGamesError('');
		fetch(`${API_BASE_URL}/api/game-catalog`)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch games');
				return res.json();
			})
			.then(data => {
				setGames(Array.isArray(data) ? data : []);
				setGamesLoading(false);
			})
			.catch(() => {
				setGames([]);
				setGamesError('Failed to load games catalog.');
				setGamesLoading(false);
			});
	}, [activeTab]);

	// Save handler for currency (must be outside useEffect)
	const handleSaveCurrency = async () => {
		if (!settingsId) return;
		try {
			const resp = await fetch(`${API_BASE_URL}/api/casinosettings?id=1`, {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ default_currency: currency }),
			});
			if (!resp.ok) {
				setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update currency.' });
				setTimeout(() => {
					setPopup((prev) => ({ ...prev, visible: false }));
				}, 2500);
				return;
			}
			setOriginalCurrency(currency);
			setPopup({ visible: true, title: 'Saved', message: 'Default currency updated.' });
			setTimeout(() => {
				setPopup((prev) => ({ ...prev, visible: false }));
			}, 2000);
		} catch {
			setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update currency.' });
			setTimeout(() => {
				setPopup((prev) => ({ ...prev, visible: false }));
			}, 2500);
		}
	};

	// Games Catalog: filter, sort, and search
	const filteredGames = games
		.filter(game => {
			// Search: start filtering after 1+ chars
			const search = gamesSearch.trim().toLowerCase();
			let matchesSearch = true;
			if (search.length >= 1) {
				matchesSearch = GAME_COLUMNS.some(col => {
					const value = game[col.key];
					return value && value.toString().toLowerCase().includes(search);
				});
			}
			// Filters
			let matchesFilters = true;
			if (gamesFilters.type && game.type !== gamesFilters.type) matchesFilters = false;
			if (gamesFilters.status && game.status !== gamesFilters.status) matchesFilters = false;
			return matchesSearch && matchesFilters;
		})
		.sort((a, b) => {
			const aValue = a[gamesSortBy];
			const bValue = b[gamesSortBy];
			if (aValue === undefined || bValue === undefined) return 0;
			if (typeof aValue === 'number' && typeof bValue === 'number') {
				return gamesSortOrder === 'asc' ? aValue - bValue : bValue - aValue;
			}
			// For date columns, sort by date
			if (gamesSortBy === 'created_at') {
				const aDate = new Date(aValue);
				const bDate = new Date(bValue);
				return gamesSortOrder === 'asc' ? aDate.getTime() - bDate.getTime() : bDate.getTime() - aDate.getTime();
			}
			// Default: string comparison
			return gamesSortOrder === 'asc'
				? aValue.toString().localeCompare(bValue.toString())
				: bValue.toString().localeCompare(aValue.toString());
		});

	// Sort handler
	const handleGamesSort = (key: string) => {
		if (gamesSortBy === key) {
			setGamesSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
		} else {
			setGamesSortBy(key);
			setGamesSortOrder('asc');
		}
	};

	return (
		<div className="min-h-screen bg-transparent px-1">
			{/* Popup notification */}
			{popup.visible && (
				<div
					className="fixed right-6 z-50 bg-white rounded-xl shadow-lg border border-gray-100 px-8 py-5 min-w-[320px] max-w-xs transition-all duration-300"
					style={{ boxShadow: '0 4px 16px 0 rgba(0,0,0,0.08)', top: '5.5rem' }}
				>
					<div className="font-semibold text-base mb-1">{popup.title}</div>
					<div className="text-sm text-gray-700">{popup.message}</div>
				</div>
			)}

			{/* Tabs */}
			<div className="max-w-6xl mx-auto mt-4">
				<div className="flex gap-2 border-b border-gray-200 dark:border-gray-700 mb-4">
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'gamingday' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('gamingday')}
					>
						Gaming Day
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'currency' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('currency')}
					>
						Currency
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'games' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('games')}
					>
						Games Catalog
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'floors' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('floors')}
					>
						Casino Floors
					</button>
				</div>
				{activeTab === 'floors' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[300px]">
						<div className="flex items-center justify-between mb-4">
							<h2 className="text-lg font-bold text-black dark:text-white">Casino Floors</h2>
							<button
								className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-green-800 hover:bg-green-700 text-white font-semibold text-base shadow-theme-xs transition"
								onClick={() => {
									setShowAddFloorModal(true);
									setIsEditFloorMode(false);
									setEditFloorId(null);
									setAddFloorName('');
								}}
								type="button"
							>
								<svg width="20" height="20" fill="none" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="2" rx="1" fill="currentColor" /><rect x="11" y="4" width="2" height="16" rx="1" fill="currentColor" /></svg>
								Add New Floor
							</button>
						</div>
						<div className="max-w-full overflow-x-auto">
							{/* Add/Edit Floor Modal */}
							{showAddFloorModal && (
								<Modal onClose={() => {
									setShowAddFloorModal(false);
									setAddFloorName('');
									setIsEditFloorMode(false);
									setEditFloorId(null);
								}} width="max-w-md" height="max-h-[60vh]">
									<div className="p-8 max-h-[60vh] overflow-y-auto">
										<div className="text-xl font-bold mb-4 text-gray-900">{isEditFloorMode ? 'Edit Floor' : 'Add New Floor'}</div>
										<div className="mb-4">
											<label className="block text-sm font-medium mb-1">Floor Name</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addFloorName}
												onChange={e => setAddFloorName(e.target.value)}
												placeholder="Enter floor name"
												disabled={addFloorLoading}
											/>
										</div>
										<div className="flex justify-end pt-2 gap-2">
											<button
												type="button"
												className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black hover:bg-red-600 hover:text-white border border-gray-300"
												onClick={() => {
													setShowAddFloorModal(false);
													setAddFloorName('');
													setIsEditFloorMode(false);
													setEditFloorId(null);
												}}
												disabled={addFloorLoading}
											>
												Cancel
											</button>
											<button
												type="button"
												className="px-5 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800"
												onClick={handleAddFloor}
												disabled={addFloorLoading || !addFloorName.trim()}
											>
												{addFloorLoading ? (isEditFloorMode ? 'Updating...' : 'Adding...') : (isEditFloorMode ? 'Update Floor' : 'Add Floor')}
											</button>
										</div>
									</div>
								</Modal>
							)}
							<table className="w-full text-left border-collapse">
								<thead className="border-b border-gray-100 dark:border-white/[0.05]">
									<tr>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Floor ID</th>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Name</th>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Actions</th>
									</tr>
								</thead>
								<tbody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
									{floorsLoading ? (
										<tr><td colSpan={3} className="text-center py-6 text-gray-400">Loading...</td></tr>
									) : floorsError ? (
										<tr><td colSpan={3} className="text-center py-6 text-red-400">{floorsError}</td></tr>
									) : floors.length === 0 ? (
										<tr><td colSpan={3} className="text-center py-6 text-gray-400">No floors found.</td></tr>
									) : (
										floors.map(floor => (
											<tr key={floor.floor_id} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition">
												<td className="px-4 py-3 text-gray-800 text-theme-sm dark:text-gray-200 text-center">{floor.floor_id}</td>
												<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{floor.name}</td>
												<td className="px-4 py-3 text-center">
													<button
														className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700"
														onClick={() => {
															setIsEditFloorMode(true);
															setEditFloorId(floor.floor_id);
															setAddFloorName(floor.name || '');
															setShowAddFloorModal(true);
														}}
													>
														Edit
													</button>
												</td>
											</tr>
										))
									)}
								</tbody>
							</table>
						</div>
					</div>
				)}

				{/* Tab Content */}
				{activeTab === 'gamingday' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8">
						<h2 className="text-lg font-bold mb-2 text-black dark:text-white">Gaming Day Control</h2>
						<p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Start or stop the gaming day and configure its default start time.</p>
						{/* ...existing code for Gaming Day Control and Default Start Time... */}
						{/* Status and Controls */}
						<div className="mb-8">
							<div className="flex flex-col md:flex-row md:items-center md:justify-between bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4">
								<div>
									<div className="text-base font-semibold text-black dark:text-white mb-1">Gaming Day Status</div>
									<div className="text-md text-gray-500 dark:text-gray-400">
										The gaming day is currently <span className={status === 'STOPPED' ? 'text-red-500 font-bold' : 'text-green-500 font-bold'}>{status}</span>
									</div>
									{gamingDay && status === 'STARTED' && gamingDay.start_time && (
										<div className="mt-2 text-xs text-gray-700">
											Started at: {gamingDay.start_time.replace('T', ' ').replace(/\.\d+Z$/, '')}
										</div>
									)}
								</div>
								<div className="flex gap-4 mt-12 md:mt-0">
									{status === 'STOPPED' ? (
										<button
											className="flex items-center gap-2 px-8 py-4 rounded-lg text-lg font-semibold bg-green-700 hover:bg-green-800 text-white transition disabled:opacity-50 disabled:cursor-not-allowed"
											onClick={async () => {
												const now = new Date().toISOString();
												try {
													const resp = await fetch(`${API_BASE_URL}/api/gamingday`, {
														method: 'POST',
														headers: { 'Content-Type': 'application/json' },
														body: JSON.stringify({
															start_time: now,
															end_time: null,
															status: 'OPEN',
															closed_by: null,
															closed_at: null
														}),
													});
													if (!resp.ok) {
														setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to start the gaming day. Please try again.' });
														setTimeout(() => {
															setPopup((prev) => ({ ...prev, visible: false }));
														}, 2500);
														return;
													}
													const data = await resp.json();
													setGamingDay(data);
													setStatus('STARTED');
													setPopup({ visible: true, title: 'Gaming Day Started', message: 'The gaming day has officially begun.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
												} catch {
													setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to start the gaming day. Please try again.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
												}
											}}
										>
											<svg width="28" height="28" fill="none" viewBox="0 0 24 24"><path d="M5 3v18l15-9L5 3Z" fill="currentColor" /></svg>
											Start Day
										</button>
									) : (
										<button
											className="flex items-center gap-2 px-8 py-4 rounded-lg text-lg font-semibold bg-red-800 hover:bg-red-700 text-white transition disabled:opacity-50 disabled:cursor-not-allowed"
											onClick={() => setShowStopConfirm(true)}
										>
											<svg width="28" height="28" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="2" fill="none" /><rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor" /></svg>
											Stop Day
										</button>
									)}
								</div>
								{/* Stop Confirmation Modal */}
								{showStopConfirm && (
									<Modal onClose={() => setShowStopConfirm(false)} width="max-w-xl" height="max-h-xl">
										<div className="p-8 max-h-[70vh] overflow-y-auto">
											<div className="text-xl font-bold mb-2 text-gray-900">Are you sure you want to stop the gaming day?</div>
											<div className="text-gray-600 mb-6">This action will close all tables and finalize the day's transactions.<br />This cannot be undone.</div>
											<div className="flex justify-end gap-3 mt-4">
												<button
													className="px-5 py-2 rounded border border-gray-300 bg-white text-gray-800 font-semibold hover:bg-gray-100"
													onClick={() => setShowStopConfirm(false)}
												>
													Cancel
												</button>
												<button
													className="px-5 py-2 rounded bg-red-600 text-white font-semibold hover:bg-red-700"
													onClick={async () => {
														if (!gamingDay?.gaming_day_id) return;
														const now = new Date().toISOString();
														try {
															const resp = await fetch(`${API_BASE_URL}/api/gamingday/${gamingDay.gaming_day_id}`, {
																method: 'PUT',
																headers: { 'Content-Type': 'application/json' },
																body: JSON.stringify({
																	end_time: now,
																	status: 'CLOSED',
																	closed_at: now,
																	closed_by: LOGGED_IN_USER_ID
																}),
															});
															if (!resp.ok) {
																setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to stop the gaming day. Please try again.' });
																setShowStopConfirm(false);
																setTimeout(() => {
																	setPopup((prev) => ({ ...prev, visible: false }));
																}, 2500);
																return;
															}
															setStatus('STOPPED');
															setPopup({ visible: true, title: 'Gaming Day Stopped', message: 'The gaming day has officially ended.' });
															setShowStopConfirm(false);
															setTimeout(() => {
																setPopup((prev) => ({ ...prev, visible: false }));
															}, 2500);
														} catch {
															setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to stop the gaming day. Please try again.' });
															setShowStopConfirm(false);
															setTimeout(() => {
																setPopup((prev) => ({ ...prev, visible: false }));
															}, 2500);
														}
													}}
												>
													Stop Gaming Day
												</button>
											</div>
										</div>
									</Modal>
								)}
							</div>
						</div>
						{/* Default Start Time */}
						<div className="mb-2">
							<div className="text-base font-semibold text-black dark:text-white mb-2">Default Start Time (24 H)</div>
							<div className="flex items-center gap-2">
								<input
									type="time"
									value={startTime}
									onChange={e => setStartTime(e.target.value)}
									className="w-32 px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-sm font-mono bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-green-400"
								/>
								{startTime !== originalStartTime && (
									<button
										className="ml-4 px-4 py-1.5 rounded bg-green-700 text-white font-semibold hover:bg-green-800 text-sm transition"
										onClick={async () => {
											if (!settingsId) return;
											try {
												const resp = await fetch(`${API_BASE_URL}/api/casinosettings?id=1`, {
													method: 'PUT',
													headers: { 'Content-Type': 'application/json' },
													body: JSON.stringify({ default_gaming_day_reset_time: startTime }),
												});
												if (!resp.ok) {
													setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update gaming day time.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
													return;
												}
												setOriginalStartTime(startTime);
												setPopup({ visible: true, title: 'Saved', message: 'Gaming day reset time updated.' });
												setTimeout(() => {
													setPopup((prev) => ({ ...prev, visible: false }));
												}, 2000);
											} catch {
												setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update gaming day time.' });
												setTimeout(() => {
													setPopup((prev) => ({ ...prev, visible: false }));
												}, 2500);
											}
										}}
									>
										Save
									</button>
								)}
								<svg width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#888" strokeWidth="1.5" /><path d="M12 6v6l4 2" stroke="#888" strokeWidth="1.5" /></svg>
							</div>
							<div className="text-sm text-gray-500 dark:text-gray-400 mt-2">Set the time when a new gaming day automatically begins.</div>
						</div>
					</div>
				)}

				{activeTab === 'currency' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8">
						<div className="mb-6">
							<h2 className="text-lg font-bold mb-2 text-black dark:text-white">Currency Configuration</h2>
							<p className="text-sm text-gray-500 dark:text-gray-400">Set the global currency symbol for the casino.</p>
						</div>
						<div className="mb-4">
							<label className="block text-lg font-semibold text-black dark:text-white mb-2">Currency</label>
							<select
								className="w-64 px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 text-base bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-green-400"
								value={currency}
								onChange={e => setCurrency(e.target.value)}
							>
								{currencyOptions.map(opt => (
									<option key={opt.value} value={opt.value}>{opt.label}</option>
								))}
							</select>
							{currency !== originalCurrency && (
								<button
									className="ml-4 px-4 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800 text-base transition"
									onClick={handleSaveCurrency}
								>
									Save
								</button>
							)}
						</div>
						<div className="text-base text-gray-500 dark:text-gray-400 mt-2">This symbol will be used to display all monetary values.</div>
					</div>
				)}

				{activeTab === 'games' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[300px]">
						<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2 gap-4">
							<h2 className="text-lg font-bold text-black dark:text-white mb-0">Games Catalog Management</h2>
							<button
								className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-green-800 hover:bg-green-700 text-white font-semibold text-base shadow-theme-xs transition"
								onClick={() => setShowAddGameModal(true)}
								type="button"
							>
								<svg width="20" height="20" fill="none" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="2" rx="1" fill="currentColor" /><rect x="11" y="4" width="2" height="16" rx="1" fill="currentColor" /></svg>
								Add Game
							</button>
						</div>
						<p className="text-sm text-gray-500 dark:text-gray-400 mb-4">View, add, edit, or remove games available in the casino.</p>
						{/* Filters and Search */}
						<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
							<div className="flex gap-3 items-center">
								<span className="text-gray-500 dark:text-gray-400">Type:</span>
								<select
									className="py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
									value={gamesFilters.type}
									onChange={e => setGamesFilters(f => ({ ...f, type: e.target.value }))}
								>
									<option value="">All</option>
									{[...new Set(games.map(g => g.type))].filter(Boolean).map(type => (
										<option key={type} value={type}>{type}</option>
									))}
								</select>
								<span className="text-gray-500 dark:text-gray-400 ml-4">Status:</span>
								<select
									className="py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
									value={gamesFilters.status}
									onChange={e => setGamesFilters(f => ({ ...f, status: e.target.value }))}
								>
									<option value="">All</option>
									{[...new Set(games.map(g => g.status))].filter(Boolean).map(status => (
										<option key={status} value={status}>{status}</option>
									))}
								</select>
							</div>
							<div className="relative w-full sm:w-auto">
								<input
									placeholder="Search..."
									className="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
									type="text"
									value={gamesSearch}
									onChange={e => setGamesSearch(e.target.value)}
								/>
							</div>
						</div>
						{/* Table */}
						<div className="max-w-full overflow-x-auto">
							<div className="min-w-[1102px]">
								<table className="w-full text-left border-collapse">
									<thead className="border-b border-gray-100 dark:border-white/[0.05]">
										<tr>
											{GAME_COLUMNS.map(col => (
												<th
													key={col.key}
													className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400 cursor-pointer select-none"
													onClick={() => handleGamesSort(col.key)}
												>
													<div className="flex items-center justify-center gap-1">
														<span>{col.label}</span>
														<span className="flex flex-col gap-0.5">
															<svg
																xmlns="http://www.w3.org/2000/svg"
																width="8"
																height="5"
																fill="none"
																className={`text-gray-300 dark:text-gray-700 ${gamesSortBy === col.key && gamesSortOrder === 'asc' ? 'text-brand-500' : ''}`}
															>
																<path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
															</svg>
															<svg
																xmlns="http://www.w3.org/2000/svg"
																width="8"
																height="5"
																fill="none"
																className={`text-gray-300 dark:text-gray-700 ${gamesSortBy === col.key && gamesSortOrder === 'desc' ? 'text-brand-500' : ''}`}
															>
																<path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
															</svg>
														</span>
													</div>
												</th>
											))}
										</tr>
									</thead>
									<tbody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
										{gamesLoading ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-gray-400">Loading...</td></tr>
										) : gamesError ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-red-400">{gamesError}</td></tr>
										) : filteredGames.length === 0 ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-gray-400">No games found.</td></tr>
										) : (
											filteredGames.map(game => (
												<tr key={game.game_id} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition">
													<td className="px-4 py-3 text-gray-800 text-theme-sm dark:text-gray-200 text-center">{game.name}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.type}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.rtp}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.max_bet}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.lines}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.reels}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.denom}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														<span className={`px-3 py-1 rounded-full text-xs font-semibold ${game.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{game.status}</span>
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.created_at ? new Date(game.created_at).toLocaleDateString() : ''}</td>
													<td className="px-4 py-3 text-center">
														<button
															className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700"
															onClick={() => {
																setIsEditMode(true);
																setEditGameId(game.game_id);
																setAddGameForm({
																	name: game.name || '',
																	title: game.title || '',
																	type: game.type || '',
																	rtp: typeof game.rtp === 'string' ? game.rtp.replace('%', '') : (game.rtp || ''),
																	max_bet: typeof game.max_bet === 'string' ? game.max_bet.replace('cr', '') : (game.max_bet || ''),
																	lines: game.lines?.toString() || '',
																	reels: game.reels?.toString() || '',
																	denom: typeof game.denom === 'string' ? game.denom.replace('INR', '').trim() : (game.denom || ''),
																	status: game.status || ''
																});
																setShowAddGameModal(true);
															}}
														>
															Edit
														</button>
													</td>
												</tr>
											))
										)}
									</tbody>
								</table>
							</div>
						</div>

						{/* Add/Edit Game Modal */}
						{showAddGameModal && (
							<Modal onClose={() => {
								setShowAddGameModal(false);
								setIsEditMode(false);
								setEditGameId(null);
								setAddGameForm({ name: '', title: '', type: '', rtp: '', max_bet: '', lines: '', reels: '', denom: '', status: '' });
							}} width="max-w-lg" height="max-h-[120vh]">
								<div className="p-8 max-h-[70vh] overflow-y-auto">
									<div className="text-xl font-bold mb-4 text-gray-900">{isEditMode ? 'Edit Game' : 'Add New Game'}</div>
									<form className="space-y-4">
										<div>
											<label className="block text-sm font-medium mb-1">Name</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.name}
												onChange={e => setAddGameForm(f => ({ ...f, name: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Title</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.title}
												onChange={e => setAddGameForm(f => ({ ...f, title: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Type</label>
											<select
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.type}
												onChange={e => setAddGameForm(f => ({ ...f, type: e.target.value }))}
											>
												<option value="">Select type</option>
												<option value="video reel">Video Reel</option>
												<option value="Stepper">Stepper</option>
											</select>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">RTP</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.rtp}
												onChange={e => setAddGameForm(f => ({ ...f, rtp: e.target.value }))}
												placeholder="Enter RTP (number)"
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Max Bet</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.max_bet}
												onChange={e => setAddGameForm(f => ({ ...f, max_bet: e.target.value }))}
												placeholder="Enter Max Bet (number)"
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Lines</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.lines}
												onChange={e => setAddGameForm(f => ({ ...f, lines: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Reels</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.reels}
												onChange={e => setAddGameForm(f => ({ ...f, reels: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Denom</label>
											<div className="flex items-center">
												<span className="mr-2">INR</span>
												<input
													type="number"
													className="w-full px-3 py-2 border rounded-lg text-sm"
													value={addGameForm.denom}
													onChange={e => setAddGameForm(f => ({ ...f, denom: e.target.value }))}
												/>
											</div>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Status</label>
											<select
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.status}
												onChange={e => setAddGameForm(f => ({ ...f, status: e.target.value }))}
											>
												<option value="">Select status</option>
												<option value="Active">Active</option>
												<option value="Inactive">Inactive</option>
											</select>
										</div>
										<div className="flex justify-end pt-2 gap-2">
											<button
												type="button"
												className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black hover:bg-red-600 hover:text-white border border-gray-300"
												onClick={() => setShowAddGameModal(false)}
											>
												Cancel
											</button>
											<button
												type="button"
												className="px-5 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800"
												onClick={handleAddGameSubmit}
											>
												{isEditMode ? 'Update Game' : 'Add Game'}
											</button>
										</div>
									</form>
								</div>
							</Modal>
						)}
					</div>
				)}
			</div>
		</div>
	);
}
