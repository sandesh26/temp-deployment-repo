"use client";
import React, { useState, useEffect } from "react";
import ToggleSwitch from './ToggleSwitch';
import Modal from "@/components/ui/modal/Modal";
import { API_BASE_URL } from "@/config/api";


export default function CasinoConfiguration() {
	// Tab state
	const [activeTab, setActiveTab] = useState<'gamingday' | 'currency' | 'idproof' | 'games' | 'floors' | 'float'>('gamingday');

	// Gaming Day state
	const [status, setStatus] = useState<'STOPPED' | 'STARTED'>('STOPPED');
	const [startTime, setStartTime] = useState('04:00');
	const [originalStartTime, setOriginalStartTime] = useState('04:00');
	const [settingsId, setSettingsId] = useState<number | null>(null);
	const [popup, setPopup] = useState<{ visible: boolean; title: string; message: string }>({ visible: false, title: '', message: '' });
	const [showStopConfirm, setShowStopConfirm] = useState(false);
	const [gamingDay, setGamingDay] = useState<any>(null);


	// Currency state
	const [currency, setCurrency] = useState('USD');
	const [originalCurrency, setOriginalCurrency] = useState('USD');
	const currencyOptions = [
		{ value: 'USD', label: 'USD ($)' },
		{ value: 'EUR', label: 'EUR (€)' },
		{ value: 'GBP', label: 'GBP (£)' },
		{ value: 'INR', label: 'INR (₹)' },
		{ value: 'JPY', label: 'JPY (¥)' },
		{ value: 'CNY', label: 'CNY (¥)' },
		{ value: 'SGD', label: 'SGD (S$)' },
		{ value: 'AUD', label: 'AUD (A$)' },
		{ value: 'CAD', label: 'CAD (C$)' },
	];
	const LOGGED_IN_USER_ID = 2;

	// Games Catalog state
	const [games, setGames] = useState<any[]>([]);
	const [gamesLoading, setGamesLoading] = useState(false);
	const [gamesError, setGamesError] = useState('');
	const [gamesSearch, setGamesSearch] = useState('');
	const [gamesFilters, setGamesFilters] = useState<{ [key: string]: string }>({ type: '', status: '' });
	const [gamesSortBy, setGamesSortBy] = useState<string>('name');
	const [gamesSortOrder, setGamesSortOrder] = useState<'asc' | 'desc'>('asc');

	// Casino Floors state
	const [floors, setFloors] = useState<any[]>([]);
	const [floorsLoading, setFloorsLoading] = useState(false);
	const [floorsError, setFloorsError] = useState('');
	const [showAddFloorModal, setShowAddFloorModal] = useState(false);
	const [addFloorName, setAddFloorName] = useState('');
	const [addFloorLoading, setAddFloorLoading] = useState(false);
	const [isEditFloorMode, setIsEditFloorMode] = useState(false);
	const [editFloorId, setEditFloorId] = useState<number | null>(null);
	// Identification Proofs state
	const [idProofs, setIdProofs] = useState<any[]>([]);
	const [idProofLoading, setIdProofLoading] = useState(false);
	const [idProofError, setIdProofError] = useState('');
	const [showAddIdModal, setShowAddIdModal] = useState(false);
	const [newIdName, setNewIdName] = useState('');
	const [addIdLoading, setAddIdLoading] = useState(false);
	const [isEditIdMode, setIsEditIdMode] = useState(false);
	const [editIdId, setEditIdId] = useState<number | null>(null);

	// Float Management state
	const [floatType, setFloatType] = useState<'cage' | 'table'>('cage');
	const [floatList, setFloatList] = useState<any[]>([]);
	const [floatLoading, setFloatLoading] = useState(false);
	const [floatError, setFloatError] = useState('');
	
	// Default Float Modal state
	const [showDefaultFloatModal, setShowDefaultFloatModal] = useState(false);
	const [selectedFloatItem, setSelectedFloatItem] = useState<any>(null);
	const [defaultFloatData, setDefaultFloatData] = useState<any[]>([]);
	const [defaultFloatLoading, setDefaultFloatLoading] = useState(false);
	const [vaultChipsList, setVaultChipsList] = useState<any[]>([]);
	const [cashAmount, setCashAmount] = useState('');
	const [chipAmounts, setChipAmounts] = useState<{ [key: number]: string }>({});
	const [originalFloatData, setOriginalFloatData] = useState<any>(null);
	const [floatSaveLoading, setFloatSaveLoading] = useState(false);
	const [floatModalStep, setFloatModalStep] = useState<'cash' | 'chips' | 'summary'>('cash'); // For navigation
	const [defaultCurrency, setDefaultCurrency] = useState('INR');
	
	// Add/Edit Floor handler
	const handleAddFloor = async () => {
		if (!addFloorName.trim()) return;
		setAddFloorLoading(true);
		try {
			let resp;
			if (isEditFloorMode && editFloorId) {
				// Edit mode: update floor
				resp = await fetch(`${API_BASE_URL}/api/floor/${editFloorId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: addFloorName.trim() })
				});
			} else {
				// Add mode: create new floor
				resp = await fetch(`${API_BASE_URL}/api/floor`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: addFloorName.trim() })
				});
			}
			if (!resp.ok) {
				setPopup({ visible: true, title: 'Error', message: isEditFloorMode ? 'Failed to update floor.' : 'Failed to add floor.' });
				setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
				setAddFloorLoading(false);
				return;
			}
			setPopup({ visible: true, title: 'Success', message: isEditFloorMode ? 'Floor updated successfully.' : 'Floor added successfully.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
			setShowAddFloorModal(false);
			setAddFloorName('');
			setIsEditFloorMode(false);
			setEditFloorId(null);
			// Refresh floors list
			setFloorsLoading(true);
			fetch(`${API_BASE_URL}/api/floor`)
				.then(res => res.ok ? res.json() : [])
				.then(data => setFloors(Array.isArray(data) ? data : []))
				.catch(() => setFloors([]))
				.finally(() => setFloorsLoading(false));
		} catch {
			setPopup({ visible: true, title: 'Error', message: isEditFloorMode ? 'Failed to update floor.' : 'Failed to add floor.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
		} finally {
			setAddFloorLoading(false);
		}
	};

	// Add/Edit Game Modal state
	// Fetch Casino Floors when tab is active
	useEffect(() => {
		if (activeTab !== 'floors') return;
		setFloorsLoading(true);
		setFloorsError('');
		fetch(`${API_BASE_URL}/api/floor`)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch floors');
				return res.json();
			})
			.then(data => {
				setFloors(Array.isArray(data) ? data : []);
				setFloorsLoading(false);
			})
			.catch(() => {
				setFloors([]);
				setFloorsError('Failed to load casino floors.');
				setFloorsLoading(false);
			});
	}, [activeTab]);
	// Fetch identification proofs when tab is active
	useEffect(() => {
		if (activeTab !== 'idproof') return;
		setIdProofLoading(true);
		setIdProofError('');
		fetch(`${API_BASE_URL}/api/identification-proof`)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch identification proofs');
				return res.json();
			})
			.then(data => setIdProofs(Array.isArray(data) ? data : []))
			.catch(() => {
				setIdProofs([]);
				setIdProofError('Failed to load identification proofs.');
			})
			.finally(() => setIdProofLoading(false));
	}, [activeTab]);

	// Fetch float list (cages or tables) when float tab is active or floatType changes
	useEffect(() => {
		if (activeTab !== 'float') return;
		let mounted = true;
		setFloatLoading(true);
		setFloatError('');
		setFloatList([]);
		const url = floatType === 'cage' ? `${API_BASE_URL}/api/cage` : `${API_BASE_URL}/api/table`;
		fetch(url)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch');
				return res.json();
			})
			.then(data => {
				if (!mounted) return;
				// API might return array directly or an object with data/results
				if (Array.isArray(data)) setFloatList(data);
				else if (data && Array.isArray((data as any).data)) setFloatList((data as any).data);
				else if (data && Array.isArray((data as any).results)) setFloatList((data as any).results);
				else setFloatList([]);
			})
			.catch(() => {
				if (!mounted) return;
				setFloatError(`Failed to load ${floatType === 'cage' ? 'cages' : 'tables'}.`);
			})
			.finally(() => {
				if (!mounted) return;
				setFloatLoading(false);
			});
		return () => { mounted = false; };
	}, [activeTab, floatType]);


	// Toggle register/deregister state for a cage/table
	const [pendingDeregister, setPendingDeregister] = useState<null | { itemId: number | string; type: 'cage' | 'table'; index: number; name?: string }>(null);
	const [pendingRegister, setPendingRegister] = useState<null | { itemId: number | string; type: 'cage' | 'table'; index: number; name?: string; mac?: string }>(null);

	const performRegisterChange = async (itemId: number | string, type: 'cage' | 'table', index: number, resolvedNewVal: boolean, extraBody?: any) => {
		const current = (floatList[index] && typeof (floatList[index].registered) !== 'undefined') ? Boolean(floatList[index].registered) : false;
		// optimistic update
		setFloatList(prev => {
			const copy = Array.isArray(prev) ? [...prev] : [];
			if (copy[index]) copy[index] = { ...copy[index], registered: resolvedNewVal };
			return copy;
		});
		try {
			const resource = type === 'cage' ? 'cage' : 'table';
			const resp = await fetch(`${API_BASE_URL}/api/${resource}/${itemId}`, {
				method: 'PATCH',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ registered: resolvedNewVal, ...(extraBody || {}) })
			});
			if (!resp.ok) throw new Error('Failed to update');
		} catch (e) {
			// revert on error
			setFloatList(prev => {
				const copy = Array.isArray(prev) ? [...prev] : [];
				if (copy[index]) copy[index] = { ...copy[index], registered: current };
				return copy;
			});
			setPopup({ visible: true, title: 'Error', message: 'Failed to update registration status.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 4000);
		}
	};

	const handleToggleRegister = async (itemId: number | string, type: 'cage' | 'table', index: number, newVal?: boolean) => {
		const current = (floatList[index] && typeof (floatList[index].registered) !== 'undefined') ? Boolean(floatList[index].registered) : false;
		const resolvedNewVal = typeof newVal === 'boolean' ? newVal : !current;
		// If user is trying to deregister (true -> false), prompt confirmation
		if (current === true && resolvedNewVal === false) {
			const name = floatList[index]?.name ?? undefined;
			setPendingDeregister({ itemId, type, index, name });
			return;
		}
		// If user is trying to register (false -> true), prompt for MAC address
		if (current === false && resolvedNewVal === true) {
			const name = floatList[index]?.name ?? undefined;
			setPendingRegister({ itemId, type, index, name, mac: '' });
			return;
		}
		// Otherwise proceed immediately
		await performRegisterChange(itemId, type, index, resolvedNewVal);
	};


	// Disable body scroll when default float modal is open
	useEffect(() => {
		if (showDefaultFloatModal) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = 'unset';
		}
		return () => {
			document.body.style.overflow = 'unset';
		};
	}, [showDefaultFloatModal]);

	const [showAddGameModal, setShowAddGameModal] = useState(false);
	const [isEditMode, setIsEditMode] = useState(false);
	const [editGameId, setEditGameId] = useState<number | null>(null);
	// Add/Edit Game form state
	const [addGameForm, setAddGameForm] = useState({
		name: '',
		title: '',
		type: '',
		rtp: '',
		max_bet: '',
		lines: '',
		reels: '',
		denom: '',
		status: ''
	});


	// Disable background scroll when Add Game modal is open
	useEffect(() => {
		if (showAddGameModal) {
			document.body.style.overflow = 'hidden';
		} else {
			document.body.style.overflow = '';
		}
		return () => {
			document.body.style.overflow = '';
		};
	}, [showAddGameModal]);

	const GAME_COLUMNS = [
		{ key: 'name', label: 'Game Name' },
		{ key: 'type', label: 'Game Type' },
		{ key: 'rtp', label: 'RTP' },
		{ key: 'max_bet', label: 'Max Bet' },
		{ key: 'lines', label: 'Lines' },
		{ key: 'reels', label: 'Reels' },
		{ key: 'denom', label: 'Denom' },
		{ key: 'status', label: 'Status' },
		{ key: 'created_at', label: 'Created At' },
	];


	useEffect(() => {
		const fetchAll = async () => {
			try {
				// Fetch casino settings
				const settingsResp = await fetch(`${API_BASE_URL}/api/casinosettings`);
				if (settingsResp.ok) {
					const settingsData = await settingsResp.json();
					if (settingsData && settingsData.default_gaming_day_reset_time) {
						setStartTime(settingsData.default_gaming_day_reset_time);
						setOriginalStartTime(settingsData.default_gaming_day_reset_time);
					}
					if (settingsData && settingsData.default_currency) {
						setCurrency(settingsData.default_currency);
						setOriginalCurrency(settingsData.default_currency);
						setDefaultCurrency(settingsData.default_currency);
					}
					if (settingsData && settingsData.id) setSettingsId(settingsData.id);
				}
				// Fetch gaming day
				const resp = await fetch(`${API_BASE_URL}/api/gamingday/current`);
				if (!resp.ok) {
					setGamingDay(null);
					setStatus('STOPPED');
					return;
				}
				const data = await resp.json();
				if (data && data.error === 'No active gaming day') {
					setGamingDay(null);
					setStatus('STOPPED');
					setPopup({ visible: true, title: 'No Active Gaming Day', message: 'There is currently no active gaming day.' });
					setTimeout(() => {
						setPopup((prev) => ({ ...prev, visible: false }));
					}, 2500);
					return;
				}
				setGamingDay(data);
				if (data.status === 'OPEN') {
					setStatus('STARTED');
				} else {
					setStatus('STOPPED');
				}
			} catch { }
		};
		fetchAll();
	}, []);
	// Add/Edit Game submit handler
	const handleAddGameSubmit = async () => {
		const now = new Date().toISOString();
		const payload: any = {
			name: addGameForm.name,
			title: addGameForm.title,
			type: addGameForm.type,
			rtp: addGameForm.rtp ? `${addGameForm.rtp}%` : '',
			max_bet: addGameForm.max_bet ? `${addGameForm.max_bet}cr` : '',
			lines: addGameForm.lines ? Number(addGameForm.lines) : null,
			reels: addGameForm.reels ? Number(addGameForm.reels) : null,
			denom: addGameForm.denom ? `INR ${parseFloat(addGameForm.denom).toFixed(2)}` : '',
			status: addGameForm.status,
			updated_at: now
		};
		if (!isEditMode) {
			payload.created_at = now;
		}
		try {
			let resp;
			if (isEditMode && editGameId) {
				// Update existing game
				resp = await fetch(`${API_BASE_URL}/api/game-catalog/${editGameId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
			} else {
				// Add new game
				resp = await fetch(`${API_BASE_URL}/api/game-catalog`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(payload)
				});
			}
			if (!resp.ok) {
				setPopup({ visible: true, title: isEditMode ? 'Error' : 'Error', message: isEditMode ? 'Failed to update game.' : 'Failed to add game.' });
				setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
				return;
			}
			setPopup({ visible: true, title: isEditMode ? 'Success' : 'Success', message: isEditMode ? 'Game updated successfully.' : 'Game added successfully.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
			setShowAddGameModal(false);
			setAddGameForm({
				name: '', title: '', type: '', rtp: '', max_bet: '', lines: '', reels: '', denom: '', status: ''
			});
			setIsEditMode(false);
			setEditGameId(null);
			// Optionally refresh games list
			if (activeTab === 'games') {
				setGamesLoading(true);
				fetch(`${API_BASE_URL}/api/game-catalog`)
					.then(res => res.ok ? res.json() : [])
					.then(data => setGames(Array.isArray(data) ? data : []))
					.catch(() => setGames([]))
					.finally(() => setGamesLoading(false));
			}
		} catch {
			setPopup({ visible: true, title: isEditMode ? 'Error' : 'Error', message: isEditMode ? 'Failed to update game.' : 'Failed to add game.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 5000);
		}
	};

	// Fetch Games Catalog when tab is active
	useEffect(() => {
		if (activeTab !== 'games') return;
		setGamesLoading(true);
		setGamesError('');
		fetch(`${API_BASE_URL}/api/game-catalog`)
			.then(res => {
				if (!res.ok) throw new Error('Failed to fetch games');
				return res.json();
			})
			.then(data => {
				setGames(Array.isArray(data) ? data : []);
				setGamesLoading(false);
			})
			.catch(() => {
				setGames([]);
				setGamesError('Failed to load games catalog.');
				setGamesLoading(false);
			});
	}, [activeTab]);

	// Save handler for currency (must be outside useEffect)
	const handleSaveCurrency = async () => {
		if (!settingsId) return;
		try {
			const resp = await fetch(`${API_BASE_URL}/api/casinosettings?id=1`, {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ default_currency: currency }),
			});
			if (!resp.ok) {
				setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update currency.' });
				setTimeout(() => {
					setPopup((prev) => ({ ...prev, visible: false }));
				}, 2500);
				return;
			}
			setOriginalCurrency(currency);
			setPopup({ visible: true, title: 'Saved', message: 'Default currency updated.' });
			setTimeout(() => {
				setPopup((prev) => ({ ...prev, visible: false }));
			}, 2000);
		} catch {
			setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update currency.' });
			setTimeout(() => {
				setPopup((prev) => ({ ...prev, visible: false }));
			}, 2500);
		}
	};

	// Games Catalog: filter, sort, and search
	const filteredGames = games
		.filter(game => {
			// Search: start filtering after 1+ chars
			const search = gamesSearch.trim().toLowerCase();
			let matchesSearch = true;
			if (search.length >= 1) {
				matchesSearch = GAME_COLUMNS.some(col => {
					const value = game[col.key];
					return value && value.toString().toLowerCase().includes(search);
				});
			}
			// Filters
			let matchesFilters = true;
			if (gamesFilters.type && game.type !== gamesFilters.type) matchesFilters = false;
			if (gamesFilters.status && game.status !== gamesFilters.status) matchesFilters = false;
			return matchesSearch && matchesFilters;
		})
		.sort((a, b) => {
			const aValue = a[gamesSortBy];
			const bValue = b[gamesSortBy];
			if (aValue === undefined || bValue === undefined) return 0;
			if (typeof aValue === 'number' && typeof bValue === 'number') {
				return gamesSortOrder === 'asc' ? aValue - bValue : bValue - aValue;
			}
			// For date columns, sort by date
			if (gamesSortBy === 'created_at') {
				const aDate = new Date(aValue);
				const bDate = new Date(bValue);
				return gamesSortOrder === 'asc' ? aDate.getTime() - bDate.getTime() : bDate.getTime() - aDate.getTime();
			}
			// Default: string comparison
			return gamesSortOrder === 'asc'
				? aValue.toString().localeCompare(bValue.toString())
				: bValue.toString().localeCompare(aValue.toString());
		});

	// Sort handler
	const handleGamesSort = (key: string) => {
		if (gamesSortBy === key) {
			setGamesSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
		} else {
			setGamesSortBy(key);
			setGamesSortOrder('asc');
		}
	};

	// Open Default Float Modal and fetch data
	const handleOpenDefaultFloatModal = async (item: any) => {
		setSelectedFloatItem(item);
		setShowDefaultFloatModal(true);
		setDefaultFloatLoading(true);
		setCashAmount('');
		setChipAmounts({});
		setFloatModalStep(floatType === 'cage' ? 'cash' : 'chips'); // Start at cash for cage, chips for table
		
		try {
			// Fetch vault chips and sort by denomination descending
			const chipsResp = await fetch(`${API_BASE_URL}/api/vault-chip-denomination`);
			if (chipsResp.ok) {
				const chipsData = await chipsResp.json();
				const sortedChips = Array.isArray(chipsData) 
					? chipsData.sort((a: any, b: any) => (b.denomination || 0) - (a.denomination || 0))
					: [];
				setVaultChipsList(sortedChips);
			}
			
			// Fetch existing default float if SET
			if (item.defaultFloat) {
				const moduleType = floatType.toUpperCase();
				const referenceId = floatType === 'cage' ? item.cage_id : item.table_id;
				const floatResp = await fetch(`${API_BASE_URL}/api/default-float?module=${moduleType}&reference_id=${referenceId}`);
				
					if (floatResp.ok) {
						const raw = await floatResp.json();
						const records = Array.isArray(raw)
							? raw
							: raw && Array.isArray((raw as any).data)
							? (raw as any).data
							: raw && Array.isArray((raw as any).results)
							? (raw as any).results
							: [];
						setDefaultFloatData(records);
						
						// Populate form with existing data
						const cashRecord = records.find((f: any) => (f.type || f.item_type) === 'CASH');
						if (cashRecord) setCashAmount((cashRecord.amount ?? '').toString());
						
						const chipData: { [key: number]: string } = {};
						records.forEach((f: any) => {
							if ((f.type || f.item_type) === 'CHIP' && f.chip_denomination_id) {
								chipData[f.chip_denomination_id] = (f.quantity ?? '').toString();
							}
						});
						setChipAmounts(chipData);
						
						// Store original data for comparison
						setOriginalFloatData({ cash: (cashRecord?.amount ?? '').toString(), chips: { ...chipData } });
					}
			} else {
				setDefaultFloatData([]);
				setOriginalFloatData({ cash: '', chips: {} });
			}
		} catch (err) {
			console.error('Error fetching default float data:', err);
		} finally {
			setDefaultFloatLoading(false);
		}
	};

	// Calculate total chip amount
	const calculateChipTotal = () => {
		let total = 0;
		vaultChipsList.forEach((chip: any) => {
			const qty = parseFloat(chipAmounts[chip.id] || '0');
			const denom = parseFloat(chip.chip_denomination || '0');
			total += qty * denom;
		});
		return total.toFixed(2);
	};

	// Check if current step has valid data
	const isCurrentStepValid = () => {
		if (floatModalStep === 'cash') {
			return cashAmount.trim() !== '' && parseFloat(cashAmount) >= 0;
		}
		if (floatModalStep === 'chips') {
			// At least one chip must have quantity
			return Object.values(chipAmounts).some(val => val.trim() !== '' && parseFloat(val) > 0);
		}
		return true;
	};

	// Navigate between modal steps
	const handleModalNext = () => {
		if (floatModalStep === 'cash') setFloatModalStep('chips');
		else if (floatModalStep === 'chips') setFloatModalStep('summary');
	};

	const handleModalBack = () => {
		if (floatModalStep === 'chips' && floatType === 'cage') setFloatModalStep('cash');
		else if (floatModalStep === 'summary') setFloatModalStep('chips');
	};

	// Check if form has changes
	const hasFloatChanges = () => {
		if (!originalFloatData) return true; // New record
		if (cashAmount !== originalFloatData.cash) return true;
		
		// Check chip changes
		for (const chipId in chipAmounts) {
			if (chipAmounts[chipId as any] !== (originalFloatData.chips[chipId as any] || '')) return true;
		}
		for (const chipId in originalFloatData.chips) {
			if ((chipAmounts[chipId as any] || '') !== originalFloatData.chips[chipId as any]) return true;
		}
		
		return false;
	};

	// Save Default Float
	const handleSaveDefaultFloat = async () => {
		if (!selectedFloatItem) return;
		setFloatSaveLoading(true);
		
		try {
			const moduleType = floatType.toUpperCase();
			const referenceId = floatType === 'cage' ? selectedFloatItem.cage_id : selectedFloatItem.table_id;
			
			// Prepare payload
			const floatRecords: any[] = [];
			
			// Add cash record
			if (cashAmount && parseFloat(cashAmount) > 0) {
				// try to find existing cash record to retain its id (for updates)
				const existingCash = defaultFloatData?.find((r: any) => (r.type || r.item_type) === 'CASH');
				if (existingCash) {
					floatRecords.push({
						...existingCash,
						module: moduleType,
						reference_id: referenceId,
						item_type: 'CASH',
						amount: parseFloat(cashAmount),
						quantity: null,
						chip_denomination_id: null
					});
				} else {
					floatRecords.push({
						module: moduleType,
						reference_id: referenceId,
						item_type: 'CASH',
						amount: parseFloat(cashAmount),
						quantity: null,
						chip_denomination_id: null
					});
				}
			}
			
			// Add chip records
			// Helper to extract chip denomination id/string from a default-float record (flexible to shapes)
			const extractDenomId = (r: any) => {
				if (!r) return '';
				if (r.chip_denomination_id !== undefined && r.chip_denomination_id !== null) return r.chip_denomination_id.toString();
				if (r.chip_denomination && typeof r.chip_denomination === 'object' && r.chip_denomination.id !== undefined) return r.chip_denomination.id.toString();
				if (r.chip_denomination && (typeof r.chip_denomination === 'string' || typeof r.chip_denomination === 'number')) return r.chip_denomination.toString();
				if (r.denomination !== undefined && r.denomination !== null) return r.denomination.toString();
				return '';
			};

			for (const chipId in chipAmounts) {
				const qty = chipAmounts[chipId];
				if (qty === undefined || qty === null) continue;
				const parsedQty = parseInt(qty as any);
				if (!(parsedQty > 0)) {
					// If user cleared quantity to 0, we may need to delete the record depending on backend. For now, skip creating/updating zero quantities.
					continue;
				}

				// try to find existing chip record for this denomination so we preserve its id when updating
				const existingChip = defaultFloatData?.find((r: any) => {
					if (!r) return false;
					if ((r.type || r.item_type) !== 'CHIP') return false;
					const denomId = extractDenomId(r);
					if (!denomId) return false;
					// Match by denom id string
					if (denomId === chipId.toString()) return true;
					// Also try numeric comparison
					if (parseInt(denomId) === parseInt(chipId)) return true;
					// Lastly try matching against vaultChipsList by denomination value
					try {
						const vaultChip = vaultChipsList.find((v: any) => (v.id?.toString() === chipId.toString()) || (v.chip_denomination?.toString() === chipId.toString()) || (v.denomination?.toString() === chipId.toString()));
						if (vaultChip) {
							const recordDenom = extractDenomId(r);
							if (recordDenom && (recordDenom === (vaultChip.id?.toString() || '') || recordDenom === (vaultChip.chip_denomination?.toString() || '') || recordDenom === (vaultChip.denomination?.toString() || ''))) return true;
						}
					} catch (e) { /* ignore */ }
					return false;
				});

				if (existingChip) {
					floatRecords.push({
						...existingChip,
						module: moduleType,
						reference_id: referenceId,
						item_type: 'CHIP',
						amount: null,
						quantity: parsedQty,
						chip_denomination_id: parseInt(chipId)
					});
				} else {
					floatRecords.push({
						module: moduleType,
						reference_id: referenceId,
						item_type: 'CHIP',
						amount: null,
						quantity: parsedQty,
						chip_denomination_id: parseInt(chipId)
					});
				}
			}

			// Debug: show payload in console for easier troubleshooting (remove in production if not needed)
			try { console.debug('Default float payload:', floatRecords); } catch (e) { /**/ }
			
			// Determine if POST or PUT
			const isUpdate = selectedFloatItem.default_float === 'SET';
			const method = isUpdate ? 'PUT' : 'POST';
			const url = `${API_BASE_URL}/api/default-float`;
			
			const resp = await fetch(url, {
				method,
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ records: floatRecords })
			});
			
			if (!resp.ok) {
				setPopup({ visible: true, title: 'Error', message: 'Failed to save default float.' });
				setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
				return;
			}
			
			setPopup({ visible: true, title: 'Success', message: 'Default float saved successfully.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
			setShowDefaultFloatModal(false);
			setFloatModalStep(floatType === 'cage' ? 'cash' : 'chips'); // Reset step
			
			// Refresh float list
			const listUrl = floatType === 'cage' ? `${API_BASE_URL}/api/cage` : `${API_BASE_URL}/api/table`;
			fetch(listUrl)
				.then(res => res.ok ? res.json() : [])
				.then(data => {
					if (Array.isArray(data)) setFloatList(data);
					else if (data && Array.isArray((data as any).data)) setFloatList((data as any).data);
					else if (data && Array.isArray((data as any).results)) setFloatList((data as any).results);
				})
				.catch(() => {});
		} catch (err) {
			setPopup({ visible: true, title: 'Error', message: 'Failed to save default float.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
		} finally {
			setFloatSaveLoading(false);
		}
	};

	// Add new identification handler
	const handleAddId = async () => {
		if (!newIdName.trim()) return;
		setAddIdLoading(true);
		try {
			if (isEditIdMode && editIdId) {
				// Update existing identification
				const resp = await fetch(`${API_BASE_URL}/api/identification-proof/${editIdId}`, {
					method: 'PUT',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: newIdName.trim() })
				});
				if (!resp.ok) {
					setPopup({ visible: true, title: 'Error', message: 'Failed to update identification.' });
					setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
					return;
				}
				const updated = await resp.json();
				setIdProofs(prev => prev.map(i => (i.identification_id === updated.identification_id || i.id === updated.id ? updated : i)));
				setPopup({ visible: true, title: 'Saved', message: 'Identification updated.' });
			} else {
				// Create new identification
				const resp = await fetch(`${API_BASE_URL}/api/identification-proof`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({ name: newIdName.trim() })
				});
				if (!resp.ok) {
					setPopup({ visible: true, title: 'Error', message: 'Failed to add identification.' });
					setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
					return;
				}
				const created = await resp.json();
				setIdProofs(prev => [...prev, created]);
				setPopup({ visible: true, title: 'Saved', message: 'Identification added.' });
			}
			setShowAddIdModal(false);
			setNewIdName('');
			setIsEditIdMode(false);
			setEditIdId(null);
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
		} catch (err) {
			setPopup({ visible: true, title: 'Error', message: isEditIdMode ? 'Failed to update identification.' : 'Failed to add identification.' });
			setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
		} finally {
			setAddIdLoading(false);
		}
	};

	return (
		<div className="min-h-screen bg-transparent px-1">
			{/* Popup notification */}
			{popup.visible && (
				<div
					className="fixed right-6 z-50 bg-white rounded-xl shadow-lg border border-gray-100 px-8 py-5 min-w-[320px] max-w-xs transition-all duration-300"
					style={{ boxShadow: '0 4px 16px 0 rgba(0,0,0,0.08)', top: '5.5rem' }}
				>
					<div className="font-semibold text-base mb-1">{popup.title}</div>
					<div className="text-sm text-gray-700">{popup.message}</div>
				</div>
			)}

			{/* Tabs */}
			<div className="max-w-6xl mx-auto mt-4">
				<div className="flex gap-2 border-b border-gray-200 dark:border-gray-700 mb-4">
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'gamingday' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('gamingday')}
					>
						Gaming Day
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'currency' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('currency')}
					>
						Currency
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'idproof' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('idproof')}
					>
						ID Proofs
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'floors' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('floors')}
					>
						Casino Floors
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'float' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('float')}
					>
						Float Management
					</button>
					<button
						className={`px-6 py-3 text-base font-semibold rounded-t-lg focus:outline-none transition-colors ${activeTab === 'games' ? 'bg-white dark:bg-gray-900 border-x border-t border-b-0 border-gray-200 dark:border-gray-700 text-brand-600' : 'text-gray-500 dark:text-gray-400 hover:text-brand-600'}`}
						onClick={() => setActiveTab('games')}
					>
						Games Catalog
					</button>
				</div>
				{activeTab === 'floors' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[300px]">
						<div className="flex items-center justify-between mb-4">
							<h2 className="text-lg font-bold text-black dark:text-white">Casino Floors</h2>
							<button
								className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-green-800 hover:bg-green-700 text-white font-semibold text-base shadow-theme-xs transition"
								onClick={() => {
									setShowAddFloorModal(true);
									setIsEditFloorMode(false);
									setEditFloorId(null);
									setAddFloorName('');
								}}
								type="button"
							>
								<svg width="20" height="20" fill="none" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="2" rx="1" fill="currentColor" /><rect x="11" y="4" width="2" height="16" rx="1" fill="currentColor" /></svg>
								Add New Floor
							</button>
						</div>
						<div className="max-w-full overflow-x-auto">
							{/* Add/Edit Floor Modal */}
							{showAddFloorModal && (
								<Modal onClose={() => {
									setShowAddFloorModal(false);
									setAddFloorName('');
									setIsEditFloorMode(false);
									setEditFloorId(null);
								}} width="max-w-md" height="max-h-[60vh]">
									<div className="p-8 max-h-[60vh] overflow-y-auto">
										<div className="text-xl font-bold mb-4 text-gray-900">{isEditFloorMode ? 'Edit Floor' : 'Add New Floor'}</div>
										<div className="mb-4">
											<label className="block text-sm font-medium mb-1">Floor Name</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addFloorName}
												onChange={e => setAddFloorName(e.target.value)}
												placeholder="Enter floor name"
												disabled={addFloorLoading}
											/>
										</div>
										<div className="flex justify-end pt-2 gap-2">
											<button
												type="button"
												className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black hover:bg-red-600 hover:text-white border border-gray-300"
												onClick={() => {
													setShowAddFloorModal(false);
													setAddFloorName('');
													setIsEditFloorMode(false);
													setEditFloorId(null);
												}}
												disabled={addFloorLoading}
											>
												Cancel
											</button>
											<button
												type="button"
												className="px-5 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800"
												onClick={handleAddFloor}
												disabled={addFloorLoading || !addFloorName.trim()}
											>
												{addFloorLoading ? (isEditFloorMode ? 'Updating...' : 'Adding...') : (isEditFloorMode ? 'Update Floor' : 'Add Floor')}
											</button>
										</div>
									</div>
								</Modal>
							)}
							<table className="w-full text-left border-collapse">
								<thead className="border-b border-gray-100 dark:border-white/[0.05]">
									<tr>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Floor ID</th>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Name</th>
										<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Actions</th>
									</tr>
								</thead>
								<tbody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
									{floorsLoading ? (
										<tr><td colSpan={3} className="text-center py-6 text-gray-400">Loading...</td></tr>
									) : floorsError ? (
										<tr><td colSpan={3} className="text-center py-6 text-red-400">{floorsError}</td></tr>
									) : floors.length === 0 ? (
										<tr><td colSpan={3} className="text-center py-6 text-gray-400">No floors found.</td></tr>
									) : (
										floors.map(floor => (
											<tr key={floor.floor_id} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition">
												<td className="px-4 py-3 text-gray-800 text-theme-sm dark:text-gray-200 text-center">{floor.floor_id}</td>
												<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{floor.name}</td>
												<td className="px-4 py-3 text-center">
													<button
														className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700"
														onClick={() => {
															setIsEditFloorMode(true);
															setEditFloorId(floor.floor_id);
															setAddFloorName(floor.name || '');
															setShowAddFloorModal(true);
														}}
													>
														Edit
													</button>
												</td>
											</tr>
										))
									)}
								</tbody>
							</table>
						</div>
					</div>
				)}

				{/* Tab Content */}
				{activeTab === 'gamingday' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8">
						<h2 className="text-lg font-bold mb-2 text-black dark:text-white">Gaming Day Control</h2>
						<p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Start or stop the gaming day and configure its default start time.</p>
						{/* ...existing code for Gaming Day Control and Default Start Time... */}
						{/* Status and Controls */}
						<div className="mb-8">
							<div className="flex flex-col md:flex-row md:items-center md:justify-between bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4">
								<div>
									<div className="text-base font-semibold text-black dark:text-white mb-1">Gaming Day Status</div>
									<div className="text-md text-gray-500 dark:text-gray-400">
										The gaming day is currently <span className={status === 'STOPPED' ? 'text-red-500 font-bold' : 'text-green-500 font-bold'}>{status}</span>
									</div>
									{gamingDay && status === 'STARTED' && gamingDay.start_time && (
										<div className="mt-2 text-xs text-gray-700">
											Started at: {gamingDay.start_time.replace('T', ' ').replace(/\.\d+Z$/, '')}
										</div>
									)}
								</div>
								<div className="flex gap-4 mt-12 md:mt-0">
									{status === 'STOPPED' ? (
										<button
											className="flex items-center gap-2 px-8 py-4 rounded-lg text-lg font-semibold bg-green-700 hover:bg-green-800 text-white transition disabled:opacity-50 disabled:cursor-not-allowed"
											onClick={async () => {
												const now = new Date().toISOString();
												try {
													const resp = await fetch(`${API_BASE_URL}/api/gamingday`, {
														method: 'POST',
														headers: { 'Content-Type': 'application/json' },
														body: JSON.stringify({
															start_time: now,
															end_time: null,
															status: 'OPEN',
															closed_by: null,
															closed_at: null
														}),
													});
													if (!resp.ok) {
														setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to start the gaming day. Please try again.' });
														setTimeout(() => {
															setPopup((prev) => ({ ...prev, visible: false }));
														}, 2500);
														return;
													}
													const data = await resp.json();
													setGamingDay(data);
													setStatus('STARTED');
													setPopup({ visible: true, title: 'Gaming Day Started', message: 'The gaming day has officially begun.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
												} catch {
													setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to start the gaming day. Please try again.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
												}
											}}
										>
											<svg width="28" height="28" fill="none" viewBox="0 0 24 24"><path d="M5 3v18l15-9L5 3Z" fill="currentColor" /></svg>
											Start Day
										</button>
									) : (
										<button
											className="flex items-center gap-2 px-8 py-4 rounded-lg text-lg font-semibold bg-red-800 hover:bg-red-700 text-white transition disabled:opacity-50 disabled:cursor-not-allowed"
											onClick={() => setShowStopConfirm(true)}
										>
											<svg width="28" height="28" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="2" fill="none" /><rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor" /></svg>
											Stop Day
										</button>
									)}
								</div>
								{/* Stop Confirmation Modal */}
								{showStopConfirm && (
									<Modal onClose={() => setShowStopConfirm(false)} width="max-w-xl" height="max-h-xl">
										<div className="p-8 max-h-[70vh] overflow-y-auto">
											<div className="text-xl font-bold mb-2 text-gray-900">Are you sure you want to stop the gaming day?</div>
											<div className="text-gray-600 mb-6">This action will close all tables and finalize the day's transactions.<br />This cannot be undone.</div>
											<div className="flex justify-end gap-3 mt-4">
												<button
													className="px-5 py-2 rounded border border-gray-300 bg-white text-gray-800 font-semibold hover:bg-gray-100"
													onClick={() => setShowStopConfirm(false)}
												>
													Cancel
												</button>
												<button
													className="px-5 py-2 rounded bg-red-600 text-white font-semibold hover:bg-red-700"
													onClick={async () => {
														if (!gamingDay?.gaming_day_id) return;
														const now = new Date().toISOString();
														try {
															const resp = await fetch(`${API_BASE_URL}/api/gamingday/${gamingDay.gaming_day_id}`, {
																method: 'PUT',
																headers: { 'Content-Type': 'application/json' },
																body: JSON.stringify({
																	end_time: now,
																	status: 'CLOSED',
																	closed_at: now,
																	closed_by: LOGGED_IN_USER_ID
																}),
															});
															if (!resp.ok) {
																setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to stop the gaming day. Please try again.' });
																setShowStopConfirm(false);
																setTimeout(() => {
																	setPopup((prev) => ({ ...prev, visible: false }));
																}, 2500);
																return;
															}
															setStatus('STOPPED');
															setPopup({ visible: true, title: 'Gaming Day Stopped', message: 'The gaming day has officially ended.' });
															setShowStopConfirm(false);
															setTimeout(() => {
																setPopup((prev) => ({ ...prev, visible: false }));
															}, 2500);
														} catch {
															setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to stop the gaming day. Please try again.' });
															setShowStopConfirm(false);
															setTimeout(() => {
																setPopup((prev) => ({ ...prev, visible: false }));
															}, 2500);
														}
													}}
												>
													Stop Gaming Day
												</button>
											</div>
										</div>
									</Modal>
								)}
							</div>
						</div>
						{/* Default Start Time */}
						<div className="mb-2">
							<div className="text-base font-semibold text-black dark:text-white mb-2">Default Start Time (24 H)</div>
							<div className="flex items-center gap-2">
								<input
									type="time"
									value={startTime}
									onChange={e => setStartTime(e.target.value)}
									className="w-32 px-3 py-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-sm font-mono bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-green-400"
								/>
								{startTime !== originalStartTime && (
									<button
										className="ml-4 px-4 py-1.5 rounded bg-green-700 text-white font-semibold hover:bg-green-800 text-sm transition"
										onClick={async () => {
											if (!settingsId) return;
											try {
												const resp = await fetch(`${API_BASE_URL}/api/casinosettings?id=1`, {
													method: 'PUT',
													headers: { 'Content-Type': 'application/json' },
													body: JSON.stringify({ default_gaming_day_reset_time: startTime }),
												});
												if (!resp.ok) {
													setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update gaming day time.' });
													setTimeout(() => {
														setPopup((prev) => ({ ...prev, visible: false }));
													}, 2500);
													return;
												}
												setOriginalStartTime(startTime);
												setPopup({ visible: true, title: 'Saved', message: 'Gaming day reset time updated.' });
												setTimeout(() => {
													setPopup((prev) => ({ ...prev, visible: false }));
												}, 2000);
											} catch {
												setPopup({ visible: true, title: 'Something went wrong', message: 'Failed to update gaming day time.' });
												setTimeout(() => {
													setPopup((prev) => ({ ...prev, visible: false }));
												}, 2500);
											}
										}}
									>
										Save
									</button>
								)}
								<svg width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#888" strokeWidth="1.5" /><path d="M12 6v6l4 2" stroke="#888" strokeWidth="1.5" /></svg>
							</div>
							<div className="text-sm text-gray-500 dark:text-gray-400 mt-2">Set the time when a new gaming day automatically begins.</div>
						</div>
					</div>
				)}

				{activeTab === 'currency' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8">
						<div className="mb-6">
							<h2 className="text-lg font-bold mb-2 text-black dark:text-white">Currency Configuration</h2>
							<p className="text-sm text-gray-500 dark:text-gray-400">Set the global currency symbol for the casino.</p>
						</div>
						<div className="mb-4">
							<label className="block text-lg font-semibold text-black dark:text-white mb-2">Currency</label>
							<select
								className="w-64 px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-700 text-base bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-green-400"
								value={currency}
								onChange={e => setCurrency(e.target.value)}
							>
								{currencyOptions.map(opt => (
									<option key={opt.value} value={opt.value}>{opt.label}</option>
								))}
							</select>
							{currency !== originalCurrency && (
								<button
									className="ml-4 px-4 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800 text-base transition"
									onClick={handleSaveCurrency}
								>
									Save
								</button>
							)}
						</div>
						<div className="text-base text-gray-500 dark:text-gray-400 mt-2">This symbol will be used to display all monetary values.</div>
					</div>
				)}

				{activeTab === 'idproof' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[200px]">
						<div className="flex items-center justify-between mb-4">
							<div>
								<h2 className="text-lg font-bold text-black dark:text-white">Identification Proofs</h2>
								<p className="text-sm text-gray-500 dark:text-gray-400">Manage identification proof types used for player registration.</p>
							</div>
							<div>
								<button
									className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-green-800 hover:bg-green-700 text-white font-semibold text-base shadow-theme-xs transition"
									onClick={() => setShowAddIdModal(true)}
									type="button"
								>
									<svg width="20" height="20" fill="none" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="2" rx="1" fill="currentColor" /><rect x="11" y="4" width="2" height="16" rx="1" fill="currentColor" /></svg>
									Add New Identification
								</button>
							</div>
						</div>
						<div className="max-w-full overflow-x-auto">
							{ idProofLoading ? (
								<div className="text-gray-500">Loading...</div>
							) : idProofError ? (
								<div className="text-red-500">{idProofError}</div>
							) : idProofs.length === 0 ? (
								<div className="py-12 text-center text-gray-500">
									<div className="text-xl font-semibold mb-2">No records to display</div>
									<div className="text-sm">There are no identification proofs configured yet. Use the button above to add a new one.</div>
								</div>
							) : (
								<table className="w-full text-left border-collapse">
									<thead className="border-b border-gray-100">
										<tr>
											<th className="px-4 py-3 text-sm text-gray-600">ID</th>
											<th className="px-4 py-3 text-sm text-gray-600">Name</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Actions</th>

										</tr>
									</thead>
									<tbody className="divide-y divide-gray-100">
										{ idProofs.map(p => (
											<tr key={p.identification_id ?? p.id} className="hover:bg-gray-50">
												<td className="px-4 py-3 text-sm text-gray-800">{p.identification_id ?? p.id}</td>
												<td className="px-4 py-3 text-sm text-gray-800">{p.name}</td>
												<td className="px-4 py-3 text-center">
													<button
														className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700"
														onClick={() => {
															setIsEditIdMode(true);
															setEditIdId(p.identification_id ?? p.id);
															setNewIdName(p.name || '');
															setShowAddIdModal(true);
														}}
													>
														Edit
													</button>
												</td>
											</tr>
										)) }
									</tbody>
								</table>
							)}
						</div>

						{/* Add Identification Modal */}
						{showAddIdModal && (
							<Modal onClose={() => { setShowAddIdModal(false); setNewIdName(''); }} width="max-w-md" height="max-h-[60vh]">
								<div className="p-8 max-h-[60vh] overflow-y-auto">
									<div className="text-xl font-bold mb-4 text-gray-900">{isEditIdMode ? 'Edit Identification' : 'Add New Identification'}</div>
									<div className="mb-4">
										<label className="block text-sm font-medium mb-1">Identification Name</label>
										<input type="text" className="w-full px-3 py-2 border rounded-lg text-sm" value={newIdName} onChange={e => setNewIdName(e.target.value)} placeholder="Enter identification name" disabled={addIdLoading} />
									</div>
									<div className="flex justify-end pt-2 gap-2">
										<button type="button" className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black border border-gray-300" onClick={() => { setShowAddIdModal(false); setNewIdName(''); setIsEditIdMode(false); setEditIdId(null); }} disabled={addIdLoading}>Cancel</button>
										<button type="button" className="px-5 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800" onClick={handleAddId} disabled={addIdLoading || !newIdName.trim()}>{addIdLoading ? (isEditIdMode ? 'Updating...' : 'Adding...') : (isEditIdMode ? 'Update Identification' : 'Add Identification')}</button>
									</div>
									</div>
							</Modal>
						)}
					</div>
				)}

				{activeTab === 'games' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[300px]">
						<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2 gap-4">
							<h2 className="text-lg font-bold text-black dark:text-white mb-0">Games Catalog Management</h2>
							<button
								className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-green-800 hover:bg-green-700 text-white font-semibold text-base shadow-theme-xs transition"
								onClick={() => setShowAddGameModal(true)}
								type="button"
							>
								<svg width="20" height="20" fill="none" viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="2" rx="1" fill="currentColor" /><rect x="11" y="4" width="2" height="16" rx="1" fill="currentColor" /></svg>
								Add Game
							</button>
						</div>
						<p className="text-sm text-gray-500 dark:text-gray-400 mb-4">View, add, edit, or remove games available in the casino.</p>
						{/* Filters and Search */}
						<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
							<div className="flex gap-3 items-center">
								<span className="text-gray-500 dark:text-gray-400">Type:</span>
								<select
									className="py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
									value={gamesFilters.type}
									onChange={e => setGamesFilters(f => ({ ...f, type: e.target.value }))}
								>
									<option value="">All</option>
									{[...new Set(games.map(g => g.type))].filter(Boolean).map(type => (
										<option key={type} value={type}>{type}</option>
									))}
								</select>
								<span className="text-gray-500 dark:text-gray-400 ml-4">Status:</span>
								<select
									className="py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
									value={gamesFilters.status}
									onChange={e => setGamesFilters(f => ({ ...f, status: e.target.value }))}
								>
									<option value="">All</option>
									{[...new Set(games.map(g => g.status))].filter(Boolean).map(status => (
										<option key={status} value={status}>{status}</option>
									))}
								</select>
							</div>
							<div className="relative w-full sm:w-auto">
								<input
									placeholder="Search..."
									className="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
									type="text"
									value={gamesSearch}
									onChange={e => setGamesSearch(e.target.value)}
								/>
							</div>
						</div>
						{/* Table */}
						<div className="max-w-full overflow-x-auto">
							<div className="min-w-[1102px]">
								<table className="w-full text-left border-collapse">
									<thead className="border-b border-gray-100 dark:border-white/[0.05]">
										<tr>
											{GAME_COLUMNS.map(col => (
												<th
													key={col.key}
													className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400 cursor-pointer select-none"
													onClick={() => handleGamesSort(col.key)}
												>
													<div className="flex items-center justify-center gap-1">
														<span>{col.label}</span>
														<span className="flex flex-col gap-0.5">
															<svg
																xmlns="http://www.w3.org/2000/svg"
																width="8"
																height="5"
																fill="none"
																className={`text-gray-300 dark:text-gray-700 ${gamesSortBy === col.key && gamesSortOrder === 'asc' ? 'text-brand-500' : ''}`}
															>
																<path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
															</svg>
															<svg
																xmlns="http://www.w3.org/2000/svg"
																width="8"
																height="5"
																fill="none"
																className={`text-gray-300 dark:text-gray-700 ${gamesSortBy === col.key && gamesSortOrder === 'desc' ? 'text-brand-500' : ''}`}
															>
																<path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
															</svg>
														</span>
													</div>
												</th>
											))}
										</tr>
									</thead>
									<tbody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
										{gamesLoading ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-gray-400">Loading...</td></tr>
										) : gamesError ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-red-400">{gamesError}</td></tr>
										) : filteredGames.length === 0 ? (
											<tr><td colSpan={GAME_COLUMNS.length} className="text-center py-6 text-gray-400">No games found.</td></tr>
										) : (
											filteredGames.map(game => (
												<tr key={game.game_id} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition">
													<td className="px-4 py-3 text-gray-800 text-theme-sm dark:text-gray-200 text-center">{game.name}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.type}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.rtp}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.max_bet}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.lines}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.reels}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.denom}</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														<span className={`px-3 py-1 rounded-full text-xs font-semibold ${game.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{game.status}</span>
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">{game.created_at ? new Date(game.created_at).toLocaleDateString() : ''}</td>
													<td className="px-4 py-3 text-center">
														<button
															className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700"
															onClick={() => {
																setIsEditMode(true);
																setEditGameId(game.game_id);
																setAddGameForm({
																	name: game.name || '',
																	title: game.title || '',
																	type: game.type || '',
																	rtp: typeof game.rtp === 'string' ? game.rtp.replace('%', '') : (game.rtp || ''),
																	max_bet: typeof game.max_bet === 'string' ? game.max_bet.replace('cr', '') : (game.max_bet || ''),
																	lines: game.lines?.toString() || '',
																	reels: game.reels?.toString() || '',
																	denom: typeof game.denom === 'string' ? game.denom.replace('INR', '').trim() : (game.denom || ''),
																	status: game.status || ''
																});
																setShowAddGameModal(true);
															}}
														>
															Edit
														</button>
													</td>
												</tr>
											))
										)}
									</tbody>
								</table>
							</div>
						</div>

						{/* Add/Edit Game Modal */}
						{showAddGameModal && (
							<Modal onClose={() => {
								setShowAddGameModal(false);
								setIsEditMode(false);
								setEditGameId(null);
								setAddGameForm({ name: '', title: '', type: '', rtp: '', max_bet: '', lines: '', reels: '', denom: '', status: '' });
							}} width="max-w-lg" height="max-h-[120vh]">
								<div className="p-8 max-h-[70vh] overflow-y-auto">
									<div className="text-xl font-bold mb-4 text-gray-900">{isEditMode ? 'Edit Game' : 'Add New Game'}</div>
									<form className="space-y-4">
										<div>
											<label className="block text-sm font-medium mb-1">Name</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.name}
												onChange={e => setAddGameForm(f => ({ ...f, name: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Title</label>
											<input
												type="text"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.title}
												onChange={e => setAddGameForm(f => ({ ...f, title: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Type</label>
											<select
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.type}
												onChange={e => setAddGameForm(f => ({ ...f, type: e.target.value }))}
											>
												<option value="">Select type</option>
												<option value="video reel">Video Reel</option>
												<option value="Stepper">Stepper</option>
											</select>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">RTP</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.rtp}
												onChange={e => setAddGameForm(f => ({ ...f, rtp: e.target.value }))}
												placeholder="Enter RTP (number)"
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Max Bet</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.max_bet}
												onChange={e => setAddGameForm(f => ({ ...f, max_bet: e.target.value }))}
												placeholder="Enter Max Bet (number)"
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Lines</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.lines}
												onChange={e => setAddGameForm(f => ({ ...f, lines: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Reels</label>
											<input
												type="number"
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.reels}
												onChange={e => setAddGameForm(f => ({ ...f, reels: e.target.value }))}
											/>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Denom</label>
											<div className="flex items-center">
												<span className="mr-2">INR</span>
												<input
													type="number"
													className="w-full px-3 py-2 border rounded-lg text-sm"
													value={addGameForm.denom}
													onChange={e => setAddGameForm(f => ({ ...f, denom: e.target.value }))}
												/>
											</div>
										</div>
										<div>
											<label className="block text-sm font-medium mb-1">Status</label>
											<select
												className="w-full px-3 py-2 border rounded-lg text-sm"
												value={addGameForm.status}
												onChange={e => setAddGameForm(f => ({ ...f, status: e.target.value }))}
											>
												<option value="">Select status</option>
												<option value="Active">Active</option>
												<option value="Inactive">Inactive</option>
											</select>
										</div>
										<div className="flex justify-end pt-2 gap-2">
											<button
												type="button"
												className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black hover:bg-red-600 hover:text-white border border-gray-300"
												onClick={() => setShowAddGameModal(false)}
											>
												Cancel
											</button>
											<button
												type="button"
												className="px-5 py-2 rounded bg-green-700 text-white font-semibold hover:bg-green-800"
												onClick={handleAddGameSubmit}
											>
												{isEditMode ? 'Update Game' : 'Add Game'}
											</button>
										</div>
									</form>
								</div>
							</Modal>
						)}
					</div>
				)}

				{activeTab === 'float' && (
					<div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-8 min-h-[200px]">
						<div className="flex items-center justify-between mb-4">
							<div>
								<h2 className="text-lg font-bold text-black dark:text-white">Float Management</h2>
								<p className="text-sm text-gray-500 dark:text-gray-400">Manage Cage and Table default floats</p>
							</div>
							<div className="flex items-center gap-3">
								<label className="text-sm text-gray-600 dark:text-gray-300 font-medium">Show:</label>
								<select 
									value={floatType} 
									onChange={e => setFloatType(e.target.value as 'cage' | 'table')}
									className="px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-sm bg-white dark:bg-gray-900 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-green-400"
								>
									<option value="cage">Cage</option>
									<option value="table">Table</option>
								</select>
							</div>
						</div>
						<div className="max-w-full overflow-x-auto">
							{floatLoading ? (
								<div className="text-center py-6 text-gray-500">Loading...</div>
							) : floatError ? (
								<div className="text-center py-6 text-red-500">{floatError}</div>
							) : floatList.length === 0 ? (
								<div className="py-12 text-center text-gray-500">
									<div className="text-xl font-semibold mb-2">No records to display</div>
									<div className="text-sm">No {floatType === 'cage' ? 'cages' : 'tables'} found.</div>
								</div>
							) : (
								<table className="w-full text-left border-collapse">
									<thead className="border-b border-gray-100 dark:border-white/[0.05]">
										<tr>
											{/* <th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">
												{floatType === 'cage' ? 'Cage ID' : 'Table ID'}
											</th> */}
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">{floatType === 'cage' ? 'Cage Name' : 'Table Name'}</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Status</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Floor ID</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Register/Deregister</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Default Float</th>
											<th className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400">Actions</th>
										</tr>
									</thead>
									<tbody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
										{floatList.map((item, index) => {
											const itemId = floatType === 'cage' ? item.cage_id : item.table_id;
											return (
												<tr key={`${floatType}-${itemId ?? item.id ?? index}`} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition">
													{/* <td className="px-4 py-3 text-gray-800 text-theme-sm dark:text-gray-200 text-center">
														{itemId ?? item.id}
													</td> */}
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														{item.name}
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														<span className={`px-3 py-1 rounded-full text-xs font-semibold ${
															item.status === 'Active' || item.status === 'OPEN' 
																? 'bg-green-100 text-green-700' 
																: 'bg-gray-100 text-gray-700'
														}`}>
															{item.status}
														</span>
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														{item.floor_id}
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														<div className="flex items-center justify-center space-x-3">
															<div className="relative inline-block group">
																<ToggleSwitch
																	id={`register-${itemId ?? (item.id ?? index)}`}
																	checked={Boolean(item.registered)}
																	onChange={(checked) => handleToggleRegister(itemId ?? (item.id ?? index), floatType, index, checked)}
																/>
																{/* CSS-only tooltip attached to the switch */}
																<div className="pointer-events-none absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-150 whitespace-nowrap z-50">
																	{item.registered ? 'Registered' : 'Not Registered'}
																	<div className="absolute left-1/2 transform -translate-x-1/2 top-full w-2 h-2 bg-gray-800 rotate-45"></div>
																</div>
															</div>
														</div>
													</td>
													<td className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
														<span className={`px-3 py-1 rounded-full text-xs font-semibold ${
															(item.defaultFloat)
																? 'bg-green-100 text-green-700' 
																: 'bg-red-100 text-red-700'
														}`}>
															{(item.defaultFloat)?'SET':'NOT SET'}
														</span>
													</td>
													<td className="px-4 py-3 text-center">
														<button
															className={`px-3 py-1 rounded text-white text-xs font-semibold ${
															item.defaultFloat  
																? 'bg-yellow-700 text-white-700' 
																: 'bg-green-700 text-white-700'
														}`}
															onClick={() => handleOpenDefaultFloatModal(item)}
														>
															{item.defaultFloat ? 'Edit Default Float' : 'Set Default Float'}
														</button>
													</td>
												</tr>
											);
										})}
									</tbody>
								</table>
							)}
						</div>
					</div>
				)}
			</div>

			{/* Default Float Management Modal */}
			{/* Deregister confirmation modal */}
			{pendingDeregister && (
				<Modal onClose={() => setPendingDeregister(null)} width="max-w-md">
					<div className="p-6">
						<h2 className="text-lg font-bold mb-3">Confirm De-register</h2>
						<p className="text-sm text-gray-700">Are you sure you want to De-register Cage - {pendingDeregister.name ?? pendingDeregister.itemId}?</p>
						<div className="flex justify-end gap-3 mt-6">
							<button
								className="px-4 py-2 bg-red-600 text-white rounded"
								onClick={() => setPendingDeregister(null)}
							>
								Cancel
							</button>
							<button
								className="px-4 py-2 bg-green-600 text-white rounded"
								onClick={async () => {
									if (!pendingDeregister) return;
									await performRegisterChange(pendingDeregister.itemId, pendingDeregister.type, pendingDeregister.index, false);
									setPendingDeregister(null);
								}}
							>
								Confirm
							</button>
						</div>
					</div>
				</Modal>
			)}
			{pendingRegister && (
				<Modal onClose={() => setPendingRegister(null)} width="max-w-md">
					<div className="p-6">
						<h2 className="text-lg font-bold mb-3">Register Cage</h2>
						<p className="text-sm text-gray-700 mb-4">To register Cage enter the new MAC Address of the Cage machine</p>
						<label className="block text-sm font-medium text-gray-700 mb-2">MAC Address</label>
						<input
							type="text"
							value={pendingRegister.mac ?? ''}
							onChange={(e) => setPendingRegister(prev => prev ? ({ ...prev, mac: e.target.value }) : prev)}
							className="w-full border rounded px-3 py-2 text-sm mb-4"
							placeholder="e.g. 00:1A:2B:3C:4D:5E"
						/>
						<div className="flex justify-end gap-3 mt-2">
							<button
								className="px-4 py-2 bg-red-600 text-white rounded"
								onClick={() => setPendingRegister(null)}
							>
								Cancel
							</button>
							<button
								className="px-4 py-2 bg-green-600 text-white rounded"
								onClick={async () => {
									if (!pendingRegister) return;
									// basic validation
									if (!pendingRegister.mac || String(pendingRegister.mac).trim() === '') {
										setPopup({ visible: true, title: 'Validation', message: 'Please enter a MAC Address' });
										setTimeout(() => setPopup(prev => ({ ...prev, visible: false })), 3000);
										return;
									}
									await performRegisterChange(pendingRegister.itemId, pendingRegister.type, pendingRegister.index, true, { macaddress: pendingRegister.mac });
									setPendingRegister(null);
								}}
							>
								Update
							</button>
						</div>
					</div>
				</Modal>
			)}
			{showDefaultFloatModal && (
				<Modal height="max-h-3xl" onClose={() => {
					setShowDefaultFloatModal(false);
					setFloatModalStep(floatType === 'cage' ? 'cash' : 'chips');
				}} >
					<div className="relative max-h-[80vh] w-full flex flex-col">
						{/* Header */}
						<div className="border-gray-200 px-6 py-4">
							<h2 className="text-2xl font-bold text-gray-900 dark:text-white">
								Default Float Configuration for {floatType.toUpperCase()} - {floatType === 'cage' ? selectedFloatItem?.cage_id : selectedFloatItem?.table_id}
							</h2>
							{/* Prefilled indicator when existing default float was loaded */}
							{originalFloatData && ( (originalFloatData.cash && originalFloatData.cash !== '') || (originalFloatData.chips && Object.keys(originalFloatData.chips).some(k => (originalFloatData.chips as any)[k] !== '' && (originalFloatData.chips as any)[k] !== undefined)) ) && (
								<div className="mt-3 inline-flex items-center gap-2 px-3 py-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded text-yellow-800 dark:text-yellow-300 text-sm">
									<span className="font-semibold">Prefilled from default float</span>
								</div>
							)}
						</div>

						{defaultFloatLoading ? (
							<div className="text-center py-12 px-6">
								<div className="inline-block animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
								<p className="mt-3 text-gray-600 dark:text-gray-400">Loading...</p>
							</div>
						) : (
							<>
								{/* Tab Navigation - Only show for CAGE */}
								{floatType === 'cage' && floatModalStep !== 'summary' && (
									<div className="flex border-b border-gray-200 dark:border-gray-700 px-6">
										<button
											className={`px-6 py-3 text-base font-semibold transition-colors ${
												floatModalStep === 'cash'
													? 'text-blue-600 border-b-2 border-blue-600'
													: 'text-gray-500 dark:text-gray-400'
											}`}
											onClick={() => setFloatModalStep('cash')}
										>
											CASH
										</button>
										<button
											className={`px-6 py-3 text-base font-semibold transition-colors ${
												floatModalStep === 'chips'
													? 'text-blue-600 border-b-2 border-blue-600'
													: 'text-gray-500 dark:text-gray-400'
											}`}
											onClick={() => setFloatModalStep('chips')}
										>
											CHIPS
										</button>
									</div>
								)}

								{/* Content Area */}
								<div className="px-6 py-6 overflow-y-auto flex-1">
									{/* CASH Step */}
									{floatModalStep === 'cash' && (
										<div className="space-y-4">
											<div>
												<label className="block text-base font-semibold text-gray-900 dark:text-white mb-3">
													Enter Initial Cash Balance ({defaultCurrency})
												</label>
												<div className="flex items-center gap-3">
													<input
														type="number"
														value={cashAmount}
														onChange={(e) => setCashAmount(e.target.value)}
														className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-base"
														placeholder="Enter cash amount"
														min="0"
														step="0.01"
													/>
													{originalFloatData && originalFloatData.cash !== '' && cashAmount === originalFloatData.cash && (
														<span className="text-xs px-2 py-1 bg-yellow-100 text-yellow-800 rounded">Prefilled</span>
													)}
												</div>
											</div>
										</div>
									)}

									{/* CHIPS Step */}
									{floatModalStep === 'chips' && (
										<div>
											<div className="bg-gray-600 dark:bg-gray-700 rounded-t-lg">
												<div className="grid grid-cols-3 gap-4 px-4 py-3 text-white font-bold text-sm uppercase">
													<div className="text-center">DENOMINATION</div>
													<div className="text-center">QUANTITY</div>
													<div className="text-center">AMOUNT</div>
												</div>
											</div>
											<div className="border border-gray-200 dark:border-gray-700 rounded-b-lg divide-y divide-gray-200 dark:divide-gray-700 max-h-[40vh] overflow-y-auto">
												{vaultChipsList.map((chip: any) => {
													const qty = parseFloat(chipAmounts[chip.id] || '0');
													const amount = qty * parseFloat(chip.chip_denomination || '0');
													return (
														<div key={chip.id} className="grid grid-cols-3 gap-4 px-4 py-4 items-center">
															<div className="text-center text-gray-900 dark:text-white font-medium">
																<img src={`${API_BASE_URL}${chip.chip_image}`} alt={`Chip ${chip.chip_denomination}`} className="inline-block w-10 h-10 object-contain mx-auto"/>&emsp; {defaultCurrency} {chip.chip_denomination}
															</div>
															<div className="text-center">
																<div className="flex items-center justify-center gap-2">
																	<input
																		type="number"
																		value={chipAmounts[chip.id] || ''}
																		onChange={(e) => setChipAmounts({
																			...chipAmounts,
																			[chip.id]: e.target.value
																		})}
																		className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-white text-center"
																		placeholder=""
																		min="0"
																		step="1"
																	/>
																	{originalFloatData && originalFloatData.chips && (originalFloatData.chips as any)[chip.id] !== undefined && String((originalFloatData.chips as any)[chip.id]) === String(chipAmounts[chip.id] || '') && (
																		<span className="text-xs px-2 py-1 bg-yellow-100 text-yellow-800 rounded">Prefilled</span>
																	)}
																</div>
															</div>
															<div className="text-center text-gray-900 dark:text-white font-medium">
																{defaultCurrency} {amount.toFixed(2)}
															</div>
														</div>
													);
												})}
											</div>
											<div className="flex justify-end mt-4 pr-4">
												<span className="text-xl font-bold text-gray-900 dark:text-white">
													TOTAL: {defaultCurrency} {calculateChipTotal()}
												</span>
											</div>
										</div>
									)}

									{/* SUMMARY Step */}
									{floatModalStep === 'summary' && (
										<div className="space-y-6">
											<h3 className="text-lg font-bold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2">
												Summary
											</h3>
											
											{/* Cash Summary */}
											{floatType === 'cage' && (
												<div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
													<h4 className="font-semibold text-gray-900 dark:text-white mb-2">Cash</h4>
													<p className="text-gray-700 dark:text-gray-300">
														Amount: <span className="font-bold">{defaultCurrency} {parseFloat(cashAmount || '0').toFixed(2)}</span>
													</p>
												</div>
											)}

											{/* Chips Summary */}
											<div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
												<h4 className="font-semibold text-gray-900 dark:text-white mb-3">Chips</h4>
												<div className="space-y-2">
													{vaultChipsList
														.filter((chip: any) => chipAmounts[chip.id] && parseFloat(chipAmounts[chip.id]) > 0)
														.map((chip: any) => {
															const qty = parseFloat(chipAmounts[chip.id] || '0');
															const amount = qty * parseFloat(chip.chip_denomination || '0');
															return (
																<div key={chip.id} className="flex justify-between text-gray-700 dark:text-gray-300">
																	<span>{chip.chip_denomination} × {qty}</span>
																	<span className="font-semibold">{defaultCurrency} {amount.toFixed(2)}</span>
																</div>
															);
														})}
												</div>
												<div className="border-t border-gray-300 dark:border-gray-600 mt-3 pt-2 flex justify-between font-bold text-gray-900 dark:text-white">
													<span>Total:</span>
													<span>{defaultCurrency} {calculateChipTotal()}</span>
												</div>
											</div>

											{/* Grand Total */}
											{floatType === 'cage' && (
												<div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-4">
													<div className="flex justify-between items-center">
														<span className="text-lg font-semibold text-gray-900 dark:text-white">Grand Total:</span>
														<span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
															{defaultCurrency} {(parseFloat(cashAmount || '0') + parseFloat(calculateChipTotal())).toFixed(2)}
														</span>
													</div>
												</div>
											)}
										</div>
									)}
								</div>

								{/* Action Buttons */}
								<div className="border-t border-gray-200 dark:border-gray-700 px-6 py-4 flex justify-between sticky bottom-0 bg-white dark:bg-gray-900 z-30">
									<div>
										{floatModalStep !== 'cash' && floatModalStep !== (floatType === 'table' ? 'chips' : 'cash') && (
											<button
												onClick={handleModalBack}
												className="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition"
											>
												BACK
											</button>
										)}
									</div>
									<div className="flex gap-3">
										<button
											onClick={() => {
												setShowDefaultFloatModal(false);
												setFloatModalStep(floatType === 'cage' ? 'cash' : 'chips');
											}}
											className="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-gray-700 transition"
										>
											CANCEL
										</button>
										{floatModalStep === 'summary' ? (
											<button
												onClick={handleSaveDefaultFloat}
												disabled={floatSaveLoading}
												className={`px-6 py-2 rounded-lg text-white font-semibold transition ${
													floatSaveLoading
														? 'bg-gray-400 cursor-not-allowed'
														: 'bg-blue-600 hover:bg-blue-700'
												}`}
											>
												{floatSaveLoading ? 'SAVING...' : 'SAVE'}
											</button>
										) : (
											<button
												onClick={handleModalNext}
												disabled={!isCurrentStepValid()}
												className={`px-6 py-2 rounded-lg text-white font-semibold transition ${
													!isCurrentStepValid()
														? 'bg-gray-400 cursor-not-allowed'
														: 'bg-blue-600 hover:bg-blue-700'
												}`}
											>
												NEXT
											</button>
										)}
									</div>
								</div>
							</>
						)}
					</div>
				</Modal>
			)}
		</div>
	);
}
