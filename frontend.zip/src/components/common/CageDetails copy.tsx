"use client"
import React, { use } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import Button from "@/components/ui/button/Button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { History, Play, Square } from 'lucide-react';

interface CageCardProps {
  cageId: string;
}

const CageCard: React.FC<CageCardProps> = ({ cageId }) => {
  
  const inventoryData = [
    { type: 'Georgian Lari', qty: '', denom: '', amount: '5,000 GEL', baseCurrency: '3,300.00 €' },
    { type: 'CHIP', qty: 'Multiple', denom: 'Multiple', amount: '9,750 CHIP', baseCurrency: '9,750.00 €' },
    { type: 'USD', qty: '', denom: '', amount: '5,000 $', baseCurrency: '4,600.00 €' },
    { type: 'British pound', qty: '', denom: '', amount: '5,000 GBP', baseCurrency: '6,250.00 €' },
    { type: 'Traveler Check', qty: '', denom: '', amount: '5,000 TR CHK', baseCurrency: '5,000.00 €' },
    { type: 'EUR', qty: 'Multiple', denom: 'Multiple', amount: '30,000 €', baseCurrency: '30,000.00 €' },
    { type: 'Chip USD', qty: 'Multiple', denom: 'Multiple', amount: '1,500 CHUS', baseCurrency: '1,380.00 €' },
  ];

  const total = '66,280.00 €';

  return (
    <div className="w-full max-w-7xl mx-auto p-4 space-y-4">
      {/* Header Section */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <span className="text-xl font-bold text-gray-800">CAGE {cageId}</span>
            {/* <span className="text-sm text-gray-500 font-medium">(CG4)</span> */}
            <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">OPEN</span>
          </div>
          <div className="flex space-x-2">
            <Button size="sm" className="bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 text-xs font-bold">
              <History className="w-4 h-4 mr-2" />
              HISTORY
            </Button>
            <Button size="sm" className="bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 text-xs font-bold">
              <Play className="w-4 h-4 mr-2" />
              CONTINUE
            </Button>
            <Button size="sm" className="bg-blue-500 text-white hover:bg-blue-600 px-4 py-2 text-xs font-bold">
              <Square className="w-4 h-4 mr-2" />
              STOP SESSION
            </Button>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-8 gap-4 text-xs mb-4">
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">TERMINAL</div>
            <div className="font-bold text-gray-800">AMEDV4EX-HP</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">GAMING DAY</div>
            <div className="font-bold text-gray-800">01/1/16</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">LAST CHANGE</div>
            <div className="font-bold text-gray-800">01/1/16 12:36:54</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">CHANGED BY</div>
            <div className="font-bold text-gray-800">Demo</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">OWNER</div>
            <div className="font-bold text-gray-800">Demo</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">NO. OF TRANS</div>
            <div className="font-bold text-gray-800">1</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">ACTIVE TIME</div>
            <div className="font-bold text-gray-800">0h 00m</div>
          </div>
          <div>
            <div className="text-gray-500 mb-1 font-medium uppercase">TRANS/HOUR</div>
            <div className="font-bold text-gray-800">211</div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-8 mt-6 border-b border-gray-200">
          <button className="pb-3 px-1 text-blue-600 border-b-2 border-blue-600 font-bold text-sm uppercase">
            TRANSACTIONS
          </button>
          <button className="pb-3 px-1 text-gray-500 hover:text-gray-700 font-bold text-sm uppercase">
            EXCHANGE RATES
          </button>
          <button className="pb-3 px-1 text-gray-500 hover:text-gray-700 font-bold text-sm uppercase">
            REPORT
          </button>
        </div>
      </div>

      {/* Cage Inventory Table */}
      <Card className="shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-bold text-gray-800">Cage Inventory</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-600">
                <TableHead className="font-bold text-white text-xs uppercase">Type</TableHead>
                <TableHead className="font-bold text-white text-xs uppercase text-center">QTY</TableHead>
                <TableHead className="font-bold text-white text-xs uppercase text-center">Denom</TableHead>
                <TableHead className="font-bold text-white text-xs uppercase text-right">Amount</TableHead>
                <TableHead className="font-bold text-white text-xs uppercase text-right">Base Currency</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {inventoryData.map((item, index) => (
                <TableRow key={index} className="hover:bg-gray-50 border-b border-gray-200">
                  <TableCell className="font-medium text-sm py-3">
                    {item.type === 'CHIP' || item.type === 'EUR' || item.type === 'Chip USD' ? 
                      <span className="text-blue-600">▼ {item.type}</span> : 
                      item.type
                    }
                  </TableCell>
                  <TableCell className="text-center text-sm py-3">{item.qty}</TableCell>
                  <TableCell className="text-center text-sm py-3">{item.denom}</TableCell>
                  <TableCell className="text-right font-medium text-sm py-3">{item.amount}</TableCell>
                  <TableCell className="text-right font-bold text-sm py-3">{item.baseCurrency}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          <div className="flex justify-end mt-4 pt-4 border-t border-gray-200">
            <div className="text-right">
              <div className="text-xs text-gray-500 mb-1 font-medium uppercase">TOTAL:</div>
              <div className="text-lg font-bold text-gray-800">{total}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CageCard;