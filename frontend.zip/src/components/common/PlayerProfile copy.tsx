"use client";
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card/card';
import Button from '@/components/ui/button/Button';
import Badge from '@/components/ui/badge/Badge';

const PlayerStats = () => {
  const playerData = {
    accountNo: '0000032',
    name: 'Dom Richard Hawthorne',
    memberSince: '01/05/2012',
    membershipExpiration: 'Never',
    lastEntry: '08/13/2015',
    secondEntry: '07/13/2015',
    address: 'United States, CASINO ROAD 125, NEW YORK',
    distance: '0 km',
    time: '0h 00m',
    credits: 'INR 8.070',
    points: '2.739',
    gameTypes: ['104 - Vega Vision (EGT)', '106 - AFRICAN DUSK (ARI)'],
    account_type: 'PLATINUM'
  };

  const todayStats = {
    winLoss: 'INR 1.154',
    trueWin: 'INR 1.126',
    expWin: 'INR -6',
    bet: 'INR 61',
    promo: 'INR 61',
    avgBet: 'INR 2.66',
    points: '0',
    playTime: '0h 17m',
    activeTime: '0h 04m',
    cashBack: 'INR 0',
    otherCosts: 'INR 350',
    netValue: 'INR -1.504'
  };

  const historicalData = [
    { period: 'Previous Visit', winLoss: 'INR -101', trueWinLoss: 'INR -101', expWinLoss: 'INR -8', bet: 'INR 160', promo: 'INR 0', avgBet: 'INR 10.00', points: '40', playersCosts: 'INR 40', netValue: 'INR 61', avgPlaytime: '0h 07m', avgActivePlaytime: '0h 02m' },
    { period: 'This Month', winLoss: 'INR -7.342', trueWinLoss: 'INR -3.967', expWinLoss: 'INR -395', bet: 'INR 10.919', promo: 'INR 3.375', avgBet: 'INR 89.50', points: '1.896', playersCosts: 'INR 600', netValue: 'INR 6.742', avgPlaytime: '1h 11m', avgActivePlaytime: '0h 02m' },
    { period: 'Previous Month', winLoss: 'INR 3.993', trueWinLoss: 'INR 5.608', expWinLoss: 'INR -5.514', bet: 'INR 104.107', promo: 'INR 1.615', avgBet: 'INR 75.55', points: '67.270', playersCosts: 'INR 9.810', netValue: 'INR -13.802', avgPlaytime: '1h 43m', avgActivePlaytime: '0h 13m' },
    { period: 'Last 30 days', winLoss: 'INR -7.576', trueWinLoss: 'INR -3.471', expWinLoss: 'INR -461', bet: 'INR 11.648', promo: 'INR 4.104', avgBet: 'INR 43.46', points: '1.886', playersCosts: 'INR 2.340', netValue: 'INR 5.236', avgPlaytime: '1h 08m', avgActivePlaytime: '0h 04m' },
    { period: 'This year', winLoss: 'INR -144.588', trueWinLoss: 'INR -133.626', expWinLoss: 'INR -80.699', bet: 'INR 1.530.792', promo: 'INR 10.962', avgBet: 'INR 62.30', points: '530.653', playersCosts: 'INR 17.636', netValue: 'INR 126.952', avgPlaytime: '2h 17m', avgActivePlaytime: '0h 22m' },
    { period: 'Lifetime', winLoss: 'INR -222.167', trueWinLoss: 'INR -184.904', expWinLoss: 'INR -319.137', bet: 'INR 2.770.544', promo: 'INR 37.263', avgBet: 'INR 31.59', points: '1.359.394', playersCosts: 'INR 36.674', netValue: 'INR 185.493', avgPlaytime: '0h 18m', avgActivePlaytime: '0h 18m' }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto space-y-4 bg-white">

      <div className="mb-8">
        <Card className="bg-white shadow-md border border-gray-100">
          <CardContent className="p-6 flex flex-row gap-8 items-center">
            {/* Photo */}
            <div className="relative">
              <div className="w-28 h-36 rounded-xl overflow-hidden border-2 border-green-200 shadow-sm">
                <img src="/lovable-uploads/12415086-08d1-450f-bfc6-3df704454870.png" alt="Player Photo" className="w-full h-full object-cover" />
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-green-700 bg-opacity-90 text-white text-xs text-center py-1 rounded-b-xl tracking-wide font-semibold">
                {playerData.account_type}
              </div>
            </div>
            {/* Details & Membership */}
            <div className="flex-1 flex flex-col gap-2">
              <div className="flex items-center gap-4">
                <span className="text-xs text-gray-400">Account No:</span>
                <span className="font-mono text-base text-gray-700">{playerData.accountNo}</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{playerData.name}</div>
              <div className="text-sm text-gray-500 mb-2">{playerData.address}</div>
              <div className="flex gap-6 text-xs text-gray-600">
                <div><span className="font-semibold">Member Since:</span> {playerData.memberSince}</div>
                <div><span className="font-semibold">Expires:</span> {playerData.membershipExpiration}</div>
                <div><span className="font-semibold">Last Entry:</span> {playerData.lastEntry}</div>
              </div>
            </div>
            {/* Card Stats */}
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl flex flex-col items-center min-w-[140px] shadow-inner border border-green-100">
              <div className="text-xs text-gray-500 mb-1">Card Details</div>
              <div className="flex flex-col gap-2">
                <div className="flex flex-col items-center">
                  <span className="text-gray-500 text-xs">Credits</span>
                  <span className="font-bold text-lg text-green-700">{playerData.credits}</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-gray-500 text-xs">Points</span>
                  <span className="font-bold text-lg text-blue-700">{playerData.points}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Statistics - Redesigned to match image */}
      <div className="bg-[#f7f8fa] rounded-lg px-8 py-6 my-2 border border-gray-200">
        {/* Headings Row */}
  <div className="flex justify-between items-center text-xs font-medium text-gray-500 mb-4 relative">
          <div className="flex-1 min-w-[120px] text-center">Win/Loss</div>
          <div className="flex-1 min-w-[120px] text-center">Bet</div>
          <div className="flex-1 min-w-[140px] text-center relative flex flex-col items-center justify-center" style={{height: '2.2rem'}}>
            <span>Points</span>
            <span
              style={{
                position: 'absolute',
                top: '-2.2rem',
                left: '100%',
                transform: 'translateX(-50%)',
                zIndex: 1,
                padding: '0.18rem 1.1rem',
                borderRadius: '9999px',
                background: '#e6f9f0',
                color: '#047857',
                fontWeight: 500,
                fontSize: '0.93rem',
                letterSpacing: '0.03em',
                border: '1.5px solid #34d399',
                boxShadow: '0 1px 4px 0 rgba(52,211,153,0.07)'
              }}
            >
              TODAY
            </span>
          </div>
          <div className="flex-1 min-w-[80px] text-center">Play Time</div>
          <div className="flex-1 min-w-[100px] text-center">CashBack</div>
          <div className="flex-1 min-w-[120px] text-center">Net Value</div>
        </div>
        {/* Values Row */}
        <div className="flex items-center justify-between text-sm mt-4" style={{height: '3.2rem'}}>
          {/* Win/Loss */}
          <div className="flex-1 min-w-[120px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-green-600 text-lg">{todayStats.winLoss}</div>
          </div>
          {/* Bet */}
          <div className="flex-1 min-w-[120px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-lg">{todayStats.bet}</div>
          </div>
          {/* Points */}
          <div className="flex-1 min-w-[80px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-lg">{todayStats.points}</div>
          </div>
          {/* PlayTime */}
          <div className="flex-1 min-w-[140px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-lg">{todayStats.playTime}</div>
          </div>
          {/* CashBack */}
          <div className="flex-1 min-w-[100px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-lg">{todayStats.cashBack}</div>
          </div>
          {/* Net Value */}
          <div className="flex-1 min-w-[120px] text-center flex flex-col items-center justify-center h-full">
            <div className="font-bold text-lg text-red-600">{todayStats.netValue}</div>
          </div>
        </div>
      </div>

      {/* Historical Data Table */}
      <Card>
        <CardContent className="p-6">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2"></th>
                  <th className="text-left py-2">Previous Visit</th>
                  <th className="text-left py-2">This Month</th>
                  <th className="text-left py-2">Previous Month</th>
                  <th className="text-left py-2">Last 30 days</th>
                  <th className="text-left py-2">This year</th>
                  <th className="text-left py-2">Lifetime</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 font-medium">Win/Loss</td>
                  <td className="py-2 text-red-600">INR -101</td>
                  <td className="py-2 text-red-600">INR -7.342</td>
                  <td className="py-2 text-green-600">INR 3.993</td>
                  <td className="py-2 text-red-600">INR -7.576</td>
                  <td className="py-2 text-red-600">INR -144.588</td>
                  <td className="py-2 text-red-600">INR -222.167</td>
                </tr>
                {/* <tr className="border-b">
                  <td className="py-2 font-medium">True Win/Loss</td>
                  <td className="py-2">INR -101</td>
                  <td className="py-2">INR -3.967</td>
                  <td className="py-2">INR 5.608</td>
                  <td className="py-2">INR -3.471</td>
                  <td className="py-2">INR -133.626</td>
                  <td className="py-2">INR -184.904</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Exp. Win/Loss</td>
                  <td className="py-2">INR -8</td>
                  <td className="py-2">INR -395</td>
                  <td className="py-2">INR -5.514</td>
                  <td className="py-2">INR -461</td>
                  <td className="py-2">INR -80.699</td>
                  <td className="py-2">INR -319.137</td>
                </tr> */}
                <tr className="border-b">
                  <td className="py-2 font-medium">Bet</td>
                  <td className="py-2">INR 160</td>
                  <td className="py-2">INR 10.919</td>
                  <td className="py-2">INR 104.107</td>
                  <td className="py-2">INR 11.648</td>
                  <td className="py-2">INR 1.530.792</td>
                  <td className="py-2">INR 2.770.544</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">- Promo</td>
                  <td className="py-2">INR 0</td>
                  <td className="py-2">INR 3.375</td>
                  <td className="py-2">INR 1.615</td>
                  <td className="py-2">INR 4.104</td>
                  <td className="py-2">INR 10.962</td>
                  <td className="py-2">INR 37.263</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Avg. Bet</td>
                  <td className="py-2">INR 10.00</td>
                  <td className="py-2">INR 89.50</td>
                  <td className="py-2">INR 75.55</td>
                  <td className="py-2">INR 43.46</td>
                  <td className="py-2">INR 62.30</td>
                  <td className="py-2">INR 31.59</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Points</td>
                  <td className="py-2">40</td>
                  <td className="py-2">1.896</td>
                  <td className="py-2">67.270</td>
                  <td className="py-2">1.886</td>
                  <td className="py-2">530.653</td>
                  <td className="py-2">1.359.394</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Player's Costs</td>
                  <td className="py-2">INR 40</td>
                  <td className="py-2">INR 600</td>
                  <td className="py-2">INR 9.810</td>
                  <td className="py-2">INR 2.340</td>
                  <td className="py-2">INR 17.636</td>
                  <td className="py-2">INR 36.674</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Net Value</td>
                  <td className="py-2 text-green-600">INR 61</td>
                  <td className="py-2 text-green-600">INR 6.742</td>
                  <td className="py-2 text-red-600">INR -13.802</td>
                  <td className="py-2 text-green-600">INR 5.236</td>
                  <td className="py-2 text-green-600">INR 126.952</td>
                  <td className="py-2 text-green-600">INR 185.493</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 font-medium">Avg. Playtime</td>
                  <td className="py-2">0h 07m</td>
                  <td className="py-2">1h 11m</td>
                  <td className="py-2">1h 43m</td>
                  <td className="py-2">1h 08m</td>
                  <td className="py-2">2h 17m</td>
                  <td className="py-2">0h 18m</td>
                </tr>
                <tr>
                  <td className="py-2 font-medium">Avg. Active Playtime</td>
                  <td className="py-2">0h 02m</td>
                  <td className="py-2">0h 02m</td>
                  <td className="py-2">0h 13m</td>
                  <td className="py-2">0h 04m</td>
                  <td className="py-2">0h 22m</td>
                  <td className="py-2">0h 18m</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlayerStats;
