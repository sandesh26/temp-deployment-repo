"use client";

import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { UserPlus } from "lucide-react";
import Modal from "../ui/modal/Modal";
import { Upload } from "lucide-react";
import { API_BASE_URL } from "@/config/api";
import resolveImageSrc from "@/lib/resolveImageSrc";

interface PlayerLog {
  id: number;
  player_id: number;
  full_name: string;
  tier: string;
  login_time: string;
  logout_time: string | null;
  status: string;
}

const initialForm = {
  first_name: "",
  last_name: "",
  full_name: "",
  address: "",
  govt_id_number: "",
  govt_id_type: "",
  photo_url: "",
  govt_id_proof: "",
  email: "",
  phone: "",
  document: null as File | null,
  tier: "",
};

  // govtIdTypes will be loaded from backend API (/api/identification-proof)

const Reception: React.FC = () => {
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [form, setForm] = useState(initialForm);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState("");
  const [popup, setPopup] = useState<{ message: string; type: "success" | "error" | "" }>({ message: "", type: "" });
  const [showPopup, setShowPopup] = useState(false);
  const [playerStats, setPlayerStats] = useState<{
    vipCount: number;
    normalCount: number;
    insideCount: number;
    todaysCount: number;
  }>({
    vipCount: 0,
    normalCount: 0,
    insideCount: 0,
    todaysCount: 0,
  });
  const [playerLogs, setPlayerLogs] = useState<PlayerLog[]>([]);
  const [hoveredCounter, setHoveredCounter] = useState<string | null>(null);
  const countersRef = useRef<HTMLDivElement | null>(null);
  const [popupQuery, setPopupQuery] = useState("");

  const isFormValid =
    form.first_name.trim().length > 0 &&
    form.last_name.trim().length > 0 &&
    form.address.trim().length > 0 &&
    form.govt_id_number.trim().length > 0 &&
    form.govt_id_type && form.govt_id_type !== "" &&
    form.tier && form.tier !== "" &&
    form.phone.trim().length === 10 &&
    !formError;
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Camera capture state
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedBlob, setCapturedBlob] = useState<Blob | null>(null);
  const [cameraUploading, setCameraUploading] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Government ID types loaded from API
  const [govtIdTypes, setGovtIdTypes] = useState<string[]>([]);
  const [govtIdTypesLoading, setGovtIdTypesLoading] = useState(false);
  const [govtIdTypesError, setGovtIdTypesError] = useState('');

  useEffect(() => {
    let mounted = true;
    const fetchGovtIdTypes = async () => {
      try {
        setGovtIdTypesLoading(true);
        const res = await fetch(`${API_BASE_URL}/api/identification-proof`);
        if (!res.ok) throw new Error('Failed to fetch identification proofs');
        const data = await res.json();
        if (!mounted) return;
        if (Array.isArray(data)) {
          // Only extract the name parameter
          setGovtIdTypes(data.map((d: any) => d.name).filter(Boolean));
        } else {
          setGovtIdTypes([]);
        }
      } catch (err) {
        console.error('Error fetching identification proofs:', err);
        if (mounted) {
          setGovtIdTypes([]);
          setGovtIdTypesError('Failed to load identification types');
        }
      } finally {
        if (mounted) setGovtIdTypesLoading(false);
      }
    };
    fetchGovtIdTypes();
    return () => { mounted = false; };
  }, []);

  // Helper functions to filter player logs
  const getPlayersInside = () => playerLogs.filter(log => log.status === 'INSIDE');
  const getVipPlayers = () => playerLogs.filter(log => log.tier === 'VIP');
  const getNormalPlayers = () => playerLogs.filter(log => log.tier !== 'VIP');
  

  // Get filtered players based on counter type
  const getFilteredPlayers = (counterType: string) => {
    switch (counterType) {
      case 'inside':
        return getPlayersInside();
      case 'vip':
        return getVipPlayers();
      case 'normal':
        return getNormalPlayers();
      case 'today':
        // Return raw logs from API (includes login_time, status, tier, full_name)
        return playerLogs;
      default:
        return [];
    }
  };

  // Format time for display
  const formatTime = (timeString: string) => {
    const date = new Date(timeString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  // Fetch player stats
  const fetchPlayerStats = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/player-entry-log?logsOnly=true`);
      if (response.ok) {
        const data = await response.json();
        setPlayerStats(data.summary);
        setPlayerLogs(data.logs || []);
      }
    } catch (error) {
      console.error("Error fetching player stats:", error);
    }
  };

  // Fetch stats on component mount
  useEffect(() => {
    fetchPlayerStats();
    const handleDocClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (!countersRef.current) return;
      // If click is inside countersRef or inside any tooltip, don't close.
      if (countersRef.current.contains(target)) return;
      setHoveredCounter(null);
    };
    document.addEventListener('click', handleDocClick);
    return () => document.removeEventListener('click', handleDocClick);
  }, []);

  // Disable background scroll when Add Player modal is open
  useEffect(() => {
    if (showAddModal) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showAddModal]);

  // Clear popup search when popup (hoveredCounter) changes
  useEffect(() => {
    setPopupQuery("");
  }, [hoveredCounter]);

  // Helper to return displayed players after applying popupQuery filter
  const getDisplayedPlayers = (counterType: string) => {
    const list = getFilteredPlayers(counterType) || [];
    const q = popupQuery.trim().toLowerCase();
    if (!q) return list;
    return list.filter((p: any) => (p.full_name || "").toLowerCase().includes(q));
  };

  // Live search
  useEffect(() => {
    if (!search.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    const handler = setTimeout(() => {
      fetch(`${API_BASE_URL}/api/user?search=${encodeURIComponent(search)}&role=Player`)
        .then(res => res.json())
        .then(data => setResults(data))
        .catch((err) => {
          console.error("Error fetching user data:", err);
          setResults([]);
        })
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(handler);
  }, [search]);

  // Explicit search handler for button
  const handleSearch = () => {
    if (!search.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    fetch(`${API_BASE_URL}/api/player/search?query=${encodeURIComponent(search)}`)
      .then(res => res.json())
      .then(data => setResults(data))
      .catch(() => setResults([]))
      .finally(() => setLoading(false));
  };

  // Handle form input
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, files } = e.target as any;
    if (name === "document" && files && files[0]) {
      setForm(f => ({ ...f, document: files[0] }));
    } else {
      setForm(f => ({ ...f, [name]: value }));
    }
  };

  // Camera functions
  const startCamera = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Camera not supported in this browser');
      return;
    }
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: cameraFacing } });
      setCameraStream(stream);
      if (videoRef.current) {
        try {
          videoRef.current.srcObject = stream;
          // Some browsers require an explicit play() call even with autoPlay; muted allows autoplay.
          await videoRef.current.play();
        } catch (err) {
          // play() can fail due to autoplay policies; ignore here but stream is attached
          console.warn('video play() failed', err);
        }
      }
      setCameraActive(true);
    } catch (err: any) {
      console.error('Error accessing camera', err);
      setCameraError(err?.message || 'Unable to access camera');
    }
  };

  // Ensure video element plays when cameraStream is set
  useEffect(() => {
    if (!cameraStream) return;
    if (!videoRef.current) return;
    try {
      videoRef.current.srcObject = cameraStream;
      // Try to play; muted video should allow autoplay in most browsers
      const p = videoRef.current.play();
      if (p && typeof p.then === 'function') {
        p.catch(err => {
          console.warn('Autoplay play() rejected', err);
        });
      }
    } catch (err) {
      console.warn('Could not attach stream to video element', err);
    }
  }, [cameraStream]);

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }
    setCameraActive(false);
    setCapturedBlob(null);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      if (blob) setCapturedBlob(blob);
    }, 'image/jpeg', 0.85);
  };

  const retakePhoto = () => {
    setCapturedBlob(null);
  };

  const uploadCapturedPhoto = async () => {
    if (!capturedBlob) return;
    setCameraUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', capturedBlob, 'photo.jpg');
      fd.append('folder', 'user-documents');
      const uploadRes = await fetch(`${API_BASE_URL}/api/upload`, { method: 'POST', body: fd });
      if (!uploadRes.ok) throw new Error('Upload failed');
      const uploadData = await uploadRes.json();
      // store camera photo in photo_url
      setForm(f => ({ ...f, photo_url: uploadData.url }));
      // stop camera after successful upload
      stopCamera();
    } catch (err) {
      console.error('Failed to upload captured photo', err);
      setCameraError('Failed to upload photo');
    } finally {
      setCameraUploading(false);
    }
  };

  const restartCamera = async (facing: 'user' | 'environment') => {
    stopCamera();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing } });
      setCameraStream(stream);
      if (videoRef.current) {
        try {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        } catch (err) {
          console.warn('video play() failed on restart', err);
        }
      }
      setCameraActive(true);
      setCameraFacing(facing);
    } catch (err: any) {
      console.error('Error restarting camera', err);
      setCameraError(err?.message || 'Unable to access camera');
    }
  };

  const toggleFacing = () => {
    const next = cameraFacing === 'user' ? 'environment' : 'user';
    if (cameraActive) restartCamera(next);
    else setCameraFacing(next);
  };

  // Close and reset the Add Player modal and camera/form state
  const closeAddModal = () => {
    setShowAddModal(false);
    setForm(initialForm);
    setFormError('');
    stopCamera();
    setCapturedBlob(null);
    setCameraError(null);
    setCameraFacing('user');
  };

  // Submit new player
  const handleAddPlayer = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormLoading(true);
    setFormError("");
    
    // Combine first name and last name into full_name
    const fullName = `${form.first_name.trim()} ${form.last_name.trim()}`.trim();
    
    // Validate phone number
    if (!/^\d{10}$/.test(form.phone)) {
      setFormError("Phone number must be exactly 10 digits");
      setFormLoading(false);
      return;
    }
    // Validate email if provided
    if (form.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) {
      setFormError("Please enter a valid email address");
      setFormLoading(false);
      return;
    }
    try {
      // Upload document (govt id) if provided and map to govt_id_proof
      let govtIdProofUrl = form.govt_id_proof || "";
      if (form.document) {
        const formData = new FormData();
        formData.append("file", form.document);
        formData.append("folder", 'user-documents');
        const uploadRes = await fetch(`${API_BASE_URL}/api/upload`, {
          method: "POST",
          body: formData,
        });
        const uploadData = await uploadRes.json();
        govtIdProofUrl = uploadData.url;
      }
      const body: any = {
        full_name: fullName,
        address: form.address,
        govt_id_number: form.govt_id_number,
        govt_id_type: form.govt_id_type,
        photo_url: form.photo_url || '',
        govt_id_proof: govtIdProofUrl,
        email: form.email,
        phone: form.phone,
        role: "Player",
        status: "Active",
        tier: form.tier,
      };
      
      const playerRes = await fetch(`${API_BASE_URL}/api/user`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!playerRes.ok) {
        // Try to read error message from response
        let errMsg: string | null = null;
        try {
          const errJson = await playerRes.json();
          if (errJson) {
            if (typeof errJson === 'string') errMsg = errJson;
            else if (errJson.message) errMsg = errJson.message;
            else if (errJson.error) errMsg = errJson.error;
          }
        } catch (e) {
          try {
            const txt = await playerRes.text();
            errMsg = txt;
          } catch (_) {
            errMsg = null;
          }
        }

        const lower = (errMsg || '').toLowerCase();
        if (lower.includes('already exists') || lower.includes('already exists') || lower.includes('already exist') || lower.includes('user with this') || lower.includes('user already')) {
          const friendly = 'Player already exists in the system';
          setFormError(friendly);
          setPopup({ message: friendly, type: 'error' });
          setShowPopup(true);
          setTimeout(() => setShowPopup(false), 3000);
        } else {
          const friendly = errMsg || 'Failed to add player';
          setFormError(friendly);
          setPopup({ message: friendly, type: 'error' });
          setShowPopup(true);
          setTimeout(() => setShowPopup(false), 3000);
        }
        setFormLoading(false);
        return;
      }
      // success
      await playerRes.json();
      closeAddModal();
      setSearch("");
      setResults([]);
      fetchPlayerStats(); // Refresh stats after adding player
      setTimeout(() => {
        setPopup({ message: "Player registered successfully!", type: "success" });
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 2000);
      }, 2000);
    } catch (err: any) {
      setFormError(err.message || "Something went wrong");
      setTimeout(() => {
        setPopup({ message: err.message || "Something went wrong", type: "error" });
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 2000);
      }, 2000);
    } finally {
      setFormLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-transparent text-black relative">
      {/* DEBUG: Popup test buttons - always visible in main content */}
      {/* <div className="absolute top-6 left-1/2 -translate-x-1/2 z-50 flex gap-2">
        <button
          className="px-3 py-2 rounded bg-green-600 text-white font-bold shadow hover:bg-green-700"
          onClick={() => {
            setPopup({ message: "Player registered successfully!", type: "success" });
            setShowPopup(true);
            setTimeout(() => setShowPopup(false), 200000);
          }}
        >Show Success Popup</button>
        <button
          className="px-3 py-2 rounded bg-red-600 text-white font-bold shadow hover:bg-red-700"
          onClick={() => {
            setPopup({ message: "Something went wrong", type: "error" });
            setShowPopup(true);
            setTimeout(() => setShowPopup(false), 200000);
          }}
        >Show Error Popup</button>
      </div> */}
      {/* Centered Popup for success/error message, excluding sidebar */}
      {showPopup && (
        <div
          className="absolute inset-0 z-50 flex items-center justify-center animate-popup pt-[0px]"
          style={{ pointerEvents: 'none' }}
        >
          <div
            className={`min-w-[320px] max-w-[90vw] w-[400px] min-h-[120px] px-8 py-6 rounded-xl shadow-2xl flex flex-col items-center justify-center gap-4 ${popup.type === "success" ? "bg-green-600 text-white" : "bg-red-600 text-white"}`}
            style={{ pointerEvents: 'auto' }}
          >
            {popup.type === "success" ? (
              <svg width="64px" height="64px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#ffffff">
                <circle cx="12" cy="12" r="10" stroke="#ffffff" strokeWidth={1.5} />
                <path d="M8.5 12.5L10.5 14.5L15.5 9.5" stroke="#ffffff" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            ) : (
              <svg width="64px" height="64px" viewBox="0 0 24 24" role="img" xmlns="http://www.w3.org/2000/svg" aria-labelledby="cancelIconTitle" stroke="#ffffff" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" fill="none" color="#000000">
                <title id="cancelIconTitle">Cancel</title>
                <path d="M15.5355339 15.5355339L8.46446609 8.46446609M15.5355339 8.46446609L8.46446609 15.5355339" />
                <path d="M4.92893219,19.0710678 C1.02368927,15.1658249 1.02368927,8.83417511 4.92893219,4.92893219 C8.83417511,1.02368927 15.1658249,1.02368927 19.0710678,4.92893219 C22.9763107,8.83417511 22.9763107,15.1658249 19.0710678,19.0710678 C15.1658249,22.9763107 8.83417511,22.9763107 4.92893219,19.0710678 Z" />
              </svg>
            )}
            <span className="font-semibold text-lg text-center">{popup.message}</span>
          </div>
        </div>
      )}
      {/* DEBUG: Show isFormValid and its components */}
      {/* <div className="bg-yellow-50 border border-yellow-300 rounded p-4 mb-4 text-xs text-yellow-900">
        <div><strong>Debug: isFormValid = {String(isFormValid)}</strong></div>
        <div>full_name: {String(form.full_name.trim().length > 0)}</div>
        <div>address: {String(form.address.trim().length > 0)}</div>
        
        <div>govt_id_number: {String(form.govt_id_number.trim().length > 0)}</div>
        <div>govt_id_type: {String(form.govt_id_type && form.govt_id_type !== "")}</div>
        <div>email: {String(form.email.trim().length > 0)}</div>
        <div>phone: {String(form.phone.trim().length === 10)}</div>
      </div> */}
      <div className="mx-auto px-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-6">
            {/* Player Stats */}
              <div className="flex items-center gap-4" ref={countersRef}>
              <div 
                className="relative bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-3 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setHoveredCounter(prev => prev === 'inside' ? null : 'inside')}
              >
                <div className="text-xs text-gray-600 font-medium">Currently Inside</div>
                <div className="text-xl font-bold text-green-700 text-center">{playerStats.insideCount}</div>
                
                {/* Hover Tooltip */}
                {hoveredCounter === 'inside' && (
                  <div onClick={e => e.stopPropagation()} className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4">
                    <h3 className="font-semibold text-gray-800 mb-3">Players Currently Inside</h3>
                    <input
                      type="search"
                      placeholder="Search by name"
                      value={popupQuery}
                      onChange={e => setPopupQuery(e.target.value)}
                      className="w-full mb-3 px-3 py-2 border rounded bg-gray-50 text-sm"
                    />
                    <div className="max-h-[calc(100vh-220px)] overflow-y-auto">
                      {getDisplayedPlayers('inside').length > 0 ? (
                        <div className="space-y-2">
                          {getDisplayedPlayers('inside').map((player) => (
                            <div key={player.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                              <div>
                                <div className="font-medium text-sm">{player.full_name}</div>
                                <div className="text-xs text-gray-500">
                                  <span className={`px-1 py-0.5 rounded text-xs ${player.tier === 'VIP' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                                    {player.tier}
                                  </span>
                                  <span className="ml-2">In: {formatTime(player.login_time)}</span>
                                </div>
                              </div>
                              <div className="text-xs text-green-600 font-medium">INSIDE</div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-gray-500 text-sm">No players currently inside</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div 
                className="relative bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-3 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setHoveredCounter(prev => prev === 'vip' ? null : 'vip')}
              >
                <div className="text-xs text-gray-600 font-medium">VIP Players</div>
                <div className="text-xl font-bold text-amber-600 text-center">{playerStats.vipCount}</div>
                
                {/* Hover Tooltip */}
                {hoveredCounter === 'vip' && (
                  <div onClick={e => e.stopPropagation()} className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4">
                    <h3 className="font-semibold text-gray-800 mb-3">VIP Players</h3>
                    <input
                      type="search"
                      placeholder="Search by name"
                      value={popupQuery}
                      onChange={e => setPopupQuery(e.target.value)}
                      className="w-full mb-3 px-3 py-2 border rounded bg-gray-50 text-sm"
                    />
                    <div className="max-h-[calc(100vh-220px)] overflow-y-auto">
                      {getDisplayedPlayers('vip').length > 0 ? (
                        <div className="space-y-2">
                          {getDisplayedPlayers('vip').map((player) => (
                            <div key={player.id} className="flex justify-between items-center p-2 bg-amber-50 rounded">
                              <div>
                                <div className="font-medium text-sm">{player.full_name}</div>
                                <div className="text-xs text-gray-500">
                                  <span className="px-1 py-0.5 rounded text-xs bg-amber-100 text-amber-800">VIP</span>
                                  <span className="ml-2">In: {formatTime(player.login_time)}</span>
                                </div>
                              </div>
                              <div className={`text-xs font-medium ${player.status === 'INSIDE' ? 'text-green-600' : 'text-gray-500'}`}>
                                {player.status}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-gray-500 text-sm">No VIP players</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div 
                className="relative bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-3 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setHoveredCounter(prev => prev === 'normal' ? null : 'normal')}
              >
                <div className="text-xs text-gray-600 font-medium">Normal Players</div>
                <div className="text-xl font-bold text-blue-600 text-center">{playerStats.normalCount}</div>
                
                {/* Hover Tooltip */}
                {hoveredCounter === 'normal' && (
                  <div onClick={e => e.stopPropagation()} className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4">
                    <h3 className="font-semibold text-gray-800 mb-3">Normal Players</h3>
                    <input
                      type="search"
                      placeholder="Search by name"
                      value={popupQuery}
                      onChange={e => setPopupQuery(e.target.value)}
                      className="w-full mb-3 px-3 py-2 border rounded bg-gray-50 text-sm"
                    />
                    <div className="max-h-[calc(100vh-220px)] overflow-y-auto">
                      {getDisplayedPlayers('normal').length > 0 ? (
                        <div className="space-y-2">
                          {getDisplayedPlayers('normal').map((player) => (
                            <div key={player.id} className="flex justify-between items-center p-2 bg-blue-50 rounded">
                              <div>
                                <div className="font-medium text-sm">{player.full_name}</div>
                                <div className="text-xs text-gray-500">
                                  <span className="px-1 py-0.5 rounded text-xs bg-blue-100 text-blue-800">{player.tier}</span>
                                  <span className="ml-2">In: {formatTime(player.login_time)}</span>
                                </div>
                              </div>
                              <div className={`text-xs font-medium ${player.status === 'INSIDE' ? 'text-green-600' : 'text-gray-500'}`}>
                                {player.status}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-gray-500 text-sm">No normal players</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <div 
                className="relative bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-3 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setHoveredCounter(prev => prev === 'today' ? null : 'today')}
              >
                <div className="text-xs text-gray-600 font-medium">Today's Count</div>
                <div className="text-xl font-bold text-gray-700 text-center">{playerStats.todaysCount}</div>
                
                {/* Hover Tooltip */}
                {hoveredCounter === 'today' && (
                  <div onClick={e => e.stopPropagation()} className="absolute top-full left-0 mt-2 w-80 bg-white border border-gray-200 rounded-lg shadow-lg z-50 p-4">
                    <h3 className="font-semibold text-gray-800 mb-3">Today's Players</h3>
                    <input
                      type="search"
                      placeholder="Search by name"
                      value={popupQuery}
                      onChange={e => setPopupQuery(e.target.value)}
                      className="w-full mb-3 px-3 py-2 border rounded bg-gray-50 text-sm"
                    />
                    <div className="max-h-[calc(100vh-220px)] overflow-y-auto">
                      {getDisplayedPlayers('today').length > 0 ? (
                        <div className="space-y-2">
                          {getDisplayedPlayers('today').map((player) => (
                            <div key={player.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                              <div>
                                <div className="font-medium text-sm">{player.full_name}</div>
                                <div className="text-xs text-gray-500">
                                  <span className={`px-1 py-0.5 rounded text-xs ${player.tier === 'VIP' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                                    {player.tier}
                                  </span>
                                  <span className="ml-2">In: {formatTime(player.login_time)}</span>
                                </div>
                              </div>
                              <div className={`text-xs font-medium ${player.status === 'INSIDE' ? 'text-green-600' : 'text-gray-500'}`}>
                                {player.status}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-gray-500 text-sm">No players logged in today</div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <button
            className="bg-green-700 hover:bg-green-800 text-white font-semibold px-5 py-2 rounded flex items-center gap-2 shadow"
            onClick={() => setShowAddModal(true)}
          >
            <UserPlus className="w-5 h-5" />
            Register New Player
          </button>
        </div>
        {/* Search Card */}
        <div className="bg-white rounded-xl shadow p-6 mb-8">
          <h2 className="text-lg font-bold mb-1">Player Search</h2>
          <p className="text-gray-600 text-sm mb-4">Search for Players by Name or RFID Number</p>
          <div className="flex gap-2 items-center mb-2">
            <input
              type="text"
              className="flex-1 bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black placeholder:text-gray-400"
              placeholder="Type here to search"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <button
              className="bg-green-700 hover:bg-green-800 px-5 py-2 rounded text-white font-semibold flex items-center gap-2"
              onClick={handleSearch}
              type="button"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              Search
            </button>
          </div>
          {loading ? (
            <div className="text-gray-600 py-4">Searching...</div>
          ) : results.length > 0 ? (
              <ul className="mt-5 grid gap-4">
                {results.map(player => {
                  // Format created_at to DD/MM/YYYY
                  let memberSince = '';
                  if (player.created_at) {
                    const d = new Date(player.created_at);
                    memberSince = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth()+1).padStart(2, '0')}/${d.getFullYear()}`;
                  }
                  return (
                    <li
                      key={player.user_id}
                      className="p-5 cursor-pointer bg-green-50 hover:bg-green-100 transition-colors rounded-xl border border-green-100 shadow-sm"
                      onClick={() => router.push(`/player/${player.user_id}`)}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <span className="text-xs font-semibold text-green-900 bg-green-200 px-2 py-1 rounded">ID: {player.user_id}</span>
                          <span className="text-xl font-bold text-green-900">{player.full_name}</span>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <button
                            className="bg-green-700 hover:bg-green-800 text-white font-semibold px-4 py-2 rounded shadow text-sm"
                            onClick={e => {
                              e.stopPropagation();
                              router.push(`/player/${player.user_id}`);
                            }}
                          >VIEW PROFILE</button>
                          <button
                            className="bg-green-700 hover:bg-green-800 text-white font-semibold px-4 py-2 rounded shadow text-sm"
                            onClick={async e => {
                              e.stopPropagation();
                              try {
                                const res = await fetch(`${API_BASE_URL}/api/player-entry-log`, {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    player_id: player.user_id,
                                    login_time: new Date().toISOString(),
                                    status: 'INSIDE',
                                  }),
                                });
                                if (!res.ok) throw new Error('Failed to check in player');
                                setPopup({ message: 'Player checked in successfully!', type: 'success' });
                                setShowPopup(true);
                                setSearch("");
                                setResults([]);
                                fetchPlayerStats();
                                setTimeout(() => setShowPopup(false), 2000);
                              } catch (err) {
                                setPopup({ message: 'Check-in failed', type: 'error' });
                                setShowPopup(true);
                                setTimeout(() => setShowPopup(false), 2000);
                              }
                            }}
                          >CHECK IN</button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 pl-1 mb-4">
                        <div className="text-base text-green-900"><span className="font-semibold">Address:</span> <span className="font-normal">{player.address || <span className="text-gray-400">N/A</span>}</span></div>
                        <div className="text-base text-green-900"><span className="font-semibold">Email:</span> <span className="font-normal">{player.email || <span className="text-gray-400">N/A</span>}</span></div>
                        <div className="text-base text-green-900"><span className="font-semibold">Phone:</span> <span className="font-normal">{player.phone || <span className="text-gray-400">N/A</span>}</span></div>
                        <div className="text-base text-green-900"><span className="font-semibold">Member Since:</span> <span className="font-normal">{memberSince || <span className="text-gray-400">N/A</span>}</span></div>
                      </div>
                    </li>
                  );
                })}
              </ul>
          ) : search.trim() ? (
            <div className="text-gray-600 py-4">No player found</div>
          ) : null}
        </div>
        {/* Empty State */}
        {(!loading && results.length === 0 && !search.trim()) && (
          <div className="flex flex-col items-center justify-center py-24">
            <p className="text-gray-600 text-lg">Search for a player to see their profile</p>
          </div>
        )}
      </div>
      {/* Add Player Modal */}
      {showAddModal && (
  <Modal onClose={() => { closeAddModal(); }} width="max-w-3xl" height="max-h-[98vh]">
        <div className="p-8 relative text-black max-h-[85vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Add New Player</h2>
            <form onSubmit={handleAddPlayer} className="">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                <div>
                  <label className="block font-medium mb-1">First Name <span className="text-red-600">*</span></label>
                  <input type="text" name="first_name" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="First Name" value={form.first_name} onChange={handleFormChange} />
                </div>
                <div>
                  <label className="block font-medium mb-1">Last Name <span className="text-red-600">*</span></label>
                  <input type="text" name="last_name" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="Last Name" value={form.last_name} onChange={handleFormChange} />
                </div>
                <div>
                  <label className="block font-medium mb-1">Player Tier <span className="text-red-600">*</span></label>
                  <select name="tier" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" value={form.tier} onChange={handleFormChange}>
                    <option value="" disabled>Select Player Tier</option>
                    <option value="Bronze">Bronze</option>
                    <option value="Silver">Silver</option>
                    <option value="Gold">Gold</option>
                    <option value="Platinum">Platinum</option>
                    <option value="VIP">VIP</option>
                    <option value="VVIP">VVIP</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium mb-1">Address <span className="text-red-600">*</span></label>
                  <input type="text" name="address" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="Address" value={form.address} onChange={handleFormChange} />
                </div>
                
                <div>
                  <label className="block font-medium mb-1">Email</label>
                  <input type="email" name="email" className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="Email" value={form.email} onChange={handleFormChange} pattern="^[^@\s]+@[^@\s]+\.[^@\s]+$" title="Please enter a valid email address" />
                </div>
                <div>
                  <label className="block font-medium mb-1">Govt ID Type <span className="text-red-600">*</span></label>
                    <select name="govt_id_type" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" value={form.govt_id_type} onChange={handleFormChange}>
                    <option value="" disabled>Select Type of Govt ID</option>
                    {govtIdTypesLoading ? (
                      <option disabled>Loading...</option>
                    ) : (
                      govtIdTypes.map((type) => (<option key={type} value={type}>{type.replace("_", " ")}</option>))
                    )}
                  </select>
                </div>
                <div>
                  <label className="block font-medium mb-1">Govt ID Number <span className="text-red-600">*</span></label>
                  <input type="text" name="govt_id_number" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="Govt ID Number" value={form.govt_id_number} onChange={handleFormChange} />
                </div>
                <div>
                  <label className="block font-medium mb-1">Phone Number <span className="text-red-600">*</span></label>
                  <input type="tel" name="phone" required className="w-full bg-[#F5F5F5] border border-[#E5E7EB] rounded px-4 py-2 text-black" placeholder="Phone Number (10 digits)" value={form.phone} onChange={e => { let value = e.target.value.replace(/[^\d]/g, ""); if (value.length > 10) value = value.slice(0, 10); setForm(f => ({ ...f, phone: value })); }} pattern="^\d{10}$" maxLength={10} title="Phone number must be 10 digits" inputMode="numeric" autoComplete="off" />
                </div>
                <div>
                  <label className="mb-1 font-medium">Upload Document</label>
                  <div className="relative">
                    <input type="file" name="document" accept="image/*,.pdf" className="hidden" ref={fileInputRef} onChange={handleFormChange} />
                    <button type="button" className="mt-1 w-full flex items-center justify-center gap-2 py-2 px-4 rounded font-bold bg-[#F5F5F5] text-black hover:bg-green-600 hover:text-white transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                      <Upload className="w-5 h-5" />
                      Upload Document (Govt ID)
                    </button>
                    {form.document && (<div className="mt-2 text-sm text-gray-600">Selected File: {form.document.name}</div>)}
                    {form.govt_id_proof && (<div className="mt-2 text-sm text-gray-600">Uploaded URL: <a className="text-blue-600 underline" href={form.govt_id_proof} target="_blank" rel="noreferrer">View</a></div>)}
                  </div>

                  {/* Camera capture for profile photo */}
                  <div className="mt-4">
                    <label className="mb-1 font-medium">Capture Photo (Camera)</label>
                    <div className="mt-2">
                      {form.photo_url ? (
                        <div>
                          <img src={resolveImageSrc(form.photo_url)} alt="Captured" className="w-36 h-36 object-cover rounded-md border" />
                          <div className="text-sm text-gray-600 mt-2">Camera photo selected</div>
                          <div className="flex gap-2 mt-2">
                            <button type="button" className="px-3 py-1 rounded bg-gray-200" onClick={() => setForm(f => ({ ...f, photo_url: '' }))}>Remove</button>
                          </div>
                        </div>
                      ) : cameraActive ? (
                        <div>
                          {!capturedBlob ? (
                            <div>
                              <video ref={videoRef} autoPlay playsInline muted className="w-full rounded-md bg-black" />
                              <div className="flex gap-2 mt-2">
                                <button type="button" className="px-3 py-1 rounded bg-blue-600 text-white" onClick={capturePhoto}>Capture</button>
                                <button type="button" className="px-3 py-1 rounded bg-gray-200" onClick={toggleFacing}>Flip</button>
                                <button type="button" className="px-3 py-1 rounded bg-red-200" onClick={stopCamera}>Close Camera</button>
                              </div>
                            </div>
                          ) : (
                            <div>
                              <img src={URL.createObjectURL(capturedBlob)} alt="preview" className="w-full rounded-md border" />
                              <div className="flex gap-2 mt-2">
                                <button type="button" className="px-3 py-1 rounded bg-gray-200" onClick={retakePhoto}>Retake</button>
                                <button type="button" className="px-3 py-1 rounded bg-green-700 text-white" onClick={uploadCapturedPhoto} disabled={cameraUploading}>{cameraUploading ? 'Uploading...' : 'Use Photo'}</button>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <button type="button" className="px-3 py-1 rounded bg-blue-600 text-white" onClick={startCamera}>Use Camera</button>
                          <button type="button" className="px-3 py-1 rounded bg-gray-200" onClick={() => { setCameraFacing('user'); }}>Front</button>
                          <button type="button" className="px-3 py-1 rounded bg-gray-200" onClick={() => { setCameraFacing('environment'); }}>Back</button>
                        </div>
                      )}
                      <canvas ref={canvasRef} className="hidden" />
                      {cameraError && <div className="text-sm text-red-500 mt-2">{cameraError}</div>}
                    </div>
                  </div>
                </div>
              </div>
              {formError && <div className="text-red-500 text-sm mt-2">{formError}</div>}
              <div className="flex justify-end gap-2 mt-4">
                <button type="button" className="px-4 py-2 text-sm font-bold rounded bg-gray-200 text-black hover:bg-red-600 hover:text-white border border-gray-300" onClick={() => { closeAddModal(); }}>Cancel</button>
                <button type="submit" className={`px-4 py-2 text-sm font-bold rounded ${formLoading || !isFormValid ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-green-700 hover:bg-green-800 text-white'} transition-colors`} disabled={formLoading || !isFormValid}>{formLoading ? "Saving..." : "Save Player"}</button>
              </div>
            </form>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default Reception;
