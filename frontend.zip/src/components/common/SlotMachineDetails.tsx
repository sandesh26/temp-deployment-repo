"use client";
import React, { useState, useEffect } from 'react';
import { Settings, Edit, X, CheckCircle, AlertTriangle, RotateCcw } from 'lucide-react';
import ToggleSwitch from './ToggleSwitch';
import { API_BASE_URL } from "@/config/api";
import { useSearchParams } from "next/navigation";
import Modal from "@/components/ui/modal/Modal";

interface MachineFormData {
  slot_machine_id: number;
  configured: string;
  machine_id: string;
  position: string;
  asset_no: string;
  serial_number: string;
  external_id: string;
  box_server: string;
  manufacturer: string;
  machine_model: string;
  cabinet_type: string;
  year_of_prod: string;
  accounting_model: string;
  mechanical_model: string;
  currency: string;
  acc_denomination: string;
  coin_value: string;
  system_interface: string;
  ticketing: boolean;
  player_tracking: boolean;
  cashless: boolean;
  restricted_promo: boolean;
  founds_transfer: boolean;
  current_bonusing_settings: string;
  use_aft_game_lock: boolean;
  main_game: string;
  game_type: string;
  max_win: number | string;
  min_denom: string;
  max_denom: string;
  min_bet: string;
  max_bet: string;
  min_rtp: string;
  max_rtp: string;
  id_prog_ver: string;
  sas_game_id: string;
  sas_paytbl_id: string;
  rom_signature: string;
  created_at: string;
}

const defaultFormData: MachineFormData = {
  slot_machine_id: 0,
  configured: "",
  machine_id: "",
  position: "",
  asset_no: "",
  serial_number: "",
  external_id: "",
  box_server: "",
  manufacturer: "",
  machine_model: "",
  cabinet_type: "",
  year_of_prod: "",
  accounting_model: "",
  mechanical_model: "",
  currency: "",
  acc_denomination: "",
  coin_value: "",
  system_interface: "",
  ticketing: false,
  player_tracking: false,
  cashless: false,
  restricted_promo: false,
  founds_transfer: false,
  current_bonusing_settings: "",
  use_aft_game_lock: false,
  main_game: "",
  game_type: "",
  max_win: "",
  min_denom: "",
  max_denom: "",
  min_bet: "",
  max_bet: "",
  min_rtp: "",
  max_rtp: "",
  id_prog_ver: "",
  sas_game_id: "",
  sas_paytbl_id: "",
  rom_signature: "",
  created_at: "",
};

const configureOptions = [
  {
    label: "DISCOVERABLE",
    value: "Discoverable",
    color: "bg-teal-400",
  },
  {
    label: "PREPARED",
    value: "Prepared",
    color: "bg-blue-500",
  },
  {
    label: "TEST",
    value: "Test",
    color: "bg-orange-400",
  },
  {
    label: "LIVE",
    value: "Live",
    color: "bg-teal-400",
  },
  {
    label: "WAREHOUSE",
    value: "Warehouse",
    color: "bg-purple-500",
  },
  {
    label: "REMOVED",
    value: "Removed",
    color: "bg-red-500",
  },
  {
    label: "ACTIVE",
    value: "Active",
    color: "bg-green-500",
  },
  {
    label: "INACTIVE",
    value: "Inactive",
    color: "bg-amber-500",
  },
  {
    label: "UNDER MAINTENANCE",
    value: "Under_Maintenance",
    color: "bg-red-900",
  }
];

const tabList = [
  { label: "GENERAL", value: "general" },
  { label: "GAMES (Under Development - Need Clarity)", value: "games" },
  // { label: "ADVANCED", value: "advanced" },
];

function deepEqual(obj1: any, obj2: any) {
  return JSON.stringify(obj1) === JSON.stringify(obj2);
}

// Utility to normalize status for comparison (case-insensitive, underscores to spaces)
function normalizeStatus(val: string) {
  return val.replace(/_/g, " ").trim().toLowerCase();
}

// Utility to get the valid API value for storage (from configureOptions or allowed list)
const allowedStatusValues = [
  "Discoverable",
  "Prepared",
  "Test",
  "Live",
  "Warehouse",
  "Removed",
  "Active",
  "Inactive",
  "Under_Maintenance"
];

const SlotMachineDetails: React.FC = () => {
  const searchParams = useSearchParams();
  const machine_id = searchParams.get("machine_id") || "1";

  // Config API state
  const [formData, setFormData] = useState<MachineFormData>(defaultFormData);
  const [originalFormData, setOriginalFormData] = useState<MachineFormData>(defaultFormData);
  const [operationType, setOperationType] = useState<'POST' | 'PUT'>('PUT');

  // Status API state
  const [status, setStatus] = useState("Discoverable");
  const [originalStatus, setOriginalStatus] = useState("Discoverable");

  // UI state
  const [configureOpen, setConfigureOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(tabList[0].value);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showFailure, setShowFailure] = useState(false);
  const [activeGamesTab, setActiveGamesTab] = useState("active");


  // Games API state
  const [gamesData, setGamesData] = useState<any[]>([]);
  const [gamesLoading, setGamesLoading] = useState(false);
  const [gamesError, setGamesError] = useState("");
  const [selectedDenom, setSelectedDenom] = useState("");

  // Fetch games from API
  useEffect(() => {
    setGamesLoading(true);
    setGamesError("");
    fetch(`${API_BASE_URL}/api/machine-games?gameDetails=true&slot_machine_id=${machine_id}`)
      .then(res => res.json())
      .then(data => {
        // Defensive: handle array at root or under 'games'
        let games: any[] = [];
        if (Array.isArray(data)) {
          games = data;
        } else if (Array.isArray(data.games)) {
          games = data.games;
        }
        setGamesData(games);
        // Set default denom if available
        const denoms = Array.from(new Set(games.map((g: any) => typeof g.game?.denom === "string" ? g.game.denom : "").filter(Boolean)));
        if (denoms.length > 0 && typeof denoms[0] === "string") {
          setSelectedDenom(denoms[0]);
        } else {
          setSelectedDenom("");
        }
        setGamesLoading(false);
      })
      .catch(() => {
        setGamesError("Failed to load games.");
        setGamesLoading(false);
      });
  }, [machine_id]);

  // Denomination list
  const denomList = Array.from(new Set(gamesData.map((g: any) => g.game?.denom).filter(Boolean)));

  // Keep selectedDenom in sync if denomList changes
  useEffect(() => {
    if (!denomList.includes(selectedDenom)) {
      if (denomList.length > 0 && typeof denomList[0] === "string") {
        setSelectedDenom(denomList[0]);
      } else {
        setSelectedDenom("");
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [denomList.join(), selectedDenom]);

  // Fetch config and status on mount
  useEffect(() => {
    fetch(`${API_BASE_URL}/api/slot-machine-configuration/${machine_id}`)
      .then(res => res.json())
      .then(data => {
        if (data && typeof data === 'object' && data.error === 'Not found') {
          setOperationType('POST');
          setFormData(defaultFormData);
          setOriginalFormData(defaultFormData);
        } else {
          setOperationType('PUT');
          setFormData(data);
          setOriginalFormData(data);
        }
      });
    fetch(`${API_BASE_URL}/api/slotmachine?machine_id=${machine_id}`)
      .then(res => res.json())
      .then(data => {
        // data is an array, take first element
        let statusValue = data[0]?.machine_status || "Discoverable";
        // Ensure statusValue matches allowed case for storage
        const matched = allowedStatusValues.find(
          s => normalizeStatus(s) === normalizeStatus(statusValue)
        );
        statusValue = matched || "Discoverable";
        setStatus(statusValue);
        setOriginalStatus(statusValue);
      });
  }, [machine_id]);

  const updateFormData = (field: keyof MachineFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Check if config or status has changed (case-insensitive compare)
  const hasConfigChanges = !deepEqual(formData, originalFormData);
  const hasStatusChanges = normalizeStatus(status) !== normalizeStatus(originalStatus);
  const hasChanges = hasConfigChanges || hasStatusChanges;

  // Confirm handler
  const handleConfirm = () => {
    setShowConfirmModal(true);
  };

  // Save handler with 2 seconds delay for processing animation
  const handleSave = async () => {
    setProcessing(true);
    setShowConfirmModal(false);

    // Add 2 seconds delay before making the API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    let configOk = true;
    let statusOk = true;

    // Prepare requests
    const requests: Promise<any>[] = [];
    if (hasConfigChanges) {
      if (operationType === 'POST') {
        requests.push(
          fetch(`${API_BASE_URL}/api/slot-machine-configuration`, {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(transformedFormData),
          }).then(res => { configOk = res.ok; })
        );
      } else {
        requests.push(
          fetch(`${API_BASE_URL}/api/slot-machine-configuration/${machine_id}`, {
            method: operationType,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(transformedFormData),
          }).then(res => { configOk = res.ok; })
        );
      }
    }
    if (hasStatusChanges) {
      // Always store in the valid API case
      let statusToStore = allowedStatusValues.find(
        s => normalizeStatus(s) === normalizeStatus(status)
      ) || "Discoverable";
      requests.push(
        fetch(`${API_BASE_URL}/api/slotmachine/${machine_id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ machine_status: statusToStore }),
        }).then(res => { statusOk = res.ok; })
      );
    }

    // Run all requests in parallel
    await Promise.all(requests);

    if ((hasConfigChanges && !configOk) || (hasStatusChanges && !statusOk)) {
      setShowFailure(true);
    } else {
      setShowSuccess(true);
      if (hasConfigChanges) {
        setOriginalFormData(formData);
        // If we just did a POST, switch to PUT for future updates
        if (operationType === 'POST') {
          setOperationType('PUT');
        }
      }
      if (hasStatusChanges) setOriginalStatus(status);
    }

    setProcessing(false);
    setTimeout(() => {
      setShowSuccess(false);
      setShowFailure(false);
    }, 2000);
  };

  useEffect(() => {
    if (!configureOpen) return;
    const handler = () => setConfigureOpen(false);
    window.addEventListener("click", handler);
    return () => window.removeEventListener("click", handler);
  }, [configureOpen]);

  // Reset handler
  const handleReset = () => {
    setFormData(originalFormData);
    setStatus(originalStatus);
  };

  // Transformed data for API submission
  const transformedFormData = {
    ...formData,
    slot_machine_id: machine_id ? parseInt(machine_id) : undefined,
    acc_denomination: formData.acc_denomination ? Number(formData.acc_denomination) : undefined,
    coin_value: formData.coin_value ? Number(formData.coin_value) : undefined,
    min_denom: formData.min_denom ? Number(formData.min_denom) : undefined,
    max_denom: formData.max_denom ? Number(formData.max_denom) : undefined,
    min_bet: formData.min_bet ? Number(formData.min_bet) : undefined,
    max_bet: formData.max_bet ? Number(formData.max_bet) : undefined,
    min_rtp: formData.min_rtp ? Number(formData.min_rtp) : undefined,
    max_rtp: formData.max_rtp ? Number(formData.max_rtp) : undefined,
    max_win: formData.max_win ? parseInt(formData.max_win as any) : undefined,
    created_at: formData.created_at ? new Date(formData.created_at).toISOString() : undefined,
    // ...other fields remain unchanged
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-slate-700 text-white p-4 rounded-t-lg flex items-center justify-between">
          {/* Tabbed Menu */}
          <div className="flex items-center space-x-2">
            {tabList.map(tab => (
              <button
                key={tab.value}
                className={`px-4 py-2 rounded-t ${activeTab === tab.value ? "bg-white text-slate-700 font-bold shadow" : "bg-slate-700 text-gray-300"}`}
                onClick={() => setActiveTab(tab.value)}
                style={{ minWidth: 100 }}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="flex items-center space-x-2">
            {/* Status Dropdown */}
            <div className="relative" onClick={e => e.stopPropagation()}>
              <button
                className="flex items-center px-3 py-1 rounded bg-slate-800 border border-slate-600 hover:bg-slate-600 transition"
                onClick={() => setConfigureOpen(v => !v)}
                type="button"
              >
                <span className={`w-3 h-3 rounded-full mr-2 ${configureOptions.find(opt => opt.value.toLowerCase() === status.toLowerCase())?.color}`}></span>
                <span className="text-sm">
                  {configureOptions.find(opt => opt.value.toLowerCase() === status.toLowerCase())?.label}
                </span>
                <svg className="ml-2 w-4 h-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {configureOpen && (
                <div className="absolute right-0 mt-2 w-57 bg-white border rounded shadow z-50">
                  {configureOptions.map(opt => (
                    <button
                      key={opt.value}
                      className="flex items-center w-full px-4 py-2 hover:bg-gray-100 text-gray-700"
                      onClick={() => {
                        setStatus(opt.value);
                        setConfigureOpen(false);
                      }}
                      type="button"
                    >
                      <span className={`w-3 h-3 rounded-full mr-2 ${opt.color}`}></span>
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {/* Reset Button */}
            <button
              className={`flex items-center px-3 py-1 rounded bg-slate-600 hover:bg-slate-500 transition text-white ${!hasChanges ? "opacity-50 cursor-not-allowed" : ""}`}
              onClick={hasChanges ? handleReset : undefined}
              disabled={!hasChanges}
              title="Reset changes"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </button>
            {/* Confirm Button */}
            <button
              className={`bg-blue-500 hover:bg-blue-600 px-4 py-1 rounded text-sm ${!hasChanges ? "opacity-50 cursor-not-allowed" : ""}`}
              onClick={hasChanges ? handleConfirm : undefined}
              disabled={!hasChanges}
            >
              Confirm
            </button>
            {/* Close Button */}
            <button
              className="bg-red-500 hover:bg-red-600 px-4 py-1 rounded text-sm flex items-center"
              title="Close"
              onClick={() => window.history.back()}
            >
              <X className="w-4 h-4 mr-1" /> Close
            </button>
          </div>
        </div>

        <div className="bg-white rounded-b-lg shadow-lg ">
          {/* Tab Content */}
          {activeTab === "general" && (
            <>
              {/* Machine Identification Section */}
              <div className="border-b">
                <div className="bg-slate-600 flex items-center justify-between px-4 py-2 border-b">
                  <span className="bg-slate-600 text-white px-3 py-1 rounded font-medium tracking-wide">
                    MACHINE IDENTIFICATION
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-red-400">DB ID : {formData.machine_id}</span>
                  </div>
                </div>
                <div className="p-6 grid grid-cols-7 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      POSITION
                    </label>
                    <select
                      className="w-full p-2 border border-blue-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-700"
                      value={formData.position}
                      onChange={(e) => updateFormData('position', e.target.value)}
                    >
                      <option value="" disabled>
                        select
                      </option>
                      <option value="Casino Floor 1">Casino Floor 1</option>
                      <option value="Casino Floor 2">Casino Floor 2</option>
                      <option value="Casino VIP Section">Casino VIP Section</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      MACHINE ID *
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      value={formData.machine_id ?? ""}
                      onChange={(e) => updateFormData('machine_id', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      ASSET NO.
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      value={formData.asset_no ?? ""}
                      onChange={(e) => updateFormData('asset_no', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      SERIAL NUMBER *
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      value={formData.serial_number ?? ""}
                      onChange={(e) => updateFormData('serial_number', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      EXTERNAL ID
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      value={formData.external_id ?? ""}
                      onChange={(e) => updateFormData('external_id', e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      BOX SERVER
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-100"
                      value={formData.box_server ?? ""}
                      onChange={(e) => updateFormData('box_server', e.target.value)}
                      disabled
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      SMIB ID
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-100 text-gray-400"
                      value={formData.slot_machine_id ?? ""}
                      disabled
                    />
                  </div>
                </div>
              </div>

              {/* Machine Data Section */}
              <div className="border-b">
                <div className="bg-slate-600 text-white px-4 py-2">
                  <span className="font-medium">MACHINE DATA</span>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-4 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MANUFACTURER *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.manufacturer ?? ""}
                        onChange={(e) => updateFormData('manufacturer', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MACHINE MODEL *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.machine_model ?? ""}
                        onChange={(e) => updateFormData('machine_model', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        CABINET TYPE *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.cabinet_type ?? ""}
                        onChange={(e) => updateFormData('cabinet_type', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Y. OF PROD.
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.year_of_prod ?? ""}
                        onChange={(e) => updateFormData('year_of_prod', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        ACCOUNTING MODEL *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.accounting_model ?? ""}
                        onChange={(e) => updateFormData('accounting_model', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MECHANICAL MODEL
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.mechanical_model ?? ""}
                        onChange={(e) => updateFormData('mechanical_model', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        CURRENCY *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.currency ?? ""}
                        onChange={(e) => updateFormData('currency', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        ACC. DENOM. *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.acc_denomination ?? ""}
                        onChange={(e) => updateFormData('acc_denomination', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        COIN VALUE
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.coin_value ?? ""}
                        onChange={(e) => updateFormData('coin_value', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* System Data Section */}
              <div className="border-b">
                <div className="bg-slate-600 text-white px-4 py-2">
                  <span className="font-medium">SYSTEM DATA</span>
                </div>
                <div className="p-6">
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      SYSTEM INTERFACE
                    </label>
                    <input
                      type="text"
                      className="w-64 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      value={formData.system_interface ?? ""}
                      onChange={(e) => updateFormData('system_interface', e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">TICKETING</span>
                        <ToggleSwitch
                          id="ticketing"
                          checked={formData.ticketing ?? false}
                          onChange={(checked) => updateFormData('ticketing', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">CASHLESS</span>
                        <ToggleSwitch
                          id="cashless"
                          checked={formData.cashless ?? false}
                          onChange={(checked) => updateFormData('cashless', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">FUNDS TRANSFER</span>
                        <ToggleSwitch
                          id="foundsTransfer"
                          checked={formData.founds_transfer ?? false}
                          onChange={(checked) => updateFormData('founds_transfer', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">USE AFT GAME LOCK</span>
                        <ToggleSwitch
                          id="useAftGameLock"
                          checked={formData.use_aft_game_lock ?? false}
                          onChange={(checked) => updateFormData('use_aft_game_lock', checked)}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">PLAYER TRACKING</span>
                        <ToggleSwitch
                          id="playerTracking"
                          checked={formData.player_tracking ?? false}
                          onChange={(checked) => updateFormData('player_tracking', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">RESTRICTED PROMO</span>
                        <ToggleSwitch
                          id="restrictedPromo"
                          checked={formData.restricted_promo ?? false}
                          onChange={(checked) => updateFormData('restricted_promo', checked)}
                        />
                      </div>
                      {/* <div className="mt-6">
                        <div className="text-sm font-medium text-gray-700 mb-2">CURRENT BONUSING SETTINGS</div>
                        <div className="text-sm text-gray-600">{formData.current_bonusing_settings ?? "—"}</div>
                      </div> */}
                    </div>
                  </div>
                </div>
              </div>

              {/* Main Game Data Section */}
              <div>
                <div className="bg-slate-600 text-white px-4 py-2">
                  <span className="font-medium">MAIN GAME DATA</span>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MAIN GAME *
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.main_game ?? ""}
                        onChange={(e) => updateFormData('main_game', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        GAME TYPE
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.game_type ?? ""}
                        onChange={(e) => updateFormData('game_type', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MAX WIN
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.max_win ?? ""}
                        onChange={(e) => updateFormData('max_win', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-6 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MIN. DENOM.
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.min_denom ?? ""}
                        onChange={(e) => updateFormData('min_denom', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MAX. DENOM.
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.max_denom ?? ""}
                        onChange={(e) => updateFormData('max_denom', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MIN. BET
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.min_bet ?? ""}
                        onChange={(e) => updateFormData('min_bet', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MAX. BET
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.max_bet ?? ""}
                        onChange={(e) => updateFormData('max_bet', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MIN. RTP
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.min_rtp ?? ""}
                        onChange={(e) => updateFormData('min_rtp', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        MAX. RTP
                      </label>
                      <input
                        type="text"
                        className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        value={formData.max_rtp ?? ""}
                        onChange={(e) => updateFormData('max_rtp', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="bg-gray-50 px-6 py-4 text-xs text-gray-500 grid grid-cols-6 gap-4">
                <div>ID PROG. VER: {formData.id_prog_ver || "—"}</div>
                <div>SAS - GAME ID: {formData.sas_game_id || "—"}</div>
                <div>SAS - PAYTBL ID: {formData.sas_paytbl_id || "—"}</div>
                <div>ROM SIGNATURE: {formData.rom_signature || "—"}</div>
                <div>CREATED: {formData.created_at ? new Date(formData.created_at).toLocaleString() : "—"}</div>
                <div></div>
              </div>
            </>
          )}
          {activeTab === "games" && (
            <div className="bg-white">
              {/* Header Section */}
              <div className="bg-slate-600 text-white border-b border-gray-200 px-4 py-2">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-4">
                    <div className=" text-white px-3 py-1 rounded text-md font-medium">
                      MAIN GAME
                    </div>
                    {/* <div className="text-sm text-gray-600">
                      <span className="font-medium">MACHINE REPORTED NAME:</span> ---
                    </div>
                    <div className="text-sm text-gray-600 ml-auto">
                      <span className="font-medium">Position:</span> 104 <span className="ml-4">Mch Id:</span> K 104
                    </div> */}
                  </div>
                </div>
              </div>
              <div className="px-4 py-2">
                {/* Info Message */}
                <div className="bg-blue-50 border border-blue-200 rounded px-4 py-2 mb-4">
                  <p className="text-blue-700 text-sm">
                    This machine has program with several different sub-versions. Please select correct sub-version.
                  </p>
                </div>
                
                {/* Sub-version Selector */}
                <div className="mb-4">
                  <select className="w-64 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>Subversion 1 (--- / Vega Vision)</option>
                    <option>Subversion 2 (--- / Other Game)</option>
                  </select>
                </div>
                
                {/* Game Details Grid */}
                <div className="grid grid-cols-4 gap-4 mb-6">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase mb-1">
                      MANUFACTURER
                    </label>
                    <div className="flex items-center">
                      <input
                        type="text"
                        className="flex-1 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        value="EGT - EGT - Eurogames T..."
                        readOnly
                      />
                      <svg className="w-4 h-4 ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase mb-1">
                      MAIN GAME
                    </label>
                    <div className="flex items-center">
                      <input
                        type="text"
                        className="flex-1 p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                        value="Vega Vision"
                        readOnly
                      />
                      <svg className="w-4 h-4 ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase mb-1">
                      GAME SET
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      value="EGT6652"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase mb-1">
                      GAME TYPE
                    </label>
                    <input
                      type="text"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-gray-100"
                      value="Multigame"
                      readOnly
                    />
                  </div>
                </div>
              </div>

              {/* Games & Machine Section */}
              <div className="border-b border-gray-200 px-6 py-3">
                <div className="flex items-center justify-between">
                  <div className="bg-gray-600 text-white px-3 py-1 rounded text-sm font-medium">
                    GAMES & MACHINE
                  </div>
                </div>
              </div>

              {/* Tab Navigation */}
              <div className="px-6 py-3 border-b border-gray-200">
                <div className="flex space-x-1">
                  <button 
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      activeGamesTab === "active" 
                        ? "bg-blue-500 text-white" 
                        : "text-gray-600 hover:text-gray-800"
                    }`}
                    onClick={() => setActiveGamesTab("active")}
                  >
                    ACTIVE GAMES
                  </button>
                  <button 
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      activeGamesTab === "byDenom" 
                        ? "bg-blue-500 text-white" 
                        : "text-gray-600 hover:text-gray-800"
                    }`}
                    onClick={() => setActiveGamesTab("byDenom")}
                  >
                    ALL GAMES BY DENOM
                  </button>
                  <button 
                    className={`px-4 py-2 rounded text-sm font-medium ${
                      activeGamesTab === "all" 
                        ? "bg-blue-500 text-white" 
                        : "text-gray-600 hover:text-gray-800"
                    }`}
                    onClick={() => setActiveGamesTab("all")}
                  >
                    ALL GAMES
                  </button>
                </div>
              </div>

              {/* Games Table for all tabs, with denom selection for 'byDenom' */}
              {
                // Filtered data for each tab
                (() => {
                  // Filtered games for tabs
                  let filteredGames = gamesData;
                  if (activeGamesTab === "active") {
                    filteredGames = gamesData.filter((g: any) => g.game?.status === "Active");
                  } else if (activeGamesTab === "byDenom") {
                    filteredGames = gamesData.filter((g: any) => g.game?.denom === selectedDenom);
                  }
                  // For "all", show all games
                  return (
                    <>
                      {gamesLoading ? (
                        <div className="p-8 text-center text-gray-500">Loading games...</div>
                      ) : gamesError ? (
                        <div className="p-8 text-center text-red-500">{gamesError}</div>
                      ) : (
                        <div>
                          {/* Denomination selector for 'ALL GAMES BY DENOM' */}
                          {activeGamesTab === "byDenom" && (
                            <div className="flex items-center space-x-2 m-3">
                              {denomList.map(denom => (
                                <button
                                  key={denom}
                                  className={`flex items-center px-3 py-2 font-medium text-sm border transition-all mr-2 ${
                                    denom === selectedDenom
                                      ? "bg-blue-500 text-white"
                                      : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
                                  }`}
                                  onClick={() => setSelectedDenom(denom)}
                                >
                                  <span className="w-3 h-3 rounded-full bg-teal-400 mr-2"></span>
                                  {denom}
                                </button>
                              ))}
                            </div>
                          )}
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50">
                              <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  <input type="checkbox" className="rounded" />
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Game No.
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  SM Reported Name
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Game Title
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Game Type
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  RTP
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Max Bet
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Lines
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                  Reels
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {filteredGames.map((item: any, index: number) => (
                                <tr key={index} className="hover:bg-gray-50">
                                  <td className="px-4 py-3">
                                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                                  </td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.game_id}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.name}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.title}</td>
                                  <td className="px-4 py-3 text-gray-600">{item.game?.type}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.rtp}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.max_bet}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.lines}</td>
                                  <td className="px-4 py-3 text-gray-900">{item.game?.reels}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </>
                  );
                })()
              }
            </div>
          )}
          {activeTab === "advanced" && (
            <div className="p-10 text-center text-lg text-gray-500 font-semibold">
              Advanced configuration coming soon...
            </div>
          )}
        </div>
      </div>

      {/* Confirm Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
          <Modal onClose={() => setShowConfirmModal(false)} width="max-w-2xl">
            <div className="flex flex-col items-center p-15 z-1000000">
              <AlertTriangle className="w-12 h-12 text-yellow-500 mb-4" />
              <h2 className="text-lg font-bold mb-2 text-center">Are you sure you want to confirm the changes?</h2>
              <div className="flex justify-end gap-4 mt-6">
                <button
                  className="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded text-sm font-semibold"
                  onClick={() => setShowConfirmModal(false)}
                >
                  No
                </button>
                <button
                  className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded text-sm font-semibold text-white"
                  onClick={handleSave}
                >
                  Yes
                </button>
              </div>
            </div>
          </Modal>
        </div>
      )}

      {/* Processing Animation */}
      {processing && (
        <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
          <Modal onClose={() => {}} width="max-w-2xl">
            <div className="flex flex-col h-full justify-center items-center p-20">
              <div className="text-lg mb-6">Processing Request...</div>
              <div className="flex justify-center">
                <svg className="animate-spin h-8 w-8 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
                </svg>
              </div>
            </div>
          </Modal>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
          <Modal onClose={() => setShowSuccess(false)} width="max-w-2xl">
            <div className="flex flex-col items-center p-20">
              <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
              <h2 className="text-lg font-bold mb-2 text-center">Changes saved successfully!</h2>
            </div>
          </Modal>
        </div>
      )}

      {/* Failure Modal */}
      {showFailure && (
        <div className="fixed inset-0 z-1000000 flex items-center justify-center bg-opacity-40">
          <Modal onClose={() => setShowFailure(false)} width="max-w-2xl">
            <div className="flex flex-col items-center p-20">
              <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
              <h2 className="text-lg font-bold mb-2 text-center">Something went wrong, Please Try Again Later</h2>
              <button className="mt-4 bg-gray-200 px-4 py-2 rounded" onClick={() => setShowFailure(false)}>OK</button>
            </div>
          </Modal>
        </div>
      )}
    </div>
  );
};

export default SlotMachineDetails;
