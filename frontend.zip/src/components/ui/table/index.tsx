import React, { ReactNode } from "react";
import { cn } from "@/lib/utils"

// Props for Table
interface TableProps {
  children: ReactNode; // Table content (thead, tbody, etc.)
  className?: string; // Optional className for styling
  style?: React.CSSProperties;
}

// Props for TableHeader
interface TableHeaderProps {
  children: ReactNode; // Header row(s)
  className?: string; // Optional className for styling
  style?: React.CSSProperties;
}

// Props for TableBody
interface TableBodyProps {
  children: ReactNode; // Body row(s)
  className?: string; // Optional className for styling
  style?: React.CSSProperties;
}

// Props for TableRow
interface TableRowProps extends React.HTMLAttributes<HTMLTableRowElement> {
  children: ReactNode; // Cells (th or td)
  className?: string; // Optional className for styling
  style?: React.CSSProperties;
}

// Props for TableCell
interface TableCellProps {
  children: ReactNode; // Cell content
  isHeader?: boolean; // If true, renders as <th>, otherwise <td>
  className?: string; // Optional className for styling
  style?: React.CSSProperties;
  colSpan?: number; 
  onClick?: React.MouseEventHandler<HTMLTableCellElement>; // <-- Add this line
}

// Table Component
const Table: React.FC<TableProps> = ({ children, className, style }) => {
  return <table className={`min-w-full  ${className}`} style={style}>{children}</table>;
};

// TableHeader Component
const TableHeader: React.FC<TableHeaderProps> = ({ children, className, style }) => {
  return <thead className={className} style={style}>{children}</thead>;
};

const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <th
    ref={ref}
    className={cn(
      "h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0",
      className
    )}
    {...props}
  />
))
TableHead.displayName = "TableHead"

// TableBody Component
const TableBody: React.FC<TableBodyProps> = ({ children, className, style }) => {
  return <tbody className={className} style={style}>{children}</tbody>;
};

// TableRow Component
const TableRow: React.FC<TableRowProps> = ({ children, className, style, ...rest }) => {
  return <tr className={className} style={style} {...rest}>{children}</tr>;
};

// TableCell Component
const TableCell: React.FC<TableCellProps> = ({
  children,
  isHeader = false,
  className,
  style,
  colSpan,
  onClick, // <-- Add this line
}) => {
  const CellTag = isHeader ? "th" : "td";
  return (
    <CellTag
      className={` ${className}`}
      style={style}
      colSpan={colSpan}
      onClick={onClick} // <-- Add this line
    >
      {children}
    </CellTag>
  );
};

export { Table, TableHeader, TableHead, TableBody, TableRow, TableCell };
