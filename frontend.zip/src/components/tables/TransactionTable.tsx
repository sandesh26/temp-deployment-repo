"use client";
import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Badge from "../ui/badge/Badge";
import Image from "next/image";

interface Transaction {
  id: number;
  user: {
    image: string;
    name: string;
  };
  transaction_type: string;
  status: string;
  amount: string;
  card_id: string;
  transaction_id: string;
  transaction_datetime: string;
  transaction_method: string;
}

// Function to generate random names
const generateRandomName = () => {
  const firstNames = ["Lindsey", "Kaiya", "Zain", "Abram", "Carla", "Elon", "Jeff", "Bill", "Mark", "Warren"];
  const lastNames = ["Curtis", "George", "Geidt", "Schleifer", "Buffett", "Musk", "Bezos", "Gates", "Zuckerberg", "Smith"];
  const randomFirstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const randomLastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  return `${randomFirstName} ${randomLastName}`;
};

// Function to generate random transaction data
const generateTransaction = (id: number): Transaction => {
  const transactionMethods = ["Cash", "Chips", "TITO", "UP", "Credit_Debit_Card"];
  const transactionTypes = ["Credit", "Debit", "Balance_Inquiry", "Encash"];
  const statuses = ["Completed", "Pending", "Failed"];
  const randomImageNumber = Math.floor(Math.random() * 37) + 1; // Random number between 1 and 37
  const randomAmount = (Math.random() * 10000).toFixed(2); // Random amount with 2 decimals
  const randomTransactionMethod = transactionMethods[Math.floor(Math.random() * transactionMethods.length)];
  const randomTransactionType = transactionTypes[Math.floor(Math.random() * transactionTypes.length)];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  const currentDateTime = new Date().toLocaleString(); // Current date and time

  return {
    id,
    user: {
      image: `/images/user/user-${randomImageNumber}.jpg`,
      name: generateRandomName(),
    },
    transaction_type: randomTransactionType,
    status: randomStatus,
    amount: randomAmount,
    card_id: `CARD-${Math.floor(1000 + Math.random() * 9000)}`, // Random 4-digit card ID
    transaction_id: `${1000 + id}`, // Sequential transaction ID
    transaction_datetime: currentDateTime,
    transaction_method: randomTransactionMethod,
  };
};

export default function TransactionTable() {
  const [tableData, setTableData] = useState<Transaction[]>([]);

  // Add default entries to the table
  useEffect(() => {
    const defaultEntries = Array.from({ length: 5 }, (_, index) =>
      generateTransaction(index + 1)
    );
    // Sort default entries in descending order of transaction_id
    const sortedEntries = defaultEntries.sort(
      (a, b) => parseInt(b.transaction_id) - parseInt(a.transaction_id)
    );
    setTableData(sortedEntries);
  }, []);

  // Function to simulate adding new transactions
  const addNewTransaction = () => {
    setTableData((prevData) => [generateTransaction(prevData.length + 1), ...prevData]);
  };

  // Simulate adding new transactions every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      addNewTransaction();
    }, 1000); // Add a new transaction every 5 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
      <div className="max-w-full overflow-x-auto">
        <div className="min-w-[1102px]">
          <Table>
            {/* Table Header */}
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Transaction ID
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Player Name
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Card ID
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Transaction Type
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Transaction Method
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Amount
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Transaction Date
                </TableCell>
                <TableCell
                  isHeader
                  className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400"
                >
                  Status
                </TableCell>
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.transaction_id}
                  </TableCell>
                  <TableCell className="px-5 py-4 sm:px-6 text-start">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 overflow-hidden rounded-full">
                        <Image
                          width={40}
                          height={40}
                          src={transaction.user.image}
                          alt={transaction.user.name}
                        />
                      </div>
                      <div>
                        <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                          {transaction.user.name}
                        </span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.card_id}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.transaction_type}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.transaction_method}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.amount}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {transaction.transaction_datetime}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={
                        transaction.status === "Completed"
                          ? "success"
                          : transaction.status === "Pending"
                          ? "warning"
                          : "error"
                      }
                    >
                      {transaction.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
