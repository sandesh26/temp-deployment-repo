"use client";
import React, { useState, useEffect, useRef } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";

import Image from "next/image";
import { API_BASE_URL } from "@/config/api";
import Modal from "../ui/modal/Modal";
import { useAuth } from "@/context/AuthContext";

// DEV: quick runtime checks to help trace invalid element type errors
if (process.env.NODE_ENV === 'development') {
  try {
    // eslint-disable-next-line no-console
    console.debug('DEV IMPORT CHECK - Modal:', typeof Modal, Modal);
  } catch (e) {
    // ignore in CI
  }
}
if (process.env.NODE_ENV === 'development') {
  try {
    // eslint-disable-next-line no-console
    console.debug('DEV IMPORT CHECK - Table components', {
      Table: typeof Table,
      TableHeader: typeof TableHeader,
      TableBody: typeof TableBody,
      TableCell: typeof TableCell,
      TableRow: typeof TableRow,
    });
  } catch (e) {
    // ignore
  }
}

// Mapping of common column keys to readable labels
const COLUMN_LABELS: Record<string, string> = {
  transaction_id: 'Transaction ID',
  id: 'ID',
  _id: 'ID',
  cage_id: 'Cage',
  player_id: 'Player Name',
  player: 'Player Name',
  amount: 'Amount',
  transaction_type: 'Transaction Type',
  payment_method: 'Payment Method',
  verified_by: 'Verified By',
  performed_by: 'Performed By',
  performedBy: 'Performed By',
  verifier: 'Verifier',
  timestamp: 'Timestamp',
  transaction_time: 'Time',
  notes: 'Notes',
  gaming_day_id: 'Gaming Day',
  gaming_day: 'Gaming Day',
  gamingday: 'Gaming Day',
  user: 'User',
  'user.name': 'User',
  transaction_type_display: 'Type',
  asset_type: 'Asset Type',
  denomination: 'Denomination',
  quantity: 'Quantity',
  total_value: 'Total Value',
  currency_code: 'Currency',
  source: 'Source',
  destination: 'Destination',
  authorized_by: 'Authorized By',
  table_id: 'Table',
};

// Allowed options for transaction type and payment method used in add/edit forms
const ALLOWED_TRANSACTION_TYPES = [
  'HANDPAY','JACKPOT','TICKET_SALE','TICKET_REDEEM','EXPIRED_TICKET','UNREADABLE_TICKET','MONEY_DEBIT','MONEY_CREDIT','FILL','CREDIT','VAULT_MONEY_FILL','VAULT_MONEY_CREDIT','CAGE_OPEN','CHIP_FILL','CHIP_CREDIT','TITO_PURCHASE','TITO_REDEEM','CHIP_PURCHASE','CHIP_REDEEM'
];
const ALLOWED_PAYMENT_METHODS = ['Cash','Chips','UPI','Credit_Debit_Card','TITO','VAULT_TRANSFER','PLAYER_CARD'];

// Source options for add-transaction form
const SOURCE_OPTIONS = ['CAGE', 'VAULT', 'TABLE', 'EXTERNAL'];

const humanizeKey = (key: string) => {
  if (!key) return '';
  // replace dots and underscores with spaces, split camelCase, then Title Case
  const withSpaces = key.replace(/\./g, ' ').replace(/_/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2');
  return withSpaces.split(' ').map(part => part ? part.charAt(0).toUpperCase() + part.slice(1).toLowerCase() : '').join(' ');
};

type AnyRecord = Record<string, any>;

export default function TransactionTable({ resourceType, apiEndpoint, onEditTransaction, onAddTransaction }: { resourceType?: string; apiEndpoint?: string; onEditTransaction?: (r?: any) => void; onAddTransaction?: () => void }) {
  const [tableData, setTableData] = useState<AnyRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [visibleColumns, setVisibleColumns] = useState<string[] | null>(null);
  const [showColumnOptions, setShowColumnOptions] = useState(false);
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  // helper to format a Date to a datetime-local input value (local time)
  const formatForInput = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const [search, setSearch] = useState<string>("");
  const [gamingDays, setGamingDays] = useState<any[]>([]);
  const [selectedGamingDay, setSelectedGamingDay] = useState<string | number | null>(null);
  // UI: show/hide date range inputs (small accordion)
  const [showDateRange, setShowDateRange] = useState<boolean>(false);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(25);
  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [serverPaged, setServerPaged] = useState<boolean>(false);
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [editRecord, setEditRecord] = useState<AnyRecord | null>(null);
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [reloadToggle, setReloadToggle] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [cages, setCages] = useState<any[]>([]);
  const [playerNames, setPlayerNames] = useState<Record<string, string | null>>({});
  const [addForm, setAddForm] = useState<Record<string, any>>({ source: resourceType ? String(resourceType).toUpperCase() : '', cage_id: '', table_id: '', amount: '', transaction_type: '', payment_method: '', asset_type: '', denomination: '', quantity: '', total_value: '', currency_code: '', destination: '', notes: '' });
  const { hasPermission, session } = useAuth();
  // Prefer common shapes: session.user.id, then session.user_id, session.user.user_id, session.user.uid, then session.id/uid
  const userId = (session as any)?.user?.id ?? (session as any)?.user_id ?? (session as any)?.user?.user_id ?? (session as any)?.user?.uid ?? (session as any)?.id ?? (session as any)?.uid ?? null;
  // identifiers and field rules used in edit form handling
  const ID_KEYS = ['id', '_id', 'transaction_id', 'id_transaction', 'reference_id', 'referenceId'];
  const EXCLUDED_FIELDS = new Set([
    'is_manual',
    'requires_verification',
    'verified_by',
    'performed_by',
    'performedBy',
    'verifier',
    'performed_by_id',
    'session_start',
    'session_end',
    'session_id',
  ]);
  // Fields that should be displayed but not editable in the edit form
  // include common id keys, the cage, and player identifiers
  const READONLY_FIELDS = new Set([...ID_KEYS, 'cage_id', 'player', 'player_id', 'playerId']);

  // Fetch data from API if apiEndpoint is provided. Otherwise, show empty state.
  useEffect(() => {
    let mounted = true;
    // map resourceType to backend endpoints (case-insensitive)
    const mapping: Record<string, string> = {
      CAGE: `${API_BASE_URL}/api/cage-transaction`,
      TABLE: `${API_BASE_URL}/api/gametransaction`,
      VAULT: `${API_BASE_URL}/api/vault-transaction`,
      GAMES: `${API_BASE_URL}/api/gametransaction`,
    };

    const key = resourceType ? String(resourceType).toUpperCase() : undefined;
    const endpoint = apiEndpoint || (key ? mapping[key] ?? `${API_BASE_URL}/api/${String(resourceType).toLowerCase()}/transactions` : null);
    if (!endpoint) {
      setTableData([]);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);
    // append date filters and pagination as query params if provided
    // ensure URL has a base when endpoint is relative
    const url = new URL(endpoint, typeof window !== 'undefined' ? window.location.origin : 'http://localhost');
    if (startDate) url.searchParams.append('start_date', startDate.toISOString());
  if (endDate) url.searchParams.append('end_date', endDate.toISOString());
  if (selectedGamingDay) url.searchParams.append('gaming_day', String(selectedGamingDay));
  if (page) url.searchParams.append('page', String(page));
  if (pageSize) url.searchParams.append('pageSize', String(pageSize));
  // debug: show final URL in console to help troubleshoot empty results
    // eslint-disable-next-line no-console
    console.debug("Fetching transactions:", url.toString());

    fetch(url.toString())
      .then(async (res) => {
        if (!mounted) return null;
        if (!res.ok) {
          const text = await res.text().catch(() => "");
          throw new Error(`HTTP ${res.status} - ${text}`);
        }
        return res.json();
      })
      .then((data) => {
        if (!mounted) return;
        // Expecting an array; if API returns object with data/results, normalize and extract total if provided
        let rows: AnyRecord[] = [];
        // detect paginated shapes and extract rows + total and paging info
        const extractRows = (payload: any): { rows: AnyRecord[]; total?: number | null; currentPage?: number | null; pageSize?: number | null; isServerPaged?: boolean } => {
          if (!payload) return { rows: [], total: null };
          // helper to read page and per_page keys
          const readPage = (p: any) => {
            if (!p) return null;
            return (
              p.page || p.page_number || p.page_no || p.current_page || p.pageIndex || p.pageIndexNumber || null
            );
          };
          const readPageSize = (p: any) => {
            if (!p) return null;
            return (p.pageSize || p.page_size || p.per_page || p.limit || p.size || null);
          };

          // If payload is plain array
          if (Array.isArray(payload)) return { rows: payload, total: payload.length, isServerPaged: false };

          // common payload shapes
          if (Array.isArray(payload.data)) {
            const total = payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload) ?? payload.meta?.current_page ?? payload.meta?.page ?? null;
            const ps = readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.data, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }
          if (Array.isArray(payload.results)) {
            const total = payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload) ?? payload.meta?.current_page ?? null;
            const ps = readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.results, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }
          if (Array.isArray(payload.items)) {
            const total = payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload) ?? payload.meta?.current_page ?? null;
            const ps = readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.items, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }

          // some APIs wrap under transactions or records
          if (Array.isArray(payload.transactions)) {
            const total = payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload) ?? payload.meta?.current_page ?? null;
            const ps = readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.transactions, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }
          if (Array.isArray(payload.records)) {
            const total = payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload) ?? payload.meta?.current_page ?? null;
            const ps = readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.records, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }

          // nested data: { data: { items: [...] } }
          if (payload.data && Array.isArray(payload.data.items)) {
            const total = payload.data.total ?? payload.total ?? payload.count ?? payload.meta?.total ?? null;
            const currentPage = readPage(payload.data) ?? readPage(payload) ?? payload.meta?.current_page ?? null;
            const ps = readPageSize(payload.data) ?? readPageSize(payload) ?? payload.meta?.per_page ?? null;
            return { rows: payload.data.items, total, currentPage, pageSize: ps, isServerPaged: Boolean(currentPage || total != null) };
          }

          return { rows: [] };
        };

        const extracted = extractRows(data);
        rows = extracted.rows || [];
        const total = extracted.total ?? null;
        const currentPage = extracted.currentPage ?? null;
        const serverPageSize = extracted.pageSize ?? null;
        const isServerPaged = extracted.isServerPaged ?? false;

        setTableData(rows);
        setTotalCount(total !== null ? total : rows.length);
        setServerPaged(isServerPaged);

        // If server provided current page or page size, respect it (but avoid extra fetch loops)
        if (currentPage && currentPage !== page) {
          setPage(Number(currentPage));
        }
        if (serverPageSize && serverPageSize !== pageSize) {
          setPageSize(Number(serverPageSize));
        }

        // initialize visible columns as union of keys across all rows
        if (rows.length > 0) {
          // If resourceType is a known source, prefer a curated column list
          const keyUpper = (resourceType ?? '').toString().toUpperCase();
          if (keyUpper === 'CAGE') {
            // Show only these columns for cage transactions
            setVisibleColumns(['transaction_id','cage_id','player_id','amount','transaction_type','payment_method','verified_by','performed_by','timestamp','notes','gaming_day_id']);
          } else if (keyUpper === 'VAULT') {
            // Show only these columns for vault transactions
            setVisibleColumns(['transaction_id','transaction_type','asset_type','denomination','quantity','total_value','currency_code','source','destination','authorized_by','performed_by','transaction_time','notes','gaming_day_id','cage_id','table_id']);
          } else {
            const keysSet = new Set<string>();
            rows.forEach(r => {
              Object.keys(r).forEach(k => {
                if (k === 'user' && r.user && typeof r.user === 'object' && r.user.name) keysSet.add('user.name');
                else keysSet.add(k);
              });
            });
            const keys = Array.from(keysSet);
            setVisibleColumns(keys);
          }
        } else {
          setVisibleColumns([]);
        }
      })
      .catch((err) => {
        if (!mounted) return;
        // eslint-disable-next-line no-console
        console.error(err);
        setError(String(err.message ?? 'Failed to load transactions'));
        setTableData([]);
        setTotalCount(0);
      })
      .finally(() => {
        if (!mounted) return;
        setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [resourceType, apiEndpoint, startDate, endDate, page, pageSize, selectedGamingDay, reloadToggle]);

  // Enrich player names for any tableData rows that reference a player_id but don't have a name cached yet
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        if (!tableData || tableData.length === 0) return;
        const needIds = Array.from(new Set(tableData
          .map(r => r.player_id ?? r.playerId)
          .filter(Boolean)
          .map(String)
          .filter(id => !(id in playerNames))
        ));
        if (needIds.length === 0) return;
        const promises = needIds.map(async (pid) => {
          const endpoints = [
            `${API_BASE_URL}/api/user/${encodeURIComponent(pid)}`,
            `${API_BASE_URL}/api/users/${encodeURIComponent(pid)}`,
          ];
          for (const ep of endpoints) {
            try {
              const res = await fetch(ep);
              if (!res.ok) continue;
              const ud = await res.json();
              const name = ud?.name ?? ud?.full_name ?? ud?.data?.name ?? ud?.data?.full_name ?? null;
              if (name) return { id: pid, name };
            } catch (e) {
              // try next
            }
          }
          return { id: pid, name: null };
        });
        const results = await Promise.all(promises);
        if (!mounted) return;
        setPlayerNames(prev => {
          const next = { ...prev };
          results.forEach(r => { next[String(r.id)] = r.name ?? null; });
          return next;
        });
      } catch (e) {
        // ignore
      }
    })();

    return () => { mounted = false; };
  }, [tableData]);

  // Fetch gaming days for the filter dropdown on mount
  useEffect(() => {
    let mounted = true;
    const tryFetch = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/gamingday`);
        if (!mounted) return;
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setGamingDays(data);
          else if (Array.isArray(data.data)) setGamingDays(data.data);
        } else {
          // fallback to current
          const res2 = await fetch(`${API_BASE_URL}/api/gamingday/current`);
          if (!mounted) return;
          if (res2.ok) {
            const d2 = await res2.json();
            // may be an object
            if (Array.isArray(d2)) setGamingDays(d2);
            else if (d2) setGamingDays([d2]);
          }
        }
      } catch (err) {
        // ignore
      }
    };
    tryFetch();
    return () => { mounted = false; };
  }, []);

  // Fetch cages for add-new form when needed
  useEffect(() => {
    let mounted = true;
    const fetchCages = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/cage`);
        if (!mounted) return;
        if (!res.ok) return setCages([]);
        const data = await res.json();
        if (Array.isArray(data)) setCages(data);
        else setCages([]);
      } catch (e) {
        if (!mounted) return;
        setCages([]);
      }
    };
    fetchCages();
    return () => { mounted = false; };
  }, []);

  // Lock background scroll when a modal is open
  const bodyOverflowRef = useRef<string | null>(null);
  useEffect(() => {
    if (typeof document === 'undefined') return;
    // when either add or edit modal is open, hide body overflow
    if (showAddModal || showEditModal) {
      if (bodyOverflowRef.current === null) bodyOverflowRef.current = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
    } else {
      if (bodyOverflowRef.current !== null) {
        document.body.style.overflow = bodyOverflowRef.current;
        bodyOverflowRef.current = null;
      }
    }

    return () => {
      if (bodyOverflowRef.current !== null) {
        document.body.style.overflow = bodyOverflowRef.current;
        bodyOverflowRef.current = null;
      }
    };
  }, [showAddModal, showEditModal]);

  // reset pagination/columns when resource type changes
  useEffect(() => {
    setPage(1);
    setVisibleColumns(null);
    setTotalCount(null);
  }, [resourceType]);

  // compute pagination values
  // compute pagination values
  // Apply the same client-side filtering here so pagination reflects the active filters
  const visibleColsForCalc = (visibleColumns ?? (tableData[0] ? Object.keys(tableData[0]).map(k => (k === 'user' ? 'user.name' : k)) : []));
  const getValueForCalc = (r: AnyRecord, c: string) => {
    if (c.includes('.')) return c.split('.').reduce((o, k) => (o ? o[k] : undefined), r);
    return r[c];
  };

  const clientFilteredRows = tableData.filter((r) => {
    if (selectedGamingDay) {
      const gd = r.gaming_day ?? r.gamingday ?? r.gaming_day_id ?? r.gaming_day_name ?? r.gamingDay;
      if (gd && String(gd) !== String(selectedGamingDay)) return false;
    }
    // client-side date/time filter fallback
    if (startDate || endDate) {
      const ts = r.timestamp ?? r.transaction_time ?? r.transactionTime ?? r.created_at ?? r.time ?? null;
      if (ts) {
        const recDate = new Date(ts);
        if (!isNaN(recDate.getTime())) {
          if (startDate && recDate < startDate) return false;
          if (endDate && recDate > endDate) return false;
        }
      }
    }
    if (search && search.trim() !== "") {
      const s = search.toLowerCase();
      return visibleColsForCalc.some((col) => {
        const v = getValueForCalc(r, col);
        return v != null && String(v).toLowerCase().includes(s);
      });
    }
    return true;
  });

  const totalEntries = serverPaged ? (totalCount ?? clientFilteredRows.length) : clientFilteredRows.length;
  const totalPages = Math.max(1, Math.ceil((totalEntries || 0) / pageSize));

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
      <div className="flex flex-col gap-2 px-4 py-4 border border-b-0 border-gray-100 dark:border-white/[0.05] rounded-t-xl sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <label htmlFor="page-size" className="sr-only">Rows per page</label>
          <div className="relative z-20 w-20">
            <select
              id="page-size"
              className="w-full py-1.5 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-md appearance-none h-9 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30"
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            >
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="absolute z-30 text-gray-500 -translate-y-1/2 right-2 top-1/2 dark:text-gray-400">
              <svg className="stroke-current" width="14" height="14" viewBox="0 0 16 16" fill="none">
                <path d="M3.8335 5.9165L8.00016 10.0832L12.1668 5.9165" stroke="" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </span>
          </div>

          {/* Compact export icon (keeps same export logic) */}
          <div className="flex items-center">
            <button
              type="button"
              title="Export"
              onClick={() => {
                try {
                  const visibleCols = (visibleColumns ?? (tableData[0] ? Object.keys(tableData[0]).map(k => (k === 'user' ? 'user.name' : k)) : []));
                  const getValue = (r: AnyRecord, c: string) => {
                    if (c.includes('.')) return c.split('.').reduce((o, k) => (o ? o[k] : undefined), r);
                    return r[c];
                  };

                  const filtered = tableData.filter((r) => {
                    if (selectedGamingDay) {
                      const gd = r.gaming_day ?? r.gamingday ?? r.gaming_day_id ?? r.gaming_day_name ?? r.gamingDay;
                      if (gd && String(gd) !== String(selectedGamingDay)) return false;
                    }
                    // Client-side date/time filter fallback (if API didn't filter)
                    if (startDate || endDate) {
                      const ts = r.timestamp ?? r.transaction_time ?? r.transactionTime ?? r.created_at ?? r.time ?? null;
                      if (ts) {
                        const recDate = new Date(ts);
                        if (!isNaN(recDate.getTime())) {
                          if (startDate && recDate < startDate) return false;
                          if (endDate && recDate > endDate) return false;
                        }
                      }
                    }
                    if (search && search.trim() !== "") {
                      const s = search.toLowerCase();
                      return visibleCols.some((col) => {
                        const v = getValue(r, col);
                        return v != null && String(v).toLowerCase().includes(s);
                      });
                    }
                    return true;
                  });

                  const rows = filtered;
                  const escape = (v: any) => {
                    if (v === null || v === undefined) return '';
                    if (typeof v === 'object') return JSON.stringify(v);
                    return String(v);
                  };

                  const csvHeader = visibleCols.join(',');
                  const csvRows = rows.map(r => visibleCols.map(col => {
                    const val = getValue(r, col);
                    const isDateLike = (v: any) => typeof v === 'string' && /\d{4}-\d{2}-\d{2}/.test(v);
                    const out = isDateLike(val) ? new Date(val).toLocaleDateString() : escape(val);
                    const quoted = `"${String(out).replace(/"/g, '""')}"`;
                    return quoted;
                  }).join(',')).join('\n');

                  const csvContent = `${csvHeader}\n${csvRows}`;
                  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  const namePrefix = resourceType ? String(resourceType).toLowerCase() : 'transactions';
                  a.download = `${namePrefix}_export_${new Date().toISOString().slice(0,10)}.csv`;
                  document.body.appendChild(a);
                  a.click();
                  a.remove();
                  URL.revokeObjectURL(url);
                } catch (e) {
                  // eslint-disable-next-line no-console
                  console.error('Export failed', e);
                  // eslint-disable-next-line no-alert
                  alert('Export failed');
                }
              }}
              className="ml-2 p-2 rounded-md bg-gray-100 hover:bg-gray-200 text-gray-700"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="text-current">
                <path d="M12 3v10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M8 7l4-4 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M21 21H3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        </div>
        <div className="flex flex-row gap-3 w-full items-right justify-end">
          <div className="flex items-center gap-2">
            <div className="relative">
              <button
                type="button"
                aria-expanded={showDateRange}
                onClick={() => setShowDateRange(s => !s)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm text-gray-700 hover:bg-gray-50"
              >
                <svg className={`w-4 h-4 transform ${showDateRange ? 'rotate-180' : ''}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.584l3.71-4.354a.75.75 0 111.14.976l-4.25 5a.75.75 0 01-1.14 0l-4.25-5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
                </svg>
                <span className="text-xs font-medium">Date & time</span>
                {(startDate || endDate) ? (
                  <span className="ml-2 text-xs text-gray-500">
                    {startDate ? startDate.toLocaleString() : ''}{startDate && endDate ? ' — ' : ''}{endDate ? endDate.toLocaleString() : ''}
                  </span>
                ) : null}
              </button>
              {showDateRange && (
                <div className="absolute right-0 mt-2 p-3 bg-white border rounded-lg shadow-lg z-50 w-[360px]">
                  <div className="flex items-center gap-2 mb-2">
                    <label className="text-xs text-gray-400">From</label>
                    <div className="w-full">
                      <input
                        type="datetime-local"
                        value={startDate ? formatForInput(startDate) : ""}
                        onChange={(e) => { setStartDate(e.target.value ? new Date(e.target.value) : null); setPage(1); }}
                        className="text-sm px-2 py-1 border rounded w-full"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <label className="text-xs text-gray-400">To</label>
                    <div className="w-full">
                      <input
                        type="datetime-local"
                        value={endDate ? formatForInput(endDate) : ""}
                        onChange={(e) => { setEndDate(e.target.value ? new Date(e.target.value) : null); setPage(1); }}
                        className="text-sm px-2 py-1 border rounded w-full"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <button type="button" onClick={() => { setStartDate(null); setEndDate(null); setShowDateRange(false); setPage(1); }} className="text-sm px-2 py-1 rounded border">Clear</button>
                    <button type="button" onClick={() => setShowDateRange(false)} className="text-sm px-2 py-1 rounded bg-blue-600 text-white">Apply</button>
                  </div>
                </div>
              )}
            </div>
            <select
              value={selectedGamingDay ?? ""}
              onChange={(e) => { setSelectedGamingDay(e.target.value || null); setPage(1); }}
              className="text-sm px-2 py-1 border rounded bg-white"
            >
              <option value="">All Gaming Days</option>
              {gamingDays.map((g: any) => (
                <option key={g.gaming_day_id} value={g.gaming_day_id}>{g.gaming_day_id} {g.start_time ? `(${new Date(g.start_time).toLocaleDateString()})` : ''}</option>
              ))}
            </select>
            <div className="ml-2">
              <AddTransactionButton onAddTransaction={() => setShowAddModal(true)} />
            </div>
            <div className="relative w-60">
              <input
                placeholder="Filter by text..."
                className="dark:bg-dark-900 h-10 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-2 pr-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
                type="text"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-full overflow-auto max-h-[60vh]">
        <div className="min-w-[1102px]">
          <Table>
            {/* Table Header (dynamic) */}
            <TableHeader className="sticky top-0 z-20 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                <TableCell isHeader className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400 bg-white dark:bg-gray-900">Action</TableCell>
                    {(visibleColumns ?? (tableData[0] ? Object.keys(tableData[0]).map(k => (k === 'user' ? 'user.name' : k)) : [])).map((col) => (
                      <TableCell key={col} isHeader className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400 bg-white dark:bg-gray-900">
                        {COLUMN_LABELS[col] ?? humanizeKey(col)}
                      </TableCell>
                    ))}
              </TableRow>
            </TableHeader>

            {/* Table Body */}
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {tableData.length > 0 ? (
                // Apply client-side filtering (search/gaming day). If serverPaged is false we also paginate client-side.
                (() => {
                  const visibleCols = (visibleColumns ?? (tableData[0] ? Object.keys(tableData[0]).map(k => (k === 'user' ? 'user.name' : k)) : []));
                  const getValue = (r: AnyRecord, c: string) => {
                    if (c.includes('.')) return c.split('.').reduce((o, k) => (o ? o[k] : undefined), r);
                    return r[c];
                  };

                  // reuse the clientFilteredRows computed above for consistency
                  const filtered = serverPaged ? clientFilteredRows : clientFilteredRows.slice((page - 1) * pageSize, page * pageSize);
                  const rowsToRender = filtered;

                  return rowsToRender.map((record, rowIndex) => (
                    <TableRow key={rowIndex}>
                        <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              if (onEditTransaction) {
                                onEditTransaction(record);
                                return;
                              }
                              // open built-in edit modal
                              setEditRecord(record);
                              // shallow clone values for editing
                              const clone: Record<string, any> = {};
                              Object.keys(record).forEach((k) => {
                                const v = record[k];
                                // format ISO datetimes to YYYY-MM-DD for date inputs
                                if (typeof v === 'string' && /\d{4}-\d{2}-\d{2}T/.test(v)) {
                                  clone[k] = v.slice(0, 10);
                                } else {
                                  clone[k] = v;
                                }
                              });
                              setFormValues(clone);
                              setShowEditModal(true);
                            }}
                            className="px-2 py-1 rounded bg-blue-600 text-white text-sm hover:bg-blue-700"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="inline-block mr-1">
                              <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 0 0 0-1.42l-2.34-2.34a1.003 1.003 0 0 0-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z" fill="currentColor" />
                            </svg>
                            Edit
                          </button>
                        </TableCell>
                        {visibleCols.map((col) => {
                        // Special handling for player columns: prefer cached playerNames, then record.player
                        if (col === 'player' || col === 'player_id') {
                          const pid = record.player_id ?? record.playerId ?? null;
                          const pname = pid ? (playerNames[String(pid)] ?? (typeof record.player === 'string' ? record.player : (record.player?.name ?? null))) : (typeof record.player === 'string' ? record.player : (record.player?.name ?? null));
                          return (
                            <TableCell key={col} className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
                              {pname ?? '—'}
                            </TableCell>
                          );
                        }

                        const val = getValue(record, col);

                        if (col === 'user.name') {
                          const user = record.user || {};
                          return (
                            <TableCell key={col} className="px-5 py-4 sm:px-6 text-center">
                              <div className="flex flex-col items-center gap-2">
                                {user.image ? (
                                  <div className="w-10 h-10 overflow-hidden rounded-full">
                                    <Image width={40} height={40} src={user.image} alt={user.name || 'user'} />
                                  </div>
                                ) : null}
                                <div>
                                  <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90 text-center">{user.name ?? user.full_name ?? val ?? '—'}</span>
                                </div>
                              </div>
                            </TableCell>
                          );
                        }

                        const isDateLike = (v: any) => typeof v === 'string' && /\d{4}-\d{2}-\d{2}/.test(v);
                        return (
                          <TableCell key={col} className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
                            {isDateLike(val) ? new Date(val).toLocaleDateString() : String(val ?? '—')}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  ));
                })()
              ) : (
                <TableRow>
                  <TableCell colSpan={(visibleColumns ?? []).length || 1} className="text-center py-6 text-gray-400">
                    {loading ? 'Loading...' : error ? error : 'No transactions to display'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
        {/* Edit modal */}
        {showEditModal && editRecord && (
          <Modal onClose={() => setShowEditModal(false)} width="max-w-2xl">
            <div className="p-6">
              <h3 className="text-lg font-semibold mb-4">Edit Transaction</h3>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setSubmitting(true);
                  try {
                    // determine id field
                    const idKeys = ['id', '_id', 'transaction_id', 'id_transaction', 'reference_id', 'referenceId'];
                    const rec = editRecord as AnyRecord;
                    let idField: string | null = null;
                    for (const k of idKeys) if (rec[k] !== undefined) { idField = k; break; }

                    // base endpoint
                    const mapping: Record<string, string> = {
                      CAGE: `${API_BASE_URL}/api/cage-transaction`,
                      TABLE: `${API_BASE_URL}/api/gametransaction`,
                      VAULT: `${API_BASE_URL}/api/vault-transaction`,
                      GAMES: `${API_BASE_URL}/api/gametransaction`,
                    };
                    const key = resourceType ? String(resourceType).toUpperCase() : undefined;
                    const baseEndpoint = apiEndpoint || (key ? mapping[key] ?? `${API_BASE_URL}/api/${String(resourceType).toLowerCase()}/transactions` : null);

                    let updateUrl = baseEndpoint;
                    if (idField && rec[idField] !== undefined) {
                      updateUrl = `${baseEndpoint}/${encodeURIComponent(String(rec[idField]))}`;
                    }

                    // prepare payload: attempt to parse JSON fields if user edited JSON
                    // but exclude read-only and explicitly removed fields
                    const payload: Record<string, any> = {};
                    Object.keys(formValues).forEach(k => {
                      if (READONLY_FIELDS.has(k) || EXCLUDED_FIELDS.has(k)) return;
                      const v = formValues[k];
                      // try parse JSON for object fields (if input is a string and looks like json)
                      if (typeof v === 'string' && v.trim().startsWith('{')) {
                        try { payload[k] = JSON.parse(v); return; } catch { /* ignore */ }
                      }
                      payload[k] = v;
                    });

                    // Ensure we never send the player display/name in the update payload
                    if (payload.player !== undefined) delete payload.player;

                    // send PATCH request
                    const res = await fetch(updateUrl!, {
                      method: 'PATCH',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(payload),
                    });
                    if (!res.ok) {
                      const txt = await res.text().catch(() => '');
                      throw new Error(`Update failed: ${res.status} ${txt}`);
                    }

                    // success: close modal and refresh table
                    setShowEditModal(false);
                    setEditRecord(null);
                    setFormValues({});
                    setReloadToggle(r => !r);
                  } catch (err: any) {
                    // eslint-disable-next-line no-console
                    console.error(err);
                    // eslint-disable-next-line no-alert
                    alert(err?.message ?? 'Update failed');
                  } finally {
                    setSubmitting(false);
                  }
                }}
              >
                <div className="grid grid-cols-1 gap-3 max-h-[60vh] overflow-auto mb-4">
                  {Object.keys(editRecord).map((key) => {
                    // skip fields that must be removed from edit form entirely
                    if (EXCLUDED_FIELDS.has(key)) return null;

                    // If we've already injected the player field after player_id, skip the later 'player' key
                    if (key === 'player' && editRecord['player_id'] !== undefined) return null;

                    const value = formValues[key];
                    // skip functions
                    if (typeof value === 'function') return null;

                      // Special-case: render selects for transaction_type and payment_method
                      if (key === 'transaction_type') {
                        return (
                          <div key={key} className="flex flex-col">
                            <label className="text-sm font-medium mb-1">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                            <select
                              value={value ?? ''}
                              onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value }))}
                              className="border rounded p-2"
                            >
                              <option value="">Select</option>
                              {ALLOWED_TRANSACTION_TYPES.map(t => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                          </div>
                        );
                      }
                      if (key === 'payment_method') {
                        return (
                          <div key={key} className="flex flex-col">
                            <label className="text-sm font-medium mb-1">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                            <select
                              value={value ?? ''}
                              onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value }))}
                              className="border rounded p-2"
                            >
                              <option value="">Select</option>
                              {ALLOWED_PAYMENT_METHODS.map(p => (
                                <option key={p} value={p}>{p}</option>
                              ))}
                            </select>
                          </div>
                        );
                      }

                    // read-only fields (id, cage_id, player) should be shown but not editable
                    if (READONLY_FIELDS.has(key)) {
                      // render nested objects as read-only textarea
                      const renderReadonly = (renderKey: string, renderValue: any) => {
                        if (renderValue && typeof renderValue === 'object') {
                          return (
                            <div key={renderKey} className="flex flex-col">
                              <label className="text-sm font-medium mb-1">{COLUMN_LABELS[renderKey] ?? humanizeKey(renderKey)}</label>
                              <textarea className="border rounded p-2 h-28 bg-gray-100" value={JSON.stringify(renderValue, null, 2)} readOnly />
                            </div>
                          );
                        }

                        return (
                          <div key={renderKey} className="flex flex-col">
                            <label className="text-sm font-medium mb-1">{COLUMN_LABELS[renderKey] ?? humanizeKey(renderKey)}</label>
                            <input type="text" value={String(renderValue ?? '')} readOnly className="border rounded p-2 bg-gray-100" />
                          </div>
                        );
                      };

                      // If this key is player_id and there is a separate player object, render player immediately after
                      if (key === 'player_id' && editRecord['player'] !== undefined) {
                        const playerVal = formValues['player'];
                        return [
                          renderReadonly(key, value),
                          renderReadonly('player', playerVal),
                        ];
                      }

                      return renderReadonly(key, value);
                    }

                    // render nested objects as textarea (editable)
                    if (value && typeof value === 'object') {
                      return (
                        <div key={key} className="flex flex-col">
                          <label className="text-sm font-medium mb-1">{key}</label>
                          <textarea
                            className="border rounded p-2 h-28"
                            value={JSON.stringify(value, null, 2)}
                            onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value }))}
                          />
                        </div>
                      );
                    }

                    // date field (YYYY-MM-DD)
                    if (typeof value === 'string' && /\d{4}-\d{2}-\d{2}/.test(value)) {
                        return (
                          <div key={key} className="flex flex-col">
                            <label className="text-sm font-medium mb-1">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                            <input type="date" value={value ?? ''} onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value }))} className="border rounded p-2" />
                          </div>
                        );
                    }

                    // boolean
                    if (typeof value === 'boolean') {
                      return (
                        <div key={key} className="flex items-center gap-2">
                          <input type="checkbox" checked={Boolean(value)} onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.checked }))} />
                          <label className="text-sm font-medium">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                        </div>
                      );
                    }

                    // number
                    if (typeof value === 'number') {
                      return (
                        <div key={key} className="flex flex-col">
                          <label className="text-sm font-medium mb-1">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                          <input type="number" value={String(value)} onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value === '' ? '' : Number(e.target.value) }))} className="border rounded p-2" />
                        </div>
                      );
                    }

                    // default: text input
                      return (
                      <div key={key} className="flex flex-col">
                        <label className="text-sm font-medium mb-1">{COLUMN_LABELS[key] ?? humanizeKey(key)}</label>
                        <input type="text" value={value ?? ''} onChange={(e) => setFormValues(v => ({ ...v, [key]: e.target.value }))} className="border rounded p-2" />
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setShowEditModal(false)} className="px-4 py-2 rounded border">Cancel</button>
                  <button type="submit" disabled={submitting} className="px-4 py-2 rounded bg-blue-600 text-white">{submitting ? 'Saving...' : 'Save'}</button>
                </div>
              </form>
            </div>
          </Modal>
        )}
          {/* Add New Transaction modal */}
          {showAddModal && (
            <Modal onClose={() => setShowAddModal(false)} width="max-w-2xl">
              <div className="p-6">
                <h3 className="text-lg font-semibold mb-4">Add New Transaction</h3>
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    // basic validation
                    const allowedTransactionTypes = [
                      'HANDPAY','JACKPOT','TICKET_SALE','TICKET_REDEEM','EXPIRED_TICKET','UNREADABLE_TICKET','MONEY_DEBIT','MONEY_CREDIT','FILL','CREDIT','VAULT_MONEY_FILL','VAULT_MONEY_CREDIT','CAGE_OPEN','CHIP_FILL','CHIP_CREDIT','TITO_PURCHASE','TITO_REDEEM','CHIP_PURCHASE','CHIP_REDEEM'
                    ];
                    const allowedPaymentMethods = ['Cash','Chips','UPI','Credit_Debit_Card','TITO','VAULT_TRANSFER','PLAYER_CARD'];

                    // build payload conditionally based on source
                    const payload: Record<string, any> = {};
                    const src = addForm.source ?? (resourceType ? String(resourceType).toUpperCase() : '');
                    // common fields
                    payload.transaction_type = addForm.transaction_type;
                    payload.payment_method = addForm.payment_method;
                    payload.amount = Number(addForm.amount || 0);

                                    // attach source-specific fields
                                    if (src === 'CAGE') {
                                      payload.cage_id = addForm.cage_id;
                                    } else if (src === 'TABLE') {
                                      payload.table_id = addForm.table_id;
                                    } else if (src === 'EXTERNAL') {
                                      if (addForm.destination) payload.destination = addForm.destination;
                                      if (addForm.notes) payload.notes = addForm.notes;
                                    }

                    // performed_by must be included and set to current user id (if available)
                    const _uid = userId ?? null;
                    // convert numeric string ids to number when possible
                    const normalizedUid = (_uid !== null && typeof _uid === 'string' && /^\d+$/.test(_uid)) ? Number(_uid) : _uid;
                    if (!(normalizedUid || normalizedUid === 0)) {
                      // eslint-disable-next-line no-alert
                      alert('You must be logged in to create a transaction. performed_by is required.');
                      return;
                    }
                    payload.performed_by = normalizedUid;
                    payload.verified_by = normalizedUid;

                    // ensure we don't accidentally send a player display/name in create
                    if (payload.player !== undefined) delete payload.player;

                    // validation
                    if (src === 'CAGE' && !payload.cage_id) return alert('Please select a cage');
                    if ((src === 'TABLE') && !payload.table_id) return alert('Please enter a table id');
                    // no VAULT source option: vault-specific validation removed
                    if (!payload.amount || isNaN(payload.amount) || payload.amount <= 0) return alert('Please enter a valid amount');
                    if (!ALLOWED_TRANSACTION_TYPES.includes(String(payload.transaction_type))) return alert('Invalid transaction type');
                    if (!ALLOWED_PAYMENT_METHODS.includes(String(payload.payment_method))) return alert('Invalid payment method');

                    try {
                      const mapping: Record<string, string> = {
                        CAGE: `${API_BASE_URL}/api/cage-transaction`,
                        TABLE: `${API_BASE_URL}/api/gametransaction`,
                        VAULT: `${API_BASE_URL}/api/vault-transaction`,
                        GAMES: `${API_BASE_URL}/api/gametransaction`,
                      };
                      const key = resourceType ? String(resourceType).toUpperCase() : undefined;
                      const baseEndpoint = apiEndpoint || (key ? mapping[key] ?? `${API_BASE_URL}/api/${String(resourceType).toLowerCase()}/transactions` : null);
                      if (!baseEndpoint) throw new Error('No endpoint configured for this resource');

                      const res = await fetch(baseEndpoint!, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload),
                      });
                      if (!res.ok) {
                        const txt = await res.text().catch(() => '');
                        throw new Error(`Create failed: ${res.status} ${txt}`);
                      }
                      // success
                      setShowAddModal(false);
                      setAddForm({ cage_id: '', amount: '', transaction_type: '', payment_method: '' });
                      setReloadToggle(r => !r);
                    } catch (err: any) {
                      // eslint-disable-next-line no-console
                      console.error(err);
                      // eslint-disable-next-line no-alert
                      alert(err?.message ?? 'Failed to create transaction');
                    }
                  }}
                >
                  <div className="grid grid-cols-1 gap-3 max-h-[60vh] overflow-auto mb-4">
                    <div className="flex flex-col">
                      <label className="text-sm font-medium mb-1">Source</label>
                      <select value={addForm.source} onChange={(e) => setAddForm(f => ({ ...f, source: e.target.value }))} className="border rounded p-2">
                        <option value="">Select source</option>
                        {SOURCE_OPTIONS.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    {/* Cage select shown when source is CAGE or when resourceType maps to CAGE */}
                    {(addForm.source === 'CAGE' || (addForm.source === '' && (resourceType ?? '').toString().toUpperCase() === 'CAGE')) && (
                      <div className="flex flex-col">
                        <label className="text-sm font-medium mb-1">Cage</label>
                        <select value={addForm.cage_id} onChange={(e) => setAddForm(f => ({ ...f, cage_id: e.target.value }))} className="border rounded p-2">
                          <option value="">Select cage</option>
                          {cages.map((c) => (
                            <option key={c.cage_id ?? c.id} value={c.cage_id ?? c.id}>{c.name ?? c.cage_id ?? c.id}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Table id input when source is TABLE */}
                    {addForm.source === 'TABLE' && (
                      <div className="flex flex-col">
                        <label className="text-sm font-medium mb-1">Table ID</label>
                        <input type="text" value={addForm.table_id} onChange={(e) => setAddForm(f => ({ ...f, table_id: e.target.value }))} className="border rounded p-2" />
                      </div>
                    )}

                    {/* Vault option removed — no vault-specific fields shown */}
                    <div className="flex flex-col">
                      <label className="text-sm font-medium mb-1">Amount</label>
                      <input type="number" step="0.01" value={addForm.amount} onChange={(e) => setAddForm(f => ({ ...f, amount: e.target.value }))} className="border rounded p-2" />
                    </div>
                    <div className="flex flex-col">
                      <label className="text-sm font-medium mb-1">Transaction Type</label>
                      <select value={addForm.transaction_type} onChange={(e) => setAddForm(f => ({ ...f, transaction_type: e.target.value }))} className="border rounded p-2">
                        <option value="">Select type</option>
                        {['HANDPAY','JACKPOT','TICKET_SALE','TICKET_REDEEM','EXPIRED_TICKET','UNREADABLE_TICKET','MONEY_DEBIT','MONEY_CREDIT','FILL','CREDIT','VAULT_MONEY_FILL','VAULT_MONEY_CREDIT','CAGE_OPEN','CHIP_FILL','CHIP_CREDIT','TITO_PURCHASE','TITO_REDEEM','CHIP_PURCHASE','CHIP_REDEEM'].map(t => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex flex-col">
                      <label className="text-sm font-medium mb-1">Payment Method</label>
                      <select value={addForm.payment_method} onChange={(e) => setAddForm(f => ({ ...f, payment_method: e.target.value }))} className="border rounded p-2">
                        <option value="">Select method</option>
                        {['Cash','Chips','UPI','Credit_Debit_Card','TITO','VAULT_TRANSFER'].map(m => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                    </div>
                    {/* performed_by is set automatically from current session and not shown to the user */}
                  </div>

                  <div className="flex justify-end gap-2">
                    <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 rounded border bg-red-600 hover:bg-red-700 text-white">Cancel</button>
                    <button type="submit" className="px-4 py-2 rounded bg-green-600 hover:bg-green-700 text-white">Create</button>
                  </div>
                </form>
              </div>
            </Modal>
          )}
      <div className="border border-t-0 rounded-b-xl border-gray-100 py-4 pl-[18px] pr-4 dark:border-white/[0.05]">
        <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between">
          <div className="pb-3 xl:pb-0">
            <p className="pb-3 text-sm font-medium text-center text-gray-500 border-b border-gray-100 dark:border-gray-800 dark:text-gray-400 xl:border-b-0 xl:pb-0 xl:text-left">
              Showing {totalEntries === 0 ? 0 : (page - 1) * pageSize + 1} to {Math.min(page * pageSize, totalEntries)} of {totalEntries} entries
            </p>
          </div>
          <div className="flex items-center justify-center gap-4 xl:justify-end">
            <button
              className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              Prev
            </button>
            <ul className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => (
                <li key={i}>
                  <button
                    className={`px-4 py-2 flex w-10 items-center justify-center h-10 rounded-lg text-sm font-medium ${page === i + 1 ? "bg-brand-500 text-white" : "text-gray-700 dark:text-gray-400 hover:bg-blue-500/[0.08] hover:text-brand-500 dark:hover:text-brand-500"}`}
                    onClick={() => setPage(i + 1)}
                  >
                    {i + 1}
                  </button>
                </li>
              ))}
            </ul>
            <button
              className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages || totalPages === 0}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export const AddTransactionButton: React.FC<{ onAddTransaction?: () => void }> = ({ onAddTransaction }) => {
  return (
    <button
      type="button"
      onClick={() => {
        if (onAddTransaction) onAddTransaction();
        else {
          // default action: quick feedback
          // eslint-disable-next-line no-alert
          alert('Add New Transaction clicked');
          // eslint-disable-next-line no-console
          console.debug('Add New Transaction clicked');
        }
      }}
      className="ml-4 flex items-center gap-2 bg-green-700 text-white px-3 py-2 rounded-lg text-sm hover:bg-green-800"
    >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="font-medium">ADD TRANSACTION</span>
    </button>
  );
};
