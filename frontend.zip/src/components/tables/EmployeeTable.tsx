"use client";
import React, { useEffect, useState, useMemo } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import { UserPlus } from "lucide-react";
import Badge from "../ui/badge/Badge";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { API_BASE_URL } from "@/config/api";

interface Employee {
  user_id: number;
  full_name: string;
  address: string;
  date_of_birth: string;
  govt_id_number: string;
  govt_id_type: string;
  photo_url: string | null;
  email: string;
  phone: string;
  role: string;
  status: string;
  created_at: string;
}



const EMPLOYEE_COLUMNS = [
  { key: "user_id", label: "Employee ID" },
  { key: "full_name", label: "Employee Name" },
  { key: "status", label: "Status" },
  { key: "phone", label: "Phone" },
  { key: "email", label: "Email" },
  { key: "role", label: "Role" },
];

function getValueByKey(obj: any, key: string) {
  return key.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
}

export default function EmployeeTable() {
  const [tableData, setTableData] = useState<Employee[]>([]);
  const router = useRouter();
  const [sortBy, setSortBy] = useState<string>("employee_id");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [search, setSearch] = useState<string>("");
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // form state for new employee
  const [fullName, setFullName] = useState<string>("");
  const [address, setAddress] = useState<string>("");
  const [dateOfBirth, setDateOfBirth] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [govtIdType, setGovtIdType] = useState<string>("");
  const [govtIdNumber, setGovtIdNumber] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [role, setRole] = useState<string>("");

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/user/employees`)
      .then((res) => res.json())
      .then((data) => setTableData(data));
  }, []);

  // Filtered and sorted data
  const filteredData = useMemo(() => {
    let data = tableData;
    if (search.trim() !== "") {
      const lower = search.toLowerCase();
      data = data.filter((row) =>
        EMPLOYEE_COLUMNS.some((col) => {
          const value = getValueByKey(row, col.key);
          return value && value.toString().toLowerCase().includes(lower);
        })
      );
    }
    return data.sort((a, b) => {
      const aValue = getValueByKey(a, sortBy);
      const bValue = getValueByKey(b, sortBy);
      if (aValue === undefined || bValue === undefined) return 0;
      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1;
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [tableData, search, sortBy, sortOrder]);

  // Pagination
  const totalEntries = filteredData.length;
  const totalPages = Math.ceil(totalEntries / pageSize);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Handlers
  const handleSort = (key: string) => {
    if (sortBy === key) {
      setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(key);
      setSortOrder("asc");
    }
  };

  const handlePageSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  // validate form fields for enabling/disabling Save button
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const isFormValid =
    fullName.trim() !== "" &&
    emailRegex.test(email.trim()) &&
    phone.replace(/\D/g, "").length === 10 &&
    role !== "";

  return (
    <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
      <div className="flex flex-col gap-2 px-4 py-4 border border-b-0 border-gray-100 dark:border-white/[0.05] rounded-t-xl sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="text-gray-500 dark:text-gray-400"> Show </span>
          <div className="relative z-20 bg-transparent">
            <select
              className="w-full py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-9 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
              value={pageSize}
              onChange={handlePageSizeChange}
            >
              <option value="10" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">10</option>
              <option value="25" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">25</option>
              <option value="50" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">50</option>
              <option value="100" className="text-gray-500 dark:bg-gray-900 dark:text-gray-400">100</option>
            </select>
            <span className="absolute z-30 text-gray-500 -translate-y-1/2 right-2 top-1/2 dark:text-gray-400">
              <svg className="stroke-current" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3.8335 5.9165L8.00016 10.0832L12.1668 5.9165" stroke="" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </span>
          </div>
          <span className="text-gray-500 dark:text-gray-400"> entries </span>
        </div>
        <div className="relative flex items-center gap-3">
          <button className="absolute text-gray-500 -translate-y-1/2 left-4 top-1/2 dark:text-gray-400">
            <svg className="fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" clipRule="evenodd" d="M3.04199 9.37363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z" fill=""></path>
            </svg>
          </button>
          <input
            placeholder="Search Employees"
            className="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-11 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
            type="text"
            value={search}
            onChange={handleSearchChange}
          />
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-green-700 hover:bg-green-800 text-white font-semibold px-5 py-2 rounded flex items-center gap-2 shadow w-70"
          >
            <UserPlus className="w-5 h-5" /> 
            Add Employee
          </button>
        </div>
      </div>
      <div className="max-w-full overflow-x-auto">
        <div className="min-w-[1102px]">
          <Table>
            <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
              <TableRow>
                  {EMPLOYEE_COLUMNS.map((col) => (
                    <TableCell
                      key={col.key}
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-center text-theme-xs dark:text-gray-400 cursor-pointer"
                      onClick={() => handleSort(col.key)}
                    >
                      <div className="flex items-center justify-center w-full relative">
                        <span className={`mx-auto${col.key === 'user_id' || col.key === 'date_of_birth' ? ' mr-6' : ''}`}>{col.label}</span>
                        <button className="flex flex-col gap-0.5 ml-2 absolute right-0 top-1/2 -translate-y-1/2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="8"
                            height="5"
                            fill="none"
                            className={`text-gray-300 dark:text-gray-700 ${sortBy === col.key && sortOrder === "asc" ? "text-brand-500" : ""}`}
                          >
                            <path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
                          </svg>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="8"
                            height="5"
                            fill="none"
                            className={`text-gray-300 dark:text-gray-700 ${sortBy === col.key && sortOrder === "desc" ? "text-brand-500" : ""}`}
                          >
                            <path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
                          </svg>
                        </button>
                      </div>
                    </TableCell>
                  ))}
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
              {paginatedData.map((employee) => (
                <TableRow
                  key={employee.user_id}
                  className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition"
                  onClick={() => router.push(`/employee/${employee.user_id}`)}
                >
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
                    {employee.user_id}
                  </TableCell>
                  <TableCell className="px-5 py-4 sm:px-6 text-start">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 overflow-hidden rounded-full bg-gray-100">
                        {employee.photo_url ? (
                          <Image
                            width={40}
                            height={40}
                            src={employee.photo_url}
                            alt={employee.full_name}
                          />
                        ) : (
                          <span className="flex items-center justify-center w-full h-full text-gray-400 text-xl">
                            {employee.full_name[0]}
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                          {employee.full_name}
                        </span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    <Badge
                      size="sm"
                      color={employee.status === "Active" ? "success" : "error"}
                    >
                      {employee.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {employee.phone}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400 text-center">
                    {employee.email}
                  </TableCell>
                  <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                    {employee.role}
                  </TableCell>
                </TableRow>
              ))}
              {paginatedData.length === 0 && (
                <TableRow>
                  <TableCell colSpan={EMPLOYEE_COLUMNS.length} className="text-center py-6 text-gray-400">
                    No data found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      {/* Add Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-500000 flex items-center justify-center bg-black/40">
          <div className="w-[900px] max-w-[95%] bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-start justify-between">
              <h3 className="text-2xl font-bold">Add New Employee</h3>
              <button className="text-gray-500" onClick={() => setShowAddModal(false)}>✕</button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Full Name <span className="text-red-600">*</span></label>
                <input required value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full px-3 py-2 border rounded" placeholder="Full Name" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Address</label>
                <input value={address} onChange={(e) => setAddress(e.target.value)} className="w-full px-3 py-2 border rounded" placeholder="Address" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email <span className="text-red-600">*</span></label>
                <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded" placeholder="Email" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Phone Number <span className="text-red-600">*</span></label>
                <input
                  type="tel"
                  inputMode="numeric"
                  pattern="\d*"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => {
                    // keep only digits and limit to 10 characters
                    const digits = e.target.value.replace(/\D/g, '').slice(0, 10);
                    setPhone(digits);
                  }}
                  className="w-full px-3 py-2 border rounded"
                  placeholder="Phone Number (10 digits)"
                />
              </div>
              <div className="flex items-center gap-4">
            <div className="w-full">
                <label className="block text-sm font-medium mb-1">Role <span className="text-red-600">*</span></label>
              <select
                required
                className="w-full rounded-lg bg-gray-100 border border-gray-200 px-4 py-2 pr-8 text-[1.05rem] focus:outline-none focus:ring-2 focus:ring-brand-500"
                value={role}
                onChange={e => setRole(e.target.value)}
              >
                <option value="">Select Role</option>
                <optgroup label="Reception">
                  <option value="Reception_Executive">Reception Executive</option>
                  <option value="Reception_Sr_Executive">Reception Senior Executive</option>
                  <option value="Reception_Supervisor">Reception Supervisor</option>
                </optgroup>
                <optgroup label="Cage">
                  <option value="Cage_Executive">Cage Executive</option>
                  <option value="Cage_Supervisor">Cage Supervisor</option>
                  <option value="Cage_Manager">Cage Manager</option>
                </optgroup>
                <optgroup label="Slot Machine">
                  <option value="Slot_Executive">Slot Executive</option>
                  <option value="Slot_Supervisor">Slot Supervisor</option>
                  <option value="Slot_Manager">Slot Manager</option>
                </optgroup>
                <optgroup label="Gaming">
                  <option value="Pit_Supervisor">Pit Supervisor</option>
                  <option value="Inspector">Inspector</option>
                  <option value="Casino_Manager">Casino Manager</option>
                  <option value="Dealer">Dealer</option>
                </optgroup>
                <optgroup label="Technical">
                  <option value="Technical_Executive">Technical Executive</option>
                </optgroup>
                <optgroup label="Administration">
                  <option value="Admin">Admin</option>
                  <option value="Super_Admin">Super Admin</option>
                </optgroup>
              </select>
            </div>
          </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setShowAddModal(false)} className="px-4 py-2 rounded bg-gray-200">Cancel</button>
              <button
                onClick={async () => {
                  // minimal client-side validation
                  if (!fullName) return alert('Please enter full name');
                  // validate email
                  const trimmedEmail = email.trim();
                  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                  if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
                    return alert('Please enter a valid email address');
                  }

                  // validate phone: only digits and must be exactly 10 digits
                  const phoneDigits = (phone || '').replace(/\D/g, '');
                  if (phoneDigits.length !== 10) {
                    return alert('Please enter a valid 10-digit phone number');
                  }

                  // ensure role selected
                  const roleValue = role || (document.getElementById('employee-role') as HTMLInputElement)?.value || '';
                  if (!roleValue) return alert('Please select a role');

                  try {
                    // 1) Create user record (send JSON — backend expects an object, not multipart)
                    const userPayload = {
                      full_name: fullName.trim(),
                      email: trimmedEmail,
                      phone: String(phoneDigits),
                      role: roleValue,
                      status: 'Active',
                      address: address.trim(),
                    } as any;

                    const userRes = await fetch(`${API_BASE_URL}/api/user`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(userPayload),
                    });
                    if (!userRes.ok) {
                      const text = await userRes.text().catch(() => '');
                      throw new Error(`user creation failed: ${userRes.status} ${text}`);
                    }
                    const createdUser = await userRes.json();
                    // robustly extract user id from common response shapes
                    const extractUserId = (obj: any) => {
                      if (!obj) return null;
                      const keys = ['user_id', 'id', 'userId'];
                      for (const k of keys) if (obj[k] !== undefined && obj[k] !== null) return obj[k];
                      if (obj.data) {
                        for (const k of keys) if (obj.data[k] !== undefined && obj.data[k] !== null) return obj.data[k];
                      }
                      if (obj.result) {
                        for (const k of keys) if (obj.result[k] !== undefined && obj.result[k] !== null) return obj.result[k];
                      }
                      // search one level deep
                      for (const v of Object.values(obj)) {
                        if (v && typeof v === 'object') {
                          const vv: any = v;
                          for (const k of keys) if (vv[k] !== undefined && vv[k] !== null) return vv[k];
                        }
                      }
                      return null;
                    };

                    const userId = extractUserId(createdUser);
                    if (!userId) {
                      throw new Error('user creation succeeded but user_id is missing in response');
                    }

                    // 2) Create employee record linked to user_id (send JSON)
                    const empPayload = {
                      user_id: userId,
                      username: "USER" + String(userId).padStart(6, '0'),
                      password_hash: "casino@123", // default password; in real app, should prompt to change
                      role: roleValue,
                      access_level: 0
                    } as any;

                    const empRes = await fetch(`${API_BASE_URL}/api/employee`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(empPayload),
                    });
                    if (!empRes.ok) {
                      const text = await empRes.text().catch(() => '');
                      // Note: we could attempt to rollback the created user here (DELETE), but endpoint/contract unknown.
                      throw new Error(`employee creation failed: ${empRes.status} ${text}`);
                    }
                    const savedEmployee = await empRes.json();

                    // refresh table data by fetching the latest employees from server
                    try {
                      const employeesRes = await fetch(`${API_BASE_URL}/api/user/employees`);
                      if (employeesRes.ok) {
                        const employees = await employeesRes.json();
                        setTableData(employees);
                      } else {
                        // fallback: prepend the saved employee if fetching list failed
                        setTableData((prev) => [savedEmployee, ...prev]);
                      }
                    } catch (err) {
                      // network or parsing error: fallback to prepending
                      setTableData((prev) => [savedEmployee, ...prev]);
                    }

                    setShowAddModal(false);
                    // clear form
                    setFullName(''); setAddress(''); setDateOfBirth(''); setEmail(''); setGovtIdType(''); setGovtIdNumber(''); setPhone(''); setUploadFile(null); setRole('');
                  } catch (err) {
                    console.error(err);
                    alert('Failed to save employee');
                  }
                }}
                className="px-4 py-2 rounded bg-green-600 text-white"
              >
                Save Employee
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="border border-t-0 rounded-b-xl border-gray-100 py-4 pl-[18px] pr-4 dark:border-white/[0.05]">
        <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between">
          <div className="pb-3 xl:pb-0">
            <p className="pb-3 text-sm font-medium text-center text-gray-500 border-b border-gray-100 dark:border-gray-800 dark:text-gray-400 xl:border-b-0 xl:pb-0 xl:text-left">
              Showing {totalEntries === 0 ? 0 : (currentPage - 1) * pageSize + 1} to{" "}
              {Math.min(currentPage * pageSize, totalEntries)} of {totalEntries} entries
            </p>
          </div>
          <div className="flex items-center justify-center gap-4 xl:justify-end">
            <button
              className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd" d="M2.58301 9.99868C2.58272 10.1909 2.65588 10.3833 2.80249 10.53L7.79915 15.5301C8.09194 15.8231 8.56682 15.8233 8.85981 15.5305C9.15281 15.2377 9.15297 14.7629 8.86018 14.4699L5.14009 10.7472L16.6675 10.7472C17.0817 10.7472 17.4175 10.4114 17.4175 9.99715C17.4175 9.58294 17.0817 9.24715 16.6675 9.24715L5.14554 9.24715L8.86017 5.53016C9.15297 5.23717 9.15282 4.7623 8.85983 4.4695C8.56684 4.1767 8.09197 4.17685 7.79917 4.46984L2.84167 9.43049C2.68321 9.568 2.58301 9.77087 2.58301 9.99715C2.58301 9.99766 2.58301 9.99817 2.58301 9.99868Z" fill="currentColor"></path>
              </svg>
            </button>
            <ul className="flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => (
                <li key={i}>
                  <button
                    className={`px-4 py-2 flex w-10 items-center justify-center h-10 rounded-lg text-sm font-medium ${
                      currentPage === i + 1
                        ? "bg-brand-500 text-white"
                        : "text-gray-700 dark:text-gray-400 hover:bg-blue-500/[0.08] hover:text-brand-500 dark:hover:text-brand-500"
                    }`}
                    onClick={() => handlePageChange(i + 1)}
                  >
                    {i + 1}
                  </button>
                </li>
              ))}
            </ul>
            <button
              className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages || totalPages === 0}
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd" d="M17.4175 9.9986C17.4178 10.1909 17.3446 10.3832 17.198 10.53L12.2013 15.5301C11.9085 15.8231 11.4337 15.8233 11.1407 15.5305C10.8477 15.2377 10.8475 14.7629 11.1403 14.4699L14.8604 10.7472L3.33301 10.7472C2.91879 10.7472 2.58301 10.4114 2.58301 9.99715C2.58301 9.58294 2.91879 9.24715 3.33301 9.24715L14.8549 9.24715L11.1403 5.53016C10.8475 5.23717 10.8477 4.7623 11.1407 4.4695C11.4336 4.1767 11.9085 4.17685 12.2013 4.46984L17.1588 9.43049C17.3173 9.568 17.4175 9.77087 17.4175 9.99715C17.4175 9.99763 17.4175 9.99812 17.4175 9.9986Z" fill="currentColor"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
