// Auto-generated roles config for seeding/persistence
export const MODULES = [
  "Dashboard",
  "Reception",
  "Vault",
  "Employees",
  "Players",
  "Cages",
  "Slot Machines",
  "Tables",
  "Casino Configuration",
  "User Management",
  "Notifications",
  "Transactions",
];

export const DEFAULT_ROLES = [
  "Reception_Executive",
  "Reception_Sr_Executive",
  "Reception_Supervisor",
  "Cage_Executive",
  "Cage_Supervisor",
  "Cage_Manager",
  "Slot_Executive",
  "Slot_Supervisor",
  "Slot_Manager",
  "Pit_Supervisor",
  "Dealer",
  "Inspector",
  "Casino_Manager",
  "Admin",
  "Super_Admin",
  "Technical_Executive",
];

export type RoleName = typeof DEFAULT_ROLES[number];

export type PermissionRow = {
  role_name: string;
  module_name: string;
  can_view?: boolean;
  can_create?: boolean;
  can_edit?: boolean;
  can_action?: boolean; // new field replacing can_delete
};

export function buildSeedPayload(overrides?: Partial<Record<string, Partial<PermissionRow>>>) {
  const rows: PermissionRow[] = [];
  for (const role of DEFAULT_ROLES) {
    for (const moduleName of MODULES) {
      const key = `${role}__${moduleName}`;
      const o = overrides && overrides[key] ? overrides[key] : {};
      rows.push({
        role_name: role,
        module_name: moduleName,
        can_view: !!o.can_view,
        can_create: !!o.can_create,
        can_edit: !!o.can_edit,
        can_action: !!o.can_action,
      });
    }
  }
  return { permissions: rows };
}

export default { MODULES, DEFAULT_ROLES, buildSeedPayload };
