"use client";
import React, { useState, useEffect } from "react";

export const DashboardMetrics = () => {
  // State variables for each metric
  const [revenue, setRevenue] = useState(125000);
  const [visits, setVisits] = useState(971);
  const [transactions, setTransactions] = useState(1087);
  const [players, setPlayers] = useState(3782);
  const [totalTransactions, setTotalTransactions] = useState(15359);
  const [highestBidder, setHighestBidder] = useState("Elon Musk");
  const [slotMachineNumber, setSlotMachineNumber] = useState(2); // State for slot machine number
  const [playersPercentageChange, setPlayersPercentageChange] = useState(-1.59); // State for percentage change
  const [transactionPercentageChange, setTransactionPercentageChange] = useState(-1.59);

  // Function to generate random gradual changes
  const generateRandomChange = (value: number, minChange: number, maxChange: number) => {
    const change = Math.random() * (maxChange - minChange) + minChange;
    return Math.random() > 0.5 ? value + change : value - change; // Randomly increase or decrease
  };

  // Function to update the highest bidder (for demo purposes)
  const updateHighestBidder = () => {
    const bidders = ["Elon Musk", "Jeff Bezos", "Bill Gates", "Mark Zuckerberg", "Warren Buffett"];
    return bidders[Math.floor(Math.random() * bidders.length)];
  };

  // Function to update the slot machine number
  const updateSlotMachineNumber = () => {
    return Math.floor(Math.random() * 10) + 1; // Random number between 1 and 10
  };

  // useEffect to simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRevenue((prev) => Math.max(100000, Math.round(generateRandomChange(prev, 500, 2000)))); // Revenue changes between 500-2000
      setVisits((prev) => Math.max(900, Math.round(generateRandomChange(prev, 10, 50)))); // Visits change between 10-50
      setTransactions((prev) => Math.max(1000, Math.round(generateRandomChange(prev, 5, 20)))); // Transactions change between 5-20
      setPlayers((prev) => Math.max(3500, Math.round(generateRandomChange(prev, 10, 30)))); // Players change between 10-30
      setTotalTransactions((prev) => Math.max(15000, Math.round(generateRandomChange(prev, 50, 200)))); // Total transactions change between 50-200
      setHighestBidder(updateHighestBidder()); // Randomly update the highest bidder
      setSlotMachineNumber(updateSlotMachineNumber()); // Randomly update the slot machine number
      setPlayersPercentageChange((prev) => parseFloat(generateRandomChange(prev, 0.1, 2).toFixed(2))); // Percentage change between 0.1% and 2%
      setTransactionPercentageChange((prev) => parseFloat(generateRandomChange(prev, 0.1, 2).toFixed(2))); // Percentage change between 0.1% and 2%
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 md:gap-6">
      {/* Metric Item: Revenue */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Today's Revenue</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              INR {revenue.toLocaleString()}
            </h4>
          </div>
        </div>
      </div>

      {/* Metric Item: Visits */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Today's Players</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {visits.toLocaleString()}
            </h4>
          </div>
        </div>
      </div>

      {/* Metric Item: Transactions */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Today's Transactions</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {transactions.toLocaleString()}
            </h4>
          </div>
        </div>
      </div>

      {/* Metric Item: Players */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Today's Visit</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {players.toLocaleString()}
            </h4>
          </div>
          {/* <div className="flex items-center gap-1">
            <span className="inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-sm bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500">
              <span className="text-xs">
                {playersPercentageChange > 0 ? "+" : ""}
                {playersPercentageChange.toFixed(2)}%
              </span>
            </span>
            <span className="text-gray-500 text-theme-xs dark:text-gray-400">Vs last month</span>
          </div> */}
        </div>
      </div>

      {/* Metric Item: Total Transactions */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Transactions</span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {totalTransactions.toLocaleString()}
            </h4>
          </div>
          {/* <div className="flex items-center gap-1">
            <span className="inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-sm bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500">
              <span className="text-xs">
                {transactionPercentageChange > 0 ? "+" : ""}
                {transactionPercentageChange.toFixed(2)}%
              </span>
            </span>
            <span className="text-gray-500 text-theme-xs dark:text-gray-400">Vs last month</span>
          </div> */}
        </div>
      </div>

      {/* Metric Item: Highest Bidder */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] md:p-6">
        <div className="flex items-end justify-between mt-1">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              Highest Bidder - Slot Machine {slotMachineNumber}
            </span>
            <h4 className="mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90">
              {highestBidder}
            </h4>
          </div>
        </div>
      </div>
    </div>
  );
};
