"use client";
import React, { useEffect, useState, useMemo } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../ui/table";
import Link from "next/link";
import Modal from "../ui/modal/Modal";
import { API_BASE_URL } from "@/config/api";

export type Balance = {
  label: string;
  value: string;
  warning?: boolean;
};

export type CardData = {
  machine_id: number;
  machine_number: string;
  location: string;
  current_player_id: number | null;
  current_balance: string;
  machine_status: string;
  last_updated: string;
  floor_id: number;
};

const SLOT_COLUMNS = [
  // { key: "machine_id", label: "Machine ID" },
  { key: "machine_number", label: "Machine Number" },
  { key: "location", label: "Location" },
  { key: "current_player_id", label: "Current Player" },
  { key: "current_balance", label: "Current Bet" },
  // { key: "machine_status", label: "Status" },
  // { key: "floor_id", label: "Floor" },
];

function getValueByKey(obj: any, key: string) {
  return key.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
}

const statusColorMap: Record<string, string> = {
  DISCOVERABLE: "bg-green-500 text-white",
  PREPARED: "bg-blue-500 text-white",
  TEST: "bg-orange-400 text-white",
  LIVE: "bg-green-600 text-white",
  WAREHOUSE: "bg-purple-500 text-white",
  REMOVED: "bg-red-500 text-white",
  INACTIVE: "bg-red-600 text-white",
  UNDER_MAINTENANCE: "bg-orange-600 text-white",
};

const StatusBadge: React.FC<{ colorCode: string; status: string }> = ({ colorCode, status }) => {
  // Normalize status to uppercase for matching
  const normalized = colorCode.replace(/_/g, " ").trim().toUpperCase();
  const color = statusColorMap[normalized] || "bg-gray-300 text-gray-700";
  return (
    <span className={`px-4 py-1 rounded text-xs font-semibold ${color}`}>
      {status}
    </span>
  );
};

const SlotMachineCards: React.FC<{ apiUrl: string }> = ({ apiUrl }) => {
  const [tableData, setTableData] = useState<CardData[]>([]);
  const [sortBy, setSortBy] = useState<string>("machine_id");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [pageSize, setPageSize] = useState<number>(10);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [search, setSearch] = useState<string>("");

  // Add Slot Machine Modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [floorOptions, setFloorOptions] = useState<{floor_id: number, name: string}[]>([]);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const [location, setLocation] = useState<string>("");

  // Auto-close toast after 3 seconds
  React.useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Fetch floor options from API once on component mount
  React.useEffect(() => {
    fetch(`${API_BASE_URL}/api/floor`)
      .then(res => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setFloorOptions(data);
        } else {
          setFloorOptions([]);
        }
      })
      .catch(() => {
        setFloorOptions([]);
      });
  }, []);

  useEffect(() => {
    let url = apiUrl;
    const urlObj = new URL(url, typeof window !== 'undefined' ? window.location.origin : 'http://localhost');
    if (location) {
      urlObj.searchParams.set('floor_id', location);
    } else {
      urlObj.searchParams.delete('floor_id');
    }
    fetch(urlObj.toString())
      .then(res => res.json())
      .then((data) => {
        setTableData(data);
      });
  }, [apiUrl, location]);

  // Filtered and sorted data
  const filteredData = useMemo(() => {
    let data = tableData;
    if (search.trim() !== "") {
      const lower = search.toLowerCase();
      data = data.filter((row) =>
        SLOT_COLUMNS.some((col) => {
          const value = getValueByKey(row, col.key);
          return value && value.toString().toLowerCase().includes(lower);
        })
      );
    }
    return data.sort((a, b) => {
      let aValue = getValueByKey(a, sortBy);
      let bValue = getValueByKey(b, sortBy);

      // Special handling for numeric sort on current_balance
      if (sortBy === "current_balance") {
        aValue = parseFloat(aValue);
        bValue = parseFloat(bValue);
        if (isNaN(aValue)) aValue = 0;
        if (isNaN(bValue)) bValue = 0;
      }

      if (aValue === undefined || bValue === undefined) return 0;
      if (aValue < bValue) return sortOrder === "asc" ? -1 : 1;
      if (aValue > bValue) return sortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [tableData, search, sortBy, sortOrder]);

  // Pagination
  const totalEntries = filteredData.length;
  const totalPages = Math.ceil(totalEntries / pageSize);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  // Handlers
  const handleSort = (key: string) => {
    if (sortBy === key) {
      setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(key);
      setSortOrder("asc");
    }
  };

  const handlePageSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  const AddSlotMachineModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [machineNumber, setMachineNumber] = useState("");
    const [location, setLocation] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleClose = () => {
      onClose();
    };

    const handleAddSlotMachine = async () => {
      if (!machineNumber || !location) return;
      setIsSubmitting(true);
      try {
        const response = await fetch(`${API_BASE_URL}/api/slotmachine`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            machine_number: machineNumber,
            floor_id: parseInt(location),
            machine_status: 'Inactive',
            current_balance: 0,

          })
        });
        if (response.ok) {
          handleClose();
          setToast({message: 'Slot machine added successfully!', type: 'success'});
          // Refresh slot machine list
          fetch(apiUrl)
            .then(res => res.json())
            .then((data) => {
              setTableData(data);
            });
        } else {
          setToast({message: 'Something went wrong. Please try again.', type: 'error'});
        }
      } catch (error) {
        setToast({message: 'Something went wrong. Please try again.', type: 'error'});
      } finally {
        setIsSubmitting(false);
      }
    };

    return (
      <Modal onClose={handleClose} width="max-w-md">
        <div className="p-8">
          <h2 className="text-xl font-bold mb-4">Add Slot Machine</h2>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">
              Machine Number <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              className="border rounded px-3 py-2 w-full"
              placeholder="Enter Machine Number"
              value={machineNumber}
              onChange={e => setMachineNumber(e.target.value)}
              autoComplete="off"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 mb-2">
              Location <span className="text-red-600">*</span>
            </label>
            <select
              className="border rounded px-3 py-2 w-full"
              value={location}
              onChange={e => setLocation(e.target.value)}
              disabled={floorOptions.length === 0}
            >
              <option value="" disabled>Select Floor</option>
              {floorOptions.length === 0 ? (
                <option value="" disabled>Loading...</option>
              ) : (
                floorOptions.map((floor) => (
                  <option key={floor.floor_id} value={floor.floor_id}>{floor.name}</option>
                ))
              )}
            </select>
          </div>
          <div className="flex justify-end gap-2 mt-8">
            <button
              className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-bold hover:bg-red-600 hover:text-white transition-colors"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              className="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded font-bold disabled:bg-gray-200 disabled:cursor-not-allowed"
              onClick={handleAddSlotMachine}
              disabled={!machineNumber || location === "" || isSubmitting}
            >
              {isSubmitting ? 'Adding...' : 'Add Slot Machine'}
            </button>
          </div>
        </div>
      </Modal>
    );
  };

  return (
    <>
      {toast && (
        <div 
          className={`fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg text-white font-medium ${
            toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
          }`}
          style={{
            animation: 'slideInRight 0.3s ease-out'
          }}
        >
          {toast.message}
        </div>
      )}
      <div className="flex justify-end mb-8">
        <button
          className="flex items-center gap-2 bg-green-700 text-white px-6 py-3 rounded-lg font-bold shadow hover:bg-green-700 transition-colors"
          onClick={() => setShowAddModal(true)}
        >
          ADD SLOT MACHINE
        </button>
      </div>
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]">
        <div className="flex flex-col gap-2 px-4 py-4 border border-b-0 border-gray-100 dark:border-white/[0.05] rounded-t-xl sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="text-gray-500 dark:text-gray-400"> Show </span>
            <div className="relative z-20 bg-transparent w-15">
              <select
                className="w-full py-2 pl-3 pr-8 text-sm text-gray-800 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 h-10 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                value={pageSize}
                onChange={handlePageSizeChange}
              >
                <option value="10">10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </select>
              <span className="absolute z-30 text-gray-500 -translate-y-1/2 right-2 top-1/2 dark:text-gray-400">
                <svg className="stroke-current" width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M3.8335 5.9165L8.00016 10.0832L12.1668 5.9165" stroke="" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"></path>
                </svg>
              </span>
            </div>
            <span className="text-gray-500 dark:text-gray-400"> entries </span>
          </div>
          <div className="flex flex-row gap-3 w-full items-right justify-end">
            <div className="w-30 sm:w-30">
              <div className="relative">
                <select
                  className="w-full py-2 pl-3 pr-8 h-10 text-sm text-gray-500 bg-transparent border border-gray-300 rounded-lg appearance-none dark:bg-dark-900 bg-none shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  disabled={floorOptions.length === 0}
                >
                  <option value="" disabled>Select Floor</option>
                  <option value="">ALL</option>
                  {floorOptions.length === 0 ? (
                    <option value="" disabled>Loading...</option>
                  ) : (
                    floorOptions.map((floor) => (
                      <option key={floor.floor_id} value={floor.floor_id}>{floor.name}</option>
                    ))
                  )}
                </select>
                <span className="pointer-events-none absolute z-30 text-gray-500 -translate-y-1/2 right-2 top-1/2 dark:text-gray-400">
                  <svg className="stroke-current" width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M3.8335 5.9165L8.00016 10.0832L12.1668 5.9165" stroke="" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"></path>
                  </svg>
                </span>
              </div>
            </div>
            <div className="relative w-60">
              <button className="absolute text-gray-500 -translate-y-1/2 left-4 top-1/2 dark:text-gray-400">
                <svg className="fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path fillRule="evenodd" clipRule="evenodd" d="M3.04199 9.37363C3.04199 5.87693 5.87735 3.04199 9.37533 3.04199C12.8733 3.04199 15.7087 5.87693 15.7087 9.37363C15.7087 12.8703 12.8733 15.7053 9.37533 15.7053C5.87735 15.7053 3.04199 12.8703 3.04199 9.37363ZM9.37533 1.54199C5.04926 1.54199 1.54199 5.04817 1.54199 9.37363C1.54199 13.6991 5.04926 17.2053 9.37533 17.2053C11.2676 17.2053 13.0032 16.5344 14.3572 15.4176L17.1773 18.238C17.4702 18.5309 17.945 18.5309 18.2379 18.238C18.5308 17.9451 18.5309 17.4703 18.238 17.1773L15.4182 14.3573C16.5367 13.0033 17.2087 11.2669 17.2087 9.37363C17.2087 5.04817 13.7014 1.54199 9.37533 1.54199Z" fill=""></path>
                </svg>
              </button>
              <input
                placeholder="Search..."
                className="dark:bg-dark-900 h-10 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-11 pr-4 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800 xl:w-[300px]"
                type="text"
                value={search}
                onChange={handleSearchChange}
              />
            </div>
          </div>
        </div>
        <div className="max-w-full overflow-x-auto">
          <div className="min-w-full">
            <Table>
              <TableHeader className="border-b border-gray-100 dark:border-white/[0.05]">
                <TableRow>
                  {SLOT_COLUMNS.map((col) => (
                    <TableCell
                      key={col.key}
                      isHeader
                      className="px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400 cursor-pointer"
                      onClick={() => handleSort(col.key)}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span>{col.label}</span>
                        <button className="flex flex-col gap-0.5 ml-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="8"
                            height="5"
                            fill="none"
                            className={`text-gray-300 dark:text-gray-700 ${sortBy === col.key && sortOrder === "asc" ? "text-brand-500" : ""}`}
                          >
                            <path fill="currentColor" d="M4.41.585a.5.5 0 0 0-.82 0L1.05 4.213A.5.5 0 0 0 1.46 5h5.08a.5.5 0 0 0 .41-.787z"></path>
                          </svg>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="8"
                            height="5"
                            fill="none"
                            className={`text-gray-300 dark:text-gray-700 ${sortBy === col.key && sortOrder === "desc" ? "text-brand-500" : ""}`}
                          >
                            <path fill="currentColor" d="M4.41 4.415a.5.5 0 0 1-.82 0L1.05.787A.5.5 0 0 1 1.46 0h5.08a.5.5 0 0 1 .41.787z"></path>
                          </svg>
                        </button>
                      </div>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHeader>

              <TableBody className="divide-y divide-gray-100 dark:divide-white/[0.05]">
                {paginatedData.map((slot) => (
                  <TableRow key={slot.machine_id}>
                    {/* <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.machine_id}
                    </TableCell> */}
                    <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      <Link
                        href={`/slot-machine?machine_id=${slot.machine_id}`}
                        className="text-brand-500 hover:text-brand-700 transition no-underline"
                      >
                        <StatusBadge colorCode={slot.machine_status.replace("_"," ")} status={slot.machine_number} />
                      </Link>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.location}
                    </TableCell>
                    <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.current_player_id ? `Player ${slot.current_player_id}` : "—"}
                    </TableCell>
                    <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.current_balance}
                    </TableCell>
                    {/* <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      <StatusBadge status={slot.machine_status.replace("_"," ")} />
                    </TableCell> */}
                    {/* <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.last_updated
                        ? new Date(slot.last_updated).toLocaleString()
                        : ""}
                    </TableCell>
                    <TableCell className="px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400">
                      {slot.floor_id}
                    </TableCell> */}
                  </TableRow>
                ))}
                {paginatedData.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={SLOT_COLUMNS.length} className="text-center py-6 text-gray-400">
                      No Slot Machine to Display !
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
        <div className="border border-t-0 rounded-b-xl border-gray-100 py-4 pl-[18px] pr-4 dark:border-white/[0.05]">
          <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between">
            <div className="pb-3 xl:pb-0">
              <p className="pb-3 text-sm font-medium text-center text-gray-500 border-b border-gray-100 dark:border-gray-800 dark:text-gray-400 xl:border-b-0 xl:pb-0 xl:text-left">
                Showing {totalEntries === 0 ? 0 : (currentPage - 1) * pageSize + 1} to{" "}
                {Math.min(currentPage * pageSize, totalEntries)} of {totalEntries} entries
              </p>
            </div>
            <div className="flex items-center justify-center gap-4 xl:justify-end">
              <button
                className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
              >
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" clipRule="evenodd" d="M2.58301 9.99868C2.58272 10.1909 2.65588 10.3833 2.80249 10.53L7.79915 15.5301C8.09194 15.8231 8.56682 15.8233 8.85981 15.5305C9.15281 15.2377 9.15297 14.7629 8.86018 14.4699L5.14009 10.7472L16.6675 10.7472C17.0817 10.7472 17.4175 10.4114 17.4175 9.99715C17.4175 9.58294 17.0817 9.24715 16.6675 9.24715L5.14554 9.24715L8.86017 5.53016C9.15297 5.23717 9.15282 4.7623 8.85983 4.4695C8.56684 4.1767 8.09197 4.17685 7.79917 4.46984L2.84167 9.43049C2.68321 9.568 2.58301 9.77087 2.58301 9.99715C2.58301 9.99766 2.58301 9.99817 2.58301 9.99868Z" fill="currentColor"></path>
                </svg>
              </button>
              <ul className="flex items-center gap-1">
                {Array.from({ length: totalPages }, (_, i) => (
                  <li key={i}>
                    <button
                      className={`px-4 py-2 flex w-10 items-center justify-center h-10 rounded-lg text-sm font-medium ${
                        currentPage === i + 1
                          ? "bg-brand-500 text-white"
                          : "text-gray-700 dark:text-gray-400 hover:bg-blue-500/[0.08] hover:text-brand-500 dark:hover:text-brand-500"
                      }`}
                      onClick={() => handlePageChange(i + 1)}
                    >
                      {i + 1}
                    </button>
                  </li>
                ))}
              </ul>
              <button
                className="flex h-10 items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 sm:p-2.5 text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages || totalPages === 0}
              >
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" clipRule="evenodd" d="M17.4175 9.9986C17.4178 10.1909 17.3446 10.3832 17.198 10.53L12.2013 15.5301C11.9085 15.8231 11.4337 15.8233 11.1407 15.5305C10.8477 15.2377 10.8475 14.7629 11.1403 14.4699L14.8604 10.7472L3.33301 10.7472C2.91879 10.7472 2.58301 10.4114 2.58301 9.99715C2.58301 9.58294 2.91879 9.24715 3.33301 9.24715L14.8549 9.24715L11.1403 5.53016C10.8475 5.23717 10.8477 4.7623 11.1407 4.4695C11.4336 4.1767 11.9085 4.17685 12.2013 4.46984L17.1588 9.43049C17.3173 9.568 17.4175 9.77087 17.4175 9.99715C17.4175 9.99763 17.4175 9.99812 17.4175 9.9986Z" fill="currentColor"></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
      {showAddModal && <AddSlotMachineModal key="add-slot-machine-modal" onClose={() => setShowAddModal(false)} />}
      <style jsx>{`
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
    </>
  );
};

export default SlotMachineCards;
