"use client";
import React from 'react';
import Link from "next/link";
import './CageCards.css';

export type Balance = {
  label: string;
  value: string;
  warning?: boolean;
};

export type CardData = {
  title: string;
  code: string;
  status: 'open' | 'closed';
  gamingDay: string;
  cageType: string;
  lastChange: string;
  changedBy: string;
  balances: Balance[];
  total: string;
};

type StatusBadgeProps = {
  status: 'open' | 'closed';
};

type CardProps = {
  data: CardData;
};

const cardData: CardData[] = [
  {
    title: 'CAGE 01',
    code: 'CG01',
    status: 'closed',
    gamingDay: '26.08.2024',
    cageType: 'Full',
    lastChange: '24.10.2024 16:07:47',
    changedBy: 'Klemen',
    balances: [
      { label: 'MONEY', value: '1,12,500.00' }
    ],
    total: '1,12,500.00'
  },
  {
    title: 'CAGE 02',
    code: 'CG02',
    status: 'closed',
    gamingDay: '27.10.2024',
    cageType: 'Full',
    lastChange: '27.10.2024 16:24:47',
    changedBy: 'Andreja',
    balances: [
      { label: 'TOKEN', value: '2,500.00', warning: true },
      { label: 'MONEY', value: '1,00,000.00' }
    ],
    total: '1,02,500.00'
  },
  {
    title: 'CAGE 03',
    code: 'CG03',
    status: 'open',
    gamingDay: '01.11.2024',
    cageType: 'Full',
    lastChange: '01.11.2024 11:52:48',
    changedBy: 'Klemen',
    balances: [
      { label: 'MONEY', value: '9,05,114.00' }
    ],
    total: '9,05,114.00'
  },
  {
    title: 'CAGE 04',
    code: 'CG04',
    status: 'closed',
    gamingDay: '27.10.2024',
    cageType: 'Full',
    lastChange: '27.10.2024 15:17:27',
    changedBy: 'Demo',
    balances: [
      { label: 'MONEY', value: '30,00,000.00' }
    ],
    total: '30,00,000.00'
  },
  {
    title: 'CAGE 05',
    code: 'CG05',
    status: 'open',
    gamingDay: '30.08.2024',
    cageType: 'Automatic',
    lastChange: '30.08.2024 10:25:01',
    changedBy: 'Super User',
    balances: [
      { label: 'MONEY', value: '12,20,000.00' }
    ],
    total: '12,20,000.00'
  },
  {
    title: 'CAGE 06',
    code: 'CG06',
    status: 'open',
    gamingDay: '30.08.2024',
    cageType: 'Automatic',
    lastChange: '30.08.2024 10:35:01',
    changedBy: 'Super User',
    balances: [
      { label: 'MONEY', value: '11,50,300.00' }
    ],
    total: '11,50,300.00'
  }
];

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => (
  <span className={`status ${status}`}>{status.toUpperCase()}</span>
);

const Card: React.FC<CardProps> = ({ data }) => (
  // <Link href={`/cage/${data.code}`} className="no-underline block">
  <Link href={`/cage/${data.code}`} className="no-underline block">
    <div className="card">
      <div className="card-header">
        <div className="title">{data.title} <span className="code">({data.code})</span></div>
        <StatusBadge status={data.status} />
      </div>
      <div className="details">
        <div><span>Gaming Day</span>{data.gamingDay || '—'}</div>
        <div><span>Cage Type</span>{data.cageType || '—'}</div>
        <div><span>Last Change</span>{data.lastChange || '—'}</div>
        <div><span>Changed By</span>{data.changedBy || '—'}</div>
      </div>
      <div className="balances">
        {data.balances.map((bal, i) => (
          <div key={i} className="balance-row">
            <span>{bal.label}</span>
            <span>&#8377; {bal.warning ? <span className="balance-warning">{bal.value}</span> : bal.value}</span>
          </div>
        ))}
      </div>
      <div className="total">
        <span>Total</span><span>&#8377; {data.total}</span>
      </div>
    </div>
  </Link>
);

const CageCards: React.FC = () => {
  return (
    <div className="card-container">
      {cardData.map((card, i) => <Card key={i} data={card} />)}

    </div>
  );
};

export default CageCards;
