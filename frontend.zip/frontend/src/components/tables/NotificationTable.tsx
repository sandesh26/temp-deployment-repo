"use client";
import React, { useState, useEffect } from "react";

interface Notification {
  id: number;
  type: "success" | "warning" | "error" | "info";
  title: string;
  message: string;
}

// Move messages and MessageType outside the function
const messages = {
  success: [
    "Congratulations! You’ve won a jackpot!",
    "Your withdrawal request has been approved.",
    "Your account has been successfully verified.",
  ],
  warning: [
    "Your session is about to expire. Please save your progress.",
    "You are nearing your daily transaction limit.",
    "Your loyalty points are about to expire.",
  ],
  error: [
    "Transaction failed. Please try again.",
    "Unable to process your request at the moment.",
    "Your account has been temporarily locked due to suspicious activity.",
  ],
  info: [
    "New games have been added to the casino!",
    "Your loyalty points have been updated.",
    "Check out the latest promotions in the rewards section.",
  ],
};

type MessageType = keyof typeof messages;

// Function to generate random notifications
const generateRandomNotification = (id: number): Notification => {
  const types = [
    { type: "success", weight: 40 },
    { type: "info", weight: 40 },
    { type: "warning", weight: 10 },
    { type: "error", weight: 10 },
  ];

  const totalWeight = types.reduce((sum, t) => sum + t.weight, 0);
  const randomWeight = Math.random() * totalWeight;
  let cumulativeWeight = 0;
  let selectedType: MessageType = "info";

  for (const t of types) {
    cumulativeWeight += t.weight;
    if (randomWeight <= cumulativeWeight) {
      selectedType = t.type as MessageType;
      break;
    }
  }

  const randomMessage =
    messages[selectedType][
      Math.floor(Math.random() * messages[selectedType].length)
    ];

  return {
    id,
    type: selectedType,
    title:
      selectedType.charAt(0).toUpperCase() + selectedType.slice(1) + " Message",
    message: randomMessage,
  };
};

export default function NotificationTable() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const initialNotifications = Array.from({ length: 10 }, (_, index) =>
      generateRandomNotification(index + 1)
    );
    setNotifications(initialNotifications);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setNotifications((prev) => [
        generateRandomNotification(prev.length + 1),
        ...prev,
      ]);
    }, 300);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`rounded-xl border p-4 ${
            notification.type === "success"
              ? "border-success-500 bg-success-50 dark:border-success-500/30 dark:bg-success-500/15"
              : notification.type === "warning"
              ? "border-warning-500 bg-warning-50 dark:border-warning-500/30 dark:bg-warning-500/15"
              : notification.type === "error"
              ? "border-error-500 bg-error-50 dark:border-error-500/30 dark:bg-error-500/15"
              : "border-blue-light-500 bg-blue-light-50 dark:border-blue-light-500/30 dark:bg-blue-light-500/15"
          }`}
        >
          <div className="flex items-start gap-3">
            <div>
              <h4 className="mb-1 text-sm font-semibold text-gray-800 dark:text-white/90">
                {notification.title}
              </h4>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {notification.message}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
