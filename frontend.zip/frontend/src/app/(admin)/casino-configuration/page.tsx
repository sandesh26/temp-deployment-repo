"use client";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import CasinoConfiguration from "@/components/common/CasinoConfiguration";
import React from "react";

export default function BasicTables() {
  return (
    <>
      <div>
        <PageBreadcrumb pageTitle="Casino Configuration" />
        <div className="space-y-6">
            <CasinoConfiguration />
        </div>
      </div>
    </>
  );
}
