"use client";

import React from "react";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import { API_BASE_URL } from "@/config/api";
import SlotMachineCards from "@/components/common/SlotMachineCards";
import { useRouter, useSearchParams } from "next/navigation";

export default function SlotMachines() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const machineStatus = searchParams.get("machine_status");

  React.useEffect(() => {
    if (!machineStatus) {
      router.replace("/slot-machines?machine_status=Live");
    }
  }, [machineStatus, router]);

  // If no status, don't render cards (redirect will happen)
  if (!machineStatus) return null;

  return (
    <div>
      <PageBreadcrumb pageTitle="Slot Machines" />
      <div className="space-y-6">
        <SlotMachineCards apiUrl={`${API_BASE_URL}/api/slotmachine?machine_status=${encodeURIComponent(machineStatus)}`} />
      </div>
    </div>
  );
}