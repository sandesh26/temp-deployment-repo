"use client";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import PlayerTable from "@/components/tables/PlayerTable";
import React from "react";

export default function BasicTables() {
  return (
    <>
      <div>
        <PageBreadcrumb pageTitle="Players List" />
        <div className="space-y-6">
            <PlayerTable />
        </div>
      </div>
    </>
  );
}
