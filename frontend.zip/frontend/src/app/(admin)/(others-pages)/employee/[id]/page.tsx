"use client";
import BackButton from "@/components/common/BackButton";
import EmployeeProfile from "@/components/common/EmployeeProfile";
import { Metadata } from "next";
import React from "react";

const metadata: Metadata = {
  title: "Gamexpro Casino Management System",
  description: "This is Next.js Casino Management Dashboard",
};

export default function Profile(props: any) {
  const { id } = React.use(props.params) as { id: string };
  return (
    <>
      <BackButton/>
      <div>
        <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] lg:p-6">
          <div className="space-y-6">
            <EmployeeProfile employeeId={id} />
          </div>
        </div>
      </div>
    </>
  );
}
