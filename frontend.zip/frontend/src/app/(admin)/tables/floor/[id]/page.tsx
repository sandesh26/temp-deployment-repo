"use client";
import React from "react";
import { useParams } from "next/navigation";
import { API_BASE_URL } from "@/config/api";
import TableCards from "@/components/common/TableCards";
import PageBreadcrumb from "@/components/common/PageBreadCrumb";

export default function Cages() {
  const params  = useParams();
  const floorId = params.id;

  return (
    <>
      <PageBreadcrumb pageTitle={`Floor ${floorId} Tables`} />
      <div className="grid grid-cols-12 gap-4 md:gap-6">
        <div className="col-span-12">
          {/* <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">
            Floor {floorId} Tables
          </h1> */}
          <TableCards apiUrl={`${API_BASE_URL}/api/table?floor=${floorId}`} />
        </div>
      </div>
    </>
  );
}