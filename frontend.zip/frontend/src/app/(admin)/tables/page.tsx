import React from "react";
import { API_BASE_URL } from "@/config/api";
import CageCards from "@/components/common/CageCards";

export default function Cages() {
  return (
    <div className="grid grid-cols-12 gap-4 md:gap-6">
      <div className="col-span-12">
        <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">
          Tables
        </h1>
        <CageCards apiUrl={`${API_BASE_URL}/api/table`} />
      </div>
    </div>
  );
}