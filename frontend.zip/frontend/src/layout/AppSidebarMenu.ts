// Extracted menuSections for sidebar search
const menuSections = [
  {
    title: "Operations",
    items: [
      { icon: null, name: "Dashboard", path: "/" },
      { icon: null, name: "Reception", path: "/reception" },
      { icon: null, name: "Chips Management", path: "/chips-management" },
      { icon: null, name: "Vault Management", path: "/vault" },
      { icon: null, name: "Employees", path: "/employee-table" },
      { icon: null, name: "Players", path: "/player-table" },
    ]
  },
  {
    title: "Configuration",
    items: [
      {
        name: "Casino Cages",
        icon: null,
        subItems: [
          { name: "First Floor", icon: null, path: "/cages/floor/1" },
          { name: "Second Floor", icon: null, path: "/cages/floor/2" },
        ],
      },
      { name: "Slot Machines", icon: null, path: "/slot-machines" },
      {
        name: "Casino Tables",
        icon: null,
        subItems: [
          { name: "First Floor", icon: null, path: "/tables/floor/1" },
          { name: "Second Floor", icon: null, path: "/tables/floor/2" },
        ],
      },
      { name: "Casino Configuration", icon: null, path: "/casino-configuration" },
    ]
  },
  {
    title: "Administration",
    items: [
      { name: "User Roles", icon: null, path: "/user-roles" },
      { name: "Notifications", icon: null, path: "/notification-table" },
      { name: "Transactions", icon: null, path: "/transaction-table" },
    ]
  }
];

export default menuSections;
