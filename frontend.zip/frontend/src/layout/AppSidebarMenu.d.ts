declare const menuSections: any[];
export default menuSections;