import OneChip from "./1-chip.svg";
import TenChip from "./10-chip.svg";
import TwentyFiveChip from "./25-chip.svg";
import FiftyChip from "./50-chip.svg";
import HundredChip from "./100-chip.svg";
import TwoHundredChip from "./200-chip.svg";
import FiveHundredChip from "./500-chip.svg";
import OneKChip from "./1000-chip.svg";
import TwoKChip from "./2000-chip.svg";
import TwoPointFiveKChip from "./2500-chip.svg";
import FiveKChip from "./5000-chip.svg";
import TenKChip from "./10000-chip.svg";

export {
    OneChip,
    TenChip,
    TwentyFiveChip,
    FiftyChip,
    HundredChip,
    TwoHundredChip,
    FiveHundredChip,
    OneKChip,
    TwoKChip,
    TwoPointFiveKChip,
    FiveKChip,
    TenKChip
};