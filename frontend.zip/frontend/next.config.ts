import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  webpack(config) {
    config.module.rules.push({
      test: /\.svg$/,
      use: ["@svgr/webpack"],
    });
    return config;
  },
  // Dev-time proxy: rewrite client /api/* requests to the backend to avoid CORS during local development.
  // Uses NEXT_PUBLIC_API_ENVIRONMENT, NEXT_PUBLIC_API_DEV_HOSTNAME, NEXT_PUBLIC_API_PROD_HOSTNAME and NEXT_PUBLIC_API_PORT.
  async rewrites() {
    const env = process.env.NEXT_PUBLIC_API_ENVIRONMENT || 'DEV';
    const devHost = process.env.NEXT_PUBLIC_API_DEV_HOSTNAME || 'localhost';
    const prodHost = process.env.NEXT_PUBLIC_API_PROD_HOSTNAME || '';
    const port = process.env.NEXT_PUBLIC_API_PORT || '';
    const apiBase = env === 'DEV' ? `http://${devHost}${port ? `:${port}` : ''}` : `https://${prodHost}`;
    return [
      {
        source: '/api/:path*',
        destination: `${apiBase}/api/:path*`,
      },
    ];
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  //typedRoutes: false,
};

export default nextConfig;
